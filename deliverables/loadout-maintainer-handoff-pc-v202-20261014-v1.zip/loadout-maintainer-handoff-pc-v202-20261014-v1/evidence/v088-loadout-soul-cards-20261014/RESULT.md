# Soul-core cards

Both soul-core slots have compact individual borders, soft backgrounds and padding. The two-column layout remains. Each disclosure expands independently, with its existing bounded internal scroll. Empty slots retain the same card boundary and selection behavior.

29 focused browser checks passed across zh-CN/en-US/ja-JP at 1366 and 1100px widths, including dark palette, independent expansion, empty slots, selection/dismissal and unchanged draft data. Screenshots were visually inspected. No browser runtime errors. This is a CSS-only change; no EXE build or game/save access.

Preview: http://127.0.0.1:5884/?demo&audit
Screenshots and check results: ui/
Source hash: source-receipt.json
