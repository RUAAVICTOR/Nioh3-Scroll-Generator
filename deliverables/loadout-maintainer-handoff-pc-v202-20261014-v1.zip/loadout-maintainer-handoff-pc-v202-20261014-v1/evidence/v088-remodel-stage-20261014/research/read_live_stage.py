"""Read at most 256 target bytes to validate the confirmed stage chain; no native calls or writes."""
from pathlib import Path
import sys, ctypes, hashlib, json, struct
from ctypes import wintypes
sys.path.insert(0,'C:/Users/RUAA/.codex/worktrees/v088-loadout/仁王3绘卷生成器项目')
from research.dump_r4_finalizer_tables import ProcessReader
from nioh3_scroll_editor.native import find_nioh3_pid,find_module_base
from nioh3_scroll_editor.game_compatibility import _file_version
out=Path('D:/Nioh3_v080_deliverables/deliverables/v088-remodel-stage-20261014/research/live-stage-read.json')
section_root=Path('C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/load-capacity-research/disassembly/live-sections')
text=(section_root/'Nioh3_v2.0.2.0.text.bin').read_bytes()
pid=find_nioh3_pid()
with ProcessReader(pid) as reader:
    exe=reader.executable_path()
    sha=hashlib.sha256(exe.read_bytes()).hexdigest()
    assert sha=='e22c4a635e4ec1e27a177b76e27d7f6a637f426c0ed3928b60f5693bc52ae130'
    assert _file_version(exe)==(2,0,2,0)
    kernel=reader.dll
    kernel.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4
    kernel.GetProcessTimes.restype=wintypes.BOOL
    def birth():
        values=[wintypes.FILETIME() for _ in range(4)]
        if not kernel.GetProcessTimes(reader.handle,*[ctypes.byref(v) for v in values]):raise ctypes.WinError(ctypes.get_last_error())
        return values[0].dwLowDateTime+(values[0].dwHighDateTime<<32)
    creation=birth();base=find_module_base(pid);raw=[]
    for rva,size in ((0x1111850,68),(0x1050092,20),(0x1066C39,20)):
        actual=reader.read(base+rva,size);expected=text[rva-0x1000:rva-0x1000+size]
        assert actual==expected,(hex(rva),actual.hex(),expected.hex())
        raw.append({'rva':hex(rva),'bytes':actual.hex()})
    container=reader.u64(base+0x47514D0);assert container>0x10000
    obj=reader.u64(container+8);assert obj>0x10000
    stage=reader.u8(obj+0x45);assert 1<=stage<=5
    assert reader.u64(base+0x47514D0)==container and reader.u64(container+8)==obj and reader.u8(obj+0x45)==stage
    assert birth()==creation and find_nioh3_pid()==pid and find_module_base(pid)==base
    report={'ok':True,'read_only':True,'game_writes':0,'native_calls':0,'debugger':False,'pid':pid,'creation_filetime':creation,'module_base':hex(base),
      'executable_sha256':sha,'version':[2,0,2,0],'stage':stage,'effective_plus_cap':[5,15,30,45,120][stage-1],'container':hex(container),'object':hex(obj),
      'signatures':raw,'target_bytes_read':68+20+20+8+8+1+8+8+1,'scope':'Single stable stage-chain observation during ordinary play; no stage switch or remodel getter invocation'}
    out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['ok','read_only','game_writes','native_calls','stage','effective_plus_cap','target_bytes_read']}))
