"""Bounded task analysis: relate the remodel cap getter to the serialized difficulty field."""
from pathlib import Path
import sys, json, hashlib, struct
sys.path.insert(0, 'C:/Users/RUAA/.codex/worktrees/v088-loadout/仁王3绘卷生成器项目/research')
from native_xrefs import parse_runtime_functions, containing_runtime_function
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
from capstone.x86 import X86_OP_IMM
root=Path('C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/load-capacity-research/disassembly/live-sections')
out=Path('D:/Nioh3_v080_deliverables/deliverables/v088-remodel-stage-20261014/research')
manifest=json.loads((root/'manifest.json').read_text())
assert manifest['executable']['sha256'].lower()=='e22c4a635e4ec1e27a177b76e27d7f6a637f426c0ed3928b60f5693bc52ae130'
sections={}
for row in manifest['sections']:
    raw=(root/row['filename']).read_bytes()
    assert hashlib.sha256(raw).hexdigest().lower()==row['sha256'].lower()
    sections[row['name']]=(int(row['rva'],0),raw)
base,text=sections['.text'];_,pdata=sections['.pdata']
functions=parse_runtime_functions(pdata);engine=Cs(CS_ARCH_X86,CS_MODE_64);engine.detail=True
report={'executable_sha256':manifest['executable']['sha256'],'read_only':True,'game_writes':0,'decoded_bytes':0,'hash_matches':[]}
for target in (0xA6C2D359,):
    offsets=[];cursor=0
    while True:
        cursor=text.find(struct.pack('<I',target),cursor)
        if cursor<0:break
        offsets.append(cursor);cursor+=4
        assert len(offsets)<=64
    print('HASH',hex(target),'raw matches',len(offsets))
    for offset in offsets:
        fn=containing_runtime_function(functions,offset+base)
        if not fn or fn.end_rva-fn.begin_rva>0x4000:
            print('SKIP',hex(offset+base),'no bounded pdata function');continue
        report['decoded_bytes']+=fn.end_rva-fn.begin_rva
        assert report['decoded_bytes']<=0x20000
        instructions=list(engine.disasm(text[fn.begin_rva-base:fn.end_rva-base],fn.begin_rva))
        hits=[i for i,ins in enumerate(instructions) if any(op.type==X86_OP_IMM and op.imm&0xffffffff==target for op in ins.operands)]
        if not hits:continue
        print('FUNCTION',hex(fn.begin_rva),hex(fn.end_rva))
        for index in hits:
            excerpt=[{'rva':hex(ins.address),'bytes':ins.bytes.hex(),'instruction':ins.mnemonic+' '+ins.op_str} for ins in instructions[max(0,index-14):index+18]]
            report['hash_matches'].append({'hash':hex(target),'function_begin':hex(fn.begin_rva),'function_end':hex(fn.end_rva),'excerpt':excerpt})
            for ins in excerpt:print(ins['rva'],ins['instruction'])
(out/'stage-source-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
