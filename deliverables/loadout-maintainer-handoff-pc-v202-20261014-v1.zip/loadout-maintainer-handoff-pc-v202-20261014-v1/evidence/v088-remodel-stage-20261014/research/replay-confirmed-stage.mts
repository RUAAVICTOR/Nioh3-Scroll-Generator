import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const source='C:/Users/RUAA/.codex/worktrees/v088-loadout/仁王3绘卷生成器项目';
const evidence='C:/Users/RUAA/.codex/worktrees/armor-remodel-batch-pr/仁王3绘卷生成器项目/research/armor_remodel_v202';
const {armorStats}=await import(pathToFileURL(source+'/apps/workshop/loadout-stats.ts').href);
const {armorRequirements}=await import(pathToFileURL(source+'/apps/workshop/loadout-requirements.ts').href);
const raw=await readFile(evidence+'/native-returns.json');const corpus=JSON.parse(raw);
const publicEvidence=JSON.parse(await readFile(evidence+'/public-evidence.json','utf8'));
assert.equal(corpus.executable_sha256.toLowerCase(),'e22c4a635e4ec1e27a177b76e27d7f6a637f426c0ed3928b60f5693bc52ae130');
const counts={weight:0,toughness:0,requirements:0},stages=new Set(),configs=new Set();
for(const event of corpus.events){
 const piece={item_id:event.item_id,rarity:event.rarity,level:event.level,level_before_forge:event.level,plus:event.plus,effects:[],
  armor_remodel:event.mode.split('/').map(Number),native_flags:event.flags,remodel_stage:event.stage};
 let result;if(event.kind==='requirements'){
  const rows=armorRequirements(piece);assert.equal(rows?.known,true);
  result=rows.values.find(value=>value.index===event.stat_index)??{minimum:0,maximum:0};
 }else result=armorStats(piece)[event.kind];
 assert.equal(result.minimum,event.actual,JSON.stringify(event));assert.equal(result.maximum,event.actual,JSON.stringify(event));
 counts[event.kind]++;stages.add(event.stage);configs.add(JSON.stringify([event.item_id,event.mode,event.stage,event.rarity,event.level,event.plus]));
}
assert.equal(Object.values(counts).reduce((a,b)=>a+b,0),1352);
const result={ok:true,counts,total:1352,configurations:configs.size,observedStages:[...stages],nativeReturnsSha256:createHash('sha256').update(raw).digest('hex'),executableSha256:corpus.executable_sha256,
 scope:'Read-only replay of retained native returns; not a new live game stage-switch observation',publicEvidence};
await writeFile('D:/Nioh3_v080_deliverables/deliverables/v088-remodel-stage-20261014/native-replay.json',JSON.stringify(result,null,2));console.log(JSON.stringify({ok:result.ok,counts,total:result.total,configurations:result.configurations,observedStages:result.observedStages}));
