# Planner Life/Ki integration

Current-state Life and Ki now follow the supplied PC v2.02 research.
Implemented base table terms, flat Life/Ki groups, Stamina Life Reflection
and Amrita-gauge Ki Reflection with native float32 and truncation semantics.
Current-style activated sources and armor requirements govern contributions.
Gauge percentage is conditional, optional and persisted; a missing value
shows the empty/full interval. Unrepresented fixed rewards, level sync and
temporary actor/context corrections are excluded from this ordinary estimate.

Validation: 128 TypeScript tests, 24 existing Python reference/evidence tests,
4,968 independent reference vectors, 40 three-locale browser checks,
typecheck and locale audit (1,958 UI messages). No EXE build, game/save writes
or new native/game acceptance. Existing owner drafts and EXE were untouched.

Preview: http://127.0.0.1:10520/?demo&audit

Receipts: tests.log, reference-replay.json, reference-vectors.json, ui/result.json,
and source-receipt.json. Source changes are retained alongside this receipt.
