"""Task-specific offline view using the existing bounded disassembly helpers."""
import hashlib
import json
from pathlib import Path
import struct
import sys
import bisect
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

root=Path('C:/Users/RUAA/.codex/worktrees/v088-loadout/仁王3绘卷生成器项目')
sys.path.insert(0,str(root/'research'))
from native_xrefs import parse_runtime_functions
from disassemble_native_functions import disassemble_functions

raw=Path('C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/load-capacity-research/disassembly/live-sections')
manifest=json.loads((raw/'manifest.json').read_text())
for section in manifest['sections']:
    assert hashlib.sha256((raw/section['filename']).read_bytes()).hexdigest().upper()==section['sha256']
text=(raw/'Nioh3_v2.0.2.0.text.bin').read_bytes()
pdata=(raw/'Nioh3_v2.0.2.0.pdata.bin').read_bytes()
functions=parse_runtime_functions(pdata)
if len(sys.argv)>1 and sys.argv[1]=='--data':
    rva=int(sys.argv[2],0);size=int(sys.argv[3],0)
    assert 0<size<=0x300
    rdata=(raw/'Nioh3_v2.0.2.0.rdata.bin').read_bytes()
    chunk=rdata[rva-0x38E2000:rva-0x38E2000+size]
    print('DATA',hex(rva),chunk.hex(' '))
    print('u32',struct.unpack('<'+'I'*(len(chunk)//4),chunk))
    print('f32',struct.unpack('<'+'f'*(len(chunk)//4),chunk))
    print('u64',struct.unpack('<'+'Q'*(len(chunk)//8),chunk))
elif len(sys.argv)>1 and sys.argv[1]=='--range':
    rva=int(sys.argv[2],0);size=int(sys.argv[3],0)
    assert 0<size<=0x300
    engine=Cs(CS_ARCH_X86,CS_MODE_64)
    for ins in engine.disasm(text[rva-0x1000:rva-0x1000+size],rva):
        print(hex(ins.address),ins.mnemonic,ins.op_str)
elif len(sys.argv)>1 and sys.argv[1]=='--field':
    field=int(sys.argv[2],0)
    starts=[function.begin_rva for function in functions]
    candidates={}
    cursor=0
    while True:
        offset=text.find(struct.pack('<I',field),cursor)
        if offset<0:break
        cursor=offset+4
        index=bisect.bisect_right(starts,offset+0x1000)-1
        if index<0:continue
        function=functions[index]
        if function.begin_rva<=offset+0x1000<function.end_rva and function.end_rva-function.begin_rva<=1600:
            candidates[function.begin_rva]=function
    engine=Cs(CS_ARCH_X86,CS_MODE_64)
    for function in candidates.values():
        instructions=list(engine.disasm(text[function.begin_rva-0x1000:function.end_rva-0x1000],function.begin_rva))
        if not any(f' + {hex(field)}]' in ins.op_str for ins in instructions):continue
        print('FUNCTION',hex(function.begin_rva),hex(function.end_rva))
        for ins in instructions:
            if ins.mnemonic in ('call','cmp','comiss','ret') or f' + {hex(field)}]' in ins.op_str:
                print(hex(ins.address),ins.mnemonic,ins.op_str)
elif len(sys.argv)==1:
    for function in functions:
        if 0x817000<=function.begin_rva<0x818B68:
            print(hex(function.begin_rva),hex(function.end_rva))
else:
    rvas=[int(value,0) for value in sys.argv[1:]]
    report=disassemble_functions(text,pdata,text_rva=0x1000,requested_rvas=rvas,vendor_path=None)
    output=Path('D:/Nioh3_v080_deliverables/deliverables/v088-loadout-names-ranks-20261012/research')
    key='-'.join(f'{rva:X}' for rva in rvas)
    (output/(key+'.json')).write_text(json.dumps(report,indent=2))
    for function in report['functions']:
        print('FUNCTION',function['begin_rva'],function['end_rva'])
        for instruction in function['instructions']:
            print(instruction['rva'],instruction['mnemonic'],instruction['operands'])
