Project Python: D:\Nioh3_v080_deliverables\ce-research-env\Scripts\python.exe
Build root: D:\Nioh3_v080_deliverables
Cargo target: D:\Nioh3_v080_deliverables\build-cache\python-tests
Test temp: D:\Nioh3_v080_deliverables\tmp\pytest-439300-e02ab23f
Lua test library: C:\Program Files\Cheat Engine\lua53-64.dll
FUNCTION 0x22CE2C4 0x22CE404
0x22CE2C4 mov qword ptr [rsp + 0x18], rbx
0x22CE2C9 mov qword ptr [rsp + 0x20], rsi
0x22CE2CE push rbp
0x22CE2CF push rdi
0x22CE2D0 push r12
0x22CE2D2 push r14
0x22CE2D4 push r15
0x22CE2D6 lea rbp, [rsp - 0x1b0]
0x22CE2DE sub rsp, 0x2b0
0x22CE2E5 mov rax, qword ptr [rip + 0x21e9c44]
0x22CE2EC xor rax, rsp
0x22CE2EF mov qword ptr [rbp + 0x1a0], rax
0x22CE2F6 mov rsi, rcx
0x22CE2F9 mov rdi, r8
0x22CE2FC mov rcx, r8
0x22CE2FF mov r14, rdx
0x22CE302 call 0x22ce558
0x22CE307 xor r15d, r15d
0x22CE30A mov qword ptr [rbp - 0x78], r14
0x22CE30E lea r12, [rip + 0x162f423]
0x22CE315 mov qword ptr [rbp - 0x80], r15
0x22CE319 mov rcx, rdi
0x22CE31C mov qword ptr [rsp + 0x70], r15
0x22CE321 mov qword ptr [rsp + 0x60], r12
0x22CE326 mov rbx, rax
0x22CE329 mov qword ptr [rsp + 0x68], rsi
0x22CE32E mov qword ptr [rsp + 0x78], r14
0x22CE333 mov qword ptr [rbp - 0x70], rsi
0x22CE337 call 0x22ce270
0x22CE33C mov qword ptr [rsp + 0x30], rax
0x22CE341 mov ecx, r15d
0x22CE344 movups xmm0, xmmword ptr [rsp + 0x30]
0x22CE349 lea rax, [rsp + 0x40]
0x22CE34E mov qword ptr [rsp + 0x20], rbx
0x22CE353 movups xmm1, xmmword ptr [rsp + 0x20]
0x22CE358 mov qword ptr [rsp + 0x28], rax
0x22CE35D lea rax, [rip + 0x162f394]
0x22CE364 mov qword ptr [rsp + 0x30], rax
0x22CE369 movdqu xmmword ptr [rsp + 0x40], xmm0
0x22CE36F mov qword ptr [rsp + 0x20], 0xcc
0x22CE378 movdqu xmmword ptr [rsp + 0x50], xmm1
0x22CE37E inc rcx
0x22CE381 lea rax, [rax + 2]
0x22CE385 cmp word ptr [rax], r15w
0x22CE389 jne 0x22ce37e
0x22CE38B movaps xmm0, xmmword ptr [rsp + 0x20]
0x22CE390 lea r8, [rsp + 0x20]
0x22CE395 mov qword ptr [rsp + 0x38], rcx
0x22CE39A lea rdx, [rsp + 0x30]
0x22CE39F movaps xmm1, xmmword ptr [rsp + 0x30]
0x22CE3A4 lea rcx, [rsp + 0x60]
0x22CE3A9 movdqa xmmword ptr [rsp + 0x30], xmm1
0x22CE3AF movdqa xmmword ptr [rsp + 0x20], xmm0
0x22CE3B5 call 0x30e2a8
0x22CE3BA lea rcx, [r14 - 1]
0x22CE3BE mov qword ptr [rsp + 0x60], r12
0x22CE3C3 cmp rcx, rax
0x22CE3C6 cmovb rax, rcx
0x22CE3CA lea rcx, [rsp + 0x60]
0x22CE3CF mov word ptr [rsi + rax*2], r15w
0x22CE3D4 call 0x9b8348
0x22CE3D9 mov rcx, qword ptr [rbp + 0x1a0]
0x22CE3E0 xor rcx, rsp
0x22CE3E3 call 0xb912e0
0x22CE3E8 lea r11, [rsp + 0x2b0]
0x22CE3F0 mov rbx, qword ptr [r11 + 0x40]
0x22CE3F4 mov rsi, qword ptr [r11 + 0x48]
0x22CE3F8 mov rsp, r11
0x22CE3FB pop r15
0x22CE3FD pop r14
0x22CE3FF pop r12
0x22CE401 pop rdi
0x22CE402 pop rbp
0x22CE403 ret 
FUNCTION 0x20B15F0 0x20B1790
0x20B15F0 mov qword ptr [rsp + 8], rbx
0x20B15F5 mov qword ptr [rsp + 0x10], rbp
0x20B15FA push rsi
0x20B15FB push rdi
0x20B15FC push r13
0x20B15FE push r14
0x20B1600 push r15
0x20B1602 mov eax, 0x3920
0x20B1607 call 0xb92310
0x20B160C sub rsp, rax
0x20B160F mov rax, qword ptr [rip + 0x240691a]
0x20B1616 xor rax, rsp
0x20B1619 mov qword ptr [rsp + 0x3910], rax
0x20B1621 mov ebx, r9d
0x20B1624 lea rcx, [rsp + 0xc0]
0x20B162C xor r9d, r9d
0x20B162F mov r14, r8
0x20B1632 mov edi, edx
0x20B1634 xor r8d, r8d
0x20B1637 lea edx, [r9 + 0x64]
0x20B163B call 0x5fbca4
0x20B1640 xor r8d, r8d
0x20B1643 lea rcx, [rsp + 0xc0]
0x20B164B mov edx, ebx
0x20B164D call 0x846b3c
0x20B1652 xor edx, edx
0x20B1654 lea rcx, [rsp + 0x30]
0x20B1659 mov r8d, 0x88
0x20B165F call 0xb93f00
0x20B1664 lea rcx, [rsp + 0x30]
0x20B1669 call 0x3fc2e4
0x20B166E mov rdx, rax
0x20B1671 lea rcx, [rsp + 0xc0]
0x20B1679 call 0x376c6c
0x20B167E lea rcx, [rsp + 0x30]
0x20B1683 call 0x3fc518
0x20B1688 mov r13, qword ptr [rip + 0x25087a1]
0x20B168F xor ebp, ebp
0x20B1691 xor r15d, r15d
0x20B1694 lea esi, [rbp + 1]
0x20B1697 mov rbx, qword ptr [r14]
0x20B169A test rbx, rbx
0x20B169D je 0x20b16bd
0x20B169F movzx edx, word ptr [rbx]
0x20B16A2 mov rcx, qword ptr [r13 + 0x68]
0x20B16A6 call 0xf4dbc
0x20B16AB test rax, rax
0x20B16AE je 0x20b16bd
0x20B16B0 mov rdx, rbx
0x20B16B3 mov rcx, rax
0x20B16B6 call 0x818018
0x20B16BB add ebp, eax
0x20B16BD add r15d, esi
0x20B16C0 add r14, 0x10
0x20B16C4 cmp r15d, 5
0x20B16C8 jb 0x20b1697
0x20B16CA lea rbx, [rip + 0x18c772f]
0x20B16D1 mov edx, dword ptr [rbx]
0x20B16D3 lea rcx, [rsp + 0x650]
0x20B16DB call 0xf65d8
0x20B16E0 mov rcx, qword ptr [r13 + 0x68]
0x20B16E4 mov r14, rax
0x20B16E7 movzx edx, word ptr [rax]
0x20B16EA call 0xf4dbc
0x20B16EF test rax, rax
0x20B16F2 je 0x20b1701
0x20B16F4 mov rdx, r14
0x20B16F7 mov rcx, rax
0x20B16FA call 0x818018
0x20B16FF add ebp, eax
0x20B1701 add rbx, 4
0x20B1705 lea rax, [rip + 0x18c76fc]
0x20B170C cmp rbx, rax
0x20B170F jne 0x20b16d1
0x20B1711 mov r8d, dword ptr [rsp + 0x2e1c]
0x20B1719 xor r9d, r9d
0x20B171C mov ecx, dword ptr [rsp + 0xec]
0x20B1723 mov edx, ebp
0x20B1725 mov byte ptr [rsp + 0x20], 0
0x20B172A call 0x81789c
0x20B172F mov ecx, eax
0x20B1731 call 0x28b404
0x20B1736 sub edi, esi
0x20B1738 je 0x20b174d
0x20B173A sub edi, esi
0x20B173C je 0x20b1747
0x20B173E cmp edi, esi
0x20B1740 jne 0x20b1751
0x20B1742 cmp eax, 2
0x20B1745 jmp 0x20b1749
0x20B1747 cmp eax, esi
0x20B1749 ja 0x20b1751
0x20B174B jmp 0x20b1754
0x20B174D test eax, eax
0x20B174F je 0x20b1754
0x20B1751 xor sil, sil
0x20B1754 lea rcx, [rsp + 0xc0]
0x20B175C call 0x6002b4
0x20B1761 mov al, sil
0x20B1764 mov rcx, qword ptr [rsp + 0x3910]
0x20B176C xor rcx, rsp
0x20B176F call 0xb912e0
0x20B1774 lea r11, [rsp + 0x3920]
0x20B177C mov rbx, qword ptr [r11 + 0x30]
0x20B1780 mov rbp, qword ptr [r11 + 0x38]
0x20B1784 mov rsp, r11
0x20B1787 pop r15
0x20B1789 pop r14
0x20B178B pop r13
0x20B178D pop rdi
0x20B178E pop rsi
0x20B178F ret 
