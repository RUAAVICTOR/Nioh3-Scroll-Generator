"""Read reviewed native tables and the static PE label-pointer table offline."""
import hashlib
import json
from pathlib import Path
import struct

root=Path('C:/Users/RUAA/.codex/worktrees/v088-loadout/仁王3绘卷生成器项目')
table=root/'nioh3_scroll_editor/data/r4_finalizer/pc_v2_02/resource_v1/tables/optional_multiplier.bin'
data=table.read_bytes(); count=struct.unpack_from('<I',data,4)[0]
print('TABLE',count,len(data),hashlib.sha256(data).hexdigest())
keys={0xC523,0xA5FD,0x222A,0x6652,0xA241,0xD08B,0x3312,0x5A3B,0x4A39,0x915D,0x40C9,0x67E1}
for index in range(count):
    row=data[8+index*32:8+(index+1)*32]
    values=struct.unpack('<8I',row)
    if index<2 or values[5] in keys:
        print('ROW',index,[hex(value) for value in values], 'i32',struct.unpack_from('<i',row,0x10)[0], 'f32',struct.unpack_from('<f',row,0x18)[0])

exe=Path('D:/SteamLibrary/steamapps/common/Nioh3/Nioh3.exe').read_bytes()
assert hashlib.sha256(exe).hexdigest().upper()=='E22C4A635E4EC1E27A177B76E27D7F6A637F426C0ED3928B60F5693BC52AE130'
pe=struct.unpack_from('<I',exe,0x3C)[0]
sections=pe+24+struct.unpack_from('<H',exe,pe+20)[0]
base=struct.unpack_from('<Q',exe,pe+24+24)[0]
def read(rva,size):
    for index in range(struct.unpack_from('<H',exe,pe+6)[0]):
        offset=sections+index*40
        virtual_size,start,raw_size,raw_offset=struct.unpack_from('<IIII',exe,offset+8)
        if start<=rva and rva+size<=start+raw_size:
            return exe[raw_offset+rva-start:raw_offset+rva-start+size]
    raise ValueError(hex(rva))
print('IMAGE BASE',hex(base))
for rva in [0x44BA040]:
    pointers=struct.unpack('<5Q',read(rva,40))
    print('POINTERS',hex(rva),[hex(value) for value in pointers])
    for pointer in pointers:
        try:print('LABEL',read(pointer-base,128).decode('utf-16-le').split('\0')[0])
        except Exception as error:print('UNRESOLVED',str(error))
