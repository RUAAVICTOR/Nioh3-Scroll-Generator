# PC v2.02 Agility and Toughness rank predicates

Status: native control flow and native parameter/label tables, recovered
offline. No new live-menu boundary observation and no game-memory/save writes.
No live game process or CE debugger was opened in this investigation.

The generic effect-strength scale (C- through AAA+) is separate from these
character-status ranks. The recovered agility formatter has exactly five
labels: AA, A, B, C, D. Toughness has four: AA, A, B, C. AAA, AAA+, A+/A-
are not additional ranks in these formatters.

## Predicates

Input weight and capacity use the same native raw units. For a positive
capacity and supported natural-sized integers:

1. Weight greater than capacity returns D directly; promotion does not fix it.
2. Otherwise, compute `floor(weight * 1000 / capacity)` (tenths of a percent).
3. Without an additional promotion: AA at <=200 if Ultimate Stamina is active;
   A at <=300 when AA was not selected; B at <=700; otherwise C.
4. Red Demon / 如风赤备 (group 0xE63F) counts all five qualifying Red Demon armor
   records via item row +0xB0 bit 0x100. On five qualifying pieces it promotes
   one tier, capped at A without Ultimate Stamina or AA with it. Therefore with
   this promotion and Ultimate Stamina, AA can extend through <=300; without
   Ultimate Stamina A extends through <=700. Overload is still D.

For Toughness: AA at >=320 with Ultimate Stamina; otherwise A at >=260,
B at >=130; otherwise C. Values in [320, infinity) stay A when Ultimate
Stamina is inactive. No generic grade-strength accumulator participates.

Ultimate Stamina is 刚之深奥, effect 0x23E8 -> group 0x4329 -> native flag +0x6D1.
The corresponding allocated attribute threshold is 150 by the owner's prior
confirmation. Character possession/unlock restrictions remain outside planner
scope. Attribute and effect conditions must be resolved before setting the
reference helper's boolean flags.

The usual percentage table is 20/30/70/100%, with the upper endpoint belonging
to the better rank. Internal truncation matters: a ratio of 30.09% still
truncates to 300 and falls in A. The display's rounding is not substituted for
this predicate. Overload uses original integers, so 100.01% remains D.

## Native evidence

- Agility calculation: 0x81789C..0x8179DA and cold chunk
  0x1A1EDC6..0x1A1EDFE; main derived-stat callers at 0x819278 / 0x8192A9.
- Its return map is [100,80,50,20,0], the display mapper at
  0x376B60..0x376C0B maps that state using 85/75/25/0 thresholds.
- Agility label dispatch: 0x22CE270 / 0x22CE284; five pointers at RVA
  0x44BA040 decode to GANKYO_SYUNBIN_AA, SPEED_A, SPEED_B, SPEED_C, SPEED_D.
- Toughness calculation: 0x9CE9CC..0x9CEA31 and AA cold chunk
  0x1A54B26..0x1A54B46. The UI wrapper at 0x22CE914 loads the armor-derived
  integer at +0x218; 0x22CE930 selects the four corresponding glyph labels.
- Requirement keys in `optional_multiplier.bin`, row stride 0x20, key +0x14,
  integer +0x10, multiplier +0x18: 0x40C9=130, 0x915D=260, 0x67E1=320.
- Both style paths have identical percentage parameters:
  0x6652 / 0xC523=20, 0xD08B / 0x222A=30, 0xA241 / 0xA5FD=70.
- Scalar getter 0x608508 multiplies the row integer by its float multiplier.
  These threshold rows all have multiplier 1.0.
- Ultimate Stamina handler writes +0x6D1 at 0x81B880 for group 0x4329.
- Red Demon handler sets the promotion field +0x61C at 0x821825 after its
  five-piece item-flag check. Captured Chinese effect description independently
  names the same five Red Demon armor parts and one-tier promotion.

## Identity and reproduction

Executable SHA256:
`E22C4A635E4EC1E27A177B76E27D7F6A637F426C0ED3928B60F5693BC52AE130`.
File version 2.0.2.0, size 77,830,112 bytes.

Existing loaded-section dump, originally captured 2026-10-05:
`C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/load-capacity-research/disassembly/live-sections/`.
Its text/pdata hashes match the independent October 6 armor dump. The task
reader verifies all three section hashes before each bounded inspection.
Raw sections remain in their original private evidence directory.

- Text SHA256: `4CEC8FB6AD867417A76DF8201C1D4F54172443884910463C1953ACAD91AE6C29`
- Rdata SHA256: `0E701E3455EC1D605CEAA4F493B0898611E0D2914D57ABFB0806C775513DB66F`
- Pdata SHA256: `FFCC9F10BA7DD90F7B1725991E4440DE93B7B3717F3A07D2A56A2C0471E6EC03`
- Parameter resource SHA256: `DF3F3F261B84C416F12DC9433BFC5427069B9E6E1AC9528EB1F4D01A3B8B7EEA`

Run task readers through `tools/run_python_tests.ps1` and the approved research
Python environment. They reuse `research/disassemble_native_functions.py` and
`research/native_xrefs.py`; narrow leaf windows handle functions without pdata.
`read_rank_parameters.py` hashes the actual installed executable before reading
its static label-pointer table. No target process is attached or invoked.

The recovered typed predicates and boundary regressions are at
`apps/workshop/loadout-ranks.ts` and `apps/desktop/tests/loadout-ranks.test.ts`.
They are ready for real total inputs; current planner sample status values are
not fed into them or represented as real calculations. This research does not
resolve the separate weight-capacity growth or armor total-stat input pipeline.
