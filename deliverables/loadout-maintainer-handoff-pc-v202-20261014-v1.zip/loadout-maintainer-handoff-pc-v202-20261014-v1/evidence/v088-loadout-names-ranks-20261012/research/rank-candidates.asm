Project Python: D:\Nioh3_v080_deliverables\ce-research-env\Scripts\python.exe
Build root: D:\Nioh3_v080_deliverables
Cargo target: D:\Nioh3_v080_deliverables\build-cache\python-tests
Test temp: D:\Nioh3_v080_deliverables\tmp\pytest-498468-259bbb50
Lua test library: C:\Program Files\Cheat Engine\lua53-64.dll
FUNCTION 0x8ABAE4 0x8ABCC5
0x8ABAE4 mov rax, rsp
0x8ABAE7 mov qword ptr [rax + 8], rbx
0x8ABAEB mov qword ptr [rax + 0x10], rsi
0x8ABAEF mov qword ptr [rax + 0x18], rdi
0x8ABAF3 push rbp
0x8ABAF4 push r14
0x8ABAF6 push r15
0x8ABAF8 lea rbp, [rax - 0x5f]
0x8ABAFC sub rsp, 0xc0
0x8ABB03 lea r14, [rcx + 0x140]
0x8ABB0A movaps xmmword ptr [rax - 0x28], xmm6
0x8ABB0E mov r15, rdx
0x8ABB11 mov rbx, rcx
0x8ABB14 mov rcx, r14
0x8ABB17 lea rdx, [rbp - 0x39]
0x8ABB1B mov r8d, 0x75
0x8ABB21 call 0x303714
0x8ABB26 cmp byte ptr [rbx + 0x43a], 0
0x8ABB2D je 0x1a2f15a
0x8ABB33 lea rdi, [r15 + 0x1d8]
0x8ABB3A mov rax, qword ptr [rdi + 8]
0x8ABB3E mov rcx, rdi
0x8ABB41 mov r8d, dword ptr [rdi + 0x218]
0x8ABB48 mov dl, byte ptr [rax + 0x188]
0x8ABB4E shr dl, 1
0x8ABB50 and dl, 1
0x8ABB53 call 0x2ff45c
0x8ABB58 mov rcx, rax
0x8ABB5B call 0x8abd50
0x8ABB60 mov rdx, qword ptr [rbp - 0x39]
0x8ABB64 lea r8, [rbp - 0x31]
0x8ABB68 lea rcx, [rbp - 1]
0x8ABB6C movaps xmm6, xmm0
0x8ABB6F call 0x301040
0x8ABB74 and qword ptr [rbp - 0x41], 0
0x8ABB79 lea rsi, [rip - 0x5aa554]
0x8ABB80 mov r15d, 2
0x8ABB86 mov qword ptr [rbp - 0x51], rsi
0x8ABB8A lea r14, [rip + 0x14014bf]
0x8ABB91 mov qword ptr [rbp - 0x59], r15
0x8ABB95 lea rdx, [rbp - 0x59]
0x8ABB99 mov qword ptr [rbp - 0x49], r14
0x8ABB9D lea rcx, [rbp - 1]
0x8ABBA1 call 0x301aac
0x8ABBA6 comiss xmm6, xmm0
0x8ABBA9 movaps xmm2, xmm6
0x8ABBAC ja 0x8abcb3
0x8ABBB2 comiss xmm2, xmm6
0x8ABBB5 jb 0x8abbbe
0x8ABBB7 and dword ptr [rbx + 0x43c], 0
0x8ABBBE mov rdx, qword ptr [rbp - 0x39]
0x8ABBC2 lea r8, [rbp - 0x31]
0x8ABBC6 lea rcx, [rbp - 1]
0x8ABBCA call 0x301040
0x8ABBCF and qword ptr [rbp - 0x41], 0
0x8ABBD4 lea rdx, [rbp - 0x59]
0x8ABBD8 lea rcx, [rbp - 1]
0x8ABBDC mov qword ptr [rbp - 0x59], r15
0x8ABBE0 mov qword ptr [rbp - 0x51], rsi
0x8ABBE4 mov qword ptr [rbp - 0x49], r14
0x8ABBE8 call 0x3030b4
0x8ABBED movss xmm1, dword ptr [rbx + 0x41c]
0x8ABBF5 movss xmm2, dword ptr [rdi + 0x1d4]
0x8ABBFD movss xmm0, dword ptr [rbx + 0x418]
0x8ABC05 subss xmm2, xmm1
0x8ABC09 subss xmm0, xmm1
0x8ABC0D movss xmm1, dword ptr [rip + 0x33285cb]
0x8ABC15 divss xmm2, xmm0
0x8ABC19 comiss xmm2, xmm1
0x8ABC1C ja 0x8abc29
0x8ABC1E xorps xmm1, xmm1
0x8ABC21 comiss xmm1, xmm2
0x8ABC24 ja 0x8abc29
0x8ABC26 movaps xmm1, xmm2
0x8ABC29 mov rdx, qword ptr [rbp - 0x39]
0x8ABC2D lea r8, [rbp - 0x31]
0x8ABC31 lea rcx, [rbp - 1]
0x8ABC35 call 0x301040
0x8ABC3A and qword ptr [rbp - 0x41], 0
0x8ABC3F lea rdx, [rbp - 0x59]
0x8ABC43 movaps xmm2, xmm1
0x8ABC46 mov qword ptr [rbp - 0x59], 6
0x8ABC4E lea rcx, [rbp - 1]
0x8ABC52 mov qword ptr [rbp - 0x51], rsi
0x8ABC56 mov qword ptr [rbp - 0x49], r14
0x8ABC5A call 0x3030b4
0x8ABC5F mov rax, qword ptr [rdi + 8]
0x8ABC63 mov rcx, rdi
0x8ABC66 mov r8d, dword ptr [rdi + 0x218]
0x8ABC6D mov dl, byte ptr [rax + 0x188]
0x8ABC73 shr dl, 1
0x8ABC75 and dl, 1
0x8ABC78 call 0x2ff45c
0x8ABC7D mov ecx, dword ptr [rax]
0x8ABC7F mov dword ptr [rbx + 0x410], ecx
0x8ABC85 mov eax, dword ptr [rdi + 0x1d4]
0x8ABC8B mov dword ptr [rbx + 0x414], eax
0x8ABC91 lea r11, [rsp + 0xc0]
0x8ABC99 mov rbx, qword ptr [r11 + 0x20]
0x8ABC9D mov rsi, qword ptr [r11 + 0x28]
0x8ABCA1 mov rdi, qword ptr [r11 + 0x30]
0x8ABCA5 movaps xmm6, xmmword ptr [r11 - 0x10]
0x8ABCAA mov rsp, r11
0x8ABCAD pop r15
0x8ABCAF pop r14
0x8ABCB1 pop rbp
0x8ABCB2 ret 
0x8ABCB3 cmp dword ptr [rbx + 0x43c], 0
0x8ABCBA je 0x8abbb2
0x8ABCC0 jmp 0x1a2f1b8
FUNCTION 0x8ABCF0 0x8ABD18
0x8ABCF0 sub rsp, 0x28
0x8ABCF4 mov rax, qword ptr [rcx + 8]
0x8ABCF8 mov r8d, dword ptr [rcx + 0x218]
0x8ABCFF mov dl, byte ptr [rax + 0x188]
0x8ABD05 shr dl, 1
0x8ABD07 and dl, 1
0x8ABD0A call 0x2ff45c
0x8ABD0F movss xmm0, dword ptr [rax]
0x8ABD13 add rsp, 0x28
0x8ABD17 ret 
FUNCTION 0x8ABD24 0x8ABD4F
0x8ABD24 sub rsp, 0x28
0x8ABD28 mov rax, qword ptr [rcx + 8]
0x8ABD2C mov r8d, dword ptr [rcx + 0x218]
0x8ABD33 mov dl, byte ptr [rax + 0x188]
0x8ABD39 shr dl, 1
0x8ABD3B and dl, 1
0x8ABD3E call 0x2ff45c
0x8ABD43 mov rcx, rax
0x8ABD46 add rsp, 0x28
0x8ABD4A jmp 0x8abd50
FUNCTION 0x421CE0 0x421E77
0x421CE0 mov qword ptr [rsp + 0x10], rbx
0x421CE5 mov qword ptr [rsp + 0x18], rdi
0x421CEA push rbp
0x421CEB lea rbp, [rsp - 0x57]
0x421CF0 sub rsp, 0xf0
0x421CF7 mov rax, qword ptr [rip + 0x4096232]
0x421CFE xor rax, rsp
0x421D01 mov qword ptr [rbp + 0x47], rax
0x421D05 mov rax, qword ptr [rcx + 0x1b8]
0x421D0C lea rdi, [rcx + 0x130]
0x421D13 mov qword ptr [rbp - 0x79], rax
0x421D17 mov rbx, rcx
0x421D1A mov rax, qword ptr [rcx + 0x1c0]
0x421D21 mov qword ptr [rbp - 0x71], rax
0x421D25 mov rax, qword ptr [rcx + 0x1c8]
0x421D2C mov qword ptr [rbp - 0x69], rax
0x421D30 mov rax, qword ptr [rcx + 0x1d0]
0x421D37 mov qword ptr [rbp - 0x61], rax
0x421D3B mov rax, qword ptr [rcx + 0x1d8]
0x421D42 mov qword ptr [rbp - 0x59], rax
0x421D46 mov rax, qword ptr [rcx + 0x1e0]
0x421D4D mov qword ptr [rbp - 0x51], rax
0x421D51 mov rax, qword ptr [rcx + 0x1e8]
0x421D58 mov qword ptr [rbp - 0x49], rax
0x421D5C mov rax, qword ptr [rcx + 0x1f0]
0x421D63 mov qword ptr [rbp - 0x41], rax
0x421D67 mov rax, qword ptr [rcx + 0x1f8]
0x421D6E mov qword ptr [rbp - 0x39], rax
0x421D72 mov rax, qword ptr [rcx + 0x200]
0x421D79 mov qword ptr [rbp - 0x31], rax
0x421D7D mov rax, qword ptr [rcx + 0x208]
0x421D84 mov qword ptr [rbp - 0x29], rax
0x421D88 mov rax, qword ptr [rcx + 0x210]
0x421D8F mov qword ptr [rbp - 0x21], rax
0x421D93 mov eax, dword ptr [rcx + 0x218]
0x421D99 mov qword ptr [rbp - 0x19], rax
0x421D9D mov eax, dword ptr [rcx + 0x21c]
0x421DA3 mov qword ptr [rbp - 0x11], rax
0x421DA7 mov eax, dword ptr [rcx + 0x220]
0x421DAD mov qword ptr [rbp - 9], rax
0x421DB1 mov eax, dword ptr [rcx + 0x224]
0x421DB7 mov qword ptr [rbp - 1], rax
0x421DBB mov eax, dword ptr [rcx + 0x228]
0x421DC1 mov qword ptr [rbp + 7], rax
0x421DC5 mov eax, dword ptr [rcx + 0x22c]
0x421DCB mov qword ptr [rbp + 0xf], rax
0x421DCF mov eax, dword ptr [rcx + 0x230]
0x421DD5 mov qword ptr [rbp + 0x17], rax
0x421DD9 mov eax, dword ptr [rcx + 0x234]
0x421DDF mov qword ptr [rbp + 0x1f], rax
0x421DE3 mov eax, dword ptr [rcx + 0x238]
0x421DE9 mov qword ptr [rbp + 0x27], rax
0x421DED mov eax, dword ptr [rcx + 0x23c]
0x421DF3 mov qword ptr [rbp + 0x2f], rax
0x421DF7 mov eax, dword ptr [rcx + 0x240]
0x421DFD mov qword ptr [rbp + 0x37], rax
0x421E01 mov eax, dword ptr [rcx + 0x244]
0x421E07 mov rcx, rdi
0x421E0A mov qword ptr [rbp + 0x3f], rax
0x421E0E call 0x3fcb8
0x421E13 xor r8d, r8d
0x421E16 mov ecx, r8d
0x421E19 add rbx, 0x20
0x421E1D lea edx, [r8 + 0xc]
0x421E21 mov rax, qword ptr [rbp + rcx - 0x79]
0x421E26 mov qword ptr [rbx - 0x10], rax
0x421E2A mov qword ptr [rbx - 8], r8
0x421E2E test rax, rax
0x421E31 je 0x421e72
0x421E33 mov rax, qword ptr [rbp + rcx - 0x19]
0x421E38 mov qword ptr [rbx], rax
0x421E3B add rcx, 8
0x421E3F add rbx, 0x18
0x421E43 sub rdx, 1
0x421E47 jne 0x421e21
0x421E49 lea eax, [rdx + 1]
0x421E4C lock cmpxchg dword ptr [rdi], r8d
0x421E51 mov rcx, qword ptr [rbp + 0x47]
0x421E55 xor rcx, rsp
0x421E58 call 0xb912e0
0x421E5D lea r11, [rsp + 0xf0]
0x421E65 mov rbx, qword ptr [r11 + 0x18]
0x421E69 mov rdi, qword ptr [r11 + 0x20]
0x421E6D mov rsp, r11
0x421E70 pop rbp
0x421E71 ret 
0x421E72 mov rax, r8
0x421E75 jmp 0x421e38
FUNCTION 0x3F7E7C 0x3F807B
0x3F7E7C mov qword ptr [rsp + 8], rbx
0x3F7E81 mov qword ptr [rsp + 0x10], rsi
0x3F7E86 push rdi
0x3F7E87 sub rsp, 0x20
0x3F7E8B mov rbx, rdx
0x3F7E8E mov rdi, rcx
0x3F7E91 add rcx, 8
0x3F7E95 xor edx, edx
0x3F7E97 mov r8d, 0x2b0
0x3F7E9D call 0xb93f00
0x3F7EA2 mov qword ptr [rdi + 0x2b8], rbx
0x3F7EA9 lea rax, [rip + 0x35190a0]
0x3F7EB0 xor esi, esi
0x3F7EB2 mov qword ptr [rdi], rax
0x3F7EB5 mov qword ptr [rdi + 0x2c0], rsi
0x3F7EBC lea rbx, [rdi + 0x2f0]
0x3F7EC3 mov word ptr [rdi + 0x2c8], si
0x3F7ECA xor edx, edx
0x3F7ECC mov qword ptr [rdi + 0x2d0], rsi
0x3F7ED3 mov r8d, 0x318
0x3F7ED9 mov qword ptr [rdi + 0x2d8], rsi
0x3F7EE0 mov rcx, rbx
0x3F7EE3 mov qword ptr [rdi + 0x2e0], rsi
0x3F7EEA mov qword ptr [rdi + 0x2e8], rsi
0x3F7EF1 call 0xb93f00
0x3F7EF6 lea r9, [rip + 0x5ba697]
0x3F7EFD mov rcx, rbx
0x3F7F00 lea edx, [rsi + 0x48]
0x3F7F03 lea r8d, [rsi + 0xb]
0x3F7F07 call 0x167d70
0x3F7F0C mov qword ptr [rdi + 0x608], rsi
0x3F7F13 lea rbx, [rdi + 0x6a0]
0x3F7F1A mov qword ptr [rdi + 0x610], rsi
0x3F7F21 lea r8d, [rsi + 0x60]
0x3F7F25 mov rcx, rbx
0x3F7F28 mov qword ptr [rdi + 0x618], rsi
0x3F7F2F xor edx, edx
0x3F7F31 mov qword ptr [rdi + 0x620], rsi
0x3F7F38 mov qword ptr [rdi + 0x628], rsi
0x3F7F3F mov qword ptr [rdi + 0x630], rsi
0x3F7F46 mov qword ptr [rdi + 0x638], rsi
0x3F7F4D mov qword ptr [rdi + 0x640], rsi
0x3F7F54 mov qword ptr [rdi + 0x648], rsi
0x3F7F5B mov qword ptr [rdi + 0x650], rsi
0x3F7F62 mov qword ptr [rdi + 0x658], rsi
0x3F7F69 mov qword ptr [rdi + 0x660], rsi
0x3F7F70 mov qword ptr [rdi + 0x668], rsi
0x3F7F77 mov qword ptr [rdi + 0x670], rsi
0x3F7F7E mov qword ptr [rdi + 0x678], rsi
0x3F7F85 mov qword ptr [rdi + 0x680], rsi
0x3F7F8C mov qword ptr [rdi + 0x688], rsi
0x3F7F93 mov qword ptr [rdi + 0x690], rsi
0x3F7F9A mov qword ptr [rdi + 0x698], rsi
0x3F7FA1 call 0xb93f00
0x3F7FA6 lea r9, [rip + 0x5f98d3]
0x3F7FAD mov rcx, rbx
0x3F7FB0 lea edx, [rsi + 0x18]
0x3F7FB3 lea r8d, [rsi + 4]
0x3F7FB7 call 0x167d70
0x3F7FBC mov word ptr [rdi + 0x700], si
0x3F7FC3 mov byte ptr [rdi + 0x702], sil
0x3F7FCA call 0x1342e0
0x3F7FCF mov edx, dword ptr [rdi + 0x2b8]
0x3F7FD5 mov rcx, rax
0x3F7FD8 call 0x134358
0x3F7FDD test rax, rax
0x3F7FE0 je 0x3f8068
0x3F7FE6 mov r9d, dword ptr [rax + 0x220]
0x3F7FED mov r8d, dword ptr [rax + 0x21c]
0x3F7FF4 mov edx, dword ptr [rax + 0x218]
0x3F7FFA mov ecx, dword ptr [rax + 0x214]
0x3F8000 mov r10d, dword ptr [rax + 0x254]
0x3F8007 mov dword ptr [rdi + 0x5a8], ecx
0x3F800D mov dword ptr [rdi + 0x5ac], edx
0x3F8013 mov dword ptr [rdi + 0x5b0], r8d
0x3F801A mov dword ptr [rdi + 0x5b4], r9d
0x3F8021 mov dword ptr [rdi + 0x5b8], r10d
0x3F8028 mov r9d, dword ptr [rax + 0x25c]
0x3F802F mov r8d, dword ptr [rax + 0x230]
0x3F8036 mov edx, dword ptr [rax + 0x22c]
0x3F803C mov ecx, dword ptr [rax + 0x228]
0x3F8042 mov eax, dword ptr [rax + 0x224]
0x3F8048 mov dword ptr [rdi + 0x5f0], eax
0x3F804E mov dword ptr [rdi + 0x5f4], ecx
0x3F8054 mov dword ptr [rdi + 0x5f8], edx
0x3F805A mov dword ptr [rdi + 0x5fc], r8d
0x3F8061 mov dword ptr [rdi + 0x600], r9d
0x3F8068 mov rbx, qword ptr [rsp + 0x30]
0x3F806D mov rax, rdi
0x3F8070 mov rsi, qword ptr [rsp + 0x38]
0x3F8075 add rsp, 0x20
0x3F8079 pop rdi
0x3F807A ret 
