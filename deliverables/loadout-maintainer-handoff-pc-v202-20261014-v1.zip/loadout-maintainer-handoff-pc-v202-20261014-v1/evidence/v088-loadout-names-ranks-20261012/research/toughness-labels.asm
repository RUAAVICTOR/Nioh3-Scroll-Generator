Project Python: D:\Nioh3_v080_deliverables\ce-research-env\Scripts\python.exe
Build root: D:\Nioh3_v080_deliverables
Cargo target: D:\Nioh3_v080_deliverables\build-cache\python-tests
Test temp: D:\Nioh3_v080_deliverables\tmp\pytest-547384-422765ed
Lua test library: C:\Program Files\Cheat Engine\lua53-64.dll
0x22ce930 xor edx, edx
0x22ce932 test ecx, ecx
0x22ce934 je 0x22ce960
0x22ce936 sub ecx, 1
0x22ce939 je 0x22ce957
0x22ce93b sub ecx, 1
0x22ce93e je 0x22ce94e
0x22ce940 cmp ecx, 1
0x22ce943 jne 0x22ce967
0x22ce945 lea rdx, [rip + 0x17e2d54]
0x22ce94c jmp 0x22ce967
0x22ce94e lea rdx, [rip + 0x17e2d2b]
0x22ce955 jmp 0x22ce967
0x22ce957 lea rdx, [rip + 0x17e2dd2]
0x22ce95e jmp 0x22ce967
0x22ce960 lea rdx, [rip + 0x17e2d99]
0x22ce967 mov rax, rdx
0x22ce96a ret 
0x22ce96b int3 
0x22ce96c sub rsp, 0x28
0x22ce970 mov edx, dword ptr [rcx + 0x218]
0x22ce976 call 0x9ce9cc
0x22ce97b mov ecx, eax
0x22ce97d add rsp, 0x28
0x22ce981 jmp 0x22ce988
0x22ce986 int3 
0x22ce987 int3 
0x22ce988 cmp ecx, 4
0x22ce98b jb 0x22ce990
0x22ce98d xor eax, eax
0x22ce98f ret 
0x22ce990 mov eax, ecx
0x22ce992 lea rcx, [rip + 0x190e927]
0x22ce999 mov rax, qword ptr [rcx + rax*8]
0x22ce99d ret 
0x22ce99e int3 
0x22ce99f int3 
0x22ce9a0 movzx eax, byte ptr [rcx + 0xb1]
0x22ce9a7 ret 
0x22ce9a8 mov eax, dword ptr [rcx + 0x44]
0x22ce9ab ret 
