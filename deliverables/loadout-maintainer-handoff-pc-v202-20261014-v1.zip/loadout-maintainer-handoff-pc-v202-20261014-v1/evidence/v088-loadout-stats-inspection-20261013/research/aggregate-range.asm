Project Python: D:\Nioh3_v080_deliverables\ce-research-env\Scripts\python.exe
Build root: D:\Nioh3_v080_deliverables
Cargo target: D:\Nioh3_v080_deliverables\build-cache\python-tests
Test temp: D:\Nioh3_v080_deliverables\tmp\pytest-541432-7157e8f4
Lua test library: C:\Program Files\Cheat Engine\lua53-64.dll
0x817d00 and al, 0x6c
0x817d03 movzx ebx, ax
0x817d06 call 0x817d50
0x817d0b movzx ecx, ax
0x817d0e movzx eax, bx
0x817d11 add ecx, eax
0x817d13 mov eax, 0x10624dd3
0x817d18 imul ecx, r12d
0x817d1c mul ecx
0x817d1e mov ebx, edx
0x817d20 shr ebx, 6
0x817d23 add ebx, ebp
0x817d25 test r14b, r14b
0x817d28 je 0x817d39
0x817d2a mov edx, 0x8459
0x817d2f mov rcx, r15
0x817d32 call 0x5575e4
0x817d37 add ebx, eax
0x817d39 mov eax, ebx
0x817d3b mov rbx, qword ptr [rsp + 0x60]
0x817d40 add rsp, 0x20
0x817d44 pop r15
0x817d46 pop r14
0x817d48 pop r13
0x817d4a pop r12
0x817d4c pop rdi
0x817d4d pop rsi
0x817d4e pop rbp
0x817d4f ret 
0x817d50 push rbx
0x817d52 sub rsp, 0x20
0x817d56 mov ebx, ecx
0x817d58 mov edx, 0xaeac
0x817d5d mov rcx, qword ptr [rip + 0x3da20cc]
0x817d64 mov rcx, qword ptr [rcx + 0x230]
0x817d6b call 0x608508
0x817d70 call 0x1111850
0x817d75 movd xmm1, eax
0x817d79 cvtdq2ps xmm1, xmm1
0x817d7c addss xmm1, xmm0
0x817d80 cvttss2si rax, xmm1
0x817d85 cmp eax, ebx
0x817d87 cmovb ebx, eax
0x817d8a mov edx, ebx
0x817d8c add rsp, 0x20
0x817d90 pop rbx
0x817d91 jmp 0xd21240
0x817d96 int3 
0x817d97 int3 
0x817d98 mov edx, 0xbe
0x817d9d cmp ecx, edx
0x817d9f cmovbe edx, ecx
0x817da2 jmp 0xd21030
0x817da7 int3 
0x817da8 mov qword ptr [rsp + 8], rbx
0x817dad mov qword ptr [rsp + 0x10], rbp
0x817db2 mov qword ptr [rsp + 0x18], rsi
0x817db7 push rdi
0x817db8 push r14
0x817dba push r15
0x817dbc sub rsp, 0x20
0x817dc0 mov r14, rdx
0x817dc3 mov esi, r9d
0x817dc6 mov dl, byte ptr [rdx + 0x30]
0x817dc9 mov rbp, rcx
0x817dcc call 0x8180ac
0x817dd1 xor edi, edi
0x817dd3 mov ebx, dword ptr [rax + 0xdc]
0x817dd9 test esi, esi
0x817ddb jne 0x817de2
0x817ddd add ebx, dword ptr [rax + 0x28]
0x817de0 jmp 0x817dea
0x817de2 cmp esi, 2
0x817de5 jne 0x817dea
0x817de7 add ebx, dword ptr [rax + 0x40]
0x817dea test dword ptr [r14 + 0x18], 0x40000
0x817df2 je 0x817e82
0x817df8 movzx edx, word ptr [rbp + 0x160]
0x817dff mov r15d, ebx
0x817e02 movzx esi, word ptr [rbp + 0x152]
0x817e09 mov rbp, qword ptr [rip + 0x3da2020]
0x817e10 mov rcx, qword ptr [rbp + 0x68]
0x817e14 call 0xf4dbc
0x817e19 test rax, rax
0x817e1c je 0x817e2c
0x817e1e mov r15d, dword ptr [rax + 0xdc]
0x817e25 movzx esi, word ptr [rax + 0x152]
0x817e2c mov rcx, qword ptr [rbp + 0x970]
0x817e33 movzx edx, si
0x817e36 call 0x1bb4578
0x817e3b mov r8, rax
0x817e3e test rax, rax
0x817e41 je 0x817e82
0x817e43 mov rcx, r14
0x817e46 call 0x2fa524
0x817e4b movss xmm0, dword ptr [r8 + 8]
0x817e51 mulss xmm0, dword ptr [rip + 0x33bca37]
0x817e59 movzx edx, ax
0x817e5c movd xmm1, edx
0x817e60 cvtdq2ps xmm1, xmm1
0x817e63 mulss xmm1, xmm0
0x817e67 movd xmm0, r15d
0x817e6c cvtdq2ps xmm0, xmm0
0x817e6f addss xmm1, dword ptr [r8 + 0x14]
0x817e75 mulss xmm1, xmm0
0x817e79 cvttss2si ecx, xmm1
0x817e7d cmp ecx, ebx
0x817e7f cmovl ebx, ecx
0x817e82 mov rbp, qword ptr [rsp + 0x48]
0x817e87 test ebx, ebx
0x817e89 mov rsi, qword ptr [rsp + 0x50]
0x817e8e cmovns edi, ebx
0x817e91 mov rbx, qword ptr [rsp + 0x40]
0x817e96 mov eax, edi
0x817e98 add rsp, 0x20
0x817e9c pop r15
0x817e9e pop r14
0x817ea0 pop rdi
0x817ea1 ret 
0x817ea2 int3 
0x817ea3 int3 
0x817ea4 mov qword ptr [rsp + 8], rbx
0x817ea9 mov qword ptr [rsp + 0x10], rbp
0x817eae mov qword ptr [rsp + 0x18], rsi
0x817eb3 push rdi
0x817eb4 push r14
0x817eb6 push r15
0x817eb8 sub rsp, 0x20
0x817ebc mov r14, rdx
0x817ebf mov esi, r9d
0x817ec2 mov dl, byte ptr [rdx + 0x30]
0x817ec5 mov rbp, rcx
0x817ec8 call 0x8180ac
0x817ecd xor edi, edi
0x817ecf mov ebx, dword ptr [rax + 0xe0]
0x817ed5 test esi, esi
0x817ed7 jne 0x817ede
0x817ed9 add ebx, dword ptr [rax + 0x2c]
0x817edc jmp 0x817ee6
0x817ede cmp esi, 2
0x817ee1 jne 0x817ee6
0x817ee3 add ebx, dword ptr [rax + 0x44]
0x817ee6 test dword ptr [r14 + 0x18], 0x40000
0x817eee je 0x817f7e
0x817ef4 movzx edx, word ptr [rbp + 0x160]
0x817efb mov r15d, ebx
0x817efe movzx esi, word ptr [rbp + 0x152]
0x817f05 mov rbp, qword ptr [rip + 0x3da1f24]
0x817f0c mov rcx, qword ptr [rbp + 0x68]
0x817f10 call 0xf4dbc
0x817f15 test rax, rax
0x817f18 je 0x817f28
0x817f1a mov r15d, dword ptr [rax + 0xe0]
0x817f21 movzx esi, word ptr [rax + 0x152]
0x817f28 mov rcx, qword ptr [rbp + 0x970]
0x817f2f movzx edx, si
0x817f32 call 0x1bb4578
0x817f37 mov r8, rax
0x817f3a test rax, rax
0x817f3d je 0x817f7e
0x817f3f mov rcx, r14
0x817f42 call 0x2fa524
0x817f47 movss xmm0, dword ptr [r8 + 0xc]
0x817f4d mulss xmm0, dword ptr [rip + 0x33bc93b]
0x817f55 movzx edx, ax
0x817f58 movd xmm1, edx
0x817f5c cvtdq2ps xmm1, xmm1
0x817f5f mulss xmm1, xmm0
0x817f63 movd xmm0, r15d
0x817f68 cvtdq2ps xmm0, xmm0
0x817f6b addss xmm1, dword ptr [r8 + 0x18]
0x817f71 mulss xmm1, xmm0
0x817f75 cvttss2si ecx, xmm1
0x817f79 cmp ecx, ebx
0x817f7b cmovl ebx, ecx
0x817f7e mov rbp, qword ptr [rsp + 0x48]
0x817f83 test ebx, ebx
0x817f85 mov rsi, qword ptr [rsp + 0x50]
0x817f8a cmovns edi, ebx
0x817f8d mov rbx, qword ptr [rsp + 0x40]
0x817f92 mov eax, edi
0x817f94 add rsp, 0x20
0x817f98 pop r15
0x817f9a pop r14
0x817f9c pop rdi
0x817f9d ret 
0x817f9e int3 
0x817f9f int3 
0x817fa0 mov qword ptr [rsp + 8], rbx
0x817fa5 push rdi
0x817fa6 sub rsp, 0x30
0x817faa mov rdi, rdx
0x817fad mov bl, r8b
0x817fb0 mov dl, byte ptr [rdx + 0x30]
0x817fb3 call 0x8180ac
0x817fb8 mov r9b, 1
0x817fbb mov r8b, bl
0x817fbe mov rdx, rdi
0x817fc1 mov rcx, rax
0x817fc4 mov rbx, qword ptr [rsp + 0x40]
0x817fc9 add rsp, 0x30
0x817fcd pop rdi
0x817fce jmp 0x2fb108
0x817fd3 int3 
0x817fd4 mov qword ptr [rsp + 8], rbx
0x817fd9 mov qword ptr [rsp + 0x10], rsi
0x817fde push rdi
0x817fdf sub rsp, 0x20
0x817fe3 mov rdi, rdx
0x817fe6 mov rsi, rcx
0x817fe9 mov dl, byte ptr [rdx + 0x30]
0x817fec call 0x8180ac
0x817ff1 test dword ptr [rdi + 0x18], 0x40000
0x817ff8 mov ebx, dword ptr [rax + 0xfc]
