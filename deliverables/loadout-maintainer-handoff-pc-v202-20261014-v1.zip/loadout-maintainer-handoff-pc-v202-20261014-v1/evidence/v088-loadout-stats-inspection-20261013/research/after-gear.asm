Project Python: D:\Nioh3_v080_deliverables\ce-research-env\Scripts\python.exe
Build root: D:\Nioh3_v080_deliverables
Cargo target: D:\Nioh3_v080_deliverables\build-cache\python-tests
Test temp: D:\Nioh3_v080_deliverables\tmp\pytest-571456-93e6bc36
Lua test library: C:\Program Files\Cheat Engine\lua53-64.dll
FUNCTION 0x2FB2BC 0x2FB94F
0x2FB2BC mov qword ptr [rsp + 0x18], rbx
0x2FB2C1 push rbp
0x2FB2C2 push rsi
0x2FB2C3 push rdi
0x2FB2C4 push r12
0x2FB2C6 push r13
0x2FB2C8 push r14
0x2FB2CA push r15
0x2FB2CC lea rbp, [rsp - 0x60]
0x2FB2D1 sub rsp, 0x160
0x2FB2D8 mov rax, qword ptr [rip + 0x41bcc51]
0x2FB2DF xor rax, rsp
0x2FB2E2 mov qword ptr [rbp + 0x50], rax
0x2FB2E6 mov eax, dword ptr [rdx + 0x1ee0]
0x2FB2EC xor r10d, r10d
0x2FB2EF mov r13d, eax
0x2FB2F2 mov qword ptr [rsp + 0x48], r8
0x2FB2F7 xor r13d, 1
0x2FB2FB mov dword ptr [rsp + 0x38], eax
0x2FB2FF mov r14, rdx
0x2FB302 mov rbx, rcx
0x2FB305 mov dword ptr [rsp + 0x40], r13d
0x2FB30A cmp byte ptr [rcx + 0x10], r10b
0x2FB30E je 0x2fb324
0x2FB310 mov rax, qword ptr [rip + 0x44561b9]
0x2FB317 mov r12b, 1
0x2FB31A mov rcx, qword ptr [rax + 8]
0x2FB31E cmp byte ptr [rcx + 0x10], 1
0x2FB322 jbe 0x2fb327
0x2FB324 mov r12b, r10b
0x2FB327 mov r13d, dword ptr [rsp + 0x38]
0x2FB32C lea rsi, [rip + 0x367b3cd]
0x2FB333 mov rdi, r8
0x2FB336 mov ecx, dword ptr [rsi]
0x2FB338 call 0x2fb950
0x2FB33D mov edx, dword ptr [rsi]
0x2FB33F mov rcx, r14
0x2FB342 mov dword ptr [rsp + 0x38], eax
0x2FB346 call 0xf65d8
0x2FB34B lea rcx, [rsp + 0x60]
0x2FB350 movups xmm0, xmmword ptr [rax]
0x2FB353 movups xmmword ptr [rcx], xmm0
0x2FB356 lea rcx, [rcx + 0x80]
0x2FB35D movups xmm1, xmmword ptr [rax + 0x10]
0x2FB361 movups xmmword ptr [rcx - 0x70], xmm1
0x2FB365 movups xmm0, xmmword ptr [rax + 0x20]
0x2FB369 movups xmmword ptr [rcx - 0x60], xmm0
0x2FB36D movups xmm1, xmmword ptr [rax + 0x30]
0x2FB371 movups xmmword ptr [rcx - 0x50], xmm1
0x2FB375 movups xmm0, xmmword ptr [rax + 0x40]
0x2FB379 movups xmmword ptr [rcx - 0x40], xmm0
0x2FB37D movups xmm1, xmmword ptr [rax + 0x50]
0x2FB381 movups xmmword ptr [rcx - 0x30], xmm1
0x2FB385 movups xmm0, xmmword ptr [rax + 0x60]
0x2FB389 movups xmmword ptr [rcx - 0x20], xmm0
0x2FB38D movups xmm1, xmmword ptr [rax + 0x70]
0x2FB391 sub rax, -0x80
0x2FB395 movups xmmword ptr [rcx - 0x10], xmm1
0x2FB399 movups xmm0, xmmword ptr [rax]
0x2FB39C movups xmmword ptr [rcx], xmm0
0x2FB39F movups xmm1, xmmword ptr [rax + 0x10]
0x2FB3A3 movups xmmword ptr [rcx + 0x10], xmm1
0x2FB3A7 movups xmm0, xmmword ptr [rax + 0x20]
0x2FB3AB movups xmmword ptr [rcx + 0x20], xmm0
0x2FB3AF movups xmm1, xmmword ptr [rax + 0x30]
0x2FB3B3 movups xmmword ptr [rcx + 0x30], xmm1
0x2FB3B7 movups xmm0, xmmword ptr [rax + 0x40]
0x2FB3BB movups xmmword ptr [rcx + 0x40], xmm0
0x2FB3BF movups xmm1, xmmword ptr [rax + 0x50]
0x2FB3C3 movups xmmword ptr [rcx + 0x50], xmm1
0x2FB3C7 mov rax, qword ptr [rax + 0x60]
0x2FB3CB mov qword ptr [rcx + 0x60], rax
0x2FB3CF movzx edx, word ptr [rsp + 0x60]
0x2FB3D4 test dx, dx
0x2FB3D7 je 0x2fb758
0x2FB3DD mov rcx, qword ptr [rip + 0x42bea4c]
0x2FB3E4 mov rcx, qword ptr [rcx + 0x68]
0x2FB3E8 call 0xf4dbc
0x2FB3ED xor r10d, r10d
0x2FB3F0 mov r15, rax
0x2FB3F3 test rax, rax
0x2FB3F6 je 0x2fb758
0x2FB3FC lea rcx, [rbx + 0x1f4]
0x2FB403 lea rdx, [rsp + 0x38]
0x2FB408 call 0x375910
0x2FB40D xor edx, edx
0x2FB40F mov qword ptr [rsp + 0x38], rax
0x2FB414 cmp byte ptr [rbx + 0x10], dl
0x2FB417 je 0x2fb47f
0x2FB419 mov rcx, qword ptr [rbx + 8]
0x2FB41D test rcx, rcx
0x2FB420 je 0x2fb47f
0x2FB422 call 0x552a8c
0x2FB427 mov ecx, eax
0x2FB429 call 0x552aa4
0x2FB42E xor edx, edx
0x2FB430 test al, al
0x2FB432 je 0x2fb47f
0x2FB434 mov dl, r12b
0x2FB437 lea rcx, [rsp + 0x60]
0x2FB43C call 0x1abc49c
0x2FB441 mov rax, qword ptr [rbx + 0x7d8]
0x2FB448 xor ecx, ecx
0x2FB44A test rax, rax
0x2FB44D je 0x2fb455
0x2FB44F movzx edx, word ptr [rax + 0x52]
0x2FB453 jmp 0x2fb457
0x2FB455 mov edx, ecx
0x2FB457 mov rcx, rbx
0x2FB45A call 0x1ab7d54
0x2FB45F movzx r8d, dx
0x2FB463 lea rcx, [rsp + 0x60]
0x2FB468 movzx edx, ax
0x2FB46B call 0x1ab3ab8
0x2FB470 mov rdx, rax
0x2FB473 lea rcx, [rsp + 0x60]
0x2FB478 call 0x552dd0
0x2FB47D xor edx, edx
0x2FB47F movsxd rax, dword ptr [rsi]
0x2FB482 movss xmm0, dword ptr [rdi + rax*4]
0x2FB487 comiss xmm0, dword ptr [rip + 0x38d8d52]
0x2FB48E jb 0x2fb4b0
0x2FB490 mov rcx, rbx
0x2FB493 call 0x2fb9b4
0x2FB498 mov r8, rax
0x2FB49B lea rdx, [rsp + 0x60]
0x2FB4A0 mov rcx, r15
0x2FB4A3 call 0x2f9d78
0x2FB4A8 xor edx, edx
0x2FB4AA mov cl, 1
0x2FB4AC test al, al
0x2FB4AE jne 0x2fb4b2
0x2FB4B0 mov cl, dl
0x2FB4B2 mov byte ptr [rsp + 0x54], dl
0x2FB4B6 mov r8b, cl
0x2FB4B9 mov rax, qword ptr [rsp + 0x50]
0x2FB4BE lea rdx, [rsp + 0x60]
0x2FB4C3 mov byte ptr [rsp + 0x30], cl
0x2FB4C7 mov rcx, r15
0x2FB4CA mov qword ptr [rsp + 0x20], rax
0x2FB4CF call 0x817fa0
0x2FB4D4 mov rcx, qword ptr [rsp + 0x38]
0x2FB4D9 lea rdx, [rsp + 0x60]
0x2FB4DE mov dword ptr [rcx], eax
0x2FB4E0 mov rcx, r15
0x2FB4E3 add dword ptr [rbx + 0x1c8], eax
0x2FB4E9 call 0x817fd4
0x2FB4EE add dword ptr [rbx + 0x218], eax
0x2FB4F4 lea rdx, [rsp + 0x60]
0x2FB4F9 mov rcx, r15
0x2FB4FC call 0x818018
0x2FB501 add dword ptr [rbx + 0x7b8], eax
0x2FB507 lea r8, [rsp + 0x60]
0x2FB50C movzx eax, word ptr [r15 + 0x138]
0x2FB514 add word ptr [rbx + 0x21c], ax
0x2FB51B movzx edx, word ptr [r15 + 0x13a]
0x2FB523 call 0x2f9f54
0x2FB528 movsx ecx, ax
0x2FB52B lea r8, [rsp + 0x60]
0x2FB530 movd xmm0, ecx
0x2FB534 cvtdq2ps xmm0, xmm0
0x2FB537 addss xmm0, dword ptr [rbx + 0x77c]
0x2FB53F movss dword ptr [rbx + 0x77c], xmm0
0x2FB547 movzx edx, word ptr [r15 + 0x13c]
0x2FB54F call 0x2f9f54
0x2FB554 movsx ecx, ax
0x2FB557 lea r8, [rsp + 0x60]
0x2FB55C movd xmm0, ecx
0x2FB560 cvtdq2ps xmm0, xmm0
0x2FB563 addss xmm0, dword ptr [rbx + 0x780]
0x2FB56B movss dword ptr [rbx + 0x780], xmm0
0x2FB573 movzx edx, word ptr [r15 + 0x140]
0x2FB57B call 0x2f9f54
0x2FB580 movsx ecx, ax
0x2FB583 lea r8, [rsp + 0x60]
0x2FB588 movd xmm0, ecx
0x2FB58C cvtdq2ps xmm0, xmm0
0x2FB58F addss xmm0, dword ptr [rbx + 0x784]
0x2FB597 movss dword ptr [rbx + 0x784], xmm0
0x2FB59F movzx edx, word ptr [r15 + 0x13e]
0x2FB5A7 call 0x2f9f54
0x2FB5AC movsx ecx, ax
0x2FB5AF lea r8, [rsp + 0x60]
0x2FB5B4 movd xmm0, ecx
0x2FB5B8 cvtdq2ps xmm0, xmm0
0x2FB5BB addss xmm0, dword ptr [rbx + 0x788]
0x2FB5C3 movss dword ptr [rbx + 0x788], xmm0
0x2FB5CB movzx edx, word ptr [r15 + 0x142]
0x2FB5D3 call 0x2f9f54
0x2FB5D8 movsx ecx, ax
0x2FB5DB lea r8, [rsp + 0x60]
0x2FB5E0 movd xmm0, ecx
0x2FB5E4 cvtdq2ps xmm0, xmm0
0x2FB5E7 addss xmm0, dword ptr [rbx + 0x78c]
0x2FB5EF movss dword ptr [rbx + 0x78c], xmm0
0x2FB5F7 movzx edx, word ptr [r15 + 0x144]
0x2FB5FF call 0x2f9f54
0x2FB604 movsx ecx, ax
0x2FB607 lea r8, [rsp + 0x60]
0x2FB60C movd xmm0, ecx
0x2FB610 cvtdq2ps xmm0, xmm0
0x2FB613 addss xmm0, dword ptr [rbx + 0x790]
0x2FB61B movss dword ptr [rbx + 0x790], xmm0
0x2FB623 movzx edx, word ptr [r15 + 0x146]
0x2FB62B call 0x2f9fe4
0x2FB630 movsx ecx, ax
0x2FB633 lea r8, [rsp + 0x60]
0x2FB638 movd xmm0, ecx
0x2FB63C cvtdq2ps xmm0, xmm0
0x2FB63F addss xmm0, dword ptr [rbx + 0x4dc]
0x2FB647 movss dword ptr [rbx + 0x4dc], xmm0
0x2FB64F movzx edx, word ptr [r15 + 0x148]
0x2FB657 call 0x2f9fe4
0x2FB65C movsx ecx, ax
0x2FB65F movd xmm0, ecx
0x2FB663 lea r8, [rsp + 0x60]
0x2FB668 cvtdq2ps xmm0, xmm0
0x2FB66B addss xmm0, dword ptr [rbx + 0x4fc]
0x2FB673 movss dword ptr [rbx + 0x4fc], xmm0
0x2FB67B movzx edx, word ptr [r15 + 0x14c]
0x2FB683 call 0x2f9fe4
0x2FB688 movsx ecx, ax
0x2FB68B lea r8, [rsp + 0x60]
0x2FB690 movd xmm0, ecx
0x2FB694 cvtdq2ps xmm0, xmm0
0x2FB697 addss xmm0, dword ptr [rbx + 0x51c]
0x2FB69F movss dword ptr [rbx + 0x51c], xmm0
0x2FB6A7 movzx edx, word ptr [r15 + 0x14a]
0x2FB6AF call 0x2f9fe4
0x2FB6B4 movsx ecx, ax
0x2FB6B7 lea r8, [rsp + 0x60]
0x2FB6BC movd xmm0, ecx
0x2FB6C0 cvtdq2ps xmm0, xmm0
0x2FB6C3 addss xmm0, dword ptr [rbx + 0x53c]
0x2FB6CB movss dword ptr [rbx + 0x53c], xmm0
0x2FB6D3 movzx edx, word ptr [r15 + 0x14e]
0x2FB6DB call 0x2f9fe4
0x2FB6E0 movsx ecx, ax
0x2FB6E3 lea r8, [rsp + 0x60]
0x2FB6E8 movd xmm0, ecx
0x2FB6EC cvtdq2ps xmm0, xmm0
0x2FB6EF addss xmm0, dword ptr [rbx + 0x55c]
0x2FB6F7 movss dword ptr [rbx + 0x55c], xmm0
0x2FB6FF movzx edx, word ptr [r15 + 0x150]
0x2FB707 call 0x2f9fe4
0x2FB70C movsx ecx, ax
0x2FB70F xor r10d, r10d
0x2FB712 movd xmm0, ecx
0x2FB716 cvtdq2ps xmm0, xmm0
0x2FB719 addss xmm0, dword ptr [rbx + 0x57c]
0x2FB721 movss dword ptr [rbx + 0x57c], xmm0
0x2FB729 cmp byte ptr [rbx + 0x7d0], r10b
0x2FB730 jne 0x2fb758
0x2FB732 cmp qword ptr [rbx + 0x7d8], r10
0x2FB739 je 0x2fb758
0x2FB73B cmp byte ptr [rsp + 0x30], r10b
0x2FB740 je 0x2fb758
0x2FB742 mov r9b, 0xff
0x2FB745 lea rdx, [rsp + 0x60]
0x2FB74A mov r8d, r13d
0x2FB74D mov rcx, rbx
0x2FB750 call 0x55764c
0x2FB755 xor r10d, r10d
0x2FB758 add rsi, 4
0x2FB75C lea rax, [rip + 0x367afc1]
0x2FB763 cmp rsi, rax
0x2FB766 jne 0x2fb336
0x2FB76C lea rdi, [rip + 0x367af8d]
0x2FB773 mov r13d, dword ptr [rsp + 0x40]
0x2FB778 cmp qword ptr [rbx + 0x7d8], r10
0x2FB77F je 0x2fb928
0x2FB785 mov r15, qword ptr [rsp + 0x48]
0x2FB78A mov r8d, dword ptr [r14 + 0x1ee0]
0x2FB791 mov rcx, r14
0x2FB794 mov edx, dword ptr [rdi]
0x2FB796 xor r8d, 1
0x2FB79A call 0xf6614
0x2FB79F lea rcx, [rsp + 0x60]
0x2FB7A4 movups xmm0, xmmword ptr [rax]
0x2FB7A7 movups xmmword ptr [rcx], xmm0
0x2FB7AA lea rcx, [rcx + 0x80]
0x2FB7B1 movups xmm1, xmmword ptr [rax + 0x10]
0x2FB7B5 movups xmmword ptr [rcx - 0x70], xmm1
0x2FB7B9 movups xmm0, xmmword ptr [rax + 0x20]
0x2FB7BD movups xmmword ptr [rcx - 0x60], xmm0
0x2FB7C1 movups xmm1, xmmword ptr [rax + 0x30]
0x2FB7C5 movups xmmword ptr [rcx - 0x50], xmm1
0x2FB7C9 movups xmm0, xmmword ptr [rax + 0x40]
0x2FB7CD movups xmmword ptr [rcx - 0x40], xmm0
0x2FB7D1 movups xmm1, xmmword ptr [rax + 0x50]
0x2FB7D5 movups xmmword ptr [rcx - 0x30], xmm1
0x2FB7D9 movups xmm0, xmmword ptr [rax + 0x60]
0x2FB7DD movups xmmword ptr [rcx - 0x20], xmm0
0x2FB7E1 movups xmm1, xmmword ptr [rax + 0x70]
0x2FB7E5 sub rax, -0x80
0x2FB7E9 movups xmmword ptr [rcx - 0x10], xmm1
0x2FB7ED movups xmm0, xmmword ptr [rax]
0x2FB7F0 movups xmmword ptr [rcx], xmm0
0x2FB7F3 movups xmm1, xmmword ptr [rax + 0x10]
0x2FB7F7 movups xmmword ptr [rcx + 0x10], xmm1
0x2FB7FB movups xmm0, xmmword ptr [rax + 0x20]
0x2FB7FF movups xmmword ptr [rcx + 0x20], xmm0
0x2FB803 movups xmm1, xmmword ptr [rax + 0x30]
0x2FB807 movups xmmword ptr [rcx + 0x30], xmm1
0x2FB80B movups xmm0, xmmword ptr [rax + 0x40]
0x2FB80F movups xmmword ptr [rcx + 0x40], xmm0
0x2FB813 movups xmm1, xmmword ptr [rax + 0x50]
0x2FB817 movups xmmword ptr [rcx + 0x50], xmm1
0x2FB81B mov rax, qword ptr [rax + 0x60]
0x2FB81F mov qword ptr [rcx + 0x60], rax
0x2FB823 movzx edx, word ptr [rsp + 0x60]
0x2FB828 test dx, dx
0x2FB82B je 0x2fb914
0x2FB831 mov rcx, qword ptr [rip + 0x42be5f8]
0x2FB838 mov rcx, qword ptr [rcx + 0x68]
0x2FB83C call 0xf4dbc
0x2FB841 xor r10d, r10d
0x2FB844 mov rsi, rax
0x2FB847 test rax, rax
0x2FB84A je 0x2fb914
0x2FB850 cmp byte ptr [rbx + 0x10], r10b
0x2FB854 je 0x2fb8be
0x2FB856 mov rcx, qword ptr [rbx + 8]
0x2FB85A test rcx, rcx
0x2FB85D je 0x2fb8be
0x2FB85F call 0x552a8c
0x2FB864 mov ecx, eax
0x2FB866 call 0x552aa4
0x2FB86B xor r10d, r10d
0x2FB86E test al, al
0x2FB870 je 0x2fb8be
0x2FB872 mov dl, r12b
0x2FB875 lea rcx, [rsp + 0x60]
0x2FB87A call 0x1abc49c
0x2FB87F mov rax, qword ptr [rbx + 0x7d8]
0x2FB886 xor ecx, ecx
0x2FB888 test rax, rax
0x2FB88B je 0x2fb893
0x2FB88D movzx edx, word ptr [rax + 0x52]
0x2FB891 jmp 0x2fb895
0x2FB893 mov edx, ecx
0x2FB895 mov rcx, rbx
0x2FB898 call 0x1ab7d54
0x2FB89D movzx r8d, dx
0x2FB8A1 lea rcx, [rsp + 0x60]
0x2FB8A6 movzx edx, ax
0x2FB8A9 call 0x1ab3ab8
0x2FB8AE mov rdx, rax
0x2FB8B1 lea rcx, [rsp + 0x60]
0x2FB8B6 call 0x552dd0
0x2FB8BB xor r10d, r10d
0x2FB8BE movsxd rax, dword ptr [rdi]
0x2FB8C1 movss xmm0, dword ptr [r15 + rax*4]
0x2FB8C7 comiss xmm0, dword ptr [rip + 0x38d8912]
0x2FB8CE jb 0x2fb8f1
0x2FB8D0 mov rcx, rbx
0x2FB8D3 call 0x2fb9b4
0x2FB8D8 mov r8, rax
0x2FB8DB lea rdx, [rsp + 0x60]
0x2FB8E0 mov rcx, rsi
0x2FB8E3 call 0x2f9d78
0x2FB8E8 xor r10d, r10d
0x2FB8EB test al, al
0x2FB8ED mov al, 1
0x2FB8EF jne 0x2fb8f4
0x2FB8F1 mov al, r10b
0x2FB8F4 cmp byte ptr [rbx + 0x7d0], r10b
0x2FB8FB jne 0x2fb914
0x2FB8FD test al, al
0x2FB8FF je 0x2fb914
0x2FB901 mov r8d, r13d
0x2FB904 lea rdx, [rsp + 0x60]
0x2FB909 mov rcx, rbx
0x2FB90C call 0x5557dc
0x2FB911 xor r10d, r10d
0x2FB914 add rdi, 4
0x2FB918 lea rax, [rip + 0x367ae05]
0x2FB91F cmp rdi, rax
0x2FB922 jne 0x2fb78a
0x2FB928 mov rcx, qword ptr [rbp + 0x50]
0x2FB92C xor rcx, rsp
0x2FB92F call 0xb912e0
0x2FB934 mov rbx, qword ptr [rsp + 0x1b0]
0x2FB93C add rsp, 0x160
0x2FB943 pop r15
0x2FB945 pop r14
0x2FB947 pop r13
0x2FB949 pop r12
0x2FB94B pop rdi
0x2FB94C pop rsi
0x2FB94D pop rbp
0x2FB94E ret 
