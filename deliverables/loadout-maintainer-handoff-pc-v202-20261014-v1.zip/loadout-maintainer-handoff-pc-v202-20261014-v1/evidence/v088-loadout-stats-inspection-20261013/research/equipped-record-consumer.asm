Project Python: D:\Nioh3_v080_deliverables\ce-research-env\Scripts\python.exe
Build root: D:\Nioh3_v080_deliverables
Cargo target: D:\Nioh3_v080_deliverables\build-cache\python-tests
Test temp: D:\Nioh3_v080_deliverables\tmp\pytest-573348-07013f77
Lua test library: C:\Program Files\Cheat Engine\lua53-64.dll
FUNCTION 0x818248 0x818959
0x818248 mov rax, rsp
0x81824B mov qword ptr [rax + 0x18], rbx
0x81824F push rbp
0x818250 push rsi
0x818251 push rdi
0x818252 push r12
0x818254 push r13
0x818256 push r14
0x818258 push r15
0x81825A lea rbp, [rax - 0xe8]
0x818261 sub rsp, 0x1b0
0x818268 movaps xmmword ptr [rax - 0x48], xmm6
0x81826C movaps xmmword ptr [rax - 0x58], xmm7
0x818270 mov rax, qword ptr [rip + 0x3c9fcb9]
0x818277 xor rax, rsp
0x81827A mov qword ptr [rbp + 0x80], rax
0x818281 mov eax, dword ptr [rdx + 0x1ee0]
0x818287 mov r12, r8
0x81828A mov r11, qword ptr [rbp + 0x110]
0x818291 mov r13, rdx
0x818294 mov dword ptr [rsp + 0x48], eax
0x818298 mov rsi, rcx
0x81829B xor eax, 1
0x81829E mov dword ptr [rsp + 0x38], r9d
0x8182A3 xor r14d, r14d
0x8182A6 mov dword ptr [rsp + 0x4c], eax
0x8182AA mov rax, qword ptr [rip + 0x3da1b7f]
0x8182B1 mov r9d, r14d
0x8182B4 mov qword ptr [rsp + 0x50], r8
0x8182B9 mov qword ptr [rsp + 0x58], rdx
0x8182BE lea r10d, [r14 + 7]
0x8182C2 mov rbx, qword ptr [rax + 0x90]
0x8182C9 cmp r9, 7
0x8182CD jge 0x8182d5
0x8182CF mov edx, dword ptr [r11 + r9*4]
0x8182D3 jmp 0x8182da
0x8182D5 mov edx, 1
0x8182DA mov rcx, rbx
0x8182DD call 0x818aec
0x8182E2 movzx ecx, word ptr [rax + 0x1a]
0x8182E6 mov dword ptr [rbp + r9*4 + 0x60], ecx
0x8182EB inc r9
0x8182EE sub r10, 1
0x8182F2 jne 0x8182c9
0x8182F4 cmp byte ptr [rsi + 0x10], r14b
0x8182F8 je 0x81830e
0x8182FA mov rax, qword ptr [rip + 0x3f391cf]
0x818301 mov dil, 1
0x818304 mov rcx, qword ptr [rax + 8]
0x818308 cmp byte ptr [rcx + 0x10], 1
0x81830C jbe 0x818311
0x81830E mov dil, r14b
0x818311 movss xmm7, dword ptr [rip + 0x33bbec7]
0x818319 lea rbx, [rip + 0x33c05a8]
0x818320 mov qword ptr [rsp + 0x40], rbx
0x818325 lea rax, [rsi + 0x24]
0x818329 mov byte ptr [rsp + 0x30], dil
0x81832E mov r15d, r14d
0x818331 lea rdx, [rsp + 0x34]
0x818336 mov dword ptr [rsp + 0x34], r15d
0x81833B mov rcx, rax
0x81833E call 0x375ce0
0x818343 mov r14, rax
0x818346 cmp r15d, 5
0x81834A jae 0x81881b
0x818350 movsxd rbx, dword ptr [rbx]
0x818353 mov rcx, r13
0x818356 mov edx, ebx
0x818358 mov dword ptr [rsp + 0x34], ebx
0x81835C call 0xf65d8
0x818361 lea rcx, [rsp + 0x70]
0x818366 mov edx, 0x80
0x81836B movups xmm0, xmmword ptr [rax]
0x81836E movups xmmword ptr [rcx], xmm0
0x818371 movups xmm1, xmmword ptr [rax + 0x10]
0x818375 movups xmmword ptr [rcx + 0x10], xmm1
0x818379 movups xmm0, xmmword ptr [rax + 0x20]
0x81837D movups xmmword ptr [rcx + 0x20], xmm0
0x818381 movups xmm1, xmmword ptr [rax + 0x30]
0x818385 movups xmmword ptr [rcx + 0x30], xmm1
0x818389 movups xmm0, xmmword ptr [rax + 0x40]
0x81838D movups xmmword ptr [rcx + 0x40], xmm0
0x818391 movups xmm1, xmmword ptr [rax + 0x50]
0x818395 movups xmmword ptr [rcx + 0x50], xmm1
0x818399 movups xmm0, xmmword ptr [rax + 0x60]
0x81839D movups xmmword ptr [rcx + 0x60], xmm0
0x8183A1 add rcx, rdx
0x8183A4 movups xmm1, xmmword ptr [rax + 0x70]
0x8183A8 add rax, rdx
0x8183AB movups xmmword ptr [rcx - 0x10], xmm1
0x8183AF movups xmm0, xmmword ptr [rax]
0x8183B2 movups xmmword ptr [rcx], xmm0
0x8183B5 movups xmm1, xmmword ptr [rax + 0x10]
0x8183B9 movups xmmword ptr [rcx + 0x10], xmm1
0x8183BD movups xmm0, xmmword ptr [rax + 0x20]
0x8183C1 movups xmmword ptr [rcx + 0x20], xmm0
0x8183C5 movups xmm1, xmmword ptr [rax + 0x30]
0x8183C9 movups xmmword ptr [rcx + 0x30], xmm1
0x8183CD movups xmm0, xmmword ptr [rax + 0x40]
0x8183D1 movups xmmword ptr [rcx + 0x40], xmm0
0x8183D5 movups xmm1, xmmword ptr [rax + 0x50]
0x8183D9 movups xmmword ptr [rcx + 0x50], xmm1
0x8183DD mov rax, qword ptr [rax + 0x60]
0x8183E1 mov qword ptr [rcx + 0x60], rax
0x8183E5 movzx edx, word ptr [rsp + 0x70]
0x8183EA test dx, dx
0x8183ED je 0x818816
0x8183F3 mov rcx, qword ptr [rip + 0x3da1a36]
0x8183FA mov rcx, qword ptr [rcx + 0x68]
0x8183FE call 0xf4dbc
0x818403 xor edx, edx
0x818405 mov r13, rax
0x818408 test rax, rax
0x81840B je 0x81888b
0x818411 cmp byte ptr [rsi + 0x10], dl
0x818414 je 0x81847c
0x818416 mov rcx, qword ptr [rsi + 8]
0x81841A test rcx, rcx
0x81841D je 0x81847c
0x81841F call 0x552a8c
0x818424 mov ecx, eax
0x818426 call 0x552aa4
0x81842B xor edx, edx
0x81842D test al, al
0x81842F je 0x81847c
0x818431 mov dl, dil
0x818434 lea rcx, [rsp + 0x70]
0x818439 call 0x1abc49c
0x81843E mov rax, qword ptr [rsi + 0x7d8]
0x818445 xor ecx, ecx
0x818447 test rax, rax
0x81844A je 0x818452
0x81844C movzx edx, word ptr [rax + 0x52]
0x818450 jmp 0x818454
0x818452 mov edx, ecx
0x818454 mov rcx, rsi
0x818457 call 0x1ab7d54
0x81845C movzx r8d, dx
0x818460 lea rcx, [rsp + 0x70]
0x818465 movzx edx, ax
0x818468 call 0x1ab3ab8
0x81846D mov rdx, rax
0x818470 lea rcx, [rsp + 0x70]
0x818475 call 0x552dd0
0x81847A xor edx, edx
0x81847C movss xmm6, dword ptr [r12 + rbx*4]
0x818482 comiss xmm6, xmm7
0x818485 jb 0x8184a8
0x818487 mov rcx, rsi
0x81848A call 0x2fb9b4
0x81848F mov r8, rax
0x818492 lea rdx, [rsp + 0x70]
0x818497 mov rcx, r13
0x81849A call 0x2f9d78
0x81849F xor edx, edx
0x8184A1 mov r12b, 1
0x8184A4 test al, al
0x8184A6 jne 0x8184ab
0x8184A8 mov r12b, dl
0x8184AB mov r9d, dword ptr [rsp + 0x38]
0x8184B0 mov r8b, r12b
0x8184B3 mov byte ptr [rsp + 0x64], dl
0x8184B7 mov rcx, r13
0x8184BA mov rax, qword ptr [rsp + 0x60]
0x8184BF lea rdx, [rsp + 0x70]
0x8184C4 mov qword ptr [rsp + 0x20], rax
0x8184C9 call 0x817af4
0x8184CE mov r9d, dword ptr [rsp + 0x38]
0x8184D3 lea rdx, [rsp + 0x70]
0x8184D8 xor r10d, r10d
0x8184DB mov r8b, r12b
0x8184DE mov byte ptr [rsp + 0x6c], r10b
0x8184E3 mov ebx, eax
0x8184E5 mov rcx, qword ptr [rsp + 0x68]
0x8184EA mov qword ptr [rsp + 0x20], rcx
0x8184EF mov rcx, r13
0x8184F2 call 0x817b3c
0x8184F7 mov rcx, qword ptr [rsi + 8]
0x8184FB lea r9, [rbp + 0x60]
0x8184FF mov edi, eax
0x818501 lea r8, [rsp + 0x70]
0x818506 mov eax, dword ptr [rsp + 0x34]
0x81850A mov dword ptr [rsp + 0x28], eax
0x81850E mov qword ptr [rsp + 0x20], rcx
0x818513 mov rcx, r13
0x818516 call 0x3fba64
0x81851B mov edx, eax
0x81851D mov ecx, ebx
0x81851F call 0x818200
0x818524 xorps xmm0, xmm0
0x818527 lea ecx, [rbx + rax]
0x81852A cvtsi2ss xmm0, rcx
0x81852F mulss xmm0, xmm6
0x818533 cvttss2si rcx, xmm0
0x818538 mov dword ptr [r14], ecx
0x81853B mov ecx, edi
0x81853D call 0x818200
0x818542 mov r9d, dword ptr [rsp + 0x38]
0x818547 lea rdx, [rsp + 0x70]
0x81854C add eax, edi
0x81854E xorps xmm0, xmm0
0x818551 xor edi, edi
0x818553 mov rcx, r13
0x818556 mov dword ptr [r14 + 8], edi
0x81855A cvtsi2ss xmm0, rax
0x81855F mulss xmm0, xmm6
0x818563 cvttss2si rax, xmm0
0x818568 mov dword ptr [r14 + 4], eax
0x81856C movzx eax, byte ptr [r13 + 0x19b]
0x818574 mov dword ptr [r14 + 0xc], eax
0x818578 call 0x817da8
0x81857D mov r9d, dword ptr [rsp + 0x38]
0x818582 lea rdx, [rsp + 0x70]
0x818587 mov rcx, r13
0x81858A mov dword ptr [r14 + 0x10], eax
0x81858E call 0x817ea4
0x818593 or dword ptr [r14 + 0x18], 0xffffffff
0x818598 mov rcx, r13
0x81859B mov dword ptr [r14 + 0x14], eax
0x81859F mov dword ptr [r14 + 0x1c], edi
0x8185A3 call 0x8180d4
0x8185A8 movss dword ptr [r14 + 0x20], xmm0
0x8185AE xorps xmm0, xmm0
0x8185B1 mov eax, dword ptr [r13 + 0xe8]
0x8185B8 mov dword ptr [r14 + 0x24], eax
0x8185BC mov eax, dword ptr [r13 + 0xec]
0x8185C3 mov dword ptr [r14 + 0x28], eax
0x8185C7 mov eax, dword ptr [r13 + 0xf0]
0x8185CE cvtsi2ss xmm0, rax
0x8185D3 mulss xmm0, dword ptr [rip + 0x33bc2b5]
0x8185DB movss dword ptr [r14 + 0x2c], xmm0
0x8185E1 call 0x8180ec
0x8185E6 movss dword ptr [r14 + 0x30], xmm0
0x8185EC mov eax, dword ptr [r13 + 0x48]
0x8185F0 mov dword ptr [r14 + 0x34], eax
0x8185F4 movzx eax, byte ptr [r13 + 0x19a]
0x8185FC mov dword ptr [r14 + 0x38], eax
0x818600 mov eax, dword ptr [r13 + 0xb0]
0x818607 shr eax, 3
0x81860A and al, 1
0x81860C mov r13, qword ptr [rsp + 0x58]
0x818611 mov byte ptr [r14 + 0x3c], al
0x818615 mov byte ptr [r14 + 0x3d], dil
0x818619 movsxd rax, dword ptr [r13 + 0x1ee0]
0x818620 imul rcx, rax, 0xf70
0x818627 mov eax, edi
0x818629 cmp byte ptr [rcx + r13 + 0xf68], dil
0x818631 mov ecx, dword ptr [rsp + 0x34]
0x818635 sete al
0x818638 cmp eax, ecx
0x81863A je 0x818647
0x81863C cmp ecx, 0xd
0x81863F je 0x818647
0x818641 xor ecx, ecx
0x818643 mov al, cl
0x818645 jmp 0x81864b
0x818647 mov al, 1
0x818649 xor ecx, ecx
0x81864B cmp byte ptr [rsi + 0x7d0], cl
0x818651 jne 0x818807
0x818657 cmp qword ptr [rsi + 0x7d8], rcx
0x81865E je 0x818807
0x818664 test r12b, r12b
0x818667 je 0x818807
0x81866D cmp byte ptr [rbp + 0x118], cl
0x818673 jne 0x818807
0x818679 mov r8d, dword ptr [rsp + 0x48]
0x81867E lea rdx, [rsp + 0x70]
0x818683 neg al
0x818685 mov rcx, rsi
0x818688 sbb r9b, r9b
0x81868B call 0x55764c
0x818690 mov rbx, qword ptr [rsp + 0x40]
0x818695 mov r12, qword ptr [rsp + 0x50]
0x81869A xor ecx, ecx
0x81869C mov dil, byte ptr [rsp + 0x30]
0x8186A1 lea rax, [rsi + 0x24]
0x8186A5 add rbx, 4
0x8186A9 inc r15d
0x8186AC mov qword ptr [rsp + 0x40], rbx
0x8186B1 cmp r15d, 6
0x8186B5 jl 0x818331
0x8186BB cmp qword ptr [rsi + 0x7d8], rcx
0x8186C2 je 0x818925
0x8186C8 cmp byte ptr [rbp + 0x118], cl
0x8186CE jne 0x818925
0x8186D4 mov ebx, ecx
0x8186D6 lea r14, [rip + 0x33c01eb]
0x8186DD mov r12b, dil
0x8186E0 xor r10d, r10d
0x8186E3 cmp ebx, 5
0x8186E6 jae 0x818916
0x8186EC movsxd r15, dword ptr [r14]
0x8186EF mov rcx, r13
0x8186F2 mov r8d, dword ptr [r13 + 0x1ee0]
0x8186F9 mov edx, r15d
0x8186FC xor r8d, 1
0x818700 call 0xf6614
0x818705 lea rcx, [rsp + 0x70]
0x81870A mov edx, 0x80
0x81870F movups xmm0, xmmword ptr [rax]
0x818712 movups xmmword ptr [rcx], xmm0
0x818715 movups xmm1, xmmword ptr [rax + 0x10]
0x818719 movups xmmword ptr [rcx + 0x10], xmm1
0x81871D movups xmm0, xmmword ptr [rax + 0x20]
0x818721 movups xmmword ptr [rcx + 0x20], xmm0
0x818725 movups xmm1, xmmword ptr [rax + 0x30]
0x818729 movups xmmword ptr [rcx + 0x30], xmm1
0x81872D movups xmm0, xmmword ptr [rax + 0x40]
0x818731 movups xmmword ptr [rcx + 0x40], xmm0
0x818735 movups xmm1, xmmword ptr [rax + 0x50]
0x818739 movups xmmword ptr [rcx + 0x50], xmm1
0x81873D movups xmm0, xmmword ptr [rax + 0x60]
0x818741 movups xmmword ptr [rcx + 0x60], xmm0
0x818745 add rcx, rdx
0x818748 movups xmm1, xmmword ptr [rax + 0x70]
0x81874C add rax, rdx
0x81874F movups xmmword ptr [rcx - 0x10], xmm1
0x818753 movups xmm0, xmmword ptr [rax]
0x818756 movups xmmword ptr [rcx], xmm0
0x818759 movups xmm1, xmmword ptr [rax + 0x10]
0x81875D movups xmmword ptr [rcx + 0x10], xmm1
0x818761 movups xmm0, xmmword ptr [rax + 0x20]
0x818765 movups xmmword ptr [rcx + 0x20], xmm0
0x818769 movups xmm1, xmmword ptr [rax + 0x30]
0x81876D movups xmmword ptr [rcx + 0x30], xmm1
0x818771 movups xmm0, xmmword ptr [rax + 0x40]
0x818775 movups xmmword ptr [rcx + 0x40], xmm0
0x818779 movups xmm1, xmmword ptr [rax + 0x50]
0x81877D movups xmmword ptr [rcx + 0x50], xmm1
0x818781 mov rax, qword ptr [rax + 0x60]
0x818785 mov qword ptr [rcx + 0x60], rax
0x818789 movzx edx, word ptr [rsp + 0x70]
0x81878E test dx, dx
0x818791 je 0x818916
0x818797 mov rcx, qword ptr [rip + 0x3da1692]
0x81879E mov rcx, qword ptr [rcx + 0x68]
0x8187A2 call 0xf4dbc
0x8187A7 xor ecx, ecx
0x8187A9 mov rdi, rax
0x8187AC test rax, rax
0x8187AF je 0x818913
0x8187B5 cmp byte ptr [rsi + 0x10], cl
0x8187B8 je 0x8188bf
0x8187BE mov rcx, qword ptr [rsi + 8]
0x8187C2 test rcx, rcx
0x8187C5 je 0x8188bf
0x8187CB call 0x552a8c
0x8187D0 mov ecx, eax
0x8187D2 call 0x552aa4
0x8187D7 test al, al
0x8187D9 je 0x8188bf
0x8187DF mov dl, r12b
0x8187E2 lea rcx, [rsp + 0x70]
0x8187E7 call 0x1abc49c
0x8187EC mov rax, qword ptr [rsi + 0x7d8]
0x8187F3 xor ecx, ecx
0x8187F5 test rax, rax
0x8187F8 je 0x818897
0x8187FE movzx edx, word ptr [rax + 0x52]
0x818802 jmp 0x818899
0x818807 mov rbx, qword ptr [rsp + 0x40]
0x81880C mov r12, qword ptr [rsp + 0x50]
0x818811 jmp 0x81869c
0x818816 mov rbx, qword ptr [rsp + 0x40]
0x81881B xor edx, edx
0x81881D cmp r15d, 4
0x818821 je 0x81869a
0x818827 mov rax, qword ptr [rsi + 8]
0x81882B mov ecx, 0x19
0x818830 cmp dword ptr [rax + 0x24], edx
0x818833 jne 0x81883d
0x818835 call 0x818104
0x81883A movzx ecx, ax
0x81883D mov dword ptr [r14], ecx
0x818840 mov dword ptr [r14 + 4], ecx
0x818844 xor ecx, ecx
0x818846 or dword ptr [r14 + 0x18], 0xffffffff
0x81884B mov dword ptr [r14 + 8], ecx
0x81884F mov qword ptr [r14 + 0x1c], rcx
0x818853 mov qword ptr [r14 + 0x24], rcx
0x818857 mov qword ptr [r14 + 0x2c], rcx
0x81885B mov dword ptr [r14 + 0x34], ecx
0x81885F mov dword ptr [r14 + 0xc], 2
0x818867 mov dword ptr [r14 + 0x10], 0x14
0x81886F mov dword ptr [r14 + 0x14], 0xa
0x818877 mov dword ptr [r14 + 0x38], 0xd
0x81887F mov word ptr [r14 + 0x3c], 0x100
0x818886 jmp 0x81869c
0x81888B mov rbx, qword ptr [rsp + 0x40]
0x818890 mov r13, qword ptr [rsp + 0x58]
0x818895 jmp 0x81881d
0x818897 mov edx, ecx
0x818899 mov rcx, rsi
0x81889C call 0x1ab7d54
0x8188A1 movzx r8d, dx
0x8188A5 lea rcx, [rsp + 0x70]
0x8188AA movzx edx, ax
0x8188AD call 0x1ab3ab8
0x8188B2 mov rdx, rax
0x8188B5 lea rcx, [rsp + 0x70]
0x8188BA call 0x552dd0
0x8188BF mov rcx, qword ptr [rsp + 0x50]
0x8188C4 movss xmm0, dword ptr [rcx + r15*4]
0x8188CA comiss xmm0, xmm7
0x8188CD jb 0x8188f1
0x8188CF mov rcx, rsi
0x8188D2 call 0x2fb9b4
0x8188D7 mov r8, rax
0x8188DA lea rdx, [rsp + 0x70]
0x8188DF mov rcx, rdi
0x8188E2 call 0x2f9d78
0x8188E7 xor ecx, ecx
0x8188E9 test al, al
0x8188EB je 0x8188f3
0x8188ED mov al, 1
0x8188EF jmp 0x8188f5
0x8188F1 xor ecx, ecx
0x8188F3 mov al, cl
0x8188F5 cmp byte ptr [rsi + 0x7d0], cl
0x8188FB jne 0x818913
0x8188FD test al, al
0x8188FF je 0x818913
0x818901 mov r8d, dword ptr [rsp + 0x4c]
0x818906 lea rdx, [rsp + 0x70]
0x81890B mov rcx, rsi
0x81890E call 0x5557dc
0x818913 xor r10d, r10d
0x818916 inc ebx
0x818918 add r14, 4
0x81891C cmp ebx, 6
0x81891F jl 0x8186e3
0x818925 mov rcx, qword ptr [rbp + 0x80]
0x81892C xor rcx, rsp
0x81892F call 0xb912e0
0x818934 lea r11, [rsp + 0x1b0]
0x81893C mov rbx, qword ptr [r11 + 0x50]
0x818940 movaps xmm6, xmmword ptr [r11 - 0x10]
0x818945 movaps xmm7, xmmword ptr [r11 - 0x20]
0x81894A mov rsp, r11
0x81894D pop r15
0x81894F pop r14
0x818951 pop r13
0x818953 pop r12
0x818955 pop rdi
0x818956 pop rsi
0x818957 pop rbp
0x818958 ret 
