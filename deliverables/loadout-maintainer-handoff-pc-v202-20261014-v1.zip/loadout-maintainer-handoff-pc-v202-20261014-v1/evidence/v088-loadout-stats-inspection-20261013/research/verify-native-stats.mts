import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const base='C:/Users/RUAA/.codex/worktrees/v088-loadout/仁王3绘卷生成器项目/apps/workshop/';
const {armorStats}=await import(pathToFileURL(base+'loadout-stats.ts').href);
const stats=JSON.parse(await readFile(base+'loadout-stats.json','utf8'));
const path='C:/Users/RUAA/.codex/worktrees/armor-remodel-batch-pr/仁王3绘卷生成器项目/research/armor_remodel_v202/native-returns.json';
const bytes=await readFile(path),digest=createHash('sha256').update(bytes).digest('hex');
assert.equal(digest,stats.armor_validation.corpus_sha256.toLowerCase());
const corpus=JSON.parse(bytes.toString()),counts={weight:0,toughness:0};
for(const event of corpus.events.filter(event=>['weight','toughness'].includes(event.kind))){
 const result=armorStats({item_id:event.item_id,rarity:event.rarity,level:event.level,level_before_forge:event.level,plus:event.plus,armor_remodel:event.mode.split('/').map(Number),native_flags:event.flags,effects:[]});
 assert(result,`Missing item ${event.item_id}`);
 const bound=result[event.kind];assert(event.actual>=bound.minimum&&event.actual<=bound.maximum,JSON.stringify({event,bound}));
 if(event.kind==='toughness'||bound.minimum===bound.maximum)assert.equal(bound.minimum,event.actual);
 counts[event.kind]++;
}
const report={ok:true,counts,corpusSha256:digest,scope:'Offline replay of retained PC v2.02 native returns. Unknown current getter stage is bounded.'};
await writeFile('D:/Nioh3_v080_deliverables/deliverables/v088-loadout-stats-inspection-20261013/research/typescript-native-parity.json',JSON.stringify(report,null,2));console.log(report);
