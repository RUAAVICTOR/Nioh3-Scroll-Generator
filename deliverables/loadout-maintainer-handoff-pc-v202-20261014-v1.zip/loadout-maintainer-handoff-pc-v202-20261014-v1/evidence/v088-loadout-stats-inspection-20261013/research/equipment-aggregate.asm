Project Python: D:\Nioh3_v080_deliverables\ce-research-env\Scripts\python.exe
Build root: D:\Nioh3_v080_deliverables
Cargo target: D:\Nioh3_v080_deliverables\build-cache\python-tests
Test temp: D:\Nioh3_v080_deliverables\tmp\pytest-561588-02247fd1
Lua test library: C:\Program Files\Cheat Engine\lua53-64.dll
Traceback (most recent call last):
  File "D:\Nioh3_v080_deliverables\deliverables\v088-loadout-stats-inspection-20261013\research\inspect_stats_code.py", line 65, in <module>
    report=disassemble_functions(text,pdata,text_rva=0x1000,requested_rvas=rvas,vendor_path=None)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "C:\Users\RUAA\.codex\worktrees\v088-loadout\仁王3绘卷生成器项目\research\disassemble_native_functions.py", line 49, in disassemble_functions
    raise ValueError(f"no pdata runtime function contains RVA 0x{requested_rva:X}")
ValueError: no pdata runtime function contains RVA 0x817364
