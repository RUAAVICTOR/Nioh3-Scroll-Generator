# Additional player HP/Ki inputs, PC v2.02

The additional maximum-stat inputs recovered in this pass are flat Life and
Ki effects, the Amrita-gauge Ki curve, a player-owned fixed Life bonus, the
style-selected active effect list, and conditional actor/context multipliers.
The current level-1 vector still reconstructs exactly as HP 880 + 135 = 1015
and Ki 960. This is a bounded extension of the previous calculation research,
not a claim that every combat state or UI consumer has been recovered.

Scope: executable 2.0.2.0, SHA-256
`e22c4a635e4ec1e27a177b76e27d7f6a637f426c0ed3928b60f5693bc52ae130`.
REA 6.4.0 / Ghidra 12.1.4 analyzed byte-identical focused carriers made by the
existing enemy-research launcher. Live phases used query/read-only handles,
same-process identity, native signatures, stable pointers and bounded reads.
No game calls, debugger, memory writes, save access or product changes occurred.

The intended deliverable was a calculation-stage inventory with concrete
additional effects and a current-vector check. Naming every source of the
conditional multipliers and the fixed Life bonus remains separate open work.

## Confirmed maximum-stat inputs

| Input | Operation and source | Qualification |
| --- | --- | --- |
| Effective level, Constitution, Stamina | Base HP table terms; RVAs `8181A4`, `818B68` | Previous native control flow and owner negative control |
| Effective Heart | Base Ki table term | Previous native control flow and current replay |
| Context correction | HP `376530`, Ki `376698`; applied to the base stage | Current factors 1; exact game-mode labels remain unverified |
| `B1B6`, Life / 体力 | Adds the effect value directly to derived HP at `81F563` | Native dispatcher and current group/text join |
| `7F69`, Ki / 精力 | Adds directly to derived Ki at `81DA6B` | Native dispatcher and current group/text join |
| `5D3A`, Life Reflection (Stamina) | Curve `FA3E` times the Stamina HP table contribution, truncated | Previous B+ positive/negative controls; current value 8, auxiliary 0 |
| `B95E`, Ki Reflection (Amrita Gauge) | Curve `CBE1` adds a fixed Ki amount after Ki multipliers | Native dispatcher/final writer and captured curve; inactive on current player |
| Player-owned fixed Life bonus | Player `+DC` -> backing `+5880` -> derived HP | New native copy-chain recovery and fresh source/backing equality |
| Style selection | Different active effect lists for owner styles 0 and 1 | Native `557A50`, `557A98`, `557B5C`; current style 0 |
| Final actor multipliers | HP fields `+3648`, `+364C`, `+30BC`; Ki `+3650`, plus guarded type/group factors | Native final writers; exposed current fields all 1 |

Internal group `0860` shares the flat HP destination, but its native label is
"备用" and description is "Dammy的说明". It is not evidence of a usable player
effect. This pass joins names through current group row text IDs at `+2C/+30`
and the hash-checked prior native localization records, not a guessed item name.
All exact rows and text IDs are retained in `analysis.json`.

The active list is a merge result. An equipment, guardian, clan or set source
must pass its own activation rules before its entry can affect this calculation.
Counting all visible/inventory entries as active will give incorrect results.
The list parser retains both raw value and auxiliary field; it does not discard
the duplicate-grade increment identified in the previous clan study.

## Amrita gauge: concrete Ki amounts

`819400` handles `B95E` by selecting a nonnegative grade at modifier `+600`.
`3771EC` reads the gauge at status `+148`, obtains its normalized ratio from
`2FEBFC`, multiplies by 1000 in float32, truncates to a curve point, and looks up
`CBE1`. The curve output is truncated to an integer and added after the
`+3650`, type and guarded group multipliers. There is no extra percent-to-ratio
conversion at this consumer.

`2FEBFC..2FEC26` returns 0 when its signed maximum at `+18` is nonpositive;
otherwise it divides float current `+14` by that maximum and clamps to [0, 1].
The leaf's early RET requires reading the branch target as well; the first-RET
excerpt alone is incomplete. The corresponding native continuation is retained
in `instructions-02.json`. Some focused Ghidra pseudo-code stops at an unmapped
branch; it is not used to override these native bytes.

The two captured `CBE1` rows are point 0 (all samples 0) and point 1000.
Full-gauge amounts for selectors 0..17 are:

`38,39,40,42,43,44,46,47,48,50,51,52,54,55,56,58,59,60`.

| Grade | Empty | 25% | 50% | 75% | Full |
| --- | ---: | ---: | ---: | ---: | ---: |
| B+ | 0 | 12 | 24 | 36 | 48 |
| A | 0 | 12 | 25 | 38 | 51 |
| AAA+ | 0 | 15 | 30 | 45 | 60 |

These are native-table predictions with float32 interpolation and integer
truncation, not live equip/unequip acceptance for this effect. The current gauge
is 5000 / 5000, but the grade gate is -1: a full gauge alone contributes no Ki.
With B95E B+ active and otherwise identical inputs, this stage predicts
960 + 48 = 1008. Its multiple-source aggregation still needs its own live control.

## Fixed Life bonus: recovered source, unnamed reward system

The previous report left backing `+5880` unexplained. The new native chain is:

1. `556118` rebuilds the backing object. At `556906..55692F`, it obtains the
   object through global RVA `4751860` -> wrapper's first qword and copies nine
   signed dwords using `9AB20C` into backing `+5880..58A0`.
2. `9AB20C` maps index 0 to the player's `+DC`, index 1 to `+E0`, and indices
   2..8 to `+E4..FC`.
3. `8175F4` adds the first value, backing `+5880`, to derived HP `+18`.

`bonus-source-01` proves the source is the same player object as the allocated
attribute capture, and its nine values exactly match the selected backing:
`[0,850,0,0,0,0,0,0,0]`. Therefore the fixed Life contribution is currently 0.
Index 1 is not a flat +850 maximum-Ki bonus: `8175F4` does not add backing
`+5884` to derived Ki, and the observed maximum remains 960. The nine-field
layout must not be labeled by order alone.

`2153A2C` can add an integer to a selected source field with a signed-max cap
and requests a player stat rebuild through `2174F44`. Its owning gameplay/UI
system is not yet identified. This pass does not rename the Life field as a
specific skill, title reward, collectible reward or permanent blessing.

## Guardian and style evidence

The hash-pinned prior native guardian catalog contains the same `B1B6` group row
as the current native table. Kongojishi / 金刚狮子 has separate records:

| Record | Style | Slot | Raw base | Raw growth parameter | Prior native-model value at level index 0 |
| --- | --- | ---: | ---: | ---: | ---: |
| 3 | Samurai | 3 | 150 | 321 | 182 |
| 240 | Ninja | 3 | 100 | 171 | 117 |

The raw base is not the final leveled protection value. These are prior native
catalog results, not a new live guardian change. The current active maximum-stat
effect inventory contains only `5D3A` among the five checked groups, so these
guardian Life entries do not explain the current 135 bonus.

Different style lists and differently leveled guardians can change the selected
maximum even when allocated attributes are unchanged. Gear requirement and set
activation gates are also upstream of the merged list; individual sources are
not separately multiplied merely because they come from different systems.

## Multipliers: guarded paths, not universal player percentages

`54F864` obtains an actor status from actor `+3A0`, takes explicit descriptor
HP `+84` / Ki `+90` factors or table-derived factors, then stores status `+364C`
and `+3650`. The table path adds deviations from 1 for eligible flag-selected
variants. Its exact player-visible scenario labels are not yet recovered.
`1C0AA54` independently copies descriptor `+8` to status HP factor `+3648`
and requests a rebuild. `+30BC` remains a confirmed HP consumer input with an
unresolved producer in this bounded scan.

The stat postprocessor `9E45B0` also contains an HP multiplier from table-manager
`+668`, row `+B4`, accessed through actor `+ABB0`; it is guarded by owner kind
`+24 == 1` and actor flags. The current owner kind is 0, so this branch is not
evidence of another percentage effect on this player. Its other kind-2 branch
modifies attack/defense fields. It must not be applied to all players.

Final type/group factors were already identified in the original study. Their
guards include actor type/flags and group size; this pass does not interpret
every group-size branch as an unconditional co-op player HP/Ki bonus.

## Current vector and verification

Fresh `live-01`: same PID 588752 and process birth, module base `7FF630AA0000`,
level 1, allocated/effective attributes `[5,5,5,6,5,5,5]`, effective level 1.
Selected/final maxima are 1015 / 960. Exposed HP multipliers and Ki multiplier
are 1. The selected fixed Life bonus is 0, `5D3A` is selector 8 with auxiliary
0, and `B95E` is inactive. HP = 780 + 70 + 30 + trunc(4.5 * 30) = 1015;
Ki = 960. This repeats the positive vector using fresh passive reads.

`analysis.json` verifies consumed capture hashes, 662 native curve rows against
the shipped same-version resource, native text record hashes, and 2079 retained
instructions / 8355 bytes against the pinned original text section. The existing
curve, Life Reflection and base-resource suites passed: 24 tests. These tests
validate the offline arithmetic and prior controls; they do not constitute live
acceptance of every new conditional path.

REA sessions `rea-02` and `rea-03` closed with `binary_session.open = false`,
source hashes unchanged and no game execution. `rea-01` retains the initial
invalid seed-file-format failure; the corrected address/TAB/kind seeds were used
for the next session. The initial first-RET disassembly attempt without leaf
opt-in also failed before producing its output; subsequent leaf excerpts are
explicitly qualified.

The field-displacement inventory is bounded to 64 KiB per function and 512 KiB
of decoded ranges and retains skipped functions. It includes unrelated structs
and stack locals; the `242CD4` float ring-buffer access is not the player's
fixed Life producer. Capstone operand access flags are not complete for every
vector store, so raw instructions and pointer provenance control the conclusion.

Remaining coverage: exact skill/reward identity of player `+DC`; full gameplay
labels and activation of descriptor multipliers; all post-damage erosion and
temporary usable-cap consumers; new live controls for B95E and style changes.
Recovery, consumption, current HP/Ki, derived maximum and usable cap must be
kept distinct. The previously recovered maximum writers do not alone establish
the formula for every combat-bar restriction.

Artifacts: `analysis.json`, `live-01/`, `bonus-source-01/`, `instructions-*.json`,
`rea-02/`, `rea-03/`, carrier/plan files and `tests.log`. Task-specific scripts
reuse the existing disassembler, capture reader, REA launcher and
`research/native_bonus_curve.py`; no new low-level framework was introduced.
