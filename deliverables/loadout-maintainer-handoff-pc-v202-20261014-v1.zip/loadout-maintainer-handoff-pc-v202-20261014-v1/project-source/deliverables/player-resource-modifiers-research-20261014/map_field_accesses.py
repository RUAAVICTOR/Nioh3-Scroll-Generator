"""Task-selected, bounded field-access inventory using existing native tooling.

Raw-byte prefilter -> original .pdata ranges -> existing exact operand decoder.
No process access. Limits are recorded; unrelated structures remain candidates.
"""
import bisect
import hashlib
import json
import struct
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from research.native_xrefs import parse_runtime_functions
from research.possessed_enemy_capture.inventory_record_field_accesses import inventory,literal_positions


def main():
    output=HERE/'field-accesses.json'
    if output.exists():raise FileExistsError(output)
    source=ROOT/'deliverables/load-capacity-research/disassembly/live-sections'
    text=(source/'Nioh3_v2.0.2.0.text.bin').read_bytes()
    pdata=(source/'Nioh3_v2.0.2.0.pdata.bin').read_bytes()
    if hashlib.sha256(text).hexdigest()!='4cec8fb6ad867417a76df8201c1d4f54172443884910463c1953acad91ae6c29':raise ValueError('Native code mismatch')
    functions=parse_runtime_functions(pdata);starts=[f.begin_rva for f in functions]
    results={};total=0
    for displacement in (0x3648,0x364C,0x3650,0x30BC,0x5880):
        selected={};skipped=[]
        for position in literal_positions(text,displacement):
            rva=position+0x1000;i=bisect.bisect_right(starts,rva)-1
            if i<0 or rva>=functions[i].end_rva:continue
            function=functions[i]
            if function.begin_rva in selected:continue
            size=function.end_rva-function.begin_rva
            if size>65536 or total+size>524288:
                skipped.append(dict(begin=hex(function.begin_rva),size=size));continue
            selected[function.begin_rva]=function;total+=size
        filtered=b''.join(struct.pack('<III',f.begin_rva,f.end_rva,f.unwind_rva) for f in sorted(selected.values(),key=lambda f:f.begin_rva))
        result=inventory(text,filtered,0x1000,displacement,Path('D:/Nioh3_v080_deliverables/ce-research-env/Lib/site-packages'))
        result['skipped_by_task_bounds']=skipped;results[hex(displacement)]=result
    report=dict(schema='nioh3-player-resource-modifier-field-map/v1',source_text_sha256=hashlib.sha256(text).hexdigest(),
        bounds=dict(max_function_bytes=65536,max_decoded_bytes=524288),selected_decoded_bytes=total,fields=results,
        limitation='Exact structure displacement candidates require native pointer/caller qualification; not every entry is a player resource writer')
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(decoded_bytes=total,fields={key:dict(accesses=value['validated_access_count'],writes=[entry for entry in value['entries'] if 'write' in entry['access']],skipped=value['skipped_by_task_bounds']) for key,value in results.items()})))


if __name__=='__main__':main()
