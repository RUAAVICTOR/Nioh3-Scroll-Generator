"""Passive same-process cross-check of the fixed bonus copy source."""
import hashlib
import json
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / 'deliverables/load-capacity-research/scripts')]
from scan_capacity import _identity
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from research.enemy_states_v201.capture_tables import BudgetReader


def main():
    output = HERE / 'bonus-source-01'
    output.mkdir(exist_ok=False)
    previous = json.loads((HERE / 'live-01/capture.json').read_text(encoding='utf-8'))
    report = dict(question='Does the native 556906..55692F source match player backing +5880?',
                  bounds=dict(max_bytes=4096, max_seconds=15), game_writes=0,
                  game_function_calls=0, debugger_used=False, blobs=[], status='exploratory')
    def blob(reader, name, address, size):
        raw = reader.read(address, size)
        (output / name).write_bytes(raw)
        report['blobs'].append(dict(file=name, address=hex(address), size=size,
                                   sha256=hashlib.sha256(raw).hexdigest()))
        return raw
    try:
        with ProcessReader() as process:
            identity = _identity(process)
            report['identity'] = identity
            if identity != previous['identity']:
                raise ValueError('Process identity changed')
            reader = BudgetReader(process, max_bytes=4096, max_seconds=15)
            text = (ROOT / 'deliverables/load-capacity-research/disassembly/live-sections/Nioh3_v2.0.2.0.text.bin').read_bytes()
            if hashlib.sha256(text).hexdigest() != '4cec8fb6ad867417a76df8201c1d4f54172443884910463c1953acad91ae6c29':
                raise ValueError('Source signature provenance mismatch')
            report['signatures'] = []
            for rva in (0x556118, 0x556906, 0x9AB20C, 0x8175F4):
                expected = text[rva - 0x1000:rva - 0x1000 + 16]
                actual = reader.read(process.module_base + rva, 16)
                if actual != expected:
                    raise ValueError('Signature mismatch')
                report['signatures'].append(dict(rva=hex(rva), bytes=actual.hex()))
            pointer_site = process.module_base + 0x4751860
            wrapper = reader.qword(pointer_site)
            source = reader.qword(wrapper)
            source_raw = blob(reader, 'source.bin', source, 0x104)
            backing_address = int(previous['joined']['backing'], 16) + 0x5880
            backing = blob(reader, 'backing-bonuses.bin', backing_address, 36)
            source_values = struct.unpack_from('<9i', source_raw, 0xDC)
            backing_values = struct.unpack('<9i', backing)
            actor = int(previous['joined']['actor'], 16)
            actor_aux = blob(reader, 'actor-aux.bin', actor + 0xABB0, 4)
            actor_flags = blob(reader, 'actor-flags.bin', actor, 1)
            if source_values != backing_values:
                raise ValueError('Fixed bonus source and selected backing differ')
            if (reader.qword(pointer_site) != wrapper or reader.qword(wrapper) != source
                    or reader.read(source + 0xDC, 36) != source_raw[0xDC:0x100]
                    or reader.read(backing_address, 36) != backing):
                raise ValueError('Source changed during capture')
            report.update(status='complete_passive_source_crosscheck', source_global_rva='0x4751860',
                          wrapper=hex(wrapper), source=hex(source), source_values=source_values,
                          backing_values=backing_values, actor_flags=actor_flags.hex(),
                          actor_aux_abb0=struct.unpack('<I', actor_aux)[0],
                          source_is_prior_player=(source == int(previous['player']['address'], 16)))
    except Exception as error:
        report['failure'] = str(error)
        raise
    finally:
        report['cleanup'] = 'Read-only process handle closed; no hooks, debugger or writes created'
        (output / 'capture.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({key: report[key] for key in ('status', 'source', 'source_values', 'source_is_prior_player')}))


if __name__ == '__main__':
    main()
