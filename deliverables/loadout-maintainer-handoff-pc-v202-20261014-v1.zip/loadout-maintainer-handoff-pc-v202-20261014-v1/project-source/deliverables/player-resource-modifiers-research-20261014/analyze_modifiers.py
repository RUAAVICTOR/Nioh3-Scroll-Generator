"""Hash-checked resource-effect inventory and Amrita-gauge curve replay."""
import hashlib
import json
import math
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
from research.native_bonus_curve import NativeBonusCurve
from nioh3_scroll_editor.r4_finalizer_reference import f32, f32_div, f32_mul
from nioh3_scroll_editor.r4_finalizer_resource import load_r4_finalizer_resource_for_version


def main():
    table_dir = ROOT / 'deliverables/life-reflection-stamina-research-20261014/native-tables-01'
    tables = json.loads((table_dir / 'capture.json').read_text(encoding='utf-8'))
    table_blobs = {b['filename']: b for b in tables['blobs']}
    def table_blob(name):
        raw = (table_dir / name).read_bytes()
        meta = table_blobs[name]
        if len(raw) != meta['size'] or hashlib.sha256(raw).hexdigest() != meta['sha256'].lower():
            raise ValueError('Table blob integrity mismatch')
        return raw
    raw_rows = [table_blob(r['blob']['filename']) for r in tables['bonus_curve']['rows']]
    resource = load_r4_finalizer_resource_for_version((2, 0, 2, 0))
    if not all(raw == resource.bonus_curve_entry(i).row for i, raw in enumerate(raw_rows)):
        raise ValueError('Native/resource curve parity failed')
    curve = NativeBonusCurve(raw_rows)
    native_text_path = ROOT / 'deliverables/clan-protection-catalog-20261010/native-extraction/native-text-01.json'
    text_raw = native_text_path.read_bytes()
    text = json.loads(text_raw)
    if text['executable_sha256'] != tables['identity']['executable_sha256']:
        raise ValueError('Text source executable mismatch')
    groups = next(t for t in tables['tables'] if t['name'] == 'effect_group')
    group_rows = table_blob('tables/effect_group/rows.bin')
    labels = {}
    for key in (0x0860, 0xB1B6, 0x7F69, 0x5D3A, 0xB95E):
        index = groups['native_keys'][hex(key)]
        row = group_rows[8 + index * 0x70:8 + (index + 1) * 0x70]
        resolved = []
        for offset in range(0, 0x70, 4):
            text_id = struct.unpack_from('<I', row, offset)[0]
            entry = text['entries'].get(str(text_id))
            if entry and entry['text']:
                raw = bytes.fromhex(entry['raw_hex'])
                if hashlib.sha256(raw).hexdigest() != entry['sha256']:
                    raise ValueError('Localization record digest mismatch')
                resolved.append(dict(offset=hex(offset), text_id=hex(text_id), text=entry['text']))
        labels[hex(key)] = dict(row_index=index, raw_hex=row.hex(), resolved_native_text=resolved,
                               merge_flags=row[0x50])
    guardian_path = ROOT / 'deliverables/guardian-spirit-catalog-20261008/guardian_spirits_native.json'
    guardian_raw = guardian_path.read_bytes()
    if hashlib.sha256(guardian_raw).hexdigest() != '9dc1279cf31e500b93c26d8f7ed590cc118daa8e2a9b7b3948e0c8212d894e81':
        raise ValueError('Guardian source identity changed')
    guardians = json.loads(guardian_raw)
    for entry in guardians['effect_groups']:
        if hex(entry['id']) in labels and entry['raw_hex'] != labels[hex(entry['id'])]['raw_hex']:
            raise ValueError('Guardian/current effect group bytes differ')
    guardian_sources = [dict(name=g['name_zh'], guardian_id=g['guardian_id'], style=g['style'],
                             slot=s['slot'], effect_group=hex(s['effect_group_id']),
                             base=s['base_value'], raw_growth_parameter=s['growth_value'],
                             activation_requirement=s['activation_requirement'],
                             raw_at_level_index0=s['raw_values_by_level_index'][0])
                        for g in guardians['guardians'] for s in g['slots']
                        if hex(s['effect_group_id']) in labels]
    live_dir = HERE / 'live-01'
    live = json.loads((live_dir / 'capture.json').read_text(encoding='utf-8'))
    if live['status'] != 'complete_passive_snapshot' or live['identity'] != tables['identity']:
        raise ValueError('Qualified same-process snapshot required')
    blobs = {}
    for meta in live['blobs']:
        raw = (live_dir / meta['file']).read_bytes()
        if len(raw) != meta['size'] or hashlib.sha256(raw).hexdigest() != meta['sha256']:
            raise ValueError('Live blob digest mismatch')
        blobs[meta['file']] = raw
    backing = blobs['stat-backing.bin']
    offset = 0x4728 if live['joined']['owner_style'] == 1 else 0x35D0
    count = struct.unpack_from('<I', backing, offset + 0xC00)[0]
    if count > 256:
        raise ValueError('Effect list capacity exceeded')
    active = []
    for i in range(count):
        p = offset + i * 12
        key, value, auxiliary = (struct.unpack_from('<H', backing, p)[0],
                                 struct.unpack_from('<i', backing, p + 4)[0],
                                 struct.unpack_from('<H', backing, p + 8)[0])
        if hex(key) in labels:
            active.append(dict(id=hex(key), value=value, auxiliary=auxiliary))
    status = blobs['status.bin']
    gauge_current = struct.unpack_from('<f', status, 0x148 + 0x14)[0]
    gauge_maximum = struct.unpack_from('<i', status, 0x148 + 0x18)[0]
    ratio = max(f32(0), min(f32(1), f32_div(gauge_current, gauge_maximum))) if gauge_maximum > 0 else f32(0)
    point = math.trunc(f32_mul(ratio, 1000))
    grade_labels = ['D-', 'D', 'D+', 'C-', 'C', 'C+', 'B-', 'B', 'B+', 'A-', 'A', 'A+', 'AA-', 'AA', 'AA+', 'AAA-', 'AAA', 'AAA+']
    predictions = []
    for selector, label in enumerate(grade_labels):
        samples = []
        for p in (0, 250, 500, 750, 1000):
            value = curve.evaluate(0xCBE1, p, selector)
            samples.append(dict(point=p, curve_float=value, extra_ki=math.trunc(value) & 0xFFFFFFFF))
        predictions.append(dict(selector=selector, label=label, predictions=samples))
    report = dict(schema='nioh3-player-resource-modifiers-analysis/v1', identity=live['identity'],
        checks=dict(all_native_curve_rows_match_resource=True, all_consumed_blob_hashes_match=True),
        native_text_source_sha256=hashlib.sha256(text_raw).hexdigest(),
        effect_groups=labels, active_maximum_effects=active,
        prior_native_guardian_sources=guardian_sources,
        current_snapshot=live['joined'],
        owner_kind24=struct.unpack_from('<I', status, 0x24)[0],
        current_gauge=dict(current=gauge_current, maximum=gauge_maximum, ratio=ratio, curve_point=point,
                           gate=live['joined']['ki_additive_gate']),
        amrita_ki_curve=dict(key='0xcbe1', rows=[dict(index=i, point=r.point, samples=r.samples)
                            for i, r in enumerate(curve.rows) if r.key == 0xCBE1], grades=predictions),
        limitations=['Gauge curve predictions require active B95E and effective grade; current gate is inactive.',
                     'Existing capture question text mentions an earlier negative control; raw current values and new task report identify this positive state.',
                     'Only primary maximum-stat effect fields are inventoried here; recovery, expenditure, erosion and current amounts are separate consumers.'])
    native = (ROOT / 'deliverables/load-capacity-research/disassembly/live-sections/Nioh3_v2.0.2.0.text.bin').read_bytes()
    if hashlib.sha256(native).hexdigest() != '4cec8fb6ad867417a76df8201c1d4f54172443884910463c1953acad91ae6c29':
        raise ValueError('Instruction provenance mismatch')
    instruction_count = byte_count = 0
    for path in sorted(HERE.glob('instructions-*.json')):
        for function in json.loads(path.read_text(encoding='utf-8'))['functions']:
            for ins in function['instructions']:
                raw = bytes.fromhex(ins['bytes_hex'])
                offset = int(ins['rva'], 16) - 0x1000
                if native[offset:offset + len(raw)] != raw:
                    raise ValueError('Instruction byte parity mismatch')
                instruction_count += 1
                byte_count += len(raw)
    sessions = []
    for directory, ordinal in (('rea-02', 13), ('rea-03', 12)):
        completion = json.loads((HERE / directory / 'completion.json').read_text(encoding='utf-8'))
        session = json.loads((HERE / directory / f'{ordinal:03d}-binary_session.json').read_text(encoding='utf-8'))
        if completion['status'] != 'complete' or session['structuredContent']['result']['open']:
            raise ValueError('REA session not cleanly closed')
        sessions.append(directory)
    report['checks'].update(instruction_count=instruction_count, instruction_bytes=byte_count,
                            all_instruction_bytes_match=True, closed_rea_sessions=sessions)
    (HERE / 'analysis.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(dict(active=active, gauge=report['current_gauge'], kind24=report['owner_kind24'],
                         named={key: value['resolved_native_text'] for key, value in labels.items()},
                         curve_rows=report['amrita_ki_curve']['rows']), ensure_ascii=False))


if __name__ == '__main__':
    main()
