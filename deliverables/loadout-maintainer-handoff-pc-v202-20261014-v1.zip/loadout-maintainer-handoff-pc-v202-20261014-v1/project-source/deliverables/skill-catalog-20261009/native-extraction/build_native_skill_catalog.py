"""Build and validate planner data only from retained native game evidence."""
import collections
import hashlib
import json
import math
import struct
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE = Path(__file__).resolve().parent
OUT = HERE.parent
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda b: hashlib.sha256(b).hexdigest()
sources = set()
proofs = []
capture = load(HERE / 'native-skills-03/capture.json')

def source(relative):
    sources.add(relative)
    return HERE / relative

def verified_blob(directory, entry):
    raw = source(directory + '/' + entry['filename']).read_bytes()
    assert len(raw) == entry['size'] and digest(raw).upper() == entry['sha256'].upper()
    return raw

def tables(directory):
    report = load(source(directory + '/capture.json'))
    assert report['status'] == 'complete_native_table_capture'
    assert report['executable_sha256'] == capture['executable_sha256']
    assert report['game_writes'] == report['native_function_calls'] == 0
    result = {}
    for table in report['tables']:
        assert table['stable'] and table['hash_index_and_row_keys_agree']
        raw = verified_blob(directory, table['rows_blob'])
        verified_blob(directory, table['context_blob'])
        hash_context = verified_blob(directory, table['hash']['context_blob'])
        index = verified_blob(directory, table['hash']['entries_blob'])
        sentinel = struct.unpack_from('<I', hash_context, 4)[0]
        count, stride, key_offset = table['row_count'], table['row_size'], table['key_offset']
        assert count == 1101 and len(raw) == 8 + count * stride
        keys = {i: k for k, i in struct.iter_unpack('<II', index) if k != sentinel and i < count}
        assert len(keys) == count
        records = {}
        for i in range(count):
            row = raw[8 + i * stride:8 + (i + 1) * stride]
            key = struct.unpack_from('<H', row, key_offset)[0]
            assert keys[i] == key and key not in records
            records[key] = (i, row)
        result[table['name']] = records
    assert set(result['skill']) == set(result['skill_text'])
    return result

primary = tables('native-skills-03')
restart = tables('native-skills-04')
assert primary == restart, 'Native table rows changed across restart'

def function(directory, begin, requirements):
    report = load(source(directory + '/capture.json'))
    assert report['executable_sha256'] == capture['executable_sha256']
    assert report['game_writes'] == 0
    entry = next(f for f in report.get('functions', report.get('code_consumers', [])) if int(f['begin'], 0) == begin)
    filename = entry.get('path', f'{begin:X}.bin')
    raw = source(directory + '/' + filename).read_bytes()
    expected = entry.get('sha256') or next(b['sha256'] for b in report['blobs'] if b['path'] == filename)
    assert digest(raw) == expected.lower()
    decoded = {i.address: f'{i.mnemonic} {i.op_str}'.rstrip() for i in Cs(CS_ARCH_X86, CS_MODE_64).disasm(raw, begin)}
    for ins in entry['instructions']:
        assert decoded[int(ins['rva'], 0)] == ins['instruction'].rstrip()
    for required in requirements:
        assert any(required in value for value in decoded.values()), (hex(begin), required)
    proofs.append({'function_rva': hex(begin), 'source': directory + '/' + filename,
                   'sha256': digest(raw), 'verified_instructions': requirements})

function('cost-sort-functions-01', 0x1E82E88, ['movss xmm0, dword ptr [r14 + 0x84]', 'movss xmm1, dword ptr [r15 + 0x84]'])
function('skill-menu-fields-03', 0x22D8164, ['cmp ecx, 2', 'cmp ecx, 3', 'cmp ecx, 4'])
function('skill-menu-fields-03', 0x22D1134, ['0x7c'])
function('skill-detail-functions-05', 0x1BBDF64, ['[r15 + 0xc]', '0x3e994f1'])
function('skill-detail-functions-05', 0x1BB0124, ['0xb9', '0x84'])
function('skill-name-functions-04', 0x216B22C, ['0xac', 'call 0x1bb0124'])
function('skill-color-consumers-08', 0x1F6FB78, [
    'cmp word ptr [r13 + 0xa0], ax', 'mov eax, 4', 'mov ecx, 0x3e91ade',
    'mov al, byte ptr [rax + 0xb9]', 'mov byte ptr [rsp + 0x30], al',
    '[rcx + rax*4 + 0x3bd9d58]', 'test byte ptr [r13 + 0x1c], al'])
function('skill-lookup-functions-02', 0x1E83A30, [
    'mov cl, byte ptr [rax + 0xb9]', 'test cl, 0xfd',
    'movsx edi, byte ptr [rax + 0xac]', 'call 0x22d1134'])

entries = {}
for filename in ['skill-native-text-tree-07.json', 'skill-type-label-tree-08.json', 'skill-category-label-tree-09.json']:
    report = load(source(filename))
    assert report['status'] == 'complete_native_text_tree_capture'
    assert report['executable_sha256'] == capture['executable_sha256']
    assert report['game_writes'] == report['native_function_calls'] == 0
    assert report['process_handle_closed']
    for key, entry in report['entries'].items():
        assert entry['found']
        raw = bytes.fromhex(entry['raw_hex'])
        native_id, units = struct.unpack_from('<II', raw)
        assert native_id == int(key) and len(raw) == 8 + units * 2
        assert raw[-2:] == b'\0\0' and raw[8:-2].decode('utf-16le') == entry['text']
        assert digest(raw) == entry['sha256']
        entries[int(key)] = entry
    for prefix in report['color_prefixes']:
        assert bytes.fromhex(prefix['raw_hex'])[:-2].decode('utf-16le') == prefix['text']
assert entries[0x3E91ADE]['text'] == '精髓'
assert entries[0x3D1D356]['text'] == '常驻'
assert entries[0x3E994F1]['text'] == ''
static = load(source('skill-static-label-tables.json'))
assert static['executable_sha256'] == capture['executable_sha256']
for table in static['ranges']:
    raw = bytes.fromhex(table['raw_hex'])
    assert digest(raw) == table['sha256']
    assert list(struct.unpack('<' + 'I' * (len(raw) // 4), raw)) == table['u32']
subtypes = next(t['u32'] for t in static['ranges'] if int(t['rva'], 0) == 0x3BD9D58)
assert subtypes[1] == 0x3D1D356
categories = next(t['u32'] for t in static['ranges'] if int(t['rva'], 0) == 0x39778E8)
assert [categories[i] for i in (0, 4, 8)] == [23, 21, 22]
assert [entries[categories[i]]['text'] for i in (1, 5, 9)] == ['共通技能', '武士技能', '忍者技能']

category_map = {23: ('common', '共通技能'), 21: ('samurai', '武士技能'), 22: ('ninja', '忍者技能')}
skills, excluded = [], []
for key, (index, row) in primary['skill'].items():
    category = struct.unpack_from('<b', row, 0xAC)[0]
    if category not in category_map or row[0xB9] not in (1, 3):
        continue
    mi, meta = primary['skill_text'][key]
    name_id, desc_id, suffix = struct.unpack_from('<III', meta, 0xC)
    rank = struct.unpack_from('<I', meta, 4)[0]
    rarity = struct.unpack_from('<H', row, 0xA0)[0]
    flags = struct.unpack_from('<I', row, 0x1C)[0]
    cost = struct.unpack_from('<f', row, 0x84)[0]
    if meta[0x7C]:
        excluded.append({'id': key, 'exclusion_reason': 'native_hidden_menu_record',
                         'category': category_map[category][0], 'name_text_id': name_id,
                         'name': entries[name_id]['text'] if name_id in entries else None,
                         'definition_index': index, 'metadata_index': mi,
                         'definition_raw_hex': row.hex(), 'metadata_raw_hex': meta.hex()})
        continue
    assert row[0xB9] == 1 and suffix == 0 and rank == 1 and not flags & 0x41
    assert rarity in range(5) and math.isfinite(cost) and cost >= 0 and cost.is_integer()
    name = entries[name_id]['text'] if name_id in entries else None
    assert name_id == 0 or name_id in entries
    type_id = 0x3E91ADE if rarity == 4 else subtypes[row[0xB9]]
    color_index = {2: 1, 3: 2, 4: 3}.get(rarity, 0)
    category_key, category_label = category_map[category]
    item = {'id': key, 'name': name, 'cost': int(cost),
            'category': category_key, 'category_label': category_label,
            'budget': category_key,
            'active_styles': ['samurai', 'ninja'] if category_key == 'common' else [category_key],
            'rarity_native': rarity, 'rarity_tag': ['RARITY_C', 'RARITY_B', 'RARITY_A', 'RARITY_S'][color_index],
            'color_index_native': color_index,
            'type': 'essence' if rarity == 4 else 'permanent', 'type_label': entries[type_id]['text'],
            'type_text_id': type_id, 'name_text_id': name_id, 'description_text_id': desc_id,
            'source': {'definition_index': index, 'metadata_index': mi,
                       'definition_row_sha256': digest(row), 'metadata_row_sha256': digest(meta),
                       'name_record_sha256': entries[name_id]['sha256'] if name_id in entries else None,
                       'rank_native': rank, 'hidden_native': meta[0x7C],
                       'flags_native': flags, 'name_suffix_selector_native': suffix}}
    reason = 'empty_native_name' if not name else 'native_placeholder_name' if name in ('SKILL NAME DUMMY', '^13~UNUSED~') else None
    if reason:
        item['exclusion_reason'] = reason
        excluded.append(item)
    else:
        skills.append(item)
skills.sort(key=lambda r: (['common', 'samurai', 'ninja'].index(r['category']), -r['cost'], r['id']))
assert len(skills) == 149 and len(excluded) == 52
counts = dict(collections.Counter(s['category'] for s in skills))
anchors = {22753: (10, 'common', 4), 43788: (8, 'samurai', 3), 47426: (8, 'ninja', 4),
           61055: (9, 'common', 4), 34689: (8, 'common', 4), 64786: (6, 'ninja', 4),
           8238: (6, 'common', 3), 58475: (8, 'common', 3)}
for key, expected in anchors.items():
    row = next(s for s in skills if s['id'] == key)
    assert (row['cost'], row['category'], row['rarity_native']) == expected
catalog = {'schema': 'nioh3-native-skill-catalog/v1', 'status': 'validated_native_definitions',
           'game_version': capture['game_version'], 'executable_sha256': capture['executable_sha256'],
           'scope': 'Named, non-placeholder definitions passing the native category/subtype/hidden filters; player unlock state is not included.',
           'category_counts': counts, 'type_counts': dict(collections.Counter(s['type'] for s in skills)),
           'budget_policy': {'independent': ['common', 'samurai', 'ninja'], 'capacities': None,
                             'capacity_note': 'Player-dependent capacities must be supplied separately.'},
           'applicability_evidence': 'Owner-specified style applicability; native budget accumulation filters category independently.',
           'rarity_note': 'Native ranks 0 and 1 share RARITY_C; preserve rarity_native when importing.',
           'zero_cost_note': 'Two named definitions have native COST 0 and flags 0x80000. They remain in the catalog without assuming player availability or selectable status.',
           'not_included': ['player unlock/ownership state', 'pairwise skill incompatibilities', 'assembled effect descriptions'],
           'skills': skills}
(OUT / 'skills_native.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(OUT / 'skills_excluded_native.json').write_text(json.dumps({'schema': 'nioh3-native-skill-exclusions/v1', 'records': excluded}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
validation = {'status': 'passed', 'definition_rows': 1101, 'metadata_rows': 1101,
              'full_native_hash_index_agreement': True, 'stable_capture_and_restart_row_parity': True,
              'named_skills': len(skills), 'category_counts': counts,
              'excluded_counts': dict(collections.Counter(r['exclusion_reason'] for r in excluded)),
              'native_text_records_validated': len(entries), 'independent_screenshot_anchor_matches': len(anchors),
              'zero_cost_named_definitions': [{'id': s['id'], 'name': s['name']} for s in skills if s['cost'] == 0],
              'function_proofs': proofs,
              'sources': [{'path': 'native-extraction/' + p, 'sha256': digest((HERE / p).read_bytes())} for p in sorted(sources)]}
(OUT / 'validation.json').write_text(json.dumps(validation, indent=2) + '\n')
lines = ['# Native Nioh 3 skill catalog — PC v2.02', '',
         'The catalog contains 149 named native definitions. Inputs are game process table bytes,',
         'keyed Chinese text records and native executable code. No community/Wiki text or',
         'screenshot transcription is used as an input. Eight owner screenshot anchors are',
         'independent checks only. Full table rows match across two captures and a game restart.', '',
         '`skills_native.json` is the planner input. Use native IDs as keys, never display names.',
         '`skills_excluded_native.json` retains 31 hidden records, 7 blank names and 14 explicit',
         'DUMMY/UNUSED placeholders. Some hidden names were not requested from the text tree.',
         '`validation.json` pins source digests and the native consumer checks.', '',
         'Common, Samurai and Ninja have independent budgets. Common applies to both styles;',
         'style-specific skills apply to their corresponding style. Capacity and unlock state',
         'are player data and are not encoded here. Style applicability follows the owner\'s',
         'explicit game observation; independent category accumulation is checked in native code.', '',
         'Native rarity ranks 0/1 both map to RARITY_C, 2 to B, 3 to A and 4 to S.',
         'The detail renderer selects native text “精髓” for rank 4; subtype 1 otherwise',
         'selects native text “常驻”. Labels are captured from the game text tree.',
         'Pairwise compatibility, essence concurrency limits and assembled effect descriptions',
         'need separate inputs before a complete planner can validate every combination.', '',
         'The native definitions for 瞬间格挡之法 and 极限识破之法 have COST 0 and flags',
         '0x80000. Preserve these values; catalog membership does not prove player availability',
         'or whether a skill is manually selectable. No replacement COST is inferred.', '',
         'Rebuild through the project Python runner with',
         '`-ScriptPath deliverables/skill-catalog-20261009/native-extraction/build_native_skill_catalog.py`.', '',
         '| ID | Name | Category | COST | Native rarity | Native color tag | Type |',
         '| ---: | --- | --- | ---: | ---: | --- | --- |']
for row in skills:
    lines.append(f"| {row['id']} | {row['name']} | {row['category_label']} | {row['cost']} | {row['rarity_native']} | {row['rarity_tag']} | {row['type_label']} |")
(OUT / 'README.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps({k: validation[k] for k in ['status', 'named_skills', 'category_counts', 'excluded_counts']}, ensure_ascii=True))
