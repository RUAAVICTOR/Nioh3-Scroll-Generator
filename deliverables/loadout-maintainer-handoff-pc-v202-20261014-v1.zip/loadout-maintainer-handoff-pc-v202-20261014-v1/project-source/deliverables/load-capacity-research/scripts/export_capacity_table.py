"""Validate raw rows and scoped runtime evidence, then export a capacity-only table."""

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--table', type=Path, required=True)
    parser.add_argument('--native', type=Path, required=True)
    parser.add_argument('--recovery', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    table = json.loads(args.table.read_text(encoding='utf-8'))
    raw = args.table.with_suffix('.bin').read_bytes()
    if hashlib.sha256(raw).hexdigest() != table['table_sha256']:
        raise RuntimeError('Raw table digest mismatch')
    if len(raw) != 8 + 32 * table['table_count'] or len(table['rows']) != table['table_count']:
        raise RuntimeError('Table size mismatch')
    for i, row in enumerate(table['rows']):
        if row['index'] != i or bytes.fromhex(row['hex']) != raw[8+i*32:8+(i+1)*32]:
            raise RuntimeError('Row/raw disagreement')
        if any(value != int.from_bytes(raw[8+i*32+j*2:10+i*32+j*2], 'little')
               for j, value in enumerate(row['u16'])):
            raise RuntimeError('Decoded u16/raw disagreement')
    native = json.loads(args.native.read_text(encoding='utf-8'))
    recovery = json.loads(args.recovery.read_text(encoding='utf-8'))
    if recovery['run_id'] != native['run_id'] or recovery['verified'] is not True:
        raise RuntimeError('Native cleanup not proven')
    cleanup = recovery['cleanup']
    if cleanup['breakpoints'] or cleanup['probe']['owned_breakpoints'] or cleanup['probe']['timer_active']:
        raise RuntimeError('Resources remain owned')
    if table['pid'] != native['target']['pid'] or table['birth_filetime'] != native['target']['birth_filetime']:
        raise RuntimeError('Evidence from different process births')
    events = native['bridge_snapshot']['events']
    counts = Counter()
    pending = {}
    pairs = []
    for event in events:
        style = event['style_field']
        stamina = event['effective_stamina']
        if style not in (0, 1) or not event['attributes_match_player'] or stamina != 5:
            raise RuntimeError('Unqualified native event')
        expected = table['rows'][stamina]['u16'][4+style]
        observed = event['pending_base'] if event['stage']=='base_before_store' else event['capacity_before_or_final']
        if observed != expected:
            raise RuntimeError('Native/table mismatch')
        counts[f"style_{style}_{event['stage']}"] += 1
        key = (event['stat'], event['owner'], style, stamina)
        if event['stage']=='base_before_store':
            pending[key] = event['sequence']
        elif key in pending:
            pairs.append({'base_sequence': pending.pop(key), 'final_sequence': event['sequence'],
                          'stat': event['stat'], 'style_field': style, 'raw_capacity': expected})
    if len(counts) != 4 or len(pairs) < 16:
        raise RuntimeError('Missing native style/stage controls')
    ui_grid = {5: (295, 141), 40: (484, 228), 80: (537, 247), 99: (558, 252)}
    if any(tuple(table['rows'][i]['u16'][4:6]) != expected for i, expected in ui_grid.items()):
        raise RuntimeError('Historical eight-point UI grid mismatch')
    rows = [{'stamina': i, 'samurai_raw_tenths': table['rows'][i]['u16'][4],
             'ninja_raw_tenths': table['rows'][i]['u16'][5],
             'samurai_capacity': f"{table['rows'][i]['u16'][4]//10}.{table['rows'][i]['u16'][4]%10}",
             'ninja_capacity': f"{table['rows'][i]['u16'][5]//10}.{table['rows'][i]['u16'][5]%10}"}
            for i in range(1, table['table_count'])]
    monotone = all(rows[i][name] >= rows[i-1][name] for i in range(1, len(rows))
                   for name in ('samurai_raw_tenths', 'ninja_raw_tenths'))
    plateau = all(row['samurai_raw_tenths']==573 and row['ninja_raw_tenths']==273 for row in rows if row['stamina']>=200)
    report = {
        'schema': 'nioh3-stamina-base-capacity-table/v1',
        'scope': 'PC v2.02 exact executable; base capacity without modifiers',
        'evidence_grades': {'rows': 'native-table', 'column_selection': 'native-control-flow and observed native outputs at stamina 5',
                            'display_unit': 'observed UI agreement for eight values; UI formatter not traced'},
        'executable_sha256': table['exe_sha256'],
        'source_table_sha256': table['table_sha256'],
        'source_files': [str(args.table), str(args.native), str(args.recovery)],
        'native_lookup': {'function_rva': '0x818AEC', 'input_type': 'signed i32', 'clamp': [1, 999],
                          'row_stride': 32, 'header_bytes': 8, 'row_count': table['table_count'],
                          'samurai_u16_offset': '0x08', 'ninja_u16_offset': '0x0A',
                          'column_selection_rva': '0x818F07', 'selector': '[stat.owner + 0x2C]',
                          'selector_mapping': {'0': 'samurai column', 'nonzero': 'ninja column'},
                          'store_rva': '0x818F1B', 'output_offset': 'stat + 0x7B4', 'output_type': 'u32'},
        'replay': {'base_raw': 'rows[clamp(stamina, 1, 999)][style + _raw_tenths]',
                   'observed_display': 'base_raw / 10', 'calculation': 'table lookup; no interpolation at this consumer'},
        'checks': {'raw_bytes': len(raw), 'ui_points_passed': 8, 'runtime_events_passed': len(events),
                   'runtime_stage_counts': dict(counts), 'same_object_base_final_pairs': pairs,
                   'monotone': monotone, 'rows_200_through_999_plateau': plateau, 'cleanup_verified': True},
        'limits': ['The engine computed both selector variants within one second; no user style-switch timing claim.',
                   'Selector belongs to each calculation owner and is not proven to be the current combat-style flag.',
                   'Only stamina 5 has new base/final runtime pairing. 40/80/99 use earlier operator UI observations.',
                   '100/150/200 and out-of-playable-range rows are native table values, not live character validation.',
                   'Modifier composition and UI rounding for modified capacities remain unverified.',
                   'Rows 1..4 are native entries; reachability in normal gameplay is not claimed.'],
        'rows': rows,
    }
    args.output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'output': str(args.output), 'rows': len(rows), 'ui_points_passed': 8,
                      'native_events': len(events), 'paired_events': len(pairs),
                      'monotone': monotone, 'plateau_from_200': plateau}))


if __name__=='__main__':
    main()
