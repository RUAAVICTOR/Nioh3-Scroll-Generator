# Guardian-spirit native dataset — PC v2.02

The accepted dataset is **guardian_spirits_native.json**. It was extracted
read-only from the owner's running Nioh 3 process. The executable is version
2.0.2.0, SHA-256
`e22c4a635e4ec1e27a177b76e27d7f6a637f426c0ed3928b60f5693bc52ae130`.
Community/Wiki material and screenshot transcriptions are not build inputs.

## Delivery

- `guardian_spirits_native.json`: 22 current style/form records (10 Samurai,
  12 Ninja), all 110 complete fixed effects, native guardian/group/text IDs,
  descriptions, formatting, base/growth values, selectors and thresholds.
  Includes all 52 original rows, 101 growth rows, and raw row bytes/hashes.
- `guardian_semantics_native.json`: destroyed-spike activation requirements,
  the other-style guardian gate, numeric/grade attribute merge rules, native
  control-flow proofs and scoped live verification.
- `guardian_spirits_native.md`: complete readable table with calculated
  values at native level inputs 1, 10 and 40.
- `native_validation.json`: hashes, native joins, 11,110 independently
  calculated values, and 110/110 matches with the separately retained UI
  verification reference. A second native capture is byte-identical.
- `native-extraction/`: original parameter blobs, current native Chinese
  text bytes, grade labels, captured runtime machine code and reproducible
  extraction/export scripts. Failed discovery captures remain preserved.

## Native reference chain

The parameter manager is reached through module RVA `0x45B9E30`. Its
`+0x3F0` context contains 52 guardian rows of stride `0x100`; guardian lookup
RVA `0x3748E0` uses the keyed hash index. Row key is `+0x24`, native name text
ID is `+0x2C`. Slot reader `0x37522C` reads six triples at `+0x6C` and six
sidecar pairs at `+0xC4`. Current player records use five nonzero slots.

The slot IDs reference **effect groups**, not equipment effect IDs. Effect
groups come from manager `+0xA8`, 1,152 rows of stride `0x70`. Formatter
`0x1BBE2B0` joins the name template with native buff/debuff substitutions;
`0x1BC1A08` handles units, decimal places and grades. All final labels are
complete, including the five previously truncated on-screen strings.

Growth evaluator `0x374E74` reads manager `+0x408`, 101 rows of stride `0x40`.
Selectors **0..5** address six u16 coefficients at `+0x2A..+0x34`; other
selectors use 1. The JSON retains the exact float32 multiplier and reproduces
the native integer multiply, float32 conversion/multiply and truncation.
Grade selector `0x22CE144` indexes 18 native grade strings at RVA `0x3BDD2E0`.

Native UI consumer `0x1D77384` tests style mask 1 (Samurai) or 2 (Ninja),
then checks ownership. The current 22 named style/form records also have
flag bit 4. The roster filter describes this capture, rather than claiming
that bit 4 universally means selectable. Internal/legacy rows are retained
in `native_records` and excluded from the current planner roster.

## Planner contract

Use `guardian_id` as identity. Names alone cannot distinguish style/form
records, especially the four Kusanagi records. IDs `0x00DB`/`0x0187` and
`0x00F7`/`0x01CD` have different fixed slots. Initial/enhanced aliases are
UI verification labels, not native name suffixes.

`raw_values_by_level_index` and `display_values_by_level_index` are indexed
directly by the native guardian-level input. Fixed slot membership does not
imply a constant number: many values grow with guardian level. Available
indices 0..100 do not establish the legal maximum guardian level.

`activation_threshold` is the required **destroyed Crucible Spike count**
(native Chinese: 地狱之楔破坏数). `activation_requirement` gives the explicit
kind and count. RVA `0x375364` uses an unsigned u16 `>=` comparison. Native
UI reads player `+0x148`; gameplay uses its copied `+0x72` field. Recompute
`0x21A2604` counts collected spike flags from manager `+0x630` across the
game-supplied playthrough/difficulty range and writer `0x217DF90` stores the
result. Native tutorial `0x04319D1E` and UI label `0x03E16EF1` identify its
meaning. The observed count was 84. This is separate from guardian level.

The other-style guardian contribution path checks effect group `0x8508`,
whose actual native name is **双灵庇佑**. Its native description is
“可同时获得两种风格的守护灵的特殊效果。” The getter must return a signed
nonnegative value; absence returns -1, while a present value of 0 qualifies.
The owner identified this as a set bonus. The native set-to-effect join,
set name and piece requirement have not yet been extracted. Do not silently
include both styles by default. A previous conversational name, 双守精元,
was a reading error and is not a native name.

`effect_groups[].aggregation` retains native cap and grade metadata. Shared
merge RVA `0x557BA0` accumulates numeric duplicates, with the native signed
cap at group `+4` enabled when nonnegative. Grade duplicates retain the best
raw rank and add one rank step for each duplicate occurrence. The getter
returns base plus the u16 extra field. These are same-group, same-bucket
attribute rules; matching display labels alone are not sufficient identity.

Live verification captured **57/57 numeric duplicate updates**, all for
group `0x3B0E` (幸运). This does not verify every source pair, caps, final
committed character totals or damage. Grade merging is recovered native
control flow; the bounded grade-only observation captured zero events and
does not establish live grade acceptance.

All 104 guardian groups have retained dispatch routes and application
leaves from RVA `0x819400`. Several hidden-display effects enable native
boolean fields at this stage. Empty displayed values and raw growth values
must not be interpreted as triggered buff strength or duration. Buff
instance stacking, duration, refresh/overwrite and final combat formulas
remain separate research questions.

## Rebuild and verify

Run from the repository root with the approved project runner. Before the
catalog builder, run `trace_group_dispatch.py` and `build_native_semantics.py`
through the same runner to regenerate the offline semantics artifacts:

```powershell
./tools/run_python_tests.ps1 -Python 'D:/Nioh3_v080_deliverables/ce-research-env/Scripts/python.exe' -MinimumFreeGiB 0 -ScriptPath 'deliverables/guardian-spirit-catalog-20261008/native-extraction/build_native_catalog.py'
./tools/run_python_tests.ps1 -Python 'D:/Nioh3_v080_deliverables/ce-research-env/Scripts/python.exe' -MinimumFreeGiB 0 -ScriptPath 'deliverables/guardian-spirit-catalog-20261008/native-extraction/validate_native_catalog.py'
```

The builder needs no running game or network. The validator reads the old UI
transcriptions only for post-build cross-checks; they cannot fill native data.
Native observations retained process birth, executable hash and function
signatures. Captures wrote no game state. The task-owned observer was stopped,
and its owned breakpoint/timer inventories were verified empty.

## Superseded references

`guardian_spirits.json`, `guardian_spirits.md`, the CSV, `source_manifest.json`
and `validation.json` describe the earlier UI verification dataset, not the
accepted native export. `live/` preserves that evidence.
`historical_mixed_reference/`, `sources/` and earlier public-research scripts
are traceability material and never participate in the native build.
