# Guardian-spirit effects observed in the local game

Verification reference only. Not the accepted native dataset for the build planner.
Source: 23 retained game screenshots, captured on 2026-10-08; executable version 2.0.2.0.
22 style/form entries, 110 ordered slots; all values retain their actual observed level.
105 complete labels and five truncated labels. Ellipses are preserved from the UI.
No community, Wiki, guide, or public workbook data is included in this table.
Native table exhaustiveness, IDs, level curves and calculation rules remain unverified.

## 草薙 · 武士 初始形态（本地标记）

Local key: `kusanagi_initial_samurai`. Observed level: 1.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 武技伤害 | +6.3% | Yes |
| 2 | 火属性伤害降低 | +13 | Yes |
| 3 | 残心精力恢复量 | +10.8% | Yes |
| 4 | 琢技造成的伤害增加倍率 | +6.9% | Yes |
| 5 | 武技灵力增加量 | +11.0% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/kusanagi-initial-samurai-lv1-panel.png>)

## 丛云 · 武士 

Local key: `murakumo_samurai`. Observed level: 10.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 敌人的雷状态累积 | +7.8% | Yes |
| 2 | 使敌人陷入雷状态时精华槽增加 | C+ | Yes |
| 3 | 守护灵技命中赋予昂灵 | — | Yes |
| 4 | 追击与近身刺击延长正面效果持续时… | +5.2% | No |
| 5 | 九十九化身时的耐久力 | +6.5% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/murakumo-samurai-lv10-panel.png>)

## 金刚狮子 · 武士 

Local key: `kongojishi_samurai`. Observed level: 40.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 格挡成功时赋予造成伤害增加 | — | Yes |
| 2 | 风属性伤害 | +12.0% | Yes |
| 3 | 体力 | +432 | Yes |
| 4 | 承受的伤害降低（攻击动作期间） | -12.0% | Yes |
| 5 | 防御精力消耗降低（绝境） | -22.8% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/kongojishi-samurai-lv40-panel.png>)

## 凰 · 武士 

Local key: `oh_samurai`. Observed level: 6.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 灵力增加量反映（精华槽） | A- | Yes |
| 2 | 防御精力消耗降低 | -8.6% | Yes |
| 3 | 吸收精华可恢复体力 | 11 | Yes |
| 4 | 格挡成功时赋予精力恢复速度增… | — | No |
| 5 | 道具掉落率 | +17.0% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/oh-samurai-lv6-panel.png>)

## 成釜狸 · 武士 

Local key: `narikama_tanuki_samurai`. Observed level: 4.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 死亡时自动回收一部分精华 | +15.0% | Yes |
| 2 | 不消耗仙药 | +11.6% | Yes |
| 3 | 水属性伤害 | +8.5% | Yes |
| 4 | 强攻击伤害 | +6.5% | Yes |
| 5 | 绝境时赋予自动恢复体力 | — | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/narikama-tanuki-samurai-lv4-panel.png>)

## 金虎鲸 · 武士 

Local key: `golden_shachi_samurai`. Observed level: 8.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 祓除常世赋予自动恢复体力 | — | Yes |
| 2 | 对处于水状态敌人的精力伤害 | +11.3% | Yes |
| 3 | 获得金钱 | +17.4% | Yes |
| 4 | 九十九化身结束时赋予造成伤害… | — | No |
| 5 | 近距离攻击伤害（常世内） | +12.1% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/isogami-samurai-lv8-panel.png>)

## 神鹿 · 武士 

Local key: `shin_roku_samurai`. Observed level: 2.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 祓除常世赋予造成伤害增加 | — | Yes |
| 2 | 感应和魂 | — | Yes |
| 3 | 雷属性伤害降低 | +14 | Yes |
| 4 | 强攻击吸取体力 | 4% | Yes |
| 5 | 异常状态抗性 | +9 | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/shin-roku-samurai-lv2-panel.png>)

## 狗宾 · 武士 

Local key: `guhin_samurai`. Observed level: 1.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 武技精力消耗降低 | -8.4% | Yes |
| 2 | 被攻击时承受的伤害降低 | -4.2% | Yes |
| 3 | 强攻击崩解力 | +11.0% | Yes |
| 4 | 精力耗尽的恢复时间缩短 | — | Yes |
| 5 | 对精力耗尽敌人的近距离伤害 | +8.4% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/guhin-samurai-lv1-panel.png>)

## 凤凰 · 武士 

Local key: `ho_oh_samurai`. Observed level: 10.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 不消耗使役符以外的阴阳术 | +6.6% | Yes |
| 2 | 使用阴阳术时赋予自动恢复体力 | — | Yes |
| 3 | 魂核掉落率 | +12.8% | Yes |
| 4 | 阴阳术伤害 | +10.4% | Yes |
| 5 | 阴阳术命中时施加移动速度降低 | — | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/ho-oh-samurai-lv10-panel.png>)

## 草薙 · 武士 强化形态（本地标记）

Local key: `kusanagi_enhanced_samurai`. Observed level: 9.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 敌人的火状态累积 | +6.5% | Yes |
| 2 | 使敌人陷入火状态时精华槽增加 | C+ | Yes |
| 3 | 伤害反映（装备重量） | C+ | Yes |
| 4 | 格挡成功时赋予昂灵 | — | Yes |
| 5 | 伤害反映（精华槽） | A- | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/kusanagi-enhanced-samurai-lv9-panel.png>)

## 草薙 · 忍者 初始形态（本地标记）

Local key: `kusanagi_initial_ninja`. Observed level: 1.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 空中攻击伤害 | +8.4% | Yes |
| 2 | 水属性伤害降低 | +13 | Yes |
| 3 | 跳跃的精力 | -10.8% | Yes |
| 4 | 速攻击伤害 | +5.7% | Yes |
| 5 | 背后攻击灵力增加量 | +11.0% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/kusanagi-initial-ninja-lv1-panel.png>)

## 丛云 · 忍者 

Local key: `murakumo_ninja`. Observed level: 40.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 敌人的风状态累积 | +9.6% | Yes |
| 2 | 使敌人陷入风状态时精华槽增加 | B+ | Yes |
| 3 | 守护灵技命中赋予昂神 | — | Yes |
| 4 | 追击和近身刺击可恢复体力 | 111 | Yes |
| 5 | 九十九化身持续时间延长 | +7.5% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/murakumo-ninja-lv40-panel.png>)

## 金刚狮子 · 忍者 

Local key: `kongojishi_ninja`. Observed level: 5.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 成功识破时造成伤害增加 | — | Yes |
| 2 | 火属性伤害 | +8.6% | Yes |
| 3 | 体力 | +130 | Yes |
| 4 | 精力恢复速度上升（无伤） | +6.0% | Yes |
| 5 | 近距离攻击伤害（无伤） | +7.6% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/kongojishi-ninja-lv5-panel.png>)

## 三味长老 · 忍者 

Local key: `shami_choro_ninja`. Observed level: 8.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 成功识破时移动速度上升 | — | Yes |
| 2 | 阴阳术命中赋予精力恢复速度增… | — | No |
| 3 | 雷属性伤害 | +8.9% | Yes |
| 4 | 绝境时赋予自动恢复体力 | — | Yes |
| 5 | 正面效果持续时间延长 | +14.2% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/sami-choro-ninja-lv8-panel.png>)

## 鞍马天狗 · 忍者 

Local key: `kurama_tengu_ninja`. Observed level: 40.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 武技精力伤害 | +9.0% | Yes |
| 2 | 感应敌人 | — | Yes |
| 3 | 风属性伤害降低 | +32 | Yes |
| 4 | 使用仙药时增加灵力 | +20 | Yes |
| 5 | 属性攻击伤害 | +10.0% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/kurama-tengu-ninja-lv40-panel.png>)

## 猫又 · 忍者 

Local key: `nekomata_ninja`. Observed level: 1.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 忍术造成的精力伤害 | +7.3% | Yes |
| 2 | 精力恢复速度 | +6.2% | Yes |
| 3 | 速攻击崩解力 | +10.6% | Yes |
| 4 | 近距离攻击的精力消耗降低 | -7.3% | Yes |
| 5 | 追击和近身刺击伤害 | +16.0% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/nekomata-ninja-lv1-panel.png>)

## 焰虎 · 忍者 

Local key: `enko_ninja`. Observed level: 2.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 对处于火状态敌人的近距离伤害 | +6.3% | Yes |
| 2 | 敌人的持续伤害 | +10.6% | Yes |
| 3 | 持续伤害降低 | -16.8% | Yes |
| 4 | 精华槽增加量 | +6.9% | Yes |
| 5 | 守护灵技灵力消耗减少 | -7.4% | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/enko-ninja-lv2-panel.png>)

## 天眼孔雀 · 忍者 

Local key: `tengen_kujaku_ninja`. Observed level: 40.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 箭弹或道具命中增加灵力 | AA+ | Yes |
| 2 | 恢复体力赋予昂灵 | — | Yes |
| 3 | 赋予属性的持续时间延长 | +15.0% | Yes |
| 4 | 造成属性伤害时增加灵力 | B+ | Yes |
| 5 | 探测敌人、宝物、精华、和魂 | — | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/ten-gen-kujaku-ninja-lv40-panel.png>)

## 凤 · 忍者 

Local key: `ho_ninja`. Observed level: 6.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 识破可增加灵力 | +3 | Yes |
| 2 | 闪避动作精力消耗降低 | -8.6% | Yes |
| 3 | 守护灵技命中赋予移动速度上升 | — | Yes |
| 4 | 获得精华 | +3.4% | Yes |
| 5 | 幸运 | +37 | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/ho-ninja-lv6-panel.png>)

## 凤凰 · 忍者 

Local key: `ho_oh_ninja`. Observed level: 10.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 不消耗使役符以外的阴阳术 | +6.6% | Yes |
| 2 | 阴阳术命中赋予精力恢复速度增加 | — | Yes |
| 3 | 获得魂核时恢复体力 | 395 | Yes |
| 4 | 阴阳术精力伤害 | +10.4% | Yes |
| 5 | 阴阳术命中时施加造成伤害减少 | — | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/ho-oh-ninja-lv10-panel.png>)

## 草薙 · 忍者 强化形态（本地标记）

Local key: `kusanagi_enhanced_ninja`. Observed level: 9.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 敌人的水状态累积 | +6.5% | Yes |
| 2 | 使敌人陷入水状态时精华槽增加 | C+ | Yes |
| 3 | 伤害反映（敏捷） | C+ | Yes |
| 4 | 成功识破时昂灵 | — | Yes |
| 5 | 伤害反映（精华槽） | A- | Yes |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/kusanagi-enhanced-ninja-lv9-panel.png>)

## 虎御前 · 忍者 

Local key: `tora_gozen_ninja`. Observed level: 15.

| Slot | Observed Chinese label | Displayed value | Label complete |
| --- | --- | --- | --- |
| 1 | 造成水属性伤害时增加灵力 | A- | Yes |
| 2 | 被攻击时承受的伤害降低 | -5.7% | Yes |
| 3 | 背后攻击伤害 | +9.9% | Yes |
| 4 | 吸收精华后赋予自动恢复体力 | — | Yes |
| 5 | 守护灵技命中赋予精力恢复速度… | — | No |

Evidence: [retained game panel](<C:/Users/RUAA/Documents/ChatGPT/仁王3绘卷生成器项目/deliverables/guardian-spirit-catalog-20261008/live/tora-gozen-ninja-lv15-panel.png>)

## Verified UI description

凤凰 · 忍者 · slot 2: 使役符以外的阴阳术道具命中敌人时，赋予特定正面效果。
Buff: 精力恢复速度增加. Combat proc, strength and duration remain unmeasured.
