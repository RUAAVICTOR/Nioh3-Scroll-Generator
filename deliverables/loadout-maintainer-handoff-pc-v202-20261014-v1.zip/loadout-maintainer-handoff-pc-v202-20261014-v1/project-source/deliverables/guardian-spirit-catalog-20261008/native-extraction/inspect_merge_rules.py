"""Inspect native merge metadata and equipment-group links offline."""
import hashlib,json,struct
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
catalog=json.loads((HERE.parent/'guardian_spirits_native.json').read_text(encoding='utf-8'))
texts=json.loads((HERE/'native-text-03.json').read_text(encoding='utf-8'))['entries']
groups=(HERE/'native-tables-01/effect_group-rows.bin').read_bytes()
report=[]
for group in catalog['effect_groups']:
 raw=bytes.fromhex(group['raw_hex']);cap=struct.unpack_from('<i',raw,4)[0]
 report.append({'id':group['id'],'label':group['label_zh'],'raw_cap':cap,'grade_flag':bool(group['flags_50']&4),
                'merge_kind':'special_max' if group['id']==0x38BA else ('grade_max_with_duplicate_rank_bonus' if group['flags_50']&4 else 'sum_with_optional_cap'),
                'hidden_display':not group['unit_template'] and not group['flags_50']&4})
for offset in range(8,len(groups),112):
 key=struct.unpack_from('<H',groups,offset+12)[0]
 if key==0x8508:
  text_id=struct.unpack_from('<I',groups,offset+44)[0]
  print('INACTIVE_GUARD_GATE',hex(key),texts.get(str(text_id),[]))
bundle=ROOT/'nioh3_scroll_editor/data/r4_finalizer/pc_v2_02/resource_v1'
manifest=json.loads((bundle/'manifest.json').read_text())
spec=next(t for t in manifest['tables'] if t['name']=='effect')
effect=(bundle/spec['file']['filename']).read_bytes();assert hashlib.sha256(effect).hexdigest().upper()==spec['file']['sha256'].upper()
links={group['id']:[] for group in catalog['effect_groups']}
for offset in range(8,len(effect),spec['row_size']):
 key,group=struct.unpack_from('<HH',effect,offset)
 if group in links:links[group].append(key)
(HERE/'merge-rule-inspection.json').write_text(json.dumps({'groups':report,'equipment_effect_ids_by_guardian_group':links},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'groups':len(report),'grade_groups':sum(g['grade_flag'] for g in report),'cap_values':sorted(set(g['raw_cap'] for g in report)),
 'grade_labels':[g['label'] for g in report if g['grade_flag']],'groups_linked_to_equipment_table':sum(bool(v) for v in links.values())},ensure_ascii=True))
