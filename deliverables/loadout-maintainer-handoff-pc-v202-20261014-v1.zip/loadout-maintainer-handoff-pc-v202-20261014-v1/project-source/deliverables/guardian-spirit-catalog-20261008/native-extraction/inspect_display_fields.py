"""Print native formatting fields and targeted consumer slices only."""
import json,struct
from pathlib import Path
HERE=Path(__file__).resolve().parent
texts=json.loads((HERE/'native-text-03.json').read_text(encoding='utf-8'))['entries']
def label(key):
    names={e['text'] for e in texts.get(str(key),[])}
    assert len(names)<=1
    return next(iter(names),None)
raw=(HERE/'native-tables-01/guardian-rows.bin').read_bytes();groups=(HERE/'native-tables-01/effect_group-rows.bin').read_bytes()
keys={struct.unpack_from('<I',raw,i+0x6C+j*12)[0] for i in range(8,len(raw),0x100) for j in range(6) if raw[i+0xFC]&4}
for i in range(8,len(groups),0x70):
    key=struct.unpack_from('<H',groups,i+0xC)[0]
    if key not in keys:continue
    fields={hex(offset):{'value':hex(struct.unpack_from('<I',groups,i+offset)[0]),'text':label(struct.unpack_from('<I',groups,i+offset)[0])} for offset in range(0x2C,0x58,4)}
    print(json.dumps({'group':hex(key),'format_fields':fields,'type_u32_58':struct.unpack_from('<I',groups,i+0x58)[0]},ensure_ascii=True))
analysis=json.loads((HERE/'guardian-candidate-analysis.json').read_text())
for begin,start,end in (('0x1d7eee0',0x1D801D0,0x1D80420),('0x1d77384',0x1D77384,0x1D77443)):
    function=next(f for f in analysis['code_consumers'] if f['begin']==begin)
    print(begin)
    print('\n'.join(i['rva']+' '+i['instruction'] for i in function['instructions'] if start<=int(i['rva'],0)<end))
