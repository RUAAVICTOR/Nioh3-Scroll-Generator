"""Exercise actual Lua callbacks, pairing and safe continuation before arming."""
import ctypes,os
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def quote(value):
    return '"'+''.join(chr(b) if 32<=b<127 and b not in (34,92) else '\\'+str(b).zfill(3) for b in value.encode())+'"'
source=r'''
local function scenario(mode)
 local s={sites={},timers={},continues=0,options={}}
 local id={pid=1,module_base=0x10000000,handle=123,site_rva=0x1000,signature_hex=string.rep('AA',16),
   creation_filetime='1',executable_sha256='mock',lookup_kind=mode,effect_ids={[0x2512]=true},guardian_begin=0x20000000,guardian_end=0x20000100}
 if mode=='merge' then id.return_rva=0x2000;id.return_signature_hex=string.rep('BB',16) end
 local r={RAX=0,RBX=0x30000000,RCX=0x100000012,RDX=0x20000000,RSI=0,RDI=7,RBP=0x2512,RSP=0x40000000,R8=3,R9=0,R10=0,R11=0,R12=0,R13=0,R14=0,R15=0,RIP=0x10001000}
 local api={pid=function() return s.options.changed and 2 or 1 end,base=function() return id.module_base end,
 handle=function() return 123 end,context=function()end,registers=function()return r end,
 continue_event=function()s.continues=s.continues+1 end,
 u64=function() return id.module_base+0x375033 end,
 u32=function(a) if s.options.read_fail then error('read fail') end;return a==0x30000C00 and 1 or 0x2512 end,
 u16=function(a) return a==0x30000000 and 0x2512 or 19 end,
 raw=function(a,n) if s.options.read_fail then error('read fail') end;if a==0x10001000 then return string.rep(s.options.signature and 'CC' or 'AA',16) end;if a==0x10002000 then return string.rep('BB',16) end;assert(a==0x30000000 and n==12);return string.rep(s.after and '11' or '00',12) end,
 list=function()local list={};for a in pairs(s.sites)do list[#list+1]=a end;return list end,
 arm=function(a,fn)s.sites[a]=fn;return true end,remove=function(a)s.sites[a]=nil end,
 timer=function(delay,fn)local t={fn=fn};s.timers[t]=true;return t end,cancel_timer=function(t)s.timers[t]=nil end}
 s.regs=r;s.id=id;s.p=assert(load(OBSERVER))()(api,id,assert(load(OWNER))())
 function s.fire(exit)assert(s.sites[exit and 0x10002000 or 0x10001000])() end
 function s.clean()s.p.stop();for t in pairs(s.timers) do s.timers[t]=nil;t.fn() end;assert(not s.p.active and not s.p.cleanup_pending and #s.p.owned_breakpoints==0 and s.p.pending_timers==0)end
 return s
end
local count=0
local function check(fn)fn();count=count+1 end
check(function()local s=scenario('activation');s.p.arm();s.fire();assert(s.continues==1 and s.p.events[1].progress_count==18 and s.p.events[1].threshold==19 and s.p.events[1].slot==4);s.clean()end)
check(function()local s=scenario('activation');s.p.arm();s.regs.RDX=0x777;s.fire();assert(s.continues==1 and #s.p.events==0 and s.p.ignored==1);s.clean()end)
check(function()local s=scenario('activation');s.p.arm();s.options.changed=true;s.fire();assert(s.continues==1 and s.p.error);s.clean()end)
check(function()local s=scenario('activation');s.p.arm();s.options.signature=true;s.fire();assert(s.continues==1 and s.p.error);s.clean()end)
check(function()local s=scenario('merge');s.p.arm();s.fire();s.after=true;s.fire(true);assert(s.continues==2 and #s.p.events==1 and s.p.events[1].before_hex~=s.p.events[1].after_hex and s.p.status().unpaired_events==0);s.clean()end)
check(function()local s=scenario('merge');s.p.arm();s.fire(true);assert(s.continues==1 and #s.p.events==0);s.clean()end)
check(function()local s=scenario('merge');s.p.arm();s.fire();s.options.read_fail=true;s.fire(true);assert(s.continues==2 and s.p.error);s.clean()end)
check(function()local s=scenario('merge');s.p.arm();s.p.active=false;s.fire();s.fire(true);assert(s.continues==2 and #s.p.events==0);s.clean()end)
check(function()local s=scenario('merge');s.p.arm();s.p.max_events=1;s.fire();s.fire(true);assert(not s.p.active and s.p.stop_reason=='event_bound' and s.continues==2);s.clean()end)
check(function()local s=scenario('activation');s.p.arm();s.p.max_hits=1;s.fire();s.fire();assert(s.continues==2 and s.p.stop_reason=='hit_bound');s.clean()end)
check(function()local s=scenario('merge');s.sites[0x777]=function()end;assert(not pcall(s.p.arm));assert(s.sites[0x777]);end)
assert(count==11)
'''
lua=ctypes.CDLL(os.environ['LUA54_LIBRARY']);lua.luaL_newstate.restype=ctypes.c_void_p
lua.luaL_openlibs.argtypes=[ctypes.c_void_p];lua.luaL_loadstring.argtypes=[ctypes.c_void_p,ctypes.c_char_p];lua.luaL_loadstring.restype=ctypes.c_int
lua.lua_pcallk.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_ssize_t,ctypes.c_void_p];lua.lua_pcallk.restype=ctypes.c_int
lua.lua_tolstring.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p];lua.lua_tolstring.restype=ctypes.c_char_p;lua.lua_close.argtypes=[ctypes.c_void_p]
state=lua.luaL_newstate()
try:
 lua.luaL_openlibs(state)
 payload=('OBSERVER='+quote((HERE/'guardian_semantics_observer.lua').read_text())+';OWNER='+quote((ROOT/'research/owned_breakpoint_lifecycle_ce.lua').read_text())+';'+source).encode()
 status=lua.luaL_loadstring(state,payload)
 if not status:status=lua.lua_pcallk(state,0,0,0,0,None)
 if status:raise RuntimeError(lua.lua_tolstring(state,-1,None).decode())
 print('11 actual Lua callback scenarios passed; no game access.')
finally:lua.lua_close(state)
