"""Read selected native text IDs from a previously verified runtime pool."""
import argparse,hashlib,json,struct,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'deliverables/load-capacity-research/scripts')]
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from capture_player import _process_executable,_sha256,_file_version
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--ids',nargs='+',default=[],type=lambda v:int(v,0));parser.add_argument('--id-file',type=Path);parser.add_argument('--keywords',nargs='+',default=[]);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    assert not args.output.exists()
    prior=json.loads((HERE/'native-text-03.json').read_text(encoding='utf-8'))
    started=time.monotonic();entries={}
    with ProcessReader() as reader:
        assert reader.pid==prior['pid'] and reader.creation_time()==prior['process_birth_filetime']
        executable=_process_executable(reader)
        assert list(_file_version(executable))==[2,0,2,0] and _sha256(executable)==prior['executable_sha256']
        assert reader.read(reader.module_base+0x375364,16)==bytes.fromhex('4883ec48488bc2440fb7d9488bc8488d')
        for anchor in prior['anchors'][:2]:
            key=int(anchor['text_id'],0);address=int(anchor['address'],0)
            raw=reader.read(address,8+(len(anchor['text'])+1)*2)
            assert struct.unpack_from('<I',raw)[0]==key and raw[8:-2].decode('utf-16le')==anchor['text']
        start=int(prior['pool_center'],0)-16*1048576;data=reader.read(start,32*1048576)
        wanted=set(args.ids)
        if args.id_file:
            bulk=json.loads(args.id_file.read_text(encoding='utf-8-sig'));assert isinstance(bulk,list) and len(bulk)<=2000 and all(isinstance(k,int) and 0<k<0x10000000 for k in bulk)
            wanted.update(bulk)
        for keyword in args.keywords:
            offset=0;needle=keyword.encode('utf-16le');hits=0
            while True:
                at=data.find(needle,offset)
                if at<0:break
                offset=at+2;hits+=1;assert hits<=1000
                for header in range(at-8,max(-1,at-4096),-2):
                    key,units=struct.unpack_from('<II',data,header)
                    if not 0x10000<=key<0x10000000 or not 1<=units<=2048:continue
                    end=header+8+units*2
                    if end<=at or end>len(data) or data[end-2:end]!=b'\0\0':continue
                    try:candidate=data[header+8:end-2].decode('utf-16le')
                    except UnicodeDecodeError:continue
                    if keyword in candidate and '\0' not in candidate:wanted.add(key);break
        for key in wanted:
            candidates=[];offset=0;needle=struct.pack('<I',key)
            while True:
                at=data.find(needle,offset)
                if at<0:break
                offset=at+1
                if at+8>len(data):continue
                units=struct.unpack_from('<I',data,at+4)[0]
                if not 1<=units<=4096 or at+8+units*2>len(data):continue
                raw=data[at:at+8+units*2]
                if raw[-2:]!=b'\0\0':continue
                try:text=raw[8:-2].decode('utf-16le')
                except UnicodeDecodeError:continue
                if not text or '\0' in text:continue
                candidates.append({'address':hex(start+at),'text':text,'raw_hex':raw.hex(),'sha256':hashlib.sha256(raw).hexdigest()})
            assert len({e['text'] for e in candidates})<=1,(hex(key),candidates)
            entries[str(key)]=candidates
        assert reader.creation_time()==prior['process_birth_filetime'] and time.monotonic()-started<20
    result={'pid':prior['pid'],'process_birth_filetime':prior['process_birth_filetime'],'executable_sha256':prior['executable_sha256'],
            'entries':entries,'read_only':True,'game_writes':0,'process_handle_closed':True,'read_bytes':len(data),'elapsed_seconds':time.monotonic()-started}
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if len(wanted)>32:print(json.dumps({'requested':len(wanted),'resolved':sum(bool(v) for v in entries.values()),'missing':[hex(int(k)) for k,v in entries.items() if not v],'output':str(args.output)}))
    else:print(json.dumps({hex(k):[e['text'] for e in entries[str(k)]] for k in wanted},ensure_ascii=True))
if __name__=='__main__':main()
