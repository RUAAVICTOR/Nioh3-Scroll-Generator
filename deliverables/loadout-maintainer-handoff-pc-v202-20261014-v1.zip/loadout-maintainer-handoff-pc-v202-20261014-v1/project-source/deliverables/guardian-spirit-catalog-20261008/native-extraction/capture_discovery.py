"""Bounded passive capture of profiled code and manager table headers.

Discovery evidence only: no guardian layout assumptions, debugger or writes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import struct
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "deliverables/load-capacity-research/scripts")]
from capture_player import _file_version, _process_executable, _sha256
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from research.dump_live_pe_sections import _pe_section_headers

PROFILE = ROOT / "nioh3_scroll_editor/data/game_versions/pc_v2_02.json"
CODE_RVA = 0x550000
CODE_SIZE = 0x20000
MAX_BYTES = 16 * 1024 * 1024
MAX_SECONDS = 20
MAX_PDATA_BYTES = 3 * 1024 * 1024


def plausible(address):
    return 0x10000 <= address < (1 << 47)


def experiment(code_rva=CODE_RVA, code_size=CODE_SIZE, store_prefix_size=0, candidate_count_limit=128):
    return {
        "schema": "nioh3-guardian-discovery-experiment/v1",
        "question": "Which native parameter-manager context and consumer supplies guardian fixed-effect references?",
        "current_evidence": "Known v2.02 manager/effect sites; existing native effect resources; no guardian layout bound.",
        "missing_vector": "Direct native guardian/style/form-to-effect reference chain.",
        "scope": "Known lookup code window, runtime pdata and candidate manager headers/small indexes only.",
        "controls": "Effect table +0xC8 count 3609 and prefix table +0xA8 count 1152.",
        "max_seconds": MAX_SECONDS, "max_read_bytes": MAX_BYTES,
        "max_pdata_bytes": MAX_PDATA_BYTES,
        "code_rva": hex(code_rva), "code_size": code_size,
        "exploratory_store_prefix_bytes": store_prefix_size,
        "exploratory_candidate_count_limit": candidate_count_limit,
        "store_prefix_scope": "Only plausible small keyed contexts; windows are not complete tables or verified row boundaries.",
        "debugger": False, "game_writes": 0, "ui_input": False,
        "expected_output": "Identity/signatures, raw blobs, manager candidate headers and cleanup proof; no completed guardian export.",
    }


def capture(pid, output, code_rva=CODE_RVA, code_size=CODE_SIZE, store_prefix_size=0, candidate_count_limit=128, max_bytes=MAX_BYTES, prefix_contexts=()):
    if not 0x1000 <= code_rva < 0x38E2000 or not 1 <= code_size <= CODE_SIZE or code_rva + code_size > 0x38E2000:
        raise ValueError("Code window exceeds profiled text range")
    if store_prefix_size not in (0, 0x1000, 0x4000, 0x10000, 0x20000, 0x40000):
        raise ValueError("Store prefix size is outside bounded exploration choices")
    if not 1 <= candidate_count_limit <= 10000:
        raise ValueError("Candidate count limit exceeds bounded exploration")
    if not MAX_BYTES <= max_bytes <= 64*1048576:
        raise ValueError("Read budget exceeds bounded exploration")
    if output.exists():
        raise FileExistsError(output)
    profile = json.loads(PROFILE.read_text(encoding="utf-8-sig"))
    output.mkdir(parents=True)
    prepared=experiment(code_rva, code_size, store_prefix_size, candidate_count_limit)
    prepared['max_read_bytes']=max_bytes
    prepared['prefix_contexts']=[hex(x) for x in prefix_contexts]
    (output / "experiment.json").write_text(json.dumps(prepared, indent=2) + "\n")
    report = {"schema": "nioh3-guardian-discovery-capture/v1", "status": "partial",
              "captured_at_utc": datetime.now(timezone.utc).isoformat(),
              "read_only": True, "debugger_used": False, "game_writes": 0,
              "blobs": [], "table_candidates": [], "guardian_mapping_verified": False,
              "cleanup": {"process_handle_closed": False}}
    started = time.monotonic()
    total = 0

    def bounded_read(reader, address, size):
        nonlocal total
        if time.monotonic() - started > MAX_SECONDS:
            raise RuntimeError("Capture time bound exceeded")
        if size < 0 or total + size > max_bytes:
            raise RuntimeError("Capture byte bound exceeded")
        total += size
        return reader.read(address, size)

    def retain(name, address, data):
        path = output / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        item = {"path": name, "address": hex(address), "size": len(data),
                "sha256": hashlib.sha256(data).hexdigest()}
        report["blobs"].append(item)
        return item

    try:
        with ProcessReader() as reader:
            if reader.pid != pid:
                raise RuntimeError("Fresh expected PID does not match reader target")
            birth = reader.creation_time()
            executable = _process_executable(reader)
            version = _file_version(executable)
            digest = _sha256(executable)
            if list(version) != profile["file_version"] or digest.upper() != profile["provenance"]["executable_sha256"].upper():
                raise RuntimeError("Executable identity does not match v2.02 profile")
            if reader.creation_time() != birth:
                raise RuntimeError("Process identity changed during hashing")
            report.update(pid=reader.pid, process_birth_filetime=birth,
                          module_base=hex(reader.module_base), executable=str(executable),
                          executable_sha256=digest, file_version=list(version),
                          profile_sha256=hashlib.sha256(PROFILE.read_bytes()).hexdigest())
            signatures = {}
            for name in ("effect_lookup", "generate_effects"):
                site = profile["text_sites"][name]
                expected = bytes.fromhex(site["captured_signature"])
                actual = bounded_read(reader, reader.module_base + int(site["rva"], 0), len(expected))
                signatures[name] = {"rva": site["rva"], "expected": expected.hex(), "actual": actual.hex()}
                report["signatures"] = signatures
                if actual != expected:
                    raise RuntimeError("Native site signature mismatch: " + name)
            code = bounded_read(reader, reader.module_base + code_rva, code_size)
            retain("lookup-code.bin", reader.module_base + code_rva, code)
            report["code_rva"] = hex(code_rva)
            sections = _pe_section_headers(executable)
            pdata = next((item for item in sections if item[0] == ".pdata"), None)
            if pdata is None or not 0 < pdata[2] <= MAX_PDATA_BYTES:
                raise RuntimeError("Pdata section exceeds prepared bounds")
            retain("pdata.bin", reader.module_base + pdata[1], bounded_read(reader, reader.module_base + pdata[1], pdata[2]))
            manager_rva = int(profile["data_sites"]["parameter_manager_pointer"]["rva"], 0)
            manager = struct.unpack("<Q", bounded_read(reader, reader.module_base + manager_rva, 8))[0]
            if not plausible(manager):
                raise RuntimeError("Parameter manager not loaded; wait for game data initialization")
            raw_manager = bounded_read(reader, manager, 0xC00)
            retain("manager.bin", manager, raw_manager)
            report.update(manager_rva=hex(manager_rva), manager_address=hex(manager))
            for offset in range(0, len(raw_manager), 8):
                context = struct.unpack_from("<Q", raw_manager, offset)[0]
                if not plausible(context):
                    continue
                candidate = {"manager_offset": hex(offset), "context_address": hex(context)}
                try:
                    ctx = bounded_read(reader, context, 0x28)
                    store, = struct.unpack_from("<Q", ctx)
                    if not plausible(store):
                        continue
                    header = bounded_read(reader, store, 0x40)
                    count = struct.unpack_from("<I", header, 4)[0]
                    if not 1 <= count <= 200000:
                        continue
                    prefix = f"candidates/{offset:03x}"
                    candidate.update(row_store_address=hex(store), row_count_candidate=count,
                                     row_stride_verified=False, guardian_table_verified=False)
                    retain(prefix + "-context.bin", context, ctx)
                    retain(prefix + "-store-header.bin", store, header)
                    hash_ptr = struct.unpack_from("<Q", ctx, 0x20)[0]
                    if plausible(hash_ptr):
                        hash_header = bounded_read(reader, hash_ptr, 0x20)
                        retain(prefix + "-hash-header.bin", hash_ptr, hash_header)
                        begin, end = struct.unpack_from("<QQ", hash_header, 8)
                        valid_hash_range = plausible(begin) and end >= begin and (end - begin) % 8 == 0
                        candidate["hash_range_valid"] = valid_hash_range
                        candidate["hash_entry_count_candidate"] = (end - begin) // 8 if valid_hash_range else None
                        selected=not prefix_contexts or offset in prefix_contexts
                        if valid_hash_range and ((count<=256 and 0<end-begin<=8192) or (prefix_contexts and selected and count<=candidate_count_limit and 0<end-begin<=32768)):
                            retain(prefix + "-hash-entries.bin", begin, bounded_read(reader, begin, end - begin))
                        if selected and store_prefix_size and count <= candidate_count_limit and valid_hash_range and 0 < end - begin <= 262144:
                            prefix_data = bounded_read(reader, store, store_prefix_size)
                            retain(prefix + "-store-prefix.bin", store, prefix_data)
                            candidate["store_prefix_size"] = len(prefix_data)
                            candidate["store_prefix_stable"] = bounded_read(reader, store, len(prefix_data)) == prefix_data
                    candidate["context_and_header_stable"] = bounded_read(reader, context, len(ctx)) == ctx and bounded_read(reader, store, len(header)) == header
                except (OSError, RuntimeError) as error:
                    candidate["read_error"] = str(error)
                report["table_candidates"].append(candidate)
            counts = {int(item["manager_offset"], 0): item.get("row_count_candidate") for item in report["table_candidates"]}
            report["control_counts"] = {"effect": counts.get(0xC8), "prefix": counts.get(0xA8)}
            if counts.get(0xC8) != 3609 or counts.get(0xA8) != 1152:
                raise RuntimeError("Known native table controls did not match")
            if reader.creation_time() != birth or struct.unpack("<Q", bounded_read(reader, reader.module_base + manager_rva, 8))[0] != manager:
                raise RuntimeError("Process/manager identity changed")
            if bounded_read(reader, manager, len(raw_manager)) != raw_manager:
                raise RuntimeError("Parameter-manager fields changed during capture")
            if bounded_read(reader, reader.module_base + code_rva, len(code)) != code:
                raise RuntimeError("Code window changed during capture")
            report["status"] = "complete_discovery_capture_only"
    except Exception as error:
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        report["cleanup"] = {"process_handle_closed": True, "owned_breakpoints": 0,
                             "owned_hooks": 0, "owned_timers": 0, "game_writes": 0}
        report.update(total_requested_read_bytes=total, elapsed_seconds=time.monotonic() - started)
        (output / "capture.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--pid", type=int)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--code-rva", type=lambda value: int(value, 0), default=CODE_RVA)
    parser.add_argument("--code-size", type=lambda value: int(value, 0), default=CODE_SIZE)
    parser.add_argument("--store-prefix-size", type=lambda value: int(value, 0), default=0)
    parser.add_argument("--candidate-count-limit", type=int, default=128)
    parser.add_argument("--max-read-bytes", type=lambda value:int(value,0), default=MAX_BYTES)
    parser.add_argument('--prefix-contexts',nargs='+',type=lambda v:int(v,0),default=[])
    args = parser.parse_args()
    if args.prepare_only:
        from capstone import Cs, CS_ARCH_X86, CS_MODE_64
        decoder = Cs(CS_ARCH_X86, CS_MODE_64)
        assert list(decoder.disasm(bytes.fromhex("488b05f0ffffff"), 0x1000))
        print(json.dumps({"prepared": True, "experiment": experiment(args.code_rva, args.code_size, args.store_prefix_size), "capstone_available": True}))
        return
    if args.pid is None or args.output is None:
        parser.error("Capture requires a freshly observed --pid and unique --output")
    report = capture(args.pid, args.output.resolve(), args.code_rva, args.code_size, args.store_prefix_size, args.candidate_count_limit,args.max_read_bytes,args.prefix_contexts)
    print(json.dumps({"status": report["status"], "pid": report["pid"],
                      "candidates": len(report["table_candidates"]),
                      "read_bytes": report["total_requested_read_bytes"],
                      "cleanup": report["cleanup"]}))


if __name__ == "__main__":
    main()
