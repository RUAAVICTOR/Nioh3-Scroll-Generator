"""Build a planner-readable catalog exclusively from retained native captures."""
import hashlib
import json
import re
import struct
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE.parent

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def u32(raw, offset):
    return struct.unpack_from('<I', raw, offset)[0]

def f32(value):
    return struct.unpack('<f', struct.pack('<f', value))[0]

def raw_value(base, growth, selector, level, curves, multiplier):
    # Native 0x374E74: selectors 0..5 select +0x2A..+0x34;
    # unknown selectors retain EDX=1. Out-of-range level returns base.
    if not 0 <= level < len(curves):
        return base
    coefficient = curves[level][selector] if selector < 6 else 1
    product = (growth * coefficient) & 0xFFFFFFFF
    value = (base + int(f32(f32(product) * multiplier))) & 0xFFFFFFFF
    return value if value < 0x80000000 else value - 0x100000000

def display_value(value, group, grades):
    if group['flags_50'] & 4:
        unsigned = value & 0xFFFFFFFF
        return grades[max(0, 17 - unsigned)]
    template = group['unit_template']
    if not template:
        return ''
    assert group['id'] != 0x54FE, 'Special time formatter needs a separate implementation'
    mode = group['decimal_mode']
    if mode in (1, 2):
        divisor = 10 ** mode
        assert value >= 0
        whole, fraction = divmod(value, divisor)
        values = [str(whole), str(fraction).zfill(mode)]
    else:
        # Native 0x1BC1C12/0x1BC1C23 supplies a second, zero argument even
        # in integer mode. Some clan groups use a two-placeholder unit here.
        values = [str(value), '0']
    template = template.replace('<dot>', '.')
    for part in values:
        template = template.replace('{}', part, 1)
    assert '{}' not in template, template
    return template

def main():
    capture = load(HERE / 'native-tables-01/capture.json')
    assert capture['status'] == 'complete_native_table_capture' and capture['game_writes'] == 0
    semantics = load(OUT / 'guardian_semantics_native.json')
    assert semantics['executable_sha256'] == capture['executable_sha256']
    assert semantics['source_policy']['native_only'] and semantics['source_policy']['game_writes'] == 0
    for entry in semantics['sources']:
        raw = (OUT / entry['path']).read_bytes()
        assert len(raw) == entry['size'] and digest(raw) == entry['sha256']
    dispatch = load(HERE / 'group-dispatch-traces.json')
    dispatch_by_group = {g['group_id']: g for g in dispatch['groups']}
    blobs = {}
    for entry in capture['blobs']:
        raw = (HERE / 'native-tables-01' / entry['path']).read_bytes()
        assert len(raw) == entry['size'] and digest(raw) == entry['sha256']
        blobs[entry['path']] = raw
    texts = load(HERE / 'native-text-03.json')
    assert texts['pid'] == capture['pid'] and texts['game_writes'] == 0
    native_text = {}
    for key, entries in texts['entries'].items():
        names = set()
        for entry in entries:
            raw = bytes.fromhex(entry['raw_hex'])
            text_id, units = struct.unpack_from('<II', raw)
            assert text_id == int(key) and len(raw) == 8 + units * 2
            assert digest(raw) == entry['sha256'] and raw[-2:] == b'\0\0'
            assert raw[8:-2].decode('utf-16le') == entry['text']
            names.add(entry['text'])
        assert len(names) == 1
        native_text[int(key)] = next(iter(names))
    def text(key):
        return native_text[key] if key else None
    constants = load(HERE / 'native-format-constants.json')
    assert constants['executable_sha256'] == capture['executable_sha256']
    grades = []
    for entry in constants['labels']:
        raw = bytes.fromhex(entry['raw_hex'])
        assert digest(raw) == entry['sha256'] and raw[:-2].decode('utf-16le') == entry['text']
        grades.append(entry['text'])
    assert len(grades) == 18
    growth_raw = blobs['guardian_growth-rows.bin']
    curves = [list(struct.unpack_from('<6H', growth_raw, 8 + index * 64 + 0x2A)) for index in range(101)]
    multiplier = struct.unpack('<f', blobs['growth-multiplier.bin'])[0]
    groups_raw = blobs['effect_group-rows.bin']
    groups = {struct.unpack_from('<H', groups_raw, offset+0xC)[0]: (index, groups_raw[offset:offset+112])
              for index, offset in enumerate(range(8, len(groups_raw), 112))}
    assert len(groups) == 1152
    rows_raw = blobs['guardian-rows.bin']
    records = []
    used_groups = {}
    for index, offset in enumerate(range(8, len(rows_raw), 256)):
        row = rows_raw[offset:offset+256]
        key, name_id, flags = u32(row, 0x24), u32(row, 0x2C), row[0xFC]
        name = text(name_id)
        # Capture-specific roster classification, not a universal bit-4 meaning.
        selected = bool(name and flags & 4 and flags & 3 in (1, 2))
        slots = []
        for slot in range(6):
            group_id, base, growth = struct.unpack_from('<Iii', row, 0x6C + slot*12)
            selector, threshold = struct.unpack_from('<HH', row, 0xC4 + slot*4)
            item = {'slot': slot+1, 'effect_group_id': group_id, 'base_value': base,
                    'growth_value': growth, 'curve_selector': selector, 'activation_threshold': threshold}
            item['activation_requirement'] = {'kind': semantics['activation']['kind'],
                                              'required_count': threshold,
                                              'comparison': 'u16(player_count) >= required_count'}
            if selected and group_id:
                group_index, group = groups[group_id]
                alternative_refs = {hex(i): u32(group, i) for i in (0x10, 0x14, 0x18, 0x1C, 0x20)}
                assert not any(alternative_refs.values()), (hex(group_id), alternative_refs)
                ids = {field: u32(group, field_offset) for field, field_offset in (
                    ('name_template', 0x2C), ('description', 0x30), ('unit_template', 0x34),
                    ('substitution_1', 0x38), ('substitution_2', 0x3C), ('substitution_description', 0x48))}
                strings = {field: text(text_id) for field, text_id in ids.items()}
                label = strings['name_template']
                for field in ('substitution_1', 'substitution_2'):
                    if strings[field]:
                        label = label.replace('{}', strings[field], 1)
                label = re.sub(r'\^09~(?:BUFF|DEBUFF)~', '', label).replace('^09~~', '')
                assert '{}' not in label and '…' not in label and '^' not in label, label
                metadata = {'id': group_id, 'row_index': group_index, 'text_ids': ids, **strings,
                            'label_zh': label, 'flags_50': u32(group, 0x50), 'decimal_mode': group[0x6C],
                            'raw_hex': group.hex(), 'raw_sha256': digest(group)}
                metadata['aggregation'] = {
                    'kind': 'grade_max_with_duplicate_rank_bonus' if metadata['flags_50'] & 4 else 'sum_with_optional_cap',
                    'raw_cap_i32': struct.unpack_from('<i', group, 4)[0],
                    'grade_flag': bool(metadata['flags_50'] & 4),
                    'evidence': 'native_control_flow',
                    'semantics_reference': 'guardian_semantics_native.json#same_group_merge'}
                assert group_id != 0x38BA
                leaf = dispatch_by_group[group_id]
                metadata['native_application_trace'] = {
                    'kind': leaf['kind'], 'leaf_rva': leaf.get('leaf_rva'),
                    'boolean_field_offsets': leaf.get('boolean_field_offsets', []),
                    'evidence': 'native_control_flow',
                    'source': 'native-extraction/group-dispatch-traces.json',
                    'scope': 'Attribute application leaf only; triggered buff and final combat behavior remain separately scoped.'}
                used_groups[group_id] = metadata
                raw_values = [raw_value(base, growth, selector, level, curves, multiplier) for level in range(101)]
                display_values = [display_value(value, metadata, grades) for value in raw_values]
                item.update(label_zh=label, description_zh=strings['description'],
                            raw_values_by_level_index=raw_values, display_values_by_level_index=display_values,
                            value_kind='grade' if metadata['flags_50'] & 4 else ('numeric' if strings['unit_template'] else 'hidden'))
            slots.append(item)
        records.append({'guardian_id': key, 'guardian_id_hex': f'0x{key:04X}', 'row_index': index,
                        'name_text_id': name_id, 'name_zh': name, 'flags_fc': flags,
                        'style': {1: 'samurai', 2: 'ninja'}.get(flags & 3),
                        'current_roster_record': selected, 'field_48': u32(row, 0x48),
                        'field_4c': u32(row, 0x4C), 'slots': slots, 'raw_hex': row.hex(), 'raw_sha256': digest(row)})
    roster = [{**record, 'slots': record['slots'][:5]} for record in records if record['current_roster_record']]
    assert len(records) == 52 and len({r['guardian_id'] for r in records}) == 52
    assert len(roster) == 22 and sum(r['style'] == 'samurai' for r in roster) == 10
    assert all(len(r['slots']) == 5 and all(s['effect_group_id'] for s in r['slots']) for r in roster)
    assert all(r['slots'][5]['effect_group_id'] == 0 for r in records if r['current_roster_record'])
    paths = ['native-tables-01/capture.json', 'native-text-03.json', 'native-format-constants.json',
             'guardian-function-analysis.json', 'guardian-unit-formatter-analysis.json',
             'guardian-value-formatter-analysis.json', 'guardian-grade-formatter-analysis.json',
             'guardian-candidate-analysis.json']
    paths += ['native-tables-01/' + b['path'] for b in capture['blobs']]
    # Include the original runtime machine-code windows and UI native consumer.
    paths += [f'discovery-{i:02}/lookup-code.bin' for i in (4, 6, 7, 8)]
    paths += ['consumer-code/1d77384.bin', 'consumer-code/1bbe2b0.bin']
    sources = []
    for relative in paths:
        path = HERE / relative
        raw = path.read_bytes()
        sources.append({'path': 'native-extraction/' + relative, 'size': len(raw), 'sha256': digest(raw)})
    sources += semantics['sources']
    semantic_raw = (OUT / 'guardian_semantics_native.json').read_bytes()
    sources.append({'path': 'guardian_semantics_native.json', 'size': len(semantic_raw), 'sha256': digest(semantic_raw)})
    sources = list({entry['path']: entry for entry in sources}.values())
    result = {'schema': 'nioh3-native-guardian-catalog/v2', 'status': 'native_extracted',
              'game_identity': {k: capture[k] for k in ('game_version', 'executable_sha256', 'pid', 'process_birth_filetime', 'captured_at_utc')},
              'source_policy': {'native_only': True, 'screenshot_transcriptions_used_as_build_inputs': False,
                                'community_or_wiki_used_as_build_inputs': False, 'game_writes': 0,
                                'eligible_as_native_planner_dataset': True,
                                'eligibility_scope': 'Fixed slots, native identities/text, level-dependent values, destroyed-spike activation requirements, other-style group gate and same-group attribute merge metadata. Triggered buffs and final combat formulas remain unresolved.'},
              'coverage': {'native_rows': 52, 'current_style_form_records': 22, 'samurai': 10, 'ninja': 12,
                           'fixed_effect_slots': 110, 'complete_labels': 110},
              'contract': {'identity': 'Use guardian_id, never name alone. Same-name style/form records are distinct.',
                           'roster': 'Current named style/form records: flags_fc bit 4 set and style mask 1/2. This is a capture-specific classification. Native UI also checks ownership at RVA 0x374BD8; bit 4 alone is not an unlock or universal selectability proof.',
                           'level_index': 'Arrays are indexed directly by native guardian-level input 0..100. Available growth rows do not prove legal maximum guardian level.',
                           'activation_threshold': 'Required destroyed Crucible Spike count (native Chinese: 地狱之楔破坏数). Native RVA 0x375364 uses unsigned u16 >=. This is separate from guardian level.',
                           'other_style_guardian': 'Other-style effects require native effect group 0x8508 (双灵庇佑); native getter result must be signed nonnegative. Its description explicitly enables both styles. Native set membership/piece requirement remains pending.',
                           'same_group_merge': 'Use native group IDs and aggregation metadata. Numeric duplicates sum with optional native raw cap; grade duplicates retain best raw rank and add one rank step per duplicate. Live numeric evidence is scoped to 57 luck updates; grade rule is native control flow only.',
                           'hidden_values': 'Raw values are retained even when the native formatter displays no number. They are not inferred buff strength or duration.',
                           'remaining_semantics': semantics['remaining_semantics']},
              'semantics': {'activation': semantics['activation'],
                            'other_style_guardian_condition': semantics['other_style_guardian_condition'],
                            'same_group_merge': semantics['same_group_merge'],
                            'evidence_file': 'guardian_semantics_native.json'},
              'native_layout': {'guardian_context_manager_offset': '0x3F0', 'guardian_stride': 256, 'guardian_key_offset': '0x24',
                                'slots': 'Six triples (u32 group, i32 base, i32 growth) at +0x6C; six (u16 curve,u16 threshold) pairs at +0xC4.',
                                'style_consumer_rva': '0x1D77384', 'slot_reader_rva': '0x37522C', 'growth_rva': '0x374E74',
                                'group_formatter_rva': '0x1BBE2B0', 'value_formatter_rva': '0x1BC1A08', 'grade_selector_rva': '0x22CE144'},
              'growth': {'coefficients_by_level_index': curves, 'curve_selector_offsets': ['0x2A','0x2C','0x2E','0x30','0x32','0x34'],
                         'multiplier_float32': multiplier, 'multiplier_raw_hex': blobs['growth-multiplier.bin'].hex(),
                         'formula': 'base + trunc(float32(float32(u32(growth * coefficient)) * multiplier)); i32 result. Selectors 0..5 use corresponding coefficient; others use 1. Level >=101 returns base.'},
              'grade_labels_by_index': grades, 'grade_index_rule': 'max(0,17-u32(raw_value))',
              'guardians': roster, 'effect_groups': list(used_groups.values()), 'native_records': records, 'sources': sources}
    destination = OUT / 'guardian_spirits_native.json'
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    lines = ['# Native guardian-spirit fixed effects — PC v2.02', '',
             'Extracted from the running game: 22 current style/form records, 110 fixed effects. All 52 native rows are retained in JSON. Names, complete effect labels, descriptions, formats and growth parameters come from native memory. Screenshot and community data are not build inputs.', '',
             'Values below are native calculations at level inputs 1 / 10 / 40. These are examples, not a legal-level-range assertion. An empty value is what the native formatter displays. The required count is the destroyed Crucible Spike count (地狱之楔破坏数), separate from guardian level.', '',
             'Other-style guardian effects are conditional on group 0x8508 (双灵庇佑). Same-group numeric/grade accumulation rules and their evidence limits are recorded in guardian_semantics_native.json. Triggered buff duration/refresh and final combat formulas are not inferred from hidden raw values.', '',
             '| Guardian native ID | Name | Style | Slot | Fixed effect | Lv1 | Lv10 | Lv40 | Required spike count |',
             '|---|---|---|---:|---|---|---|---|---:|']
    for guardian in roster:
        for slot in guardian['slots']:
            values = slot['display_values_by_level_index']
            fields = [guardian['guardian_id_hex'], guardian['name_zh'], guardian['style'], str(slot['slot']), slot['label_zh'],
                      values[1], values[10], values[40], str(slot['activation_threshold'])]
            lines.append('| ' + ' | '.join(f.replace('|', '\\|') for f in fields) + ' |')
    (OUT / 'guardian_spirits_native.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'coverage': result['coverage'], 'effect_groups': len(used_groups), 'output': str(destination)}))

if __name__ == '__main__':
    main()
