"""Capture native grade labels without modifying or invoking the game."""
import argparse
import hashlib
import json
import struct
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / 'deliverables/load-capacity-research/scripts')]
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from capture_player import _file_version, _process_executable, _sha256

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--identity',type=Path,default=HERE/'native-tables-01/capture.json');parser.add_argument('--output',type=Path,default=HERE/'native-format-constants.json');args=parser.parse_args()
    assert not args.output.exists()
    identity = json.loads(args.identity.read_text())
    formatter = json.loads((HERE / 'guardian-unit-formatter-analysis.json').read_text())[0]
    started = time.monotonic()
    total = 0
    def read(reader, address, size):
        nonlocal total
        total += size
        assert total <= 16384 and time.monotonic() - started < 20
        return reader.read(address, size)
    with ProcessReader() as reader:
        assert reader.pid == identity['pid']
        assert reader.creation_time() == identity['process_birth_filetime']
        exe = _process_executable(reader)
        assert list(_file_version(exe)) == [2, 0, 2, 0]
        assert _sha256(exe) == identity['executable_sha256']
        signature = bytes.fromhex(formatter['signature'])
        assert read(reader, reader.module_base + int(formatter['begin'], 0), len(signature)) == signature
        instruction = read(reader, reader.module_base + 0x1BC1A74, 7)
        assert instruction[:3] == bytes.fromhex('488d0d')
        table_rva = 0x1BC1A74 + 7 + struct.unpack_from('<i', instruction, 3)[0]
        pointers = read(reader, reader.module_base + table_rva, 18 * 8)
        assert read(reader, reader.module_base + table_rva, len(pointers)) == pointers
        labels = []
        for index, (pointer,) in enumerate(struct.iter_unpack('<Q', pointers)):
            assert reader.module_base <= pointer < reader.module_base + 0x5000000
            raw = read(reader, pointer, 64)
            end = next(i for i in range(0, len(raw), 2) if raw[i:i+2] == b'\0\0') + 2
            raw = raw[:end]
            labels.append({'index': index, 'address': hex(pointer), 'rva': hex(pointer-reader.module_base),
                           'text': raw[:-2].decode('utf-16le'), 'raw_hex': raw.hex(),
                           'sha256': hashlib.sha256(raw).hexdigest()})
        assert reader.creation_time() == identity['process_birth_filetime']
    result = {'schema': 'nioh3-native-format-constants/v1', 'pid': identity['pid'],
              'process_birth_filetime': identity['process_birth_filetime'],
              'executable_sha256': identity['executable_sha256'], 'read_only': True,
              'game_writes': 0, 'table_rva': hex(table_rva), 'pointer_array_hex': pointers.hex(),
              'pointer_array_sha256': hashlib.sha256(pointers).hexdigest(), 'labels': labels,
              'total_read_bytes': total, 'process_handle_closed': True}
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'table_rva': hex(table_rva), 'labels': [x['text'] for x in labels], 'read_bytes': total}))

if __name__ == '__main__':
    main()
