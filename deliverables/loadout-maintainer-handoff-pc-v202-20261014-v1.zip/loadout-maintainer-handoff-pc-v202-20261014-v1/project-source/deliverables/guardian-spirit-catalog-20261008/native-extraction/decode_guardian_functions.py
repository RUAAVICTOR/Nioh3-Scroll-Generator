"""Decode only identified guardian lookup/slot/curve functions from saved bytes."""
import hashlib,json,struct,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];sys.path.insert(0,str(ROOT))
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from research.native_xrefs import parse_runtime_functions
directory=HERE/('discovery-08' if '--grade' in sys.argv else ('discovery-07' if '--unit' in sys.argv else ('discovery-06' if '--format' in sys.argv else 'discovery-04')));capture=json.loads((directory/'capture.json').read_text())
for spec in capture['blobs']:
    if spec['path'] in ('lookup-code.bin','pdata.bin'):
        assert hashlib.sha256((directory/spec['path']).read_bytes()).hexdigest()==spec['sha256']
raw=(directory/'lookup-code.bin').read_bytes();base=int(capture['code_rva'],0)
functions=parse_runtime_functions((directory/'pdata.bin').read_bytes())
decoder=Cs(CS_ARCH_X86,CS_MODE_64)
report=[]
for target in ((0x22CE144,) if '--grade' in sys.argv else ((0x1BC1A08,) if '--unit' in sys.argv else ((0x1BC1C6C,) if '--format' in sys.argv else (0x3748E0,0x374E74,0x37522C,0x375364)))):
    function=next(x for x in functions if x.begin_rva==target)
    data=raw[target-base:function.end_rva-base];assert len(data)==function.end_rva-target
    insns=list(decoder.disasm(data,target))
    row={'begin':hex(target),'end':hex(function.end_rva),'signature':data[:16].hex(),
         'sha256':hashlib.sha256(data).hexdigest(),'instructions':[{'rva':hex(i.address),'instruction':i.mnemonic+' '+i.op_str} for i in insns]}
    report.append(row)
    print(hex(target));print('\n'.join(i.mnemonic+' '+i.op_str for i in insns))
(HERE/('guardian-grade-formatter-analysis.json' if '--grade' in sys.argv else ('guardian-unit-formatter-analysis.json' if '--unit' in sys.argv else ('guardian-value-formatter-analysis.json' if '--format' in sys.argv else 'guardian-function-analysis.json')))).write_text(json.dumps(report,indent=2)+'\n')
