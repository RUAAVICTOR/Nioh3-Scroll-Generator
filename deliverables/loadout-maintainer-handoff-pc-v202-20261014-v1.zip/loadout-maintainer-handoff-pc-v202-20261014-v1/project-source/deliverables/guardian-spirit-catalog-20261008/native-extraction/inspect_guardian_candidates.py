"""Bounded offline table layout and code-consumer discovery; no game writes."""
import bisect
import hashlib
import json
import struct
import sys
import time
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
from capstone.x86 import X86_OP_MEM, X86_REG_RIP
from research.native_xrefs import parse_runtime_functions
from research.dump_live_pe_sections import _pe_section_headers
from nioh3_scroll_editor.process_memory_readonly import ProcessReader

directory = HERE / 'discovery-03'
capture = json.loads((directory / 'capture.json').read_text())
def raw(name):
    spec = next(b for b in capture['blobs'] if b['path'] == name)
    data = (directory / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == spec['sha256']
    return data
store = raw('candidates/3f0-store-prefix.bin')
entries = raw('candidates/3f0-hash-entries.bin')
header = raw('candidates/3f0-hash-header.bin')
sentinel = struct.unpack_from('<I', header, 4)[0]
count = struct.unpack_from('<I',store,4)[0]
keys = {index:key for key,index in struct.iter_unpack('<II',entries) if key != sentinel and index<count}
assert len(keys)==count
strides=[]
for stride in range(4,0x201,4):
    if 8+count*stride>len(store): continue
    for offset in range(0,stride-1,2):
        if all(struct.unpack_from('<H',store,8+index*stride+offset)[0]==key for index,key in keys.items()):
            strides.append({'stride':hex(stride),'key_offset':hex(offset),'key_width':16})
rows=[]
for index,key in sorted(keys.items()):
    data=store[8+index*0x100:8+(index+1)*0x100]
    rows.append({'index':index,'key':hex(key),'words':list(struct.unpack('<128H',data)),
                 'dwords':list(struct.unpack('<64I',data))})
exe=Path(capture['executable'])
assert hashlib.sha256(exe.read_bytes()).hexdigest()==capture['executable_sha256']
sections=_pe_section_headers(exe)
text_section=next(x for x in sections if x[0]=='.text')
with exe.open('rb') as stream: pe_header=stream.read(0x10000)
pe_offset=struct.unpack_from('<I',pe_header,0x3C)[0]
section_table=pe_offset+24+struct.unpack_from('<H',pe_header,pe_offset+20)[0]
for i in range(struct.unpack_from('<H',pe_header,pe_offset+6)[0]):
    offset=section_table+40*i
    if pe_header[offset:offset+8].rstrip(b'\0')==b'.text':
        virtual_size,text_rva,raw_size,raw_offset=struct.unpack_from('<IIII',pe_header,offset+8)
        text_section=('.text',text_rva,virtual_size,raw_offset,raw_size)
functions=parse_runtime_functions(raw('pdata.bin'))
starts=[x.begin_rva for x in functions]
decoder=Cs(CS_ARCH_X86,CS_MODE_64);decoder.detail=True
selected={}
started=time.monotonic()
live_blobs=[]
with ProcessReader() as reader:
    assert reader.pid==capture['pid'] and reader.creation_time()==capture['process_birth_filetime']
    remaining=text_section[2];cursor=0;tail=b''
    while remaining:
        block=reader.read(reader.module_base+text_section[1]+cursor,min(1024*1024,remaining));remaining-=len(block)
        data=tail+block;base=text_section[1]+cursor-len(tail)
        for value in (0x3F0,):
            pattern=struct.pack('<I',value);position=0
            while True:
                found=data.find(pattern,position)
                if found<0:break
                position=found+1;rva=base+found
                fi=bisect.bisect_right(starts,rva)-1
                if fi>=0 and rva<functions[fi].end_rva:selected[functions[fi].begin_rva]=functions[fi]
        cursor+=len(block);tail=block[-3:]
        assert time.monotonic()-started<20,'Raw prefilter time bound'
assert len(selected)<=2000
decoded=0;consumers=[];skipped=[]
with ProcessReader() as reader:
    assert reader.pid==capture['pid'] and reader.creation_time()==capture['process_birth_filetime']
    for function in selected.values():
        size=function.end_rva-function.begin_rva
        if size>0x10000:skipped.append(hex(function.begin_rva));continue
        assert decoded+size<=4*1024*1024,'Offline decode bound'
        data=reader.read(reader.module_base+function.begin_rva,size)
        decoded+=size;insns=list(decoder.disasm(data,function.begin_rva))
        roots=[];contexts=[]
        for insn in insns:
            for op in insn.operands:
                if op.type!=X86_OP_MEM:continue
                if op.mem.base==X86_REG_RIP and insn.address+insn.size+op.mem.disp==0x45B9E30:roots.append(hex(insn.address))
                if op.mem.disp==0x3F0:contexts.append(hex(insn.address))
        if roots and contexts:
            path=HERE/'consumer-code'/f'{function.begin_rva:X}.bin';path.parent.mkdir(exist_ok=True);path.write_bytes(data)
            live_blobs.append({'path':str(path.relative_to(HERE)),'rva':hex(function.begin_rva),'size':size,'sha256':hashlib.sha256(data).hexdigest()})
            consumers.append({'begin':hex(function.begin_rva),'end':hex(function.end_rva),
              'manager_root_sites':roots,'candidate_context_sites':contexts,'sha256':hashlib.sha256(data).hexdigest(),
              'instructions':[{'rva':hex(i.address),'bytes':i.bytes.hex(),'instruction':i.mnemonic+' '+i.op_str} for i in insns]})
report={'candidate_table_offset':'0x3F0','row_count':count,'key_layout_candidates':strides,
  'rows':rows,'code_consumers':consumers,'prefilter_functions':len(selected),'decoded_bytes':decoded,
  'skipped_functions':skipped,'elapsed_seconds':time.monotonic()-started,'guardian_membership_verified':False,
  'live_code_read_only':True,'pid':capture['pid'],'process_birth_filetime':capture['process_birth_filetime'],
  'executable_sha256':capture['executable_sha256'],'live_consumer_blobs':live_blobs,'game_writes':0,'process_handle_closed':True}
(HERE/'guardian-candidate-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('row_count','key_layout_candidates','prefilter_functions','decoded_bytes','elapsed_seconds')}))
print(json.dumps([{'begin':x['begin'],'context_sites':x['candidate_context_sites']} for x in consumers]))
print(json.dumps([{'index':x['index'],'key':x['key'],'first_dwords':x['dwords'][:12]} for x in rows]))
