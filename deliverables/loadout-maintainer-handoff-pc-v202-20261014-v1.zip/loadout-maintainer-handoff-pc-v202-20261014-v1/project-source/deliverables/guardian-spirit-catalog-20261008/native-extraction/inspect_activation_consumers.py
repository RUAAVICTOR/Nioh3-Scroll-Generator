"""Inspect retained native guardian consumers without requiring a live game."""
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
report=json.loads((HERE/'guardian-candidate-analysis.json').read_text())
for f in report['code_consumers']:
    ins=f['instructions']
    hits=[i for i,x in enumerate(ins) if x['instruction'] in ('call 0x375364','call 0x374e74')]
    for i in hits:
        print(f['begin'], 'target',ins[i]['instruction'])
        print('\n'.join(x['rva']+' '+x['instruction'] for x in ins[max(0,i-22):i+14]))
