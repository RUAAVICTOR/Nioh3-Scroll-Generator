"""Prepare, control and retain an isolated bounded CE effect-origin observer."""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / ".tools/cheat-engine-mcp/python/src"),
                str(ROOT / "deliverables/load-capacity-research/scripts")]
from ce_mcp_server.bridge import CheatEngineBridge
from research.possessed_enemy_capture.run_possessed_enemy_observer import lua_literal
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from capture_player import _file_version, _process_executable, _sha256


def main(args):
    control_dir = args.output_dir.resolve() if args.output_dir else HERE
    control_dir.mkdir(parents=True,exist_ok=True)
    profile = json.loads((ROOT / "nioh3_scroll_editor/data/game_versions/pc_v2_02.json").read_text())
    expected_ce = json.loads((HERE / "owned-ce-session.json").read_text(encoding="utf-8-sig"))["task_ce_pid"]
    bridge = CheatEngineBridge(host="127.0.0.1", port=5568)
    bridge.start()
    mode = args.lookup
    if args.action != 'prepare' and (control_dir/'ce-prepared-identity.json').exists():
        mode = json.loads((control_dir/'ce-prepared-identity.json').read_text()).get('lookup_kind',mode)
    observer = HERE / ('guardian_semantics_observer.lua' if mode in ('activation','merge','grade_merge') else 'effect_origin_observer.lua')
    records = {"action": args.action, "calls": [], "observer_sha256": hashlib.sha256(observer.read_bytes()).hexdigest()}
    try:
        deadline = time.monotonic() + 15
        session_id = f"ce-{expected_ce}"
        while not any(item["session_id"] == session_id for item in bridge.list_sessions()):
            if time.monotonic() > deadline:
                raise RuntimeError("Dedicated CE session did not connect")
            time.sleep(0.2)

        def call(tool, payload):
            value = bridge.call_tool(tool, payload, session_id, 15)
            records["calls"].append({"tool": tool, "result": value})
            if value.get("ok") is not True or value.get("bridge_session_id") != session_id:
                raise RuntimeError(json.dumps(value))
            return value

        def lua(script):
            return call("ce.lua_exec", {"script": script})

        if args.action == "query":
            call("ce.get_attached_process", {})
            lua("return {debugging=debug_isDebugging(),breakpoints=debug_getBreakpointList(),own=nioh3GuardianOrigin and nioh3GuardianOrigin.status() or nil}")
        elif args.action == "prepare":
            with ProcessReader() as reader:
                if reader.pid != args.pid:
                    raise RuntimeError("Fresh target PID mismatch")
                birth = reader.creation_time()
                executable = _process_executable(reader)
                digest = _sha256(executable)
                if list(_file_version(executable)) != profile["file_version"] or digest.upper() != profile["provenance"]["executable_sha256"].upper():
                    raise RuntimeError("Target executable mismatch")
                site = profile["text_sites"]["effect_lookup"]
                rva = int(site["rva"], 0)
                expected = bytes.fromhex(site["captured_signature"])
                if args.lookup == 'text':
                    assert args.native_site_file and args.text_id_file
                    rva=0x5A4B04
                    expected=args.native_site_file.read_bytes()[:16]
                    assert len(expected)==16 and expected[:3]==bytes.fromhex('448bc1')
                if args.lookup == 'guardian':
                    source = json.loads((HERE / 'guardian-function-analysis.json').read_text())
                    guardian_site = next(row for row in source if row['begin'] == '0x3748e0')
                    rva = int(guardian_site['begin'], 0)
                    expected = bytes.fromhex(guardian_site['signature'])
                if args.lookup == 'activation':
                    source = json.loads((HERE / 'guardian-function-analysis.json').read_text())
                    activation = next(row for row in source if row['begin'] == '0x375364')
                    rva = int(activation['begin'], 0);expected = bytes.fromhex(activation['signature'])
                if args.lookup in ('merge','grade_merge'):
                    native = (HERE / 'aggregation-functions-02/557BA0.bin').read_bytes()
                    rva = 0x557D3E if args.lookup == 'grade_merge' else 0x557D0F;expected = native[rva-0x557BA0:rva-0x557BA0+16]
                if reader.read(reader.module_base+rva,len(expected)) != expected:
                    raise RuntimeError("Target lookup signature mismatch")
                manager = reader.u64(reader.module_base + int(profile["data_sites"]["parameter_manager_pointer"]["rva"], 0))
                effect_context = reader.u64(manager+(0x3F0 if args.lookup == 'guardian' else 0xC8))
                if reader.creation_time() != birth:
                    raise RuntimeError("Target process replaced")
                identity = {"pid": reader.pid, "module_base": reader.module_base,
                            "creation_filetime": birth, "executable_sha256": digest,
                            "effect_context": effect_context, "site_rva": rva,
                            "signature_hex": expected.hex().upper(), "lookup_kind": args.lookup}
            attached = call("ce.get_attached_process", {})
            if attached.get("attached") and int(attached.get("process_id",0)) != args.pid:
                raise RuntimeError("Dedicated CE unexpectedly attached to another process; no retargeting")
            if not attached.get("attached"):
                call("ce.attach_process", {"process_id": args.pid})
            names = json.loads((ROOT / "nioh3_scroll_editor/data/effect_names_multilingual.json").read_text(encoding="utf-8-sig"))
            targets = ("不消耗使役符以外的阴阳术", "阴阳术精力伤害", "获得魂核时恢复体力")
            identity["effect_ids"] = {entry["effect_id"]: True for entry in names["effects"].values() if entry["names"].get("zh-CN") in targets}
            if args.lookup == 'text':
                text_ids=json.loads(args.text_id_file.read_text(encoding='utf-8-sig'))
                assert isinstance(text_ids,list) and 0<len(text_ids)<=64 and all(isinstance(i,int) for i in text_ids)
                identity['effect_ids']={i:True for i in text_ids}
                identity['sample_all_text']=args.sample_all_text
            if args.lookup in ('guardian','activation'):
                source = json.loads((HERE / 'guardian-candidate-analysis.json').read_text())
                identity['effect_ids'] = {int(row['key'], 0):True for row in source['rows']}
            if args.lookup == 'activation':
                with ProcessReader() as reader:
                    manager=reader.u64(reader.module_base+0x45B9E30)
                    identity['guardian_begin']=reader.u64(reader.u64(manager+0x3F0))+8
                    identity['guardian_end']=identity['guardian_begin']+52*256
            if args.lookup in ('merge','grade_merge'):
                native = (HERE / 'aggregation-functions-02/557BA0.bin').read_bytes()
                identity['return_rva']=0x557D58 if args.lookup == 'grade_merge' else 0x557CF0
                identity['return_signature_hex']=native[identity['return_rva']-0x557BA0:identity['return_rva']-0x557BA0+16].hex().upper()
                with ProcessReader() as reader:
                    assert reader.read(reader.module_base+identity['return_rva'],16).hex().upper()==identity['return_signature_hex']
                catalog=json.loads((HERE.parent/'guardian_spirits_native.json').read_text(encoding='utf-8'))
                identity['effect_ids']={g['id']:True for g in catalog['effect_groups'] if args.lookup != 'grade_merge' or g['flags_50']&4}
            # Lua dictionary keys must remain numeric, not the generic encoder's string keys.
            effect_ids = "{" + ",".join(f"[{key}]=true" for key in identity.pop("effect_ids")) + "}"
            bootstrap = """
local inventory=debug_getBreakpointList()
assert(inventory==nil or (type(inventory)=='table' and next(inventory)==nil),'Foreign breakpoints')
assert(not nioh3GuardianOrigin or (not nioh3GuardianOrigin.active and not nioh3GuardianOrigin.cleanup_pending and nioh3GuardianOrigin.pending_timers==0),'Prior observer not clean')
local broken=debug_isBroken()
if type(broken)~='boolean' then local ok,context=pcall(debug_getCurrentContextTable);assert(ok,'Debugger context query failed');broken=type(context)=='table' end
assert(not broken,'Stopped debugger event')
if not debug_isDebugging() then debugProcess(2) end
assert(debug_isDebugging(),'VEH debugger unavailable')
inventory=debug_getBreakpointList()
assert(type(inventory)=='table' and next(inventory)==nil,'Unknown/nonempty debugger inventory')
local identity=IDENTITY
identity.handle=getOpenedProcessHandle();identity.effect_ids=EFFECT_IDS
assert(getOpenedProcessID()==identity.pid and getAddressSafe('Nioh3.exe')==identity.module_base,'CE target mismatch')
local oneShot=assert(load(TIMER_SOURCE))()
local api={pid=getOpenedProcessID,base=function() return getAddressSafe('Nioh3.exe') end,
handle=getOpenedProcessHandle,list=debug_getBreakpointList,remove=debug_removeBreakpoint,
remove_id=debug_removeBreakpointByID,timer=oneShot,
cancel_timer=function(t) t.Enabled=false;t.destroy() end,
arm=function(a,fn) return debug_setBreakpoint(a,1,bptExecute,bpmDebugRegister,fn) end,
context=debug_getContext,u64=readQword,u32=readInteger,u16=readSmallInteger,
continue_event=function() debug_continueFromBreakpoint(co_run) end,
registers=function() return {RAX=RAX,RBX=RBX,RCX=RCX,RDX=RDX,RSI=RSI,RDI=RDI,RBP=RBP,RSP=RSP,R8=R8,R9=R9,R10=R10,R11=R11,R12=R12,R13=R13,R14=R14,R15=R15,RIP=RIP} end,
raw=function(a,n) local b=readBytes(a,n,true);assert(b and #b==n,'Unreadable bounded stack');local z={};for i=1,#b do z[i]=string.format('%02X',b[i]) end;return table.concat(z) end}
nioh3GuardianOrigin=assert(load(OBSERVER_SOURCE))()(api,identity,assert(load(OWNER_SOURCE))())
return {prepared=true,pid=getOpenedProcessID(),debugging=debug_isDebugging(),breakpoints=debug_getBreakpointList(),status=nioh3GuardianOrigin.status()}
"""
            replacements = {"IDENTITY": lua_literal(identity), "EFFECT_IDS": effect_ids,
                            "TIMER_SOURCE": lua_literal((ROOT / "research/ce_main_thread_timer.lua").read_text()),
                            "OBSERVER_SOURCE": lua_literal((HERE / ("guardian_semantics_observer.lua" if args.lookup in ('activation','merge','grade_merge') else "effect_origin_observer.lua")).read_text()),
                            "OWNER_SOURCE": lua_literal((ROOT / "research/owned_breakpoint_lifecycle_ce.lua").read_text())}
            for key, value in replacements.items():
                bootstrap = bootstrap.replace(key, value)
            lua("local value;synchronize(function() value=(function() " + bootstrap + " end)() end);return value")
            records["identity"] = identity
            (control_dir / "ce-prepared-identity.json").write_text(json.dumps(identity, indent=2) + "\n", encoding="utf-8")
        elif args.action in ("arm", "snapshot", "stop", "cleanup"):
            with ProcessReader() as reader:
                identity = json.loads((control_dir / "ce-prepared-identity.json").read_text(encoding="utf-8"))
                if reader.pid != identity["pid"] or reader.creation_time() != identity["creation_filetime"]:
                    raise RuntimeError("Prepared process identity changed")
                if args.action == "arm" and reader.read(reader.module_base+identity["site_rva"],16).hex().upper() != identity["signature_hex"]:
                    raise RuntimeError("Native site changed before arm")
            if args.action == "arm":
                lua("local value;synchronize(function() value=assert(nioh3GuardianOrigin).arm() end);return value")
            elif args.action == "cleanup":
                lua("local result;synchronize(function() local ok,value=pcall(function() return nioh3GuardianOrigin.retry_cleanup() end);local cok,context=pcall(debug_getCurrentContextTable);result={cleanup_ok=ok,value=value,inventory=debug_getBreakpointList(),status=nioh3GuardianOrigin.status(),context_query_ok=cok,stopped=type(context)=='table'} end);return result")
            elif args.action == "stop":
                lua("return assert(nioh3GuardianOrigin).stop('owner_runner_stop')")
                time.sleep(0.5)
                lua("return {status=nioh3GuardianOrigin.status(),inventory=debug_getBreakpointList(),debugging=debug_isDebugging(),broken=debug_isBroken()}")
            else:
                lua("return {status=nioh3GuardianOrigin.status(),events=nioh3GuardianOrigin.events,identity=nioh3GuardianOrigin.identity,inventory=debug_getBreakpointList(),debugging=debug_isDebugging(),broken=debug_isBroken()}")
    except Exception as error:
        records["error"] = str(error)
        raise
    finally:
        bridge.stop()
        destination = control_dir / ("ce-" + args.action + ".json")
        if destination.exists():
            destination = control_dir / ("ce-" + args.action + "-" + str(time.time_ns()) + ".json")
        destination.write_text(json.dumps(records, indent=2) + "\n")
    if args.action == 'snapshot':
        print(json.dumps({'action':args.action,'output':str(destination),'calls':[{'tool':c['tool'],'status':c['result'].get('status'),'event_count':len(c['result'].get('events',[]))} for c in records['calls']]}))
    else:
        print(json.dumps(records, ensure_ascii=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--action", choices=("query","prepare","arm","snapshot","stop","cleanup"), required=True)
    parser.add_argument("--pid", type=int)
    parser.add_argument('--lookup', choices=('effect','guardian','activation','merge','grade_merge','text'), default='effect')
    parser.add_argument('--output-dir',type=Path);parser.add_argument('--native-site-file',type=Path);parser.add_argument('--text-id-file',type=Path)
    parser.add_argument('--sample-all-text',action='store_true')
    main(parser.parse_args())
