"""Validate retained live duplicate merges against independently read native metadata."""
import hashlib,json,struct
from pathlib import Path
HERE=Path(__file__).resolve().parent
catalog=json.loads((HERE.parent/'guardian_spirits_native.json').read_text(encoding='utf-8'))
groups={g['id']:g for g in catalog['effect_groups']}
records=[]
for path in sorted(HERE.glob('ce-snapshot*.json')):
 data=json.loads(path.read_text())
 for call in data['calls']:
  result=call['result']
  if result.get('identity',{}).get('lookup_kind')=='merge' and result.get('events'):
   assert result['identity']['executable_sha256']==catalog['game_identity']['executable_sha256']
   records.append((path,data,result))
assert records
path,data,result=records[-1]
events=[]
for event in result['events']:
 key=event['group_id'];group=groups[key];raw=bytes.fromhex(group['raw_hex']);cap=struct.unpack_from('<i',raw,4)[0]
 def decode(value):
  raw=bytes.fromhex(value);assert len(raw)==12
  native_key,base,extra=struct.unpack_from('<H2xIH',raw)
  assert native_key==key
  return base,extra
 before,extra=decode(event['before_hex']);after,after_extra=decode(event['after_hex']);incoming=event['incoming_value']
 if key==0x38BA:
  expected=max((before+extra)&0xFFFFFFFF,incoming);expected_extra=extra;kind='special_max'
 elif group['flags_50']&4:
  expected=max(before,incoming);expected_extra=(extra+1)&0xFFFF;kind='grade_max_with_duplicate_rank_bonus'
 else:
  expected=(before+extra+incoming)&0xFFFFFFFF;expected_extra=extra;kind='sum_with_optional_cap'
  if cap>=0 and ((expected+extra)&0xFFFFFFFF)>cap:expected=cap
 assert (after,after_extra)==(expected,expected_extra),(key,event,(expected,expected_extra))
 events.append({'group_id':key,'label_zh':group['label_zh'],'kind':kind,'before_value':before,'before_extra':extra,
    'incoming':incoming,'after_value':after,'after_extra':after_extra,'raw_cap':cap,'match':True})
cleanup=[]
for candidate in sorted(HERE.glob('ce-cleanup*.json')):
 value=json.loads(candidate.read_text())
 if value.get('observer_sha256')!=data['observer_sha256']:continue
 for call in value['calls']:
  native=call['result'];status=native.get('status',{})
  if status.get('event_count')==len(events) and native.get('inventory')==[] and not native.get('stopped',True) and not status.get('active',True) and not status.get('cleanup_pending',True) and status.get('pending_timers')==0 and status.get('owned_breakpoints')==[]:
   cleanup.append(candidate)
assert cleanup
report={'schema':'nioh3-native-guardian-semantics-validation/v1','status':'passed_scoped_live_merges',
  'native_snapshot':{'path':str(path.relative_to(HERE)), 'sha256':hashlib.sha256(path.read_bytes()).hexdigest()},
  'cleanup_proof':{'path':str(cleanup[-1].relative_to(HERE)),'sha256':hashlib.sha256(cleanup[-1].read_bytes()).hexdigest()},
  'native_merge_pairs':len(events),'matched_pairs':len(events),'unpaired_events':result['status']['unpaired_events'],
  'numeric_merge_pairs':sum(e['kind']=='sum_with_optional_cap' for e in events),
  'grade_merge_pairs':sum(e['kind']=='grade_max_with_duplicate_rank_bonus' for e in events),
  'distinct_groups':len({e['group_id'] for e in events}),'events':events,'game_writes':0,
  'scope':'Native same-group attribute-bucket merges only. This does not prove final damage multiplication, temporary buff refresh/overwrite rules, or a legal guardian maximum level.'}
(HERE/'semantics-live-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='events'}))
print(json.dumps(list({(e['group_id'],e['label_zh'],e['kind'],e['before_value'],e['incoming'],e['after_value'],e['after_extra']) for e in events}),ensure_ascii=True))
