"""Print bounded facts from retained native sources."""
import json,struct
from pathlib import Path
HERE=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
raw=(HERE/'native-tables-01/effect_group-rows.bin').read_bytes()
texts=load(HERE/'native-text-03.json')['entries']
for offset in range(8,len(raw),112):
    if struct.unpack_from('<H',raw,offset+12)[0]==0x8508:
        row=raw[offset:offset+112]
        print('GATE_ROW',row.hex())
        for at in (0x2c,0x30,0x34,0x38,0x3c,0x48):
            key=struct.unpack_from('<I',row,at)[0]
            print(hex(at),hex(key),json.dumps([e['text'] for e in texts.get(str(key),[])],ensure_ascii=True))
root=HERE.parents[2]
bundle=root/'nioh3_scroll_editor/data/r4_finalizer/pc_v2_02/resource_v1'
spec=next(t for t in load(bundle/'manifest.json')['tables'] if t['name']=='effect')
effect=(bundle/spec['file']['filename']).read_bytes()
print('GATE_EQUIPMENT_IDS',[struct.unpack_from('<H',effect,i)[0] for i in range(8,len(effect),216) if struct.unpack_from('<H',effect,i+2)[0]==0x8508])
for filename,starts,terms in (
 ('activation-consumers-02/capture.json',[0x374f58,0x1d7eee0],['8508','call 0x3fbd08','call 0x557ba0','call 0x375364','0x148','0x3e16ef1','0x72','0x70','0x7d0']),
 ('activation-consumers-03/capture.json',[0x217df90],['0x148','call']),
 ('activation-functions-04/capture.json',[0x21a2604],['0x630','0xb8','call 0x217df90']),
 ('aggregation-functions-02/capture.json',[0x557ba0],['0x557d0f','0x557d3e','0x50','[rbp + 4]']),
 ('aggregation-functions-03/capture.json',[0x19a11e9],['word ptr','add','mov'])):
    data=load(HERE/filename)
    for f in data.get('functions',data.get('code_consumers',[])):
        if int(f['begin'],0) not in starts:continue
        print('FUNCTION',filename,f['begin'],f.get('path'),f.get('sha256'))
        hits=[i for i,x in enumerate(f['instructions']) if any(t in x['instruction'] for t in terms)]
        selected=set()
        for i in hits:selected.update(range(max(0,i-2),min(len(f['instructions']),i+4)))
        for i in sorted(selected):print(f['instructions'][i]['rva'],f['instructions'][i]['instruction'])
text=load(HERE/'activation-keyword-native-text-03.json')['entries']
for key in (0x3e16ef1,0x4319d1e,0x9c8512b):
 print('ACTIVATION_TEXT',hex(key),json.dumps([e['text'] for e in text.get(str(key),[])],ensure_ascii=True))
