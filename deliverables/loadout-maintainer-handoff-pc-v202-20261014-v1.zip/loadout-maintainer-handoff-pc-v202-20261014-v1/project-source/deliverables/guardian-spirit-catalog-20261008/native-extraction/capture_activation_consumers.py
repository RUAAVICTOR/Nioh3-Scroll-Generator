"""Bounded native field/call consumer capture, never changes game state."""
import argparse,bisect,hashlib,json,re,struct,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'deliverables/load-capacity-research/scripts')]
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86 import X86_OP_MEM,X86_OP_IMM,X86_REG_RIP
from research.native_xrefs import parse_runtime_functions
from research.dump_live_pe_sections import _pe_section_headers
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from capture_player import _process_executable,_sha256,_file_version

def capture(output, targets, narrow_field=False, manager_contexts=(), plan_path=None, identity_path=None, pdata_path=None, immediates=(), data_ranges=()):
    assert not output.exists();output.mkdir(parents=True)
    plan=json.loads((plan_path or HERE/'activation-stacking-plan.json').read_text())
    identity=json.loads((identity_path or HERE/'native-tables-01/capture.json').read_text())
    functions=parse_runtime_functions((pdata_path or HERE/'discovery-03/pdata.bin').read_bytes());starts=[f.begin_rva for f in functions]
    started=time.monotonic();reads=0;decoded=0
    report={'experiment':plan,'targets':[hex(t) for t in targets],'status':'partial','game_writes':0,'code_consumers':[],'blobs':[]}
    def read(reader,address,size):
        nonlocal reads
        reads+=size
        assert reads<=plan['limits']['read_bytes'] and time.monotonic()-started<plan['limits']['seconds']
        return reader.read(address,size)
    def retain(name,address,raw):
        (output/name).write_bytes(raw)
        report['blobs'].append({'path':name,'address':hex(address),'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    try:
        with ProcessReader() as reader:
            assert reader.pid==identity['pid'] and reader.creation_time()==identity['process_birth_filetime']
            exe=_process_executable(reader)
            assert list(_file_version(exe))==[2,0,2,0] and _sha256(exe)==identity['executable_sha256']
            report.update(pid=reader.pid,process_birth_filetime=reader.creation_time(),module_base=hex(reader.module_base),executable_sha256=identity['executable_sha256'])
            signature=bytes.fromhex('4883ec48488bc2440fb7d9488bc8488d')
            assert read(reader,reader.module_base+0x375364,len(signature))==signature
            for rva in (() if manager_contexts or immediates or data_ranges else (0x4751850,0x4751860)):
                pointer=struct.unpack('<Q',read(reader,reader.module_base+rva,8))[0]
                if pointer:
                    data=read(reader,pointer,0x200);retain(f'root-{rva:X}.bin',pointer,data)
                    report[f'root_{rva:X}']={'address':hex(pointer),'u16_72':struct.unpack_from('<H',data,0x72)[0],'u16_148':struct.unpack_from('<H',data,0x148)[0]}
            section=next(s for s in _pe_section_headers(exe) if s[0]=='.text')
            selected={};cursor=0;tail=b''
            root_decoder=Cs(CS_ARCH_X86,CS_MODE_64);root_decoder.detail=True
            root_window_bytes=0
            while cursor<section[2]:
                block=read(reader,reader.module_base+section[1]+cursor,min(1048576,section[2]-cursor))
                data=tail+block;base=section[1]+cursor-len(tail)
                # Root-specific RIP-relative MOVs avoid unrelated stack +0x148.
                candidates=[];pos=0
                for context in tuple(immediates):
                    pos=0;needle=struct.pack('<I',context)
                    while True:
                        at=data.find(needle,pos)
                        if at<0:break
                        pos=at+1;candidates.append(base+at)
                for match in re.finditer(rb'[\x48\x4c][\x8b\x8d][\x05\x0d\x15\x1d\x25\x2d\x35\x3d]([\s\S]{4})',data):
                    at=match.start()
                    root=base+at+7+struct.unpack('<i',match.group(1))[0]
                    if any(begin<=root<end for begin,end in data_ranges):
                        candidates.append(base+at)
                    elif manager_contexts and root==0x45B9E30:
                        window=data[at:at+96];root_window_bytes+=len(window)
                        assert root_window_bytes<=plan['limits']['decoded_bytes']
                        nearby=list(root_decoder.disasm(window,base+at))
                        if any(op.type==X86_OP_MEM and op.mem.disp in manager_contexts for i in nearby for op in i.operands):
                            candidates.append(base+at)
                    elif not manager_contexts and not immediates and not data_ranges and root==0x4751860:
                        candidates.append(base+at)
                if narrow_field:
                    pos=0
                    while True:
                        at=data.find(b'\x48\x01\0\0',pos)
                        if at<0:break
                        pos=at+1;prefix=data[max(0,at-5):at]
                        if b'\x66' in prefix or b'\x0f\xb7' in prefix:candidates.append(base+at)
                pos=0
                while True:
                    at=data.find(b'\xe8',pos)
                    if at<0 or at+5>len(data):break
                    pos=at+1
                    if base+at+5+struct.unpack_from('<i',data,at+1)[0] in targets:candidates.append(base+at)
                for rva in candidates:
                    index=bisect.bisect_right(starts,rva)-1
                    if index>=0 and rva<functions[index].end_rva:selected[functions[index].begin_rva]=functions[index]
                cursor+=len(block);tail=block[-4:]
            assert len(selected)<=plan['limits']['functions'],len(selected)
            decoder=Cs(CS_ARCH_X86,CS_MODE_64);decoder.detail=True
            skipped=[]
            for function in selected.values():
                size=function.end_rva-function.begin_rva
                if size>plan['limits']['function_bytes']:skipped.append(hex(function.begin_rva));continue
                decoded+=size;assert decoded<=plan['limits']['decoded_bytes']
                data=read(reader,reader.module_base+function.begin_rva,size)
                insns=list(decoder.disasm(data,function.begin_rva))
                direct=[hex(i.address) for i in insns if i.mnemonic in ('call','jmp') and i.operands and i.operands[0].type==X86_OP_IMM and i.operands[0].imm in targets]
                global_refs=[];field_refs=[]
                for insn in insns:
                    for op in insn.operands:
                        if op.type!=X86_OP_MEM:continue
                        if op.mem.base==X86_REG_RIP and insn.address+insn.size+op.mem.disp==0x4751860:global_refs.append(hex(insn.address))
                        if op.mem.disp==0x148:field_refs.append(hex(insn.address))
                narrow_refs=[hex(i.address) for i in insns if '+ 0x148]' in i.op_str and 'word ptr [' in i.op_str and 'dword ptr' not in i.op_str and 'qword ptr' not in i.op_str and 'rbp +' not in i.op_str and 'rsp +' not in i.op_str]
                manager_roots=[hex(i.address) for i in insns for op in i.operands if op.type==X86_OP_MEM and op.mem.base==X86_REG_RIP and i.address+i.size+op.mem.disp==0x45B9E30]
                context_refs=[hex(i.address) for i in insns for op in i.operands if op.type==X86_OP_MEM and op.mem.disp in manager_contexts]
                immediate_refs=[hex(i.address) for i in insns for op in i.operands if op.type==X86_OP_IMM and op.imm in immediates]
                data_refs=[hex(i.address) for i in insns for op in i.operands if op.type==X86_OP_MEM and op.mem.base==X86_REG_RIP and any(begin<=i.address+i.size+op.mem.disp<end for begin,end in data_ranges)]
                if data_ranges:
                    if not data_refs and not direct:continue
                elif immediates:
                    if not immediate_refs and not direct and not (manager_roots and context_refs):continue
                elif manager_contexts:
                    if not direct and not (manager_roots and context_refs):continue
                elif not direct and not (global_refs and field_refs) and not (narrow_field and narrow_refs):continue
                retain(f'{function.begin_rva:X}.bin',reader.module_base+function.begin_rva,data)
                report['code_consumers'].append({'begin':hex(function.begin_rva),'end':hex(function.end_rva),'signature':data[:16].hex(),
                    'direct_sites':direct,'global_refs':global_refs,'field_refs':field_refs,'narrow_field_refs':narrow_refs,
                    'manager_root_sites':manager_roots,'candidate_context_sites':context_refs,
                    'immediate_sites':immediate_refs,
                    'data_reference_sites':data_refs,
                    'instructions':[{'rva':hex(i.address),'bytes':i.bytes.hex(),'instruction':i.mnemonic+' '+i.op_str} for i in insns]})
            assert reader.creation_time()==identity['process_birth_filetime']
            report.update(status='complete_bounded_native_capture',prefilter_functions=len(selected),skipped_functions=skipped)
            report.update(manager_prefilter_window_bytes=96,manager_prefilter_decoded_bytes=root_window_bytes,
                          manager_prefilter_limitation='Context access farther than 96 bytes from a manager root may be missed')
    except Exception as error:
        report['error']=str(error);raise
    finally:
        report.update(read_bytes=reads,decoded_bytes=decoded,elapsed_seconds=time.monotonic()-started,process_handle_closed=True,debugger_used=False)
        (output/'capture.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('status','read_bytes','decoded_bytes','elapsed_seconds')}))
    print(json.dumps({'consumers':len(report['code_consumers'])}))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True,type=Path);parser.add_argument('--targets',nargs='+',type=lambda v:int(v,0));parser.add_argument('--narrow-field',action='store_true')
    parser.add_argument('--manager-contexts',nargs='+',type=lambda v:int(v,0),default=[])
    parser.add_argument('--plan',type=Path);parser.add_argument('--identity',type=Path);parser.add_argument('--pdata',type=Path)
    parser.add_argument('--immediates',nargs='+',type=lambda v:int(v,0),default=[])
    parser.add_argument('--data-ranges',nargs='+',type=lambda v:int(v,0),default=[])
    args=parser.parse_args()
    assert len(args.data_ranges)%2==0
    data_ranges=list(zip(args.data_ranges[::2],args.data_ranges[1::2]));assert all(0<=b<e for b,e in data_ranges)
    targets=args.targets if args.targets is not None else ([] if args.manager_contexts or args.immediates or data_ranges else [0x375364,0x1ABAB18])
    capture(args.output.resolve(),set(targets),args.narrow_field,args.manager_contexts,args.plan,args.identity,args.pdata,args.immediates,data_ranges)
