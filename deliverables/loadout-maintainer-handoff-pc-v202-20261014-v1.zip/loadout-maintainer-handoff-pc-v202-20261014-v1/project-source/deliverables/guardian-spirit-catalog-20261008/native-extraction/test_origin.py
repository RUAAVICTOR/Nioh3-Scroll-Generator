"""Run actual observer code in a closed Lua mock before native arming."""
import ctypes
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
source = r'''
local function scenario(options)
  options=options or {}
  local s={sites={},timers={},continues=0,removed={}}
  local identity={pid=1,module_base=0x10000000,handle=123,creation_filetime='1',
    executable_sha256='MOCK',site_rva=0x1000,signature_hex=string.rep('AA',16),
    effect_context=0x20000000,effect_ids={[0x2512]=true}}
  local regs={RAX=0,RBX=0,RCX=0x20000000,RDX=0x100002512,RSI=0,RDI=0,RBP=0,
    RSP=0x30000000,R8=0,R9=0,R10=0,R11=0,R12=0,R13=0,R14=0,R15=0,RIP=0x10001000}
  if options.text then identity.lookup_kind='text';regs.RCX=0x102512;identity.effect_ids={[0x102512]=true} end
  if options.sample_all then identity.sample_all_text=true end
  local api={pid=function() return options.changed and 2 or 1 end,
    base=function() return identity.module_base end,handle=function() return 123 end,
    context=function() end,registers=function() return regs end,
    raw=function(a,n) if a==0x10001000 then return string.rep(options.bad_signature and 'BB' or 'AA',16) end;assert(a==regs.RSP and n==0x180);if options.read_fail then error('mock stack read failure') end;return string.rep('00',n) end,
    u64=function(a) assert(a==regs.RSP);return 0x10500000 end,
    continue_event=function() s.continues=s.continues+1 end,
    list=function() local x={};for a in pairs(s.sites) do x[#x+1]=a end;return x end,
    arm=function(a,fn) s.sites[a]=fn;return true end,
    remove=function(a) s.removed[#s.removed+1]=a;s.sites[a]=nil end,
    timer=function(delay,fn) local t={delay=delay,fn=fn};s.timers[t]=true;return t end,
    cancel_timer=function(t) s.timers[t]=nil end}
  s.api=api;s.regs=regs;s.options=options
  s.probe=assert(load(OBSERVER))()(api,identity,assert(load(OWNER))())
  function s.fire() assert(s.sites[0x10001000])() end
  function s.ticks()
    for t in pairs(s.timers) do s.timers[t]=nil;t.fn() end
  end
  return s
end
local passed=0
local function check(fn) fn();passed=passed+1 end
check(function() local s=scenario();s.probe.arm();s.fire();assert(#s.probe.events==1 and s.probe.events[1].effect_id==0x2512);assert(s.continues==1);s.probe.stop();s.ticks();assert(not s.probe.active and not s.probe.cleanup_pending and #s.probe.owned_breakpoints==0 and s.probe.pending_timers==0) end)
check(function() local s=scenario();s.sites[0x777]=function()end;assert(not pcall(s.probe.arm));assert(s.sites[0x777] and #s.removed==0) end)
check(function() local s=scenario();s.probe.arm();s.options.changed=true;s.fire();s.ticks();assert(s.continues==1 and s.probe.error and #s.probe.events==0 and #s.probe.owned_breakpoints==0) end)
check(function() local s=scenario();s.probe.arm();s.options.bad_signature=true;s.fire();s.ticks();assert(s.continues==1 and s.probe.error and #s.probe.events==0 and #s.probe.owned_breakpoints==0) end)
check(function() local s=scenario({read_fail=true});s.probe.arm();s.fire();s.ticks();assert(s.continues==1 and s.probe.error and #s.probe.owned_breakpoints==0) end)
check(function() local s=scenario();s.probe.arm();s.probe.active=false;s.fire();assert(s.continues==1 and #s.probe.events==0);s.probe.stop();s.ticks() end)
check(function() local s=scenario();s.probe.arm();s.regs.RCX=1;s.fire();assert(s.probe.ignored==1 and s.continues==1);s.probe.stop();s.ticks() end)
check(function() local s=scenario();s.probe.max_hits=1;s.probe.arm();s.regs.RCX=1;s.fire();s.fire();s.ticks();assert(s.probe.stop_reason=='hit_bound' and s.continues==2 and #s.probe.owned_breakpoints==0) end)
check(function() local s=scenario();s.probe.max_events=1;s.probe.arm();s.fire();s.ticks();assert(s.probe.stop_reason=='event_bound' and s.continues==1 and #s.probe.owned_breakpoints==0) end)
check(function() local s=scenario({text=true});s.probe.arm();s.fire();assert(#s.probe.events==1 and s.probe.events[1].text_id==0x102512 and s.continues==1);s.probe.stop();s.ticks();assert(#s.probe.owned_breakpoints==0) end)
check(function() local s=scenario({text=true});s.probe.arm();s.regs.RCX=0x100102512;s.fire();assert(#s.probe.events==1 and s.probe.events[1].text_id==0x102512 and s.continues==1);s.probe.stop();s.ticks() end)
check(function() local s=scenario({text=true});s.probe.arm();s.regs.RCX=0x987;s.fire();assert(#s.probe.events==0 and s.probe.ignored==1 and s.continues==1);s.probe.stop();s.ticks() end)
check(function() local s=scenario({text=true,sample_all=true});s.probe.arm();s.regs.RCX=0x987;s.fire();assert(#s.probe.events==1 and s.probe.events[1].text_id==0x987 and s.continues==1);s.probe.stop();s.ticks() end)
check(function() local s=scenario({sample_all=true});s.probe.arm();s.regs.RDX=0x987;s.fire();assert(#s.probe.events==0 and s.probe.ignored==1 and s.continues==1);s.probe.stop();s.ticks() end)
assert(passed==14)
'''


def quote(path):
    return '"' + ''.join(chr(b) if 32 <= b < 127 and b not in (34, 92) else "\\" + str(b).zfill(3) for b in str(path).encode()) + '"'


lua = ctypes.CDLL(os.environ["LUA54_LIBRARY"])
lua.luaL_newstate.restype = ctypes.c_void_p
lua.luaL_openlibs.argtypes = [ctypes.c_void_p]
lua.luaL_loadstring.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
lua.luaL_loadstring.restype = ctypes.c_int
lua.lua_pcallk.argtypes = [ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_ssize_t,ctypes.c_void_p]
lua.lua_pcallk.restype = ctypes.c_int
lua.lua_tolstring.argtypes = [ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p]
lua.lua_tolstring.restype = ctypes.c_char_p
lua.lua_close.argtypes = [ctypes.c_void_p]
state = lua.luaL_newstate()
try:
    lua.luaL_openlibs(state)
    payload = ("OBSERVER=" + quote((HERE / "effect_origin_observer.lua").read_text()) + ";OWNER=" + quote((ROOT / "research/owned_breakpoint_lifecycle_ce.lua").read_text()) + ";" + source).encode()
    result = lua.luaL_loadstring(state,payload)
    if not result:
        result = lua.lua_pcallk(state,0,0,0,0,None)
    if result:
        raise RuntimeError(lua.lua_tolstring(state,-1,None).decode(errors="replace"))
    print("14 closed-mock observer scenarios passed; no CE or game access.")
finally:
    lua.lua_close(state)
