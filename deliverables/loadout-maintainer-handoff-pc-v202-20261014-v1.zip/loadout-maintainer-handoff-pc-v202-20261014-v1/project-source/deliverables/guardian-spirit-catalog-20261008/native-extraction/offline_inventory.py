"""Inspect retained native resources only; never attach to the running game."""
import hashlib
import json
import struct
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BUNDLE = ROOT / "nioh3_scroll_editor/data/r4_finalizer/pc_v2_02/resource_v1"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def source(path):
    return {"path": path.relative_to(ROOT).as_posix(),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    manifest_path = BUNDLE / "manifest.json"
    manifest = load(manifest_path)
    resources = {}
    inputs = [source(manifest_path)]
    for spec in manifest["tables"]:
        if spec["name"] not in ("effect", "effect_group", "level_curve"):
            continue
        path = BUNDLE / spec["file"]["filename"]
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest.upper() != spec["file"]["sha256"].upper() or len(raw) != spec["file"]["size"]:
            raise RuntimeError("Native resource identity mismatch: " + str(path))
        if len(raw) != 8 + spec["row_size"] * spec["row_count"]:
            raise RuntimeError("Unexpected native row store length")
        if struct.unpack_from("<I", raw, 4)[0] != spec["row_count"]:
            raise RuntimeError("Native row count mismatch")
        resources[spec["name"]] = {"spec": spec, "raw": raw}
        inputs.append(source(path))
    group_rows = resources["effect_group"]
    text_ids = {}
    for i in range(group_rows["spec"]["row_count"]):
        begin = 8 + i * group_rows["spec"]["row_size"]
        key = struct.unpack_from("<H", group_rows["raw"], begin + 0x0C)[0]
        text_id = struct.unpack_from("<I", group_rows["raw"], begin + 0x2C)[0]
        if key in text_ids:
            raise RuntimeError("Duplicate effect-group key")
        text_ids[key] = text_id
    effect_rows = resources["effect"]
    native = {}
    for i in range(effect_rows["spec"]["row_count"]):
        begin = 8 + i * effect_rows["spec"]["row_size"]
        effect_id, group = struct.unpack_from("<HH", effect_rows["raw"], begin)
        if effect_id in native:
            raise RuntimeError("Duplicate native effect ID")
        native[effect_id] = {"row_index": i, "group_key": group,
                             "native_text_id": text_ids.get(group),
                             "row_sha256": hashlib.sha256(effect_rows["raw"][begin:begin + 0xD8]).hexdigest()}
    names_path = ROOT / "nioh3_scroll_editor/data/effect_names_multilingual.json"
    names = load(names_path)
    inputs.append(source(names_path))
    anchors = ("不消耗使役符以外的阴阳术", "强攻击吸取体力",
               "守护灵技命中赋予^09~BUFF~{}^09~~", "格挡成功时赋予^09~BUFF~{}^09~~")
    anchor_candidates = {}
    for label in anchors:
        matches = []
        for entry in names["effects"].values():
            if entry["names"].get("zh-CN") != label:
                continue
            record = native.get(entry["effect_id"])
            if not record:
                continue
            matches.append({"effect_id": f"0x{entry['effect_id']:04X}", **record,
                            "historical_text_id": entry["text_id"],
                            "historical_text_id_matches_v202_row": record["native_text_id"] == int(entry["text_id"], 16),
                            "historical_name_provenance": entry.get("provenance", {}).get("zh-CN"),
                            "guardian_membership_verified": False})
        anchor_candidates[label] = matches
    capture_path = HERE.parent / "live/manager-inspection.json"
    capture = load(capture_path)
    inputs.append(source(capture_path))
    report = {
        "schema": "nioh3-guardian-native-extraction-offline-inventory/v1",
        "runtime_access_performed": False, "game_writes_performed": False,
        "game_version": manifest["game_version"],
        "verified_resource_counts": {key: value["spec"]["row_count"] for key, value in resources.items()},
        "localization_version": names["game_version"],
        "historical_localization_is_current_version_capture": False,
        "anchor_candidates": anchor_candidates,
        "manager_snapshot": {"pid_at_capture": capture["pid"],
                             "executable_sha256": capture["executable_sha256"],
                             "candidate_context_count": len(capture["exploratory_table_candidates"]),
                             "guardian_context_identified": False},
        "source_files": inputs,
        "scope": "Hash-verified existing native rows and candidate text-ID joins. No guardian-to-effect mapping, current localization capture, guardian formulas or exhaustive roster claim.",
    }
    (HERE / "offline_inventory.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"native_counts": report["verified_resource_counts"],
                      "anchor_candidate_counts": {key: len(value) for key, value in anchor_candidates.items()},
                      "current_text_id_matches": {key: sum(item["historical_text_id_matches_v202_row"] for item in value) for key, value in anchor_candidates.items()},
                      "guardian_context_identified": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
