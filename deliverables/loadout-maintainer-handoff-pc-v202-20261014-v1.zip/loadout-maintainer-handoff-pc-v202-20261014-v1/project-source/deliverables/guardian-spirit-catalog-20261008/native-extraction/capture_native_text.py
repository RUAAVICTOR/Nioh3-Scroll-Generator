"""Bounded current-runtime text-ID extraction; historical text is only an anchor."""
import argparse,hashlib,json,struct,sys,time
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'research')]
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from dump_effect_catalog_current_locale import _candidate_regions,parse_text_entry,TEXT_ID_ANCHORS

def capture(pid,output,window_mb):
    assert not output.exists()
    table_dir=HERE/'native-tables-01';tables=json.loads((table_dir/'capture.json').read_text())
    names=json.loads((ROOT/'nioh3_scroll_editor/data/effect_names_multilingual.json').read_text(encoding='utf-8-sig'))
    expected={text_id:names['effects'][f'0x{effect_id:08X}']['names']['zh-CN'] for effect_id,text_id in TEXT_ID_ANCHORS.items()}
    wanted=set(expected)
    for name,stride,offset in (('guardian',0x100,0x2C),('effect_group',0x70,0x2C)):
        spec=next(x for x in tables['blobs'] if x['path']==name+'-rows.bin');data=(table_dir/spec['path']).read_bytes()
        assert hashlib.sha256(data).hexdigest()==spec['sha256']
        wanted.update(struct.unpack_from('<I',data,i+offset)[0] for i in range(8,len(data),stride))
    wanted.discard(0);wanted.discard(0xFFFFFFFF)
    guardian_raw=(table_dir/'guardian-rows.bin').read_bytes()
    guardian_groups={struct.unpack_from('<I',guardian_raw,offset+0x6C+slot*12)[0] for offset in range(8,len(guardian_raw),0x100) for slot in range(6)}
    group_raw=(table_dir/'effect_group-rows.bin').read_bytes()
    for offset in range(8,len(group_raw),0x70):
        if struct.unpack_from('<H',group_raw,offset+0xC)[0] in guardian_groups:
            wanted.update(value for value in struct.unpack_from('<10I',group_raw,offset+0x2C) if 0x10000<=value<0x10000000)
    report={'schema':'nioh3-native-text-capture/v1','captured_at_utc':datetime.now(timezone.utc).isoformat(),
      'status':'partial','pid':pid,'game_writes':0,'read_only':True,'entries':{},'attempts':[]}
    started=time.monotonic();total=0
    try:
        with ProcessReader() as reader:
            assert reader.pid==pid and reader.creation_time()==tables['process_birth_filetime']
            class Bounded:
                def read(self,address,size,exact=True):
                    nonlocal total
                    assert time.monotonic()-started<30 and total+size<=768*1024*1024,'Text capture read/time bound'
                    total+=size;return reader.read(address,size,exact=exact)
            bounded=Bounded();regions=_candidate_regions(reader)
            windows=[]
            for region in regions:
                hint=region.allocation_base+0x1514F0000
                if region.memory_type==0x20000 and region.base<=hint<region.base+region.size:
                    windows.append((max(region.base,hint-48*1048576),min(region.base+region.size,hint+48*1048576),'relative_hint'))
            windows.extend((max(r.base,r.base+r.size-256*1048576),r.base+r.size,'private_tail') for r in regions if r.memory_type==0x20000 and r.size>=64*1048576)
            anchors=[];center=None
            for start,end,mode in windows:
                report['attempts'].append({'start':hex(start),'end':hex(end),'mode':mode})
                cursor=start
                while cursor<end:
                    size=min(4*1048576,end-cursor);block=bounded.read(cursor,size)
                    for text_id,label in expected.items():
                        pattern=struct.pack('<I',text_id);offset=0
                        while True:
                            found=block.find(pattern,offset)
                            if found<0:break
                            offset=found+1;entry=parse_text_entry(bounded,cursor+found,text_id)
                            if entry and entry.text==label:anchors.append(entry)
                    if len({e.text_id for e in anchors})>=2:
                        for anchor in anchors:
                            cluster=[e for e in anchors if abs(e.address-anchor.address)<=2*1048576]
                            if len({e.text_id for e in cluster})>=2:
                                center=sum(e.address for e in cluster)//len(cluster);break
                    if center:break
                    cursor+=size
                if center:break
            assert center,'No validated current Chinese text cluster in read budget'
            report['pool_center']=hex(center)
            report['anchors']=[{'text_id':hex(e.text_id),'address':hex(e.address),'text':e.text} for e in anchors]
            region=next(r for r in regions if r.base<=center<r.base+r.size)
            start=max(region.base,center-window_mb*1024*1024//2);end=min(region.base+region.size,center+window_mb*1024*1024//2)
            block=bounded.read(start,end-start);found_entries={}
            for text_id in wanted:
                pattern=struct.pack('<I',text_id);offset=0
                while True:
                    found=block.find(pattern,offset)
                    if found<0:break
                    offset=found+1;entry=parse_text_entry(bounded,start+found,text_id)
                    if entry:
                        raw=bounded.read(entry.address,8+entry.code_units_including_null*2)
                        found_entries.setdefault(text_id,[]).append({'address':hex(entry.address),'text':entry.text,
                          'raw_hex':raw.hex(),'sha256':hashlib.sha256(raw).hexdigest()})
            report['entries']={str(key):values for key,values in found_entries.items()}
            report.update(process_birth_filetime=reader.creation_time(),module_base=hex(reader.module_base),executable_sha256=tables['executable_sha256'])
            assert reader.creation_time()==tables['process_birth_filetime']
            report['status']='complete_native_text_window_capture'
    except Exception as error:
        report['error']=str(error);raise
    finally:
        report.update(process_handle_closed=True,total_requested_read_bytes=total,elapsed_seconds=time.monotonic()-started)
        output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'pool_center':report.get('pool_center'),'wanted':len(wanted),
      'resolved':len(report['entries']),'read_bytes':total,'elapsed_seconds':report['elapsed_seconds']}))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--pid',type=int,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--window-mb',type=int,choices=(2,8,32),default=2)
    args=parser.parse_args();capture(args.pid,args.output.resolve(),args.window_mb)
