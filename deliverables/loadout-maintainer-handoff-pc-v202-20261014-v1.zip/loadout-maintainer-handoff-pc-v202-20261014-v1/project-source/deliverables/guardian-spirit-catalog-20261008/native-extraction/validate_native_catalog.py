"""Independently verify native joins, calculations and separate UI cross-checks."""
import ctypes
import hashlib
import json
import struct
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE.parent

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def main():
    catalog = load(OUT / 'guardian_spirits_native.json')
    assert catalog['source_policy']['native_only']
    assert catalog['schema'] == 'nioh3-native-guardian-catalog/v2'
    for source in catalog['sources']:
        data = (OUT / source['path']).read_bytes()
        assert len(data) == source['size'] and hashlib.sha256(data).hexdigest() == source['sha256']
    table = (HERE / 'native-tables-01/guardian-rows.bin').read_bytes()
    growth = (HERE / 'native-tables-01/guardian_growth-rows.bin').read_bytes()
    groups = (HERE / 'native-tables-01/effect_group-rows.bin').read_bytes()
    multiplier = struct.unpack('<f', (HERE / 'native-tables-01/growth-multiplier.bin').read_bytes())[0]
    recapture = load(HERE / 'native-tables-02/capture.json')
    assert recapture['status'] == 'complete_native_table_capture'
    assert recapture['executable_sha256'] == catalog['game_identity']['executable_sha256']
    for blob in recapture['blobs']:
        fresh = (HERE / 'native-tables-02' / blob['path']).read_bytes()
        assert hashlib.sha256(fresh).hexdigest() == blob['sha256']
        assert fresh == (HERE / 'native-tables-01' / blob['path']).read_bytes()
    group_by_key = {struct.unpack_from('<H', groups, pos+12)[0]: groups[pos:pos+112] for pos in range(8,len(groups),112)}
    semantics = load(OUT/'guardian_semantics_native.json')
    assert catalog['semantics']['activation'] == semantics['activation']
    assert semantics['activation']['kind'] == 'destroyed_crucible_spike_count'
    gate = semantics['other_style_guardian_condition']
    assert catalog['semantics']['other_style_guardian_condition'] == gate
    assert bytes.fromhex(gate['raw_group_row_hex']) == group_by_key[0x8508]
    gate_texts = load(HERE/'cross-style-native-text-01.json')['entries']
    assert gate['label_zh'] == gate_texts[str(struct.unpack_from('<I',group_by_key[0x8508],44)[0])][0]['text'] == '双灵庇佑'
    assert gate['description_zh'] == gate_texts[str(struct.unpack_from('<I',group_by_key[0x8508],48)[0])][0]['text']
    merge_validation = load(HERE/'semantics-live-validation.json')
    assert merge_validation['matched_pairs'] == merge_validation['native_merge_pairs'] == 57
    assert merge_validation['distinct_groups'] == 1 and merge_validation['grade_merge_pairs'] == 0
    assert semantics['same_group_merge']['grade']['observed_pairs'] == 0
    # Confirm the original code windows really contain the reported functions.
    proofs = 0
    for name, directory, base in (
        ('guardian-function-analysis.json', 4, 0x374000),
        ('guardian-value-formatter-analysis.json', 6, 0x1BC1C00),
        ('guardian-unit-formatter-analysis.json', 7, 0x1BC1800),
        ('guardian-grade-formatter-analysis.json', 8, 0x22CE100)):
        code = (HERE / f'discovery-{directory:02}/lookup-code.bin').read_bytes()
        for function in load(HERE / name):
            begin, end = int(function['begin'],0), int(function['end'],0)
            raw = code[begin-base:end-base]
            assert hashlib.sha256(raw).hexdigest() == function['sha256']
            assert raw.startswith(bytes.fromhex(function['signature']))
            proofs += 1
    roster = catalog['guardians']
    assert len(roster) == 22 and sum(r['style']=='samurai' for r in roster) == 10
    assert len(catalog['native_records']) == 52
    calculation_checks = 0
    activation_checks = 0
    aggregation_checks = set()
    for guardian in catalog['native_records']:
        row = table[8+guardian['row_index']*256:8+(guardian['row_index']+1)*256]
        assert row.hex() == guardian['raw_hex']
        assert struct.unpack_from('<I',row,36)[0] == guardian['guardian_id']
        for index, slot in enumerate(guardian['slots']):
            assert struct.unpack_from('<Iii',row,108+index*12) == (slot['effect_group_id'],slot['base_value'],slot['growth_value'])
            assert struct.unpack_from('<HH',row,196+index*4) == (slot['curve_selector'],slot['activation_threshold'])
            assert slot['activation_requirement']['kind'] == 'destroyed_crucible_spike_count'
            assert slot['activation_requirement']['required_count'] == struct.unpack_from('<H',row,198+index*4)[0]
            activation_checks += 1
            if guardian['current_roster_record'] and index<5:
                native_group = group_by_key[slot['effect_group_id']]
                exported = next(g for g in catalog['effect_groups'] if g['id']==slot['effect_group_id'])
                assert native_group.hex() == exported['raw_hex']
                assert exported['aggregation']['raw_cap_i32'] == struct.unpack_from('<i',native_group,4)[0]
                assert exported['aggregation']['grade_flag'] == bool(struct.unpack_from('<I',native_group,80)[0]&4)
                aggregation_checks.add(slot['effect_group_id'])
                assert '{}' not in slot['label_zh'] and '…' not in slot['label_zh']
                for level in range(101):
                    selector = slot['curve_selector']
                    coeff = struct.unpack_from('<H',growth,8+level*64+42+selector*2)[0] if selector<=5 else 1
                    product = ctypes.c_uint32(slot['growth_value']*coeff).value
                    addition = int(ctypes.c_float(ctypes.c_float(product).value*multiplier).value)
                    expected = ctypes.c_int32(slot['base_value']+addition).value
                    assert expected == slot['raw_values_by_level_index'][level]
                    calculation_checks += 1
    # The old screenshot dataset participates ONLY here, after the native export.
    ui = load(OUT / 'live/ui_observations.json')
    ids = {'kusanagi_initial_samurai':0xDB,'murakumo_samurai':0x4D,'kongojishi_samurai':3,
           'oh_samurai':0x25,'narikama_tanuki_samurai':0x6E,'golden_shachi_samurai':0x4B,
           'shin_roku_samurai':0x124,'guhin_samurai':0xF,'ho_oh_samurai':0x15D,'kusanagi_enhanced_samurai':0xF7,
           'kusanagi_initial_ninja':0x187,'murakumo_ninja':0xB8,'kongojishi_ninja':0xF0,
           'shami_choro_ninja':0x91,'kurama_tengu_ninja':0x111,'nekomata_ninja':0xC5,
           'enko_ninja':0x167,'tengen_kujaku_ninja':0x73,'ho_ninja':0x89,'ho_oh_ninja':0x17C,
           'kusanagi_enhanced_ninja':0x1CD,'tora_gozen_ninja':0x15E}
    crosschecks = []
    for panel in ui['panels']:
        guardian = next(r for r in roster if r['guardian_id']==ids[panel['id']])
        calculated = [s['display_values_by_level_index'][panel['level']] for s in guardian['slots']]
        crosschecks.append({'guardian_id':guardian['guardian_id'],'reference_id':panel['id'],'level':panel['level'],
                            'native_calculated':calculated,'ui_transcribed':panel['values'],'match':calculated==panel['values']})
    mismatches = [x for x in crosschecks if not x['match']]
    report = {'schema':'nioh3-native-guardian-validation/v1','status':'passed' if not mismatches else 'ui_crosscheck_mismatch',
              'manifest_hash_checks':len(catalog['sources']),'native_code_function_hash_checks':proofs,
              'native_records':52,'current_roster_records':22,'complete_effect_labels':110,
              'independent_raw_value_checks':calculation_checks,'ui_reference_build_input':False,
              'second_native_capture_all_blobs_identical': True,
              'activation_requirement_raw_checks':activation_checks,
              'native_group_merge_metadata_checks':len(aggregation_checks),
              'native_semantics_code_proofs':len(semantics['native_code_proofs']),
              'live_numeric_merge_pairs':57,'live_numeric_groups':1,'live_grade_merge_pairs':0,
              'ui_value_crosschecks':110,'ui_mismatches':mismatches,'ui_crosschecks':crosschecks,
              'limitations':catalog['contract']['remaining_semantics'],
              'catalog_sha256':hashlib.sha256((OUT/'guardian_spirits_native.json').read_bytes()).hexdigest()}
    (OUT / 'native_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='ui_crosschecks'},ensure_ascii=True))
    assert not mismatches, 'Native calculations differ from retained UI verification; preserve both and investigate'

if __name__ == '__main__':
    main()
