"""Trace only native integer dispatch decisions; never execute game code."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
analysis = load(HERE / 'guardian-candidate-analysis.json')
function = next(f for f in analysis['code_consumers'] if f['begin'] == '0x819400')
raw = (HERE / 'consumer-code/819400.bin').read_bytes()
assert hashlib.sha256(raw).hexdigest() == function['sha256']
assert len(raw) == int(function['end'], 0) - int(function['begin'], 0)
instructions = {int(i['rva'], 0): i for i in function['instructions']}
for address, item in instructions.items():
    start = address - 0x819400
    assert raw[start:start + len(bytes.fromhex(item['bytes']))].hex() == item['bytes']

def trace(key):
    regs = {'ebx': key, 'edx': key, 'r13d': 0}
    address = 0x819451
    zero = carry = None
    route = []
    for _ in range(180):
        item = instructions[address]
        route.append(item)
        text = item['instruction']
        op, _, operands = text.partition(' ')
        args = operands.split(', ')
        following = address + len(bytes.fromhex(item['bytes']))
        def value(token):
            if token in regs:
                return regs[token]
            return int(token, 0)
        if text == 'mov qword ptr [rbp - 0x50], rdi':
            pass  # Stack local stores no dispatch state.
        elif op == 'mov' and args[0] in ('eax', 'ecx', 'edx', 'r8d', 'r10d', 'r11d') and (args[1] in regs or re.fullmatch(r'(0x[0-9a-f]+|[0-9]+)', args[1])):
            regs[args[0]] = value(args[1]) & 0xFFFFFFFF
        elif op in ('cmp', 'sub') and args[0] in regs:
            left, right = value(args[0]), value(args[1])
            zero, carry = left == right, left < right
            if op == 'sub':
                regs[args[0]] = (left - right) & 0xFFFFFFFF
        elif op == 'jmp':
            following = int(operands, 0)
        elif op in ('je', 'jne', 'ja', 'jbe', 'jb', 'jae'):
            assert zero is not None and carry is not None
            take = {'je': zero, 'jne': not zero, 'ja': not carry and not zero,
                    'jbe': carry or zero, 'jb': carry, 'jae': not carry}[op]
            if take:
                following = int(operands, 0)
        else:
            # Preserve leaf code, including shared paths, without evaluating values.
            leaf, cursor, visited = [], address, set()
            for _ in range(40):
                if cursor == 0x8225F9 or cursor in visited:
                    break
                visited.add(cursor)
                entry = instructions[cursor]
                leaf.append(entry)
                if entry['instruction'].startswith('jmp '):
                    cursor = int(entry['instruction'].split()[1], 0)
                elif entry['instruction'].startswith(('j', 'ret')):
                    break
                else:
                    cursor += len(bytes.fromhex(entry['bytes']))
            rendered = '\n'.join(i['instruction'] for i in leaf)
            byte_fields = re.findall(r'mov byte ptr \[rdi \+ (0x[0-9a-f]+)\], r14b', rendered)
            kind = 'native_leaf_retained'
            if byte_fields and ('mov r14d, 1' in rendered or 'lea r14d, [r13 + 1]' in rendered):
                kind = 'boolean_enable_in_attribute_application'
            elif 'addss ' in rendered and 'movss dword ptr [rdi' in rendered:
                kind = 'float_add_in_attribute_application'
            return {'group_id': key, 'leaf_rva': hex(address), 'kind': kind,
                    'boolean_field_offsets': byte_fields, 'dispatch_route': route[:-1],
                    'leaf_instructions': leaf}
        if following == 0x8225F9:
            return {'group_id': key, 'kind': 'no_application_in_this_dispatcher', 'dispatch_route': route}
        address = following
    raise AssertionError('Bound exceeded')

catalog = load(HERE.parent / 'guardian_spirits_native.json')
results = []
for group in catalog['effect_groups']:
    result = trace(group['id'])
    result['label_zh'] = group['label_zh']
    results.append(result)
report = {'schema': 'nioh3-native-group-dispatch-traces/v1', 'evidence': 'native_control_flow',
          'native_code_source': 'consumer-code/819400.bin', 'native_code_sha256': function['sha256'],
          'scope': 'Dispatch and retained application leaves only. Boolean enables do not establish triggered buff strength, duration, refresh or final combat calculation.',
          'groups': results}
(HERE / 'group-dispatch-traces.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'groups': len(results), 'kinds': {kind: sum(g['kind'] == kind for g in results) for kind in sorted({g['kind'] for g in results})},
                  'boolean_groups': [{'id': g['group_id'], 'label': g['label_zh']} for g in results if g['kind'].startswith('boolean')]}, ensure_ascii=True))
