"""Inspect extracted names, native slot fields and style consumers offline."""
import json,struct,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];sys.path.insert(0,str(ROOT))
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from research.native_xrefs import parse_runtime_functions
texts=json.loads((HERE/'native-text-02.json').read_text(encoding='utf-8'))['entries']
def label(key):
    values={row['text'] for row in texts.get(str(key),[])}
    assert len(values)<=1,(hex(key),values)
    return next(iter(values),None)
directory=HERE/'native-tables-01';raw=(directory/'guardian-rows.bin').read_bytes();groups=(directory/'effect_group-rows.bin').read_bytes()
by_group={struct.unpack_from('<H',groups,i+0xC)[0]:groups[i:i+0x70] for i in range(8,len(groups),0x70)}
rows=[]
for index,offset in enumerate(range(8,len(raw),0x100)):
    row=raw[offset:offset+0x100];name_id=struct.unpack_from('<I',row,0x2C)[0]
    slots=[]
    for slot in range(6):
        key,base,growth=struct.unpack_from('<Iii',row,0x6C+slot*12)
        curve,unlock=struct.unpack_from('<HH',row,0xC4+slot*4)
        group=by_group.get(key)
        slots.append({'slot':slot+1,'effect_group':hex(key),'base':base,'growth':growth,'curve':curve,'unlock':unlock,
            'text':label(struct.unpack_from('<I',group,0x2C)[0]) if group else None,
            'group_hex':group.hex() if group else None})
    record={'row':index,'key':hex(struct.unpack_from('<I',row,0x24)[0]),'name_id':hex(name_id),'name':label(name_id),
            'field_48':struct.unpack_from('<I',row,0x48)[0],'field_4c':struct.unpack_from('<I',row,0x4C)[0],
            'field_fc':row[0xFC:].hex(),'slots':slots}
    rows.append(record)
(HERE/'native-export-inspection.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for row in rows:
    print(json.dumps({k:v for k,v in row.items() if k!='slots'},ensure_ascii=True))
print(json.dumps([row for row in rows if row['name']=='凤凰'],ensure_ascii=True))
directory=HERE/'discovery-05';raw=(directory/'lookup-code.bin').read_bytes();base=0x34E900
decoder=Cs(CS_ARCH_X86,CS_MODE_64);insns=[]
for insn in decoder.disasm(raw[0x34EA18-base:0x34EA18-base+128],0x34EA18):
    insns.append(insn)
    if insn.mnemonic=='ret':break
print('Native style selector 0x34EA18:');print('\n'.join(i.mnemonic+' '+i.op_str for i in insns))
