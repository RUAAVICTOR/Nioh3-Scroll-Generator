"""Retain the native collectible counter source and aggregation cap constant."""
import hashlib,json,struct,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'deliverables/load-capacity-research/scripts')]
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from capture_player import _process_executable,_sha256,_file_version
def main():
 out=HERE/'semantics-tables-01';assert not out.exists();out.mkdir()
 prior=json.loads((HERE/'native-tables-01/capture.json').read_text());started=time.monotonic();total=0
 report={'read_only':True,'game_writes':0,'status':'partial','blobs':[]}
 def read(reader,address,size):
  nonlocal total
  total+=size;assert total<=1048576 and time.monotonic()-started<20
  return reader.read(address,size)
 def retain(name,address,data):
  (out/name).write_bytes(data);report['blobs'].append({'path':name,'address':hex(address),'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 try:
  with ProcessReader() as r:
   assert r.pid==prior['pid'] and r.creation_time()==prior['process_birth_filetime']
   exe=_process_executable(r);assert list(_file_version(exe))==[2,0,2,0] and _sha256(exe)==prior['executable_sha256']
   report.update(pid=r.pid,process_birth_filetime=r.creation_time(),module_base=hex(r.module_base),executable_sha256=prior['executable_sha256'])
   assert read(r,r.module_base+0x2859F8,7)==bytes.fromhex('4c8b01413b5004')
   manager=r.u64(r.module_base+0x45B9E30);context=r.u64(manager+0x630);store=r.u64(context);count=r.u32(store+4)
   assert 0<count<=1024
   rows=read(r,store,8+count*0xC4);retain('collectible-rows.bin',store,rows);assert read(r,store,len(rows))==rows
   report['collectible_table']={'manager_offset':'0x630','row_stride':196,'row_count':count,'collection_flag_offset':'0xB8','recomputation_rva':'0x21A2604'}
   player=r.u64(r.module_base+0x4751850);indirect=r.u64(r.module_base+0x4751860)
   assert r.u64(indirect)==player and r.u64(player)==r.module_base+0x402DA20
   raw=read(r,player,0x200);retain('player-prefix.bin',player,raw)
   report['activation_input']={'player_address':hex(player),'offset':'0x148','u16_value':struct.unpack_from('<H',raw,0x148)[0],
      'ui_double_dereference_global_rva':'0x4751860','direct_player_global_rva':'0x4751850'}
   raw=read(r,r.module_base+0x3BD41D4,4);retain('merge-cap-enable-floor.bin',r.module_base+0x3BD41D4,raw)
   report['merge_cap_enable_floor']=struct.unpack('<f',raw)[0]
   assert r.creation_time()==prior['process_birth_filetime'];report['status']='complete'
 finally:
  report.update(process_handle_closed=True,read_bytes=total,elapsed_seconds=time.monotonic()-started)
  (out/'capture.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k!='blobs'}))
if __name__=='__main__':main()
