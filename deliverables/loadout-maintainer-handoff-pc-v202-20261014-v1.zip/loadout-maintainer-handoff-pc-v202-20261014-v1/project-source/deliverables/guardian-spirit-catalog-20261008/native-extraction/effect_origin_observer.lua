-- One bounded hardware execute observer. Never calls game code or writes memory.
return function(api, identity, makeOwner)
  assert(identity.pid and identity.module_base and identity.handle)
  assert(identity.creation_filetime and identity.executable_sha256)
  local p={active=false,cleanup_pending=false,cleanup_errors={},owned_breakpoints={},
    events={},hits=0,ignored=0,max_hits=128,max_events=64,max_seconds=20,
    identity=identity,game_writes=0,pending_timers=0}
  local timers={}
  local function hex(x) return string.format('0x%X',x) end
  local function verify()
    assert(api.pid()==identity.pid and api.base()==identity.module_base and api.handle()==identity.handle,
      'Target identity/handle changed')
    assert(api.raw(identity.module_base+identity.site_rva,16)==identity.signature_hex,'Lookup signature changed')
  end
  local function timer(delay,fn)
    local token={}
    timers[token]=true;p.pending_timers=p.pending_timers+1
    token.native=api.timer(delay,function()
      if timers[token] then timers[token]=nil;p.pending_timers=p.pending_timers-1 end
      fn()
    end)
    return token
  end
  local function cancel(token)
    if token and timers[token] then
      api.cancel_timer(token.native)
      timers[token]=nil;p.pending_timers=p.pending_timers-1
    end
  end
  local owner=makeOwner({list=api.list,remove=api.remove,remove_id=api.remove_id,
    timer=timer,arm=api.arm},p)
  local budget=nil
  function p.stop(reason)
    p.active=false;p.stop_reason=p.stop_reason or reason or 'manual'
    cancel(budget);budget=nil
    p.cleanup_pending=true
    timer(1,function() owner.stop() end)
    return p.status()
  end
  function p.retry_cleanup() return owner.stop() end
  function p.status()
    return {active=p.active,cleanup_pending=p.cleanup_pending,owned_breakpoints=p.owned_breakpoints,
      cleanup_errors=p.cleanup_errors,pending_timers=p.pending_timers,hits=p.hits,
      event_count=#p.events,ignored=p.ignored,error=p.error,stop_reason=p.stop_reason}
  end
  local function callback()
    local ok,failure=pcall(function()
      if not p.active then return end
      verify();api.context()
      p.hits=p.hits+1
      if p.hits>p.max_hits then p.stop('hit_bound');return end
      local regs=api.registers()
      local effect=(identity.lookup_kind=='text' and regs.RCX or regs.RDX)&0xFFFFFFFF
      local selected=identity.effect_ids[effect] or (identity.lookup_kind=='text' and identity.sample_all_text==true)
      if (identity.lookup_kind~='text' and regs.RCX~=identity.effect_context) or not selected then
        p.ignored=p.ignored+1;return
      end
      assert(#p.events<p.max_events,'Event bound')
      local caller=api.u64(regs.RSP)
      p.events[#p.events+1]={effect_id=effect,context=hex(regs.RCX),
        text_id=identity.lookup_kind=='text' and effect or nil,
        caller=hex(caller),caller_rva=hex(caller-identity.module_base),
        registers=regs,stack_address=hex(regs.RSP),stack_hex=api.raw(regs.RSP,0x180)}
      if #p.events>=p.max_events then p.stop('event_bound') end
    end)
    if not ok then p.error=tostring(failure);p.stop('callback_error') end
    api.continue_event()
    return 1
  end
  function p.arm()
    verify()
    local inventory=api.list()
    assert(type(inventory)=='table' and next(inventory)==nil,'Foreign breakpoint inventory')
    p.active=true
    local ok,why=owner.arm(identity.module_base+identity.site_rva,callback)
    if not ok then p.error=why;p.stop('arm_failed');error(why) end
    budget=timer(p.max_seconds*1000,function() budget=nil;p.stop('time_bound') end)
    return p.status()
  end
  return p
end
