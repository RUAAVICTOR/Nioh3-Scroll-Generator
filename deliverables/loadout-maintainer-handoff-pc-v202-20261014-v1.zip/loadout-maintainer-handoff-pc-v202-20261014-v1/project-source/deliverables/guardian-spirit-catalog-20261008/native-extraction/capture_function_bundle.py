"""Retain explicitly selected native function bodies with fresh identity checks."""
import argparse,bisect,hashlib,json,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];sys.path[:0]=[str(ROOT),str(ROOT/'deliverables/load-capacity-research/scripts')]
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from capture_player import _process_executable,_sha256,_file_version
from research.native_xrefs import parse_runtime_functions
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--rvas',nargs='+',required=True,type=lambda v:int(v,0));parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--identity',type=Path,default=HERE/'native-tables-01/capture.json');parser.add_argument('--pdata',type=Path,default=HERE/'discovery-03/pdata.bin');parser.add_argument('--leaf-window-size',type=int,choices=(512,1024,2048,4096),default=512);args=parser.parse_args()
    assert not args.output.exists();args.output.mkdir(parents=True)
    expected=json.loads(args.identity.read_text());functions=parse_runtime_functions(args.pdata.read_bytes());starts=[f.begin_rva for f in functions]
    started=time.monotonic();total=0;report={'read_only':True,'game_writes':0,'native_function_calls':0,'functions':[],'status':'partial'}
    try:
        with ProcessReader() as reader:
            assert reader.pid==expected['pid'] and reader.creation_time()==expected['process_birth_filetime']
            exe=_process_executable(reader);assert list(_file_version(exe))==[2,0,2,0] and _sha256(exe)==expected['executable_sha256']
            report.update(pid=reader.pid,process_birth_filetime=reader.creation_time(),module_base=hex(reader.module_base),executable_sha256=expected['executable_sha256'])
            assert reader.read(reader.module_base+0x3748E0,8)==bytes.fromhex('40534883ec20488b')
            decoder=Cs(CS_ARCH_X86,CS_MODE_64)
            seen=set()
            for rva in args.rvas:
                fi=bisect.bisect_right(starts,rva)-1;f=functions[fi]
                bounded=f.begin_rva<=rva<f.end_rva
                begin,end=(f.begin_rva,f.end_rva) if bounded else (rva,rva+args.leaf_window_size)
                if begin in seen:continue
                seen.add(begin);size=end-begin;total+=size*2
                assert size<=0x10000 and total<=4*1048576 and time.monotonic()-started<20
                raw=reader.read(reader.module_base+begin,size)
                assert reader.read(reader.module_base+begin,size)==raw
                name=f'{begin:X}.bin';(args.output/name).write_bytes(raw)
                insns=list(decoder.disasm(raw,begin))
                report['functions'].append({'begin':hex(begin),'end':hex(end),'pdata_boundary':bounded,'path':name,'signature':raw[:16].hex(),'sha256':hashlib.sha256(raw).hexdigest(),
                    'instructions':[{'rva':hex(i.address),'bytes':i.bytes.hex(),'instruction':i.mnemonic+' '+i.op_str} for i in insns]})
            assert reader.creation_time()==expected['process_birth_filetime'];report['status']='complete'
    finally:
        report.update(read_bytes=total,elapsed_seconds=time.monotonic()-started,process_handle_closed=True,debugger_used=False)
        (args.output/'capture.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps([{'begin':f['begin'],'end':f['end'],'instructions':len(f['instructions'])} for f in report['functions']]))
if __name__=='__main__':main()
