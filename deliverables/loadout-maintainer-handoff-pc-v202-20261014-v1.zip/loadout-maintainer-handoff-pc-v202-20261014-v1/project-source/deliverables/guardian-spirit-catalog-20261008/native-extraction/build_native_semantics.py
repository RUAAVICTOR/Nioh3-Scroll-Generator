"""Join verified native semantics with explicit evidence limits."""
import hashlib
import json
import struct
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE = Path(__file__).resolve().parent
OUT = HERE.parent
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
digest = lambda raw: hashlib.sha256(raw).hexdigest()
capture = load(HERE / 'native-tables-01/capture.json')
sources = set()
proofs = []
decoder = Cs(CS_ARCH_X86, CS_MODE_64)

def source(relative):
    sources.add(relative)
    return HERE / relative

def function(directory, begin, requirements):
    report = load(source(directory + '/capture.json'))
    assert report['game_writes'] == 0
    assert report['pid'] == capture['pid'] and report['process_birth_filetime'] == capture['process_birth_filetime']
    assert report['executable_sha256'] == capture['executable_sha256']
    entry = next(f for f in report.get('functions', report.get('code_consumers', [])) if int(f['begin'], 0) == begin)
    filename = entry.get('path', f'{begin:X}.bin')
    raw = source(directory + '/' + filename).read_bytes()
    expected = entry.get('sha256') or next(b['sha256'] for b in report['blobs'] if b['path'] == filename)
    assert digest(raw) == expected
    decoded = {i.address: f'{i.mnemonic} {i.op_str}'.rstrip() for i in decoder.disasm(raw, begin)}
    for item in entry['instructions']:
        assert decoded[int(item['rva'], 0)] == item['instruction'].rstrip()
    for rva, instruction in requirements.items():
        assert decoded[rva] == instruction, (hex(rva), decoded.get(rva), instruction)
    proofs.append({'function_rva': hex(begin), 'source': directory+'/'+filename,
                   'sha256': expected, 'checked_instructions': {hex(k): v for k,v in requirements.items()}})
    return decoded

function('activation-consumers-02', 0x1D7EEE0, {
    0x1D7F9F4: 'mov rcx, qword ptr [rax]',
    0x1D7F9F7: 'movzx eax, word ptr [rcx + 0x148]',
    0x1D8005A: 'call 0x375364',
    0x1D806A0: 'mov ecx, 0x3e16ef1'})
function('activation-consumers-03', 0x217DF90, {
    0x217DFA3: 'mov word ptr [rax + 0x148], dx'})
function('activation-functions-04', 0x21A2604, {
    0x21A263E: 'mov rax, qword ptr [r9 + 0x630]',
    0x21A268C: 'movzx edx, word ptr [r15 + 0xb8]',
    0x21A2717: 'call 0x217df90'})
function('activation-consumers-02', 0x374F58, {
    0x375024: 'movzx ecx, word ptr [rsi + 0x72]',
    0x37502E: 'call 0x375364',
    0x37503E: 'cmp r13b, r15b',
    0x375041: 'je 0x37505b',
    0x37504A: 'mov edx, 0x8508',
    0x37504F: 'call 0x3fbd08',
    0x375059: 'js 0x3750c0',
    0x3750B8: 'call 0x557ba0'})
function('aggregation-functions-02', 0x3FBD08, {
    0x3FBD4A: 'je 0x19a11e9',
    0x3FBD5E: 'or eax, 0xffffffff'})
function('aggregation-functions-02', 0x557BA0, {
    0x557D38: 'test byte ptr [rcx + 0x50], 4',
    0x557D45: 'cmovb eax, edi',
    0x557D52: 'add word ptr [rbx + r8*4 + 8], ax',
    0x557D65: 'add r9d, edx',
    0x557D68: 'add r9d, edi',
    0x557D70: 'mov ecx, dword ptr [rcx + 4]',
    0x557D93: 'mov dword ptr [rbx + r8*4 + 4], ecx'})
function('aggregation-functions-03', 0x19A11E9, {
    0x19A11EF: 'movzx eax, word ptr [rdx + rcx*4 + 8]',
    0x19A11F4: 'add eax, dword ptr [rdx + rcx*4 + 4]'})
threshold_function = next(f for f in load(source('guardian-function-analysis.json')) if f['begin'] == '0x375364')
window = source('discovery-04/lookup-code.bin').read_bytes()
threshold_code = window[0x375364-0x374000:0x37538A-0x374000]
assert digest(threshold_code) == threshold_function['sha256']
threshold_decoded = {i.address: f'{i.mnemonic} {i.op_str}'.rstrip() for i in decoder.disasm(threshold_code, 0x375364)}
assert threshold_decoded[0x37537C] == 'cmp r11w, word ptr [rsp + 0x2e]'
assert threshold_decoded[0x375382] == 'setae al'
proofs.append({'function_rva': '0x375364', 'source': 'discovery-04/lookup-code.bin',
               'window_begin_rva': '0x374000', 'function_sha256': threshold_function['sha256'],
               'checked_instructions': {'0x37537c': threshold_decoded[0x37537C], '0x375382': threshold_decoded[0x375382]}})

def text_from(relative, key):
    report = load(source(relative))
    assert report['pid'] == capture['pid'] and report['game_writes'] == 0
    entries = report['entries'][str(key)]
    assert len({e['text'] for e in entries}) == 1
    for e in entries:
        raw = bytes.fromhex(e['raw_hex'])
        assert digest(raw) == e['sha256']
        assert struct.unpack_from('<I', raw)[0] == key
        assert len(raw) == 8 + struct.unpack_from('<I', raw, 4)[0]*2
        assert raw[8:-2].decode('utf-16le') == e['text'] and raw[-2:] == b'\0\0'
    return entries[0]['text']

activation_label = text_from('activation-keyword-native-text-03.json', 0x3E16EF1)
tutorial = text_from('activation-keyword-native-text-03.json', 0x4319D1E)
assert '楔柱破坏数' in activation_label and '根据破坏的地狱之楔数量启用特殊效果' in tutorial
gate_name = text_from('cross-style-native-text-01.json', 0x35B4E5B)
gate_description = text_from('cross-style-native-text-01.json', 0x35ED7A1)
assert gate_name == '双灵庇佑'
assert gate_description == '可同时获得两种风格的守护灵的特殊效果。'
groups_raw = source('native-tables-01/effect_group-rows.bin').read_bytes()
gate_row = next(groups_raw[p:p+112] for p in range(8,len(groups_raw),112) if struct.unpack_from('<H', groups_raw, p+12)[0] == 0x8508)
assert struct.unpack_from('<II', gate_row, 0x2C) == (0x35B4E5B, 0x35ED7A1)
tables = load(source('semantics-tables-01/capture.json'))
assert tables['status'] == 'complete' and tables['executable_sha256'] == capture['executable_sha256']
for blob in tables['blobs']:
    raw = source('semantics-tables-01/'+blob['path']).read_bytes()
    assert len(raw) == blob['size'] and digest(raw) == blob['sha256']
assert struct.unpack('<f', (HERE/'semantics-tables-01/merge-cap-enable-floor.bin').read_bytes())[0] == 0.0
assert struct.unpack_from('<H', (HERE/'semantics-tables-01/player-prefix.bin').read_bytes(), 0x148)[0] == tables['activation_input']['u16_value']
live = load(source('semantics-live-validation.json'))
assert live['status'] == 'passed_scoped_live_merges' and live['matched_pairs'] == live['native_merge_pairs'] == 57
for key in ('native_snapshot', 'cleanup_proof'):
    entry = live[key]
    assert digest(source(entry['path']).read_bytes()) == entry['sha256']
source('ce-snapshot-1791478836354714500.json')
source('ce-cleanup-1791478838064941100.json')
dispatch = load(source('group-dispatch-traces.json'))
assert digest(source(dispatch['native_code_source']).read_bytes()) == dispatch['native_code_sha256']
assert len(dispatch['groups']) == 104
result = {
    'schema': 'nioh3-native-guardian-semantics/v1',
    'executable_sha256': capture['executable_sha256'],
    'source_policy': {'native_only': True, 'game_writes': 0, 'native_function_calls': 0},
    'activation': {
        'kind': 'destroyed_crucible_spike_count', 'label_zh': '地狱之楔破坏数',
        'comparison': 'u16(destroyed_crucible_spike_count) >= u16(slot.activation_threshold)',
        'evidence': ['native_table', 'native_control_flow', 'native_tutorial_text'],
        'player_field_offset': '0x148', 'gameplay_copy_field_offset': '0x72',
        'threshold_comparison_rva': '0x375364', 'ui_consumer_rva': '0x1D7EEE0',
        'counter_recomputation_rva': '0x21A2604', 'counter_writer_rva': '0x217DF90',
        'ui_label_text_id': 0x3E16EF1, 'ui_label_native_text': activation_label,
        'tutorial_text_id': 0x4319D1E, 'tutorial_native_text': tutorial,
        'observed_count': tables['activation_input']['u16_value'],
        'counter_scope': 'Native recomputation counts collected spike flags across the difficulty/playthrough range supplied by the game; this is not a single-map count or guardian level.'},
    'other_style_guardian_condition': {
        'effect_group_id': 0x8508, 'label_zh': gate_name, 'description_zh': gate_description,
        'name_text_id': 0x35B4E5B, 'description_text_id': 0x35ED7A1,
        'check': 'Native group getter result must be signed nonnegative. An absent group returns -1; a present raw value of 0 passes this check.',
        'check_rva': '0x37504A', 'getter_rva': '0x3FBD08', 'consumer_rva': '0x374F58',
        'evidence': ['native_control_flow', 'native_effect_group_row', 'native_description_text'],
        'source_type': 'set_bonus_reported_by_owner',
        'set_name_and_piece_requirement': None,
        'set_membership_native_join_verified': False,
        'raw_group_row_hex': gate_row.hex(), 'raw_group_row_sha256': digest(gate_row)},
    'same_group_merge': {
        'identity': 'Same effect_group_id in the same native style bucket; label equality is not identity.',
        'merge_rva': '0x557BA0', 'getter_leaf_rva': '0x19A11E9',
        'record_layout': {'stride': 12, 'group_key': 0, 'u32_base': 4, 'u16_extra': 8, 'byte_flag': 10},
        'numeric': {'evidence': ['native_control_flow', 'observed_numeric_merge'],
                    'base_update': 'base=u32(old_base+old_extra+incoming); if native i32 cap>=0 and u32(base+old_extra)>cap, base=cap; extra unchanged.',
                    'getter': 'u32(base+extra)', 'cap_enable_floor_float32': 0.0,
                    'observed_pairs': 57, 'observed_groups': [{'id': 0x3B0E, 'label_zh': '幸运'}],
                    'live_scope': 'Numeric duplicate record updates for one group only. Does not prove cap activation, every guardian/equipment source pair, final committed totals or combat damage.'},
        'grade': {'evidence': ['native_control_flow'],
                  'base_update': 'base=max_unsigned(old_base,incoming); extra=u16(old_extra+1)',
                  'getter': 'u32(base+extra)',
                  'clean_bucket_rule': 'Best raw grade rank plus one rank step per duplicate occurrence; format using native grade index rule.',
                  'observed_pairs': 0, 'live_verification': 'pending_controlled_grade_duplicate'},
        'special_group_38ba': {'base_update': 'base=max_unsigned(u32(old_base+old_extra),incoming); extra unchanged',
                              'present_in_current_guardian_groups': False},
        'scope': 'Native attribute accumulation only. This does not establish how triggered buff instances stack, refresh, expire or enter final combat formulas.'},
    'application_dispatch': {'function_rva': '0x819400', 'trace_file': 'native-extraction/group-dispatch-traces.json',
                              'groups_traced': 104, 'evidence': 'native_control_flow',
                              'scope': dispatch['scope']},
    'native_code_proofs': proofs,
    'remaining_semantics': ['legal maximum guardian level', 'controlled live grade-duplicate confirmation',
                            'native set-to-effect join and piece requirement for group 0x8508',
                            'triggered buff strength, duration, refresh/overwrite and final combat formulas']}
result['sources'] = [{'path': 'native-extraction/'+relative, 'size': (HERE/relative).stat().st_size,
                      'sha256': digest((HERE/relative).read_bytes())} for relative in sorted(sources)]
(OUT/'guardian_semantics_native.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'status': 'native_semantics_built', 'code_proofs': len(proofs), 'source_hashes': len(sources),
                  'numeric_pairs': 57, 'grade_pairs': 0, 'activation_kind': result['activation']['kind']}, ensure_ascii=True))
