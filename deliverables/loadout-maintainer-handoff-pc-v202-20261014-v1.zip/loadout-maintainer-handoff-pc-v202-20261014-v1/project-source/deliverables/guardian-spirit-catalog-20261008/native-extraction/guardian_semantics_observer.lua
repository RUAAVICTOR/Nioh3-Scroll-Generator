-- Read-only native activation inputs or duplicate-group before/after records.
return function(api,identity,makeOwner)
  local p={active=false,cleanup_pending=false,cleanup_errors={},owned_breakpoints={},events={},
    hits=0,ignored=0,max_hits=256,max_events=64,max_seconds=20,pending_timers=0,game_writes=0,identity=identity}
  local timers,pending={},{}
  local function hex(x) return string.format('0x%X',x) end
  local function verify()
    assert(api.pid()==identity.pid and api.base()==identity.module_base and api.handle()==identity.handle,'Changed identity')
    assert(api.raw(identity.module_base+identity.site_rva,16)==identity.signature_hex,'Changed entry signature')
    if identity.return_rva then assert(api.raw(identity.module_base+identity.return_rva,16)==identity.return_signature_hex,'Changed exit signature') end
  end
  local function timer(delay,fn)
    local token={};timers[token]=true;p.pending_timers=p.pending_timers+1
    token.native=api.timer(delay,function() if timers[token] then timers[token]=nil;p.pending_timers=p.pending_timers-1 end;fn() end)
    return token
  end
  local function cancel(token)
    if token and timers[token] then api.cancel_timer(token.native);timers[token]=nil;p.pending_timers=p.pending_timers-1 end
  end
  local owner=makeOwner({list=api.list,remove=api.remove,remove_id=api.remove_id,timer=timer,arm=api.arm},p)
  local budget
  function p.stop(reason)
    p.active=false;p.stop_reason=p.stop_reason or reason or 'manual';cancel(budget);budget=nil
    p.cleanup_pending=true;timer(1,function() owner.stop() end);return p.status()
  end
  function p.retry_cleanup() return owner.stop() end
  function p.status()
    local count=0;for _ in pairs(pending) do count=count+1 end
    return {active=p.active,cleanup_pending=p.cleanup_pending,owned_breakpoints=p.owned_breakpoints,
      cleanup_errors=p.cleanup_errors,pending_timers=p.pending_timers,hits=p.hits,event_count=#p.events,
      ignored=p.ignored,error=p.error,stop_reason=p.stop_reason,unpaired_events=count}
  end
  local function callback(exit)
    local ok,why=pcall(function()
      if not p.active then return end
      verify();api.context();p.hits=p.hits+1
      if p.hits>p.max_hits then p.stop('hit_bound');return end
      local r=api.registers()
      if identity.lookup_kind=='activation' then
        local pointer=r.RDX;local slot=r.R8&0xFFFFFFFF
        if pointer<identity.guardian_begin or pointer>=identity.guardian_end or (pointer-identity.guardian_begin)%256~=0 or slot>=6 then p.ignored=p.ignored+1;return end
        local key=api.u32(pointer+0x24)
        assert(identity.effect_ids[key],'Unknown guardian key')
        p.events[#p.events+1]={kind='activation',guardian_id=key,slot=slot+1,progress_count=r.RCX&0xFFFF,
          threshold=api.u16(pointer+0xC6+slot*4)&0xFFFF,caller_rva=hex(api.u64(r.RSP)-identity.module_base),registers=r}
      else
        local group=r.RBP&0xFFFF;local stack=hex(r.RSP)
        if not exit then
          if not identity.effect_ids[group] then p.ignored=p.ignored+1;return end
          local index=r.RSI&0xFFFFFFFF;local count=api.u32(r.RBX+0xC00)
          assert(index<count and count<=256,'Invalid native bucket')
          local address=r.RBX+index*12
          assert(api.u16(address)&0xFFFF==group,'Wrong native duplicate identity')
          assert(not pending[stack],'Nested duplicate on same stack')
          pending[stack]={kind='merge',group_id=group,incoming_value=r.RDI&0xFFFFFFFF,
            address=address,before_hex=api.raw(address,12),registers=r}
        else
          local event=pending[stack]
          if not event then p.ignored=p.ignored+1;return end
          assert(group==event.group_id,'Changed paired identity')
          event.after_hex=api.raw(event.address,12);p.events[#p.events+1]=event;pending[stack]=nil
        end
      end
      if #p.events>=p.max_events then p.stop('event_bound') end
    end)
    if not ok then p.error=tostring(why);p.stop('callback_error') end
    api.continue_event();return 1
  end
  function p.arm()
    verify();local inventory=api.list();assert(type(inventory)=='table' and next(inventory)==nil,'Foreign breakpoints')
    p.active=true
    local ok,why=owner.arm(identity.module_base+identity.site_rva,function() return callback(false) end)
    if not ok then p.error=why;p.stop('arm_failed');error(why) end
    if identity.return_rva then
      ok,why=owner.arm(identity.module_base+identity.return_rva,function() return callback(true) end)
      if not ok then p.error=why;p.stop('arm_failed');error(why) end
    end
    budget=timer(p.max_seconds*1000,function() budget=nil;p.stop('time_bound') end)
    return p.status()
  end
  return p
end
