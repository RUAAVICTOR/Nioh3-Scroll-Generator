"""Analyze hash-verified discovery bytes with bounded native function decoding."""
import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
from research.native_xrefs import parse_runtime_functions
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
from capstone.x86 import X86_OP_IMM, X86_OP_MEM, X86_OP_REG, X86_REG_RIP


def analyze(directory):
    capture = json.loads((directory / "capture.json").read_text())
    if capture["status"] != "complete_discovery_capture_only":
        raise RuntimeError("Incomplete discovery capture")
    files = {}
    for item in capture["blobs"]:
        data = (directory / item["path"]).read_bytes()
        if len(data) != item["size"] or hashlib.sha256(data).hexdigest() != item["sha256"]:
            raise RuntimeError("Raw evidence mismatch: " + item["path"])
        files[item["path"]] = data
    code = files["lookup-code.bin"]
    base = int(capture["code_rva"], 0)
    manager_rva = int(capture["manager_rva"], 0)
    decoder = Cs(CS_ARCH_X86, CS_MODE_64)
    decoder.detail = True
    rows = []
    skipped = []
    decoded_bytes = 0
    functions_examined = 0
    for function in parse_runtime_functions(files["pdata.bin"]):
        if not base <= function.begin_rva < base + len(code):
            continue
        size = function.end_rva - function.begin_rva
        if function.end_rva > base + len(code) or size > 0x10000:
            skipped.append({"rva": hex(function.begin_rva), "reason": "Function boundary/size exceeds code window"})
            continue
        if decoded_bytes + size > 0x40000 or functions_examined >= 2000:
            raise RuntimeError("Offline decode bound exceeded")
        raw = code[function.begin_rva - base:function.end_rva - base]
        insns = list(decoder.disasm(raw, function.begin_rva))
        decoded_bytes += size
        functions_examined += 1
        aliases = set()
        context_offsets = set()
        root_sites = []
        strides = set()
        calls = set()
        for insn in insns:
            if insn.mnemonic == "imul" and len(insn.operands) == 3 and insn.operands[2].type == X86_OP_IMM:
                stride = insn.operands[2].imm
                if 2 <= stride <= 0x1000:
                    strides.add(stride)
            if insn.mnemonic == "call":
                if insn.operands[0].type == X86_OP_IMM:
                    calls.add(insn.operands[0].imm)
                aliases.difference_update({"rax", "rcx", "rdx", "r8", "r9", "r10", "r11"})
                continue
            if insn.mnemonic != "mov" or len(insn.operands) != 2 or insn.operands[0].type != X86_OP_REG:
                continue
            dest = insn.reg_name(insn.operands[0].reg)
            operand = insn.operands[1]
            new_alias = False
            if operand.type == X86_OP_MEM:
                mem = operand.mem
                if mem.base == X86_REG_RIP and insn.address + insn.size + mem.disp == manager_rva:
                    new_alias = True
                    root_sites.append(hex(insn.address))
                elif insn.reg_name(mem.base) in aliases and mem.index == 0 and 0 <= mem.disp < 0xC00 and mem.disp % 8 == 0:
                    context_offsets.add(mem.disp)
            elif operand.type == X86_OP_REG and insn.reg_name(operand.reg) in aliases:
                new_alias = True
            aliases.discard(dest)
            if new_alias:
                aliases.add(dest)
        if root_sites or strides:
            rows.append({"begin_rva": hex(function.begin_rva), "end_rva": hex(function.end_rva),
                         "native_function_sha256": hashlib.sha256(raw).hexdigest(),
                         "complete_decode": sum(i.size for i in insns) == len(raw),
                         "manager_root_sites": root_sites,
                         "candidate_context_offsets": [hex(i) for i in sorted(context_offsets)],
                         "imul_stride_candidates": [hex(i) for i in sorted(strides)],
                         "direct_calls": [hex(i) for i in sorted(calls)],
                         "instructions": [{"rva": hex(i.address), "bytes": i.bytes.hex(),
                                           "instruction": i.mnemonic + " " + i.op_str} for i in insns]})
    report = {"schema": "nioh3-guardian-discovery-analysis/v1",
              "capture_sha256": hashlib.sha256((directory / "capture.json").read_bytes()).hexdigest(),
              "runtime_access_performed": False, "functions_examined": functions_examined,
              "decoded_bytes": decoded_bytes, "function_candidates": rows,
              "skipped": skipped, "guardian_mapping_verified": False,
              "limits": ["Only captured code window analyzed; no absence proof.",
                         "Register alias tracking is discovery support, not full control-flow proof.",
                         "IMUL constants are stride candidates, not identified guardian layouts."]}
    (directory / "analysis.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"functions_examined": functions_examined, "decoded_bytes": decoded_bytes,
                      "manager_functions": [{key: row[key] for key in ("begin_rva", "candidate_context_offsets", "direct_calls")} for row in rows if row["manager_root_sites"]],
                      "stride_functions": len(rows), "guardian_mapping_verified": False}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", type=Path, required=True)
    analyze(parser.parse_args().capture.resolve())
