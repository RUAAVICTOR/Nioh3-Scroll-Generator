"""Retain complete native guardian, growth and effect-group row stores read-only."""
import argparse,hashlib,json,struct,sys,time
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'deliverables/load-capacity-research/scripts')]
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from capture_player import _file_version,_process_executable,_sha256

def capture(pid,directory):
    assert not directory.exists();directory.mkdir(parents=True)
    profile=json.loads((ROOT/'nioh3_scroll_editor/data/game_versions/pc_v2_02.json').read_text())
    functions=json.loads((HERE/'guardian-function-analysis.json').read_text())
    report={'schema':'nioh3-native-guardian-table-capture/v1','captured_at_utc':datetime.now(timezone.utc).isoformat(),
      'status':'partial','read_only':True,'game_writes':0,'debugger_used':False,'tables':[],'blobs':[]}
    started=time.monotonic();total=0
    def read(reader,address,size):
        nonlocal total
        assert total+size<=2*1024*1024 and time.monotonic()-started<20
        total+=size;return reader.read(address,size)
    def retain(name,address,data):
        (directory/name).write_bytes(data)
        report['blobs'].append({'path':name,'address':hex(address),'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    try:
        with ProcessReader() as reader:
            assert reader.pid==pid
            birth=reader.creation_time();exe=_process_executable(reader);digest=_sha256(exe)
            assert list(_file_version(exe))==profile['file_version'] and digest.upper()==profile['provenance']['executable_sha256'].upper()
            report.update(pid=pid,module_base=hex(reader.module_base),process_birth_filetime=birth,executable_sha256=digest,game_version='PC v2.02')
            for function in functions:
                expected=bytes.fromhex(function['signature']);actual=read(reader,reader.module_base+int(function['begin'],0),len(expected))
                assert actual==expected
            manager=reader.u64(reader.module_base+0x45B9E30)
            for name,offset,stride,expected_count,key_offset in (
              ('guardian',0x3F0,0x100,52,0x24),('guardian_growth',0x408,0x40,101,None),
              ('effect_group',0xA8,0x70,1152,0x0C)):
                context=reader.u64(manager+offset);store=reader.u64(context);count=reader.u32(store+4)
                assert count==expected_count
                size=8+count*stride
                data=read(reader,store,size);retain(name+'-rows.bin',store,data)
                assert read(reader,store,size)==data
                metadata={'name':name,'manager_offset':hex(offset),'context':hex(context),'store':hex(store),
                  'row_count':count,'row_stride':stride,'key_offset':key_offset,'stable':True}
                if key_offset is not None:
                    hash_object=reader.u64(context+0x20);header=read(reader,hash_object,0x20)
                    sentinel=struct.unpack_from('<I',header,4)[0];begin,end=struct.unpack_from('<QQ',header,8)
                    assert 0<end-begin<65536 and (end-begin)%8==0
                    entries=read(reader,begin,end-begin);retain(name+'-hash-header.bin',hash_object,header);retain(name+'-hash-entries.bin',begin,entries)
                    keys={index:key&0xFFFF for key,index in struct.iter_unpack('<II',entries) if key!=sentinel and index<count}
                    assert len(keys)==count
                    assert all(struct.unpack_from('<H',data,8+index*stride+key_offset)[0]==key for index,key in keys.items())
                    metadata['hash_index_and_row_keys_agree']=True
                report['tables'].append(metadata)
            # The native growth routine multiplies signed growth input by the
            # selected u16 coefficient and this exact float32 constant.
            constant_rva=0x374F06+8+0x385F778
            # Resolve from the retained instruction bytes instead of guessing length.
            code=(HERE/'discovery-04/lookup-code.bin').read_bytes();code_base=0x374000
            from capstone import Cs,CS_ARCH_X86,CS_MODE_64
            for insn in Cs(CS_ARCH_X86,CS_MODE_64).disasm(code[0xF00:0xF1B],code_base+0xF00):
                if insn.mnemonic=='mulss':
                    constant_rva=insn.address+insn.size+struct.unpack_from('<i',insn.bytes,len(insn.bytes)-4)[0]
            constant=read(reader,reader.module_base+constant_rva,4)
            retain('growth-multiplier.bin',reader.module_base+constant_rva,constant)
            report['growth_multiplier']={'rva':hex(constant_rva),'float32':struct.unpack('<f',constant)[0]}
            assert reader.creation_time()==birth and reader.u64(reader.module_base+0x45B9E30)==manager
            report['status']='complete_native_table_capture'
    finally:
        report.update(process_handle_closed=True,total_read_bytes=total,elapsed_seconds=time.monotonic()-started)
        (directory/'capture.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'tables':report['tables'],'growth_multiplier':report['growth_multiplier'],'read_bytes':total}))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--pid',type=int,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();capture(args.pid,args.output.resolve())
