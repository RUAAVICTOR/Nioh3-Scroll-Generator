"""Find candidate effect-reference clusters in saved bytes; no membership claim."""
import argparse
import hashlib
import json
import struct
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main(directory, reference_kind):
    capture = load(directory / "capture.json")
    if capture["status"] != "complete_discovery_capture_only":
        raise RuntimeError("Incomplete capture")
    labels = load(HERE.parent / "live/ui_labels.json")
    localization = load(ROOT / "nioh3_scroll_editor/data/effect_names_multilingual.json")
    ids_by_label = defaultdict(set)
    manifest = load(ROOT / 'nioh3_scroll_editor/data/r4_finalizer/pc_v2_02/resource_v1/manifest.json')
    spec = next(item for item in manifest['tables'] if item['name'] == 'effect')
    effect_raw = (ROOT / 'nioh3_scroll_editor/data/r4_finalizer/pc_v2_02/resource_v1' / spec['file']['filename']).read_bytes()
    assert hashlib.sha256(effect_raw).hexdigest().upper() == spec['file']['sha256'].upper()
    effect_groups = dict(struct.unpack_from('<HH', effect_raw, 8 + i * spec['row_size']) for i in range(spec['row_count']))
    for entry in localization["effects"].values():
        if entry.get("provenance", {}).get("zh-CN", {}).get("kind") == "native_localization_pool":
            value = entry['effect_id'] if reference_kind == 'effect' else effect_groups[entry['effect_id']]
            ids_by_label[entry["names"].get("zh-CN")].add(value)
    groups = {key: [(i + 1, ids_by_label[label]) for i, label in enumerate(value) if ids_by_label[label]]
              for key, value in labels["effects"].items()}
    hints = []
    for blob in capture["blobs"]:
        if not blob["path"].endswith("-store-prefix.bin"):
            continue
        data = (directory / blob["path"]).read_bytes()
        if hashlib.sha256(data).hexdigest() != blob["sha256"]:
            raise RuntimeError("Blob mismatch")
        words = [struct.unpack_from("<H", data, i)[0] for i in range(8, len(data) - 1, 2)]
        positions = defaultdict(list)
        for i, word in enumerate(words):
            positions[word].append(8 + 2 * i)
        for key, signature in groups.items():
            if len(signature) < 3:
                continue
            matches = sorted((pos, slot, effect_id) for slot, values in signature for effect_id in values for pos in positions[effect_id])
            if not matches:
                continue
            starts = [pos for pos, _, _ in matches]
            best = None
            for start in starts:
                local = [item for item in matches if start <= item[0] <= start + 0x100]
                distinct_slots = len({item[1] for item in local})
                if distinct_slots >= 3 and (best is None or distinct_slots > best["matched_slots"]):
                    best = {"guardian_reference_hint": key, "blob": blob["path"],
                            "window_start": hex(start), "matched_slots": distinct_slots,
                            "matchable_slots": len(signature),
                            "hits": [{"offset": hex(pos), "slot_hint": slot, "candidate_effect_id": hex(effect_id)} for pos, slot, effect_id in local],
                            "guardian_membership_verified": False}
            if best:
                hints.append(best)
    hints.sort(key=lambda item: (-item["matched_slots"], item["blob"], item["guardian_reference_hint"]))
    report = {"schema": "nioh3-guardian-reference-discovery-hints/v1",
              "capture": str(directory), "reference_kind": reference_kind, "hints": hints,
              "matchable_slot_counts": {key: len(value) for key, value in groups.items()},
              "scope": "Name-derived native ID sets and raw word co-occurrence are discovery hints only. No table layout or guardian membership is established."}
    (directory / (reference_kind + "-reference-hints.json")).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"hint_count": len(hints), "top": hints[:12], "matchable_slot_counts": report["matchable_slot_counts"]}, ensure_ascii=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", type=Path, required=True)
    parser.add_argument('--reference-kind', choices=('effect', 'group'), default='effect')
    args = parser.parse_args()
    main(args.capture.resolve(), args.reference_kind)
