# Native clan protection extraction — PC v2.02

Completion means every native clan joined by ID to its protection effect groups,
Chinese labels, raw values and verified display units; retain any rank-dependent
scaling rather than treating an unverified base as the final value. Inputs must
be actual game extraction. Screenshots, community pages and Wiki are not inputs.
Preserve unknown/hidden records separately and record scope explicitly.

Phase 1: reuse the guardian bounded discovery helper with a freshly observed PID,
approved executable hash and profiled signatures. Capture manager contexts and
64-KiB prefixes only for small tables (count <=128), plus complete bounded hash
indices. Existing 16-MiB/20-second read bounds, known effect/group controls and
stable reads apply. No debugger, game calls, UI input, writes or save changes.

Locate clan labels through the verified native locale text tree, then identify
candidate tables by exact native label IDs and native index agreement. Recover
consumers before interpreting layouts, effect slots, value formats or scaling.
Use the existing generic table dumper, function scanner and text-tree adapter
where appropriate. Code/row/text bytes and digests are retained for review.

The initial 16-MiB discovery exhausted its read budget with all known table
controls correct; raw partial output and its bound failure are retained in
discovery-01. Re-run unchanged bounded reads with 32 MiB/20 seconds. This is a
measured adjustment for additional loaded small contexts, not a semantic result.

Discovery-02 completed bounded reads but rejected a changed manager snapshot;
no table semantics are accepted from this partial phase. Retry after data
initialization with the same 32-MiB/20-second bounds and full stability checks.

Native text-tree reuse: research/native_text_tree.py separates the retained
skill adapter's verified node/text decoding from task addresses and identity.
NativeTextTree receives a bounded read callback, head, TextTreeLayout and node,
depth/text limits; it supports exact lookup and complete traversal with cycle,
duplicate-key, keyed UTF-16 header and terminator checks. The clan adapter
capture_clan_text.py --identity <capture.json> --output <unique.json> supplies
the PC v2.02 signatures/RVAs and fresh PID/birth; max 32 MiB/20 seconds,
65536 nodes, depth 64, 4096 units. Optional --id-file limits later requests.
This read-only tree capability is validated only for the supplied native layout;
callers remain responsible for process identity, signatures and final stability.
Partial discovery identity is usable solely for identity checks, never for
accepting its unstable manager/table mapping. Full captures retain node bytes.

Exact native surname text IDs locate manager +0x758: 51 rows, unique stride
152/key uint16 +4 by complete native index agreement; name text ID appears at
+0xC. Broad discovery's mutable manager-tail stability is not used to accept
this mapping. Recapture only the complete clan and effect-group tables using
the existing generic table adapter with stable row/index checks (8 MiB/20s).
The optional capture_skill_tables.py --spec-file <JSON> supplies bounded task
specs (<=12 tables) to the existing capture_generic_table mechanism; default
skill captures are unchanged. Consumers remain pending.

Use capture_activation_consumers.py --manager-contexts 0x758 with the task's
consumer-plan.json, fresh identity and retained pdata. Existing measured
35s/96MiB/8MiB-decode/1800-function bounds apply; root prefilter limits remain
explicit and full function code is retained. No breakpoint or writes.

Owner holds the clan detail page. Read-only current-clan control: getter
0x10C8F38 loads root RVA 0x45B9E70 +0x21220; 0x2935ED4 locates up to 60
32-byte contribution records at root+0x21380, stored u64 +0x10. Capture only
these fields with fresh identity/signatures, stable double reads, 16 KiB/20s,
no native calls or debugger. Native elapsed-time contribution for the current
clan is retained as an uncomputed input; do not mislabel stored contributions
as an exact current UI rank if they could cross a threshold.

Function-bundle helper adds optional --identity/--pdata for fresh phases;
format-constant helper adds --identity/--output and forbids capture overwrite.
Static-label adapter adds --ranges-file/--output for <=32 file-backed ranges,
<=64 KiB total, still hashing the approved PC v2.02 executable. These extend
existing components, preserve default semantics and are limited to their
verified code/layout signatures. This task captures rank thresholds at
RVA 0x3BDCB30 and the known native grade-label pointer table.

Completion: stable complete native table at manager+0x758 contains 51 rows;
native consumers establish u32 key+4 (the capture's u16 key agrees for all
records), name text ID+0xC and two (u32 group,i32 base,float32 growth) triples
at +0x30/+0x3C. ID 0 is unnamed and retained separately. All 50 named records
resolve both groups and Chinese labels/descriptions through the native tree.
The 100 slots resolve 99 distinct effect groups: 77 numeric, 12 grade and
11 hidden-value formats. Hidden raw parameters are preserved without assigning
unverified buff magnitude/duration semantics.

Native 0x220D9EC calls base getter 0x220DA9C and clan rank getter 0x220D234,
adds one rank step when the requested ID equals the current joined clan,
caps the step at 7, multiplies the float32 growth and truncates toward zero.
0x2180BD8 applies the resulting group/value to the selected effect record.
0x220D630 and 0x220D670 supply ten contribution thresholds and keyed rank
labels. Native UI consumers 0x1DF63A0/0x2751984 format this same value through
0x1BC1C6C/0x1BC1A08. This establishes definitions and calculations, not player
unlock, legal selection, simultaneous activation, aggregation or combat outcomes.

Fresh current-clan read completed with process handle closed and no debugger,
native call or write. ID 7 (加藤), stored contribution 91605, already exceeds
the final rank threshold 60000. Therefore the unresolved elapsed-time addition
cannot alter this snapshot's rank 9 (宿老). Native code computes -15.5% and
-16.5%; these are calculated controls, not observed UI display acceptance.
Owner was released from holding the menu after capture completion.

Function-bundle helper also supports --leaf-window-size (512/1024/2048/4096),
default 512, retaining pdata_boundary=false on leaf windows. The final value
formatter had an exact pdata boundary, so no expanded leaf window was needed.

Offline export initially rejected clan ID 43/group 0x5972: its integer-mode
unit is +{}<dot>{}%, yielding the exact assertion "+3.{}%" in the reused
guardian display helper. Native 0x1BC1C12/0x1BC1C23 supplies a second zero
argument in integer mode. The existing helper now preserves this argument;
no separate formatter was added. All 11110 prior exported guardian display
values were rechecked unchanged. The tree mock initially failed with KeyError
-8 because its fixture packed the text pointer at +36 instead of +40; correcting
the fixture alignment made the native layout mocks pass. Neither export failure
required live collection or changed game state.

Output: clan_protections_native.json and clan_protections_native.md. Rebuild via
tools/run_python_tests.ps1 -Python D:/Nioh3_v080_deliverables/ce-research-env/Scripts/python.exe
-MinimumFreeGiB 0 -ScriptPath deliverables/clan-protection-catalog-20261010/native-extraction/build_native_catalog.py.
Run validate_native_catalog.py through the same runner for offline verification.
The native text decoder is covered by retained-tree re-traversal (30506 nodes),
277 exact catalog lookups and 13 mocked hit/miss/cache/invalid-input checks.
Its caller continues to own identity/signatures, budget and runtime stability.
Validation also verifies 193 source hashes, 171 function/window disassemblies,
47 key native instructions, 20 rank boundary cases and 2000 exported rank values.
validation.json records the passed results and evidence scope. No formal research
record, commit, product integration, publication or further live operation was made.
