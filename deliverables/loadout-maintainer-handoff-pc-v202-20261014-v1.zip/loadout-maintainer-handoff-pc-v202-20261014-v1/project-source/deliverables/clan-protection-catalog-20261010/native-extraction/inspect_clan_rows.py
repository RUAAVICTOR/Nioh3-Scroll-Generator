"""Print compact native clan rows and targeted table consumer instructions."""
import argparse
import json
import struct
from pathlib import Path
HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--function', nargs='*', default=[])
parser.add_argument('--capture', default='clan-consumers-01')
parser.add_argument('--around-values', action='store_true')
args = parser.parse_args()
text = json.loads((HERE / 'native-text-01.json').read_text(encoding='utf-8'))['entries']
label = lambda k: text.get(str(k), {}).get('text')
clans = (HERE / 'native-tables-01/tables/clan/rows.bin').read_bytes()
groups = (HERE / 'native-tables-01/tables/effect_group/rows.bin').read_bytes()
by_group = {struct.unpack_from('<H', groups, at + 12)[0]: groups[at:at+112] for at in range(8, len(groups), 112)}
if not args.function:
    for index, at in enumerate(range(8, len(clans), 152)):
        row = clans[at:at+152]
        slots = []
        for pos in (0x30, 0x3C):
            group, field, value = struct.unpack_from('<IIf', row, pos)
            gr = by_group.get(group)
            slots.append({'group': hex(group), 'label': label(struct.unpack_from('<I', gr, 0x2C)[0]) if gr else None,
                          'field_u32': field, 'field_float': value})
        print(json.dumps({'index': index, 'id': struct.unpack_from('<H', row, 4)[0],
                          'name': label(struct.unpack_from('<I', row, 12)[0]), 'fields_28_2c': list(struct.unpack_from('<2I', row, 0x28)),
                          'slots': slots}, ensure_ascii=True))
else:
    report = json.loads((HERE / args.capture / 'capture.json').read_text())
    for f in report.get('code_consumers', report.get('functions', [])):
        if int(f['begin'], 0) in [int(x, 0) for x in args.function]:
            print(f['begin'])
            indices=set(range(len(f['instructions'])))
            if args.around_values:
                indices={j for n,i in enumerate(f['instructions']) if i['instruction'] in ('call 0x220d9ec','call 0x220da9c') for j in range(max(0,n-12),min(len(f['instructions']),n+28))}
            for n in sorted(indices):
                i=f['instructions'][n];print(i['rva'], i['instruction'])
