"""Build the clan definition catalog from retained native rows/text/code only."""
import bisect
import hashlib
import importlib.util
import json
import math
import re
import struct
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE.parent
ROOT = HERE.parents[2]


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def u32(raw, offset):
    return struct.unpack_from('<I', raw, offset)[0]


# Reuse the previously verified native value formatter rather than duplicating it.
FORMAT_PATH = ROOT / 'deliverables/guardian-spirit-catalog-20261008/native-extraction/build_native_catalog.py'
spec = importlib.util.spec_from_file_location('native_guardian_formatter', FORMAT_PATH)
formatter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(formatter)


def raw_value(base, growth, rank_index, is_current_clan):
    assert 0 <= rank_index <= 9 and isinstance(is_current_clan, bool)
    step = min(rank_index + int(is_current_clan), 7)
    increment = math.trunc(formatter.f32(formatter.f32(step) * growth))
    value = (base + increment) & 0xFFFFFFFF
    return value if value < 0x80000000 else value - 0x100000000


def rank_index(contribution, thresholds):
    assert 0 <= contribution <= 0xFFFFFFFFFFFFFFFF
    return bisect.bisect_right(thresholds, contribution) - 1


def main():
    capture = load(HERE / 'native-tables-01/capture.json')
    assert capture['status'] == 'complete_native_table_capture'
    assert capture['game_writes'] == capture['native_function_calls'] == 0
    blobs = {}
    for item in capture['blobs']:
        raw = (HERE / 'native-tables-01' / item['filename']).read_bytes()
        assert len(raw) == item['size'] and digest(raw).lower() == item['sha256'].lower()
        blobs[item['filename']] = raw
    for table in capture['tables']:
        assert table['stable'] and table['hash_index_and_row_keys_agree']
        rows = blobs[table['rows_blob']['filename']]
        assert u32(rows, 4) == table['row_count']
        keys = [struct.unpack_from('<H', rows, 8 + i * table['row_size'] + table['key_offset'])[0]
                for i in range(table['row_count'])]
        pairs = list(struct.iter_unpack('<II', blobs[table['hash']['entries_blob']['filename']]))
        populated = [(key, index) for key, index in pairs if index != 0xFFFFFFFF]
        assert len(populated) == len(keys) and len(set(keys)) == len(keys)
        assert sorted(populated) == sorted((key, i) for i, key in enumerate(keys))

    texts = load(HERE / 'native-text-01.json')
    assert texts['status'] == 'complete_native_text_tree_capture'
    assert texts['pid'] == capture['pid'] and texts['executable_sha256'] == capture['executable_sha256']
    assert texts['game_writes'] == texts['native_function_calls'] == 0
    assert len(texts['entries']) == texts['native_node_count'] == 30506
    native_text = {}
    for key, item in texts['entries'].items():
        raw = bytes.fromhex(item['raw_hex'])
        text_key, units = struct.unpack_from('<II', raw)
        assert text_key == int(key) and len(raw) == 8 + units * 2 and raw[-2:] == b'\0\0'
        assert digest(raw) == item['sha256'] and raw[8:-2].decode('utf-16le') == item['text']
        native_text[int(key)] = item['text']
    node_blob = texts['nodes_blob']
    raw = (HERE / node_blob['filename']).read_bytes()
    assert len(raw) == node_blob['size'] and digest(raw) == node_blob['sha256']
    def text(key):
        return native_text[key] if key else None

    constants = load(HERE / 'native-grade-constants.json')
    assert constants['executable_sha256'] == capture['executable_sha256']
    assert digest(bytes.fromhex(constants['pointer_array_hex'])) == constants['pointer_array_sha256']
    grades = []
    for item in constants['labels']:
        raw = bytes.fromhex(item['raw_hex'])
        assert digest(raw) == item['sha256'] and raw[:-2].decode('utf-16le') == item['text']
        grades.append(item['text'])
    assert len(grades) == 18
    thresholds_source = load(HERE / 'native-rank-thresholds.json')
    assert thresholds_source['executable_sha256'] == capture['executable_sha256']
    threshold_bytes = bytes.fromhex(thresholds_source['ranges'][0]['raw_hex'])
    assert digest(threshold_bytes) == thresholds_source['ranges'][0]['sha256']
    thresholds = list(struct.unpack('<10Q', threshold_bytes))
    assert thresholds == sorted(set(thresholds)) and thresholds[0] == 0
    name_ids = [0x248A247, 0x25FF623, 0x26A3684, 0x24F740F, 0x2509936,
                0x26FB27E, 0x2642BBB, 0x26C6652, 0x266DC75, 0x26A1569]
    ranks = [{'rank_index': i, 'name_text_id': key, 'name_zh': text(key),
              'minimum_contribution': thresholds[i], 'step_other_clan': min(i, 7),
              'step_current_clan': min(i + 1, 7)} for i, key in enumerate(name_ids)]

    groups_raw = blobs['tables/effect_group/rows.bin']
    groups = {struct.unpack_from('<H', groups_raw, at + 0xC)[0]: (i, groups_raw[at:at+112])
              for i, at in enumerate(range(8, len(groups_raw), 112))}
    rows = blobs['tables/clan/rows.bin']
    clans, excluded, used_groups = [], [], {}
    for index, at in enumerate(range(8, len(rows), 152)):
        row = rows[at:at+152]
        clan_id, name_id = u32(row, 4), u32(row, 0xC)
        assert clan_id == struct.unpack_from('<H', row, 4)[0]
        record = {'clan_id': clan_id, 'row_index': index, 'name_text_id': name_id,
                  'name_zh': text(name_id), 'raw_hex': row.hex(), 'raw_sha256': digest(row)}
        if clan_id == 0:
            assert not record['name_zh']
            record['exclusion_reason'] = 'Unnamed native no-clan record; retained separately.'
            excluded.append(record)
            continue
        assert record['name_zh']
        slots = []
        for slot, pos in enumerate((0x30, 0x3C)):
            group_id, base, growth = struct.unpack_from('<Iif', row, pos)
            group_index, group = groups[group_id]
            assert not any(u32(group, off) for off in (0x10, 0x14, 0x18, 0x1C, 0x20))
            ids = {field: u32(group, off) for field, off in (
                ('name_template', 0x2C), ('description', 0x30), ('unit_template', 0x34),
                ('substitution_1', 0x38), ('substitution_2', 0x3C), ('substitution_description', 0x48))}
            strings = {field: text(key) for field, key in ids.items()}
            label = strings['name_template']
            for field in ('substitution_1', 'substitution_2'):
                if strings[field]:
                    label = label.replace('{}', strings[field], 1)
            label = re.sub(r'\^09~(?:BUFF|DEBUFF)~', '', label).replace('^09~~', '')
            assert '{}' not in label and '^' not in label, label
            metadata = {'id': group_id, 'row_index': group_index, 'label_zh': label,
                        'text_ids': ids, **strings, 'flags_50': u32(group, 0x50),
                        'decimal_mode': group[0x6C], 'raw_hex': group.hex(), 'raw_sha256': digest(group)}
            assert group_id != 0x54FE and math.isfinite(growth)
            used_groups[group_id] = metadata
            values = {kind: [raw_value(base, growth, rank, joined) for rank in range(10)]
                      for kind, joined in (('other_clan', False), ('current_clan', True))}
            try:
                displays = {kind: [formatter.display_value(v, metadata, grades) for v in seq]
                            for kind, seq in values.items()}
            except AssertionError as error:
                raise RuntimeError(json.dumps({'clan_id': clan_id, 'group_id': hex(group_id),
                                               'decimal_mode': metadata['decimal_mode'],
                                               'unit_template': metadata['unit_template'],
                                               'raw_values': values})) from error
            kind = 'grade' if metadata['flags_50'] & 4 else ('numeric' if strings['unit_template'] else 'hidden')
            slots.append({'slot_index': slot, 'effect_group_id': group_id, 'label_zh': label,
                          'description_zh': strings['description'], 'value_kind': kind,
                          'base_raw_value': base, 'growth_float32': growth,
                          'growth_raw_hex': row[pos+8:pos+12].hex(),
                          'base_display_value': formatter.display_value(base, metadata, grades),
                          'raw_values_by_rank_index': values, 'display_values_by_rank_index': displays,
                          'native_slot_offset': hex(pos)})
        record['slots'] = slots
        clans.append(record)
    assert len(clans) == 50 and len(excluded) == 1
    assert {c['clan_id'] for c in clans} == set(range(1, 51))
    assert all(len(c['slots']) == 2 for c in clans)
    current = load(HERE / 'current-clan-01.json')
    assert current['status'] == 'complete_current_clan_capture'
    assert current['executable_sha256'] == capture['executable_sha256'] and current['pid'] == capture['pid']
    current_id = current['current_clan_id']
    contribution = next(c['stored_contribution'] for c in current['contributions'] if c['id'] == current_id)
    current_rank = rank_index(contribution, thresholds)
    assert current_rank == 9  # Elapsed-time addition cannot alter this already capped rank.
    current_clan = next(c for c in clans if c['clan_id'] == current_id)
    live_control = {'clan_id': current_id, 'name_zh': current_clan['name_zh'],
                    'stored_contribution': contribution, 'rank_index': current_rank,
                    'rank_name_zh': ranks[current_rank]['name_zh'],
                    'computed_display_values': [s['display_values_by_rank_index']['current_clan'][current_rank] for s in current_clan['slots']],
                    'evidence': 'Native player ID/contribution snapshot plus native code calculation; no UI value observation.',
                    'scope': 'Stored contribution already exceeds the final threshold; uncomputed elapsed-time addition does not change rank 9.'}
    # Include raw source manifests and all selected exact function windows.
    paths = ['native-tables-01/capture.json', 'native-text-01.json', node_blob['filename'],
             'native-grade-constants.json', 'native-rank-thresholds.json', 'current-clan-01.json']
    paths += ['native-tables-01/' + b['filename'] for b in capture['blobs']]
    for folder in ('clan-consumers-01', 'clan-value-functions-02', 'clan-rank-functions-03',
                   'clan-current-functions-04', 'clan-value-callers-05', 'clan-format-functions-06'):
        paths += [p.relative_to(HERE).as_posix() for p in (HERE / folder).rglob('*') if p.is_file()]
    sources = [{'path': 'native-extraction/' + p, 'size': (HERE/p).stat().st_size,
                'sha256': digest((HERE/p).read_bytes())} for p in sorted(set(paths))]
    result = {'schema': 'nioh3-native-clan-protection-catalog/v1', 'status': 'native_extracted',
              'game_identity': {k: capture[k] for k in ('game_version', 'executable_sha256', 'pid', 'process_birth_filetime', 'captured_at_utc')},
              'source_policy': {'native_only': True, 'community_or_wiki_used_as_build_inputs': False,
                                'screenshot_transcriptions_used_as_build_inputs': False, 'game_writes': 0,
                                'native_function_calls': 0, 'debugger_used': False},
              'coverage': {'native_rows': 51, 'named_clans': 50, 'protection_slots': 100,
                           'resolved_effect_groups': len(used_groups), 'rank_indices': 10},
              'native_layout': {'manager_offset': '0x758', 'stride': 152, 'key': 'u32 +0x4',
                                'name_text_id': 'u32 +0xC', 'slots': '(u32 group, i32 base, float32 growth) at +0x30 and +0x3C',
                                'effect_group_manager_offset': '0xA8', 'effect_group_stride': 112},
              'semantics': {'evidence': 'native_table_and_native_control_flow',
                            'formula': 'i32(base + trunc(float32(float32(min(rank_index + int(is_current_clan), 7)) * growth_float32)))',
                            'rank_domain': [0, 9], 'growth_step_cap': 7,
                            'current_clan_bonus': 'The compared clan ID equals native current joined clan ID; +1 before the step-7 cap.',
                            'rank_threshold_rva': '0x3BDCB30', 'rank_mapper_rva': '0x220D630',
                            'rank_name_mapper_rva': '0x220D670', 'rank_getter_rva': '0x220D234',
                            'base_getter_rva': '0x220DA9C', 'value_getter_rva': '0x220D9EC',
                            'application_consumer_rva': '0x2180BD8', 'name_getter_rva': '0x1BBDA4C',
                            'value_formatter_rva': '0x1BC1A08', 'unit_wrapper_rva': '0x1BC1C6C',
                            'grade_selector_rva': '0x22CE144', 'grade_index_rule': 'max(0,17-u32(raw_value))'},
              'contract': {'identity': 'Join by native clan_id and effect_group_id, never by display names alone.',
                           'rank_input': 'Use the rank belonging to the selected clan, not a global player rank.',
                           'arrays': 'Index 0..9 is native rank index. other_clan/current_clan describe whether this ID equals the joined clan.',
                           'availability': 'The complete native named catalog does not prove player unlock, legal slot selection or simultaneous activation.',
                           'hidden_values': 'An empty native display is preserved. Raw values do not establish triggered buff magnitude or duration.',
                           'contribution': 'Native rank uses stored contribution plus elapsed-time contribution for the joined clan. This export accepts rank index; elapsed-time conversion is not implemented.',
                           'remaining_scope': 'Selection/unlock rules, duplicate-effect aggregation and final combat formulas are outside this definition catalog.'},
              'ranks': ranks, 'grade_labels_by_index': grades, 'clans': clans,
              'effect_groups': sorted(used_groups.values(), key=lambda g: g['id']),
              'excluded_native_records': excluded, 'live_control': live_control, 'sources': sources}
    destination = OUT / 'clan_protections_native.json'
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    lines = ['# Native clan protections — PC v2.02', '',
             'All 50 named native clans and 100 protection slots, extracted from game memory. The unnamed ID 0 record is preserved separately in JSON. Native text, tables and machine code are the only inputs; no Wiki, community or screenshot transcription was used.', '',
             'Each effect retains its native group ID, raw base, float32 growth, full description and values at all ten rank indices. Numeric values below are native calculations, not separately observed UI values. An empty display means the native formatter shows no number; it is not a zero-percent claim.', '',
             'Formula: base + trunc(float32(min(rank + current-clan bonus, 7) * growth)). The current joined clan receives one extra step before the cap. Rank 7..9 share the same final growth step; the current clan reaches it at rank 6. The two effect definitions do not establish legal selection or simultaneous activation.', '',
             '| Rank index | Native rank name | Minimum contribution | Other clan step | Current clan step |',
             '|---:|---|---:|---:|---:|']
    for r in ranks:
        lines.append(f"| {r['rank_index']} | {r['name_zh']} | {r['minimum_contribution']} | {r['step_other_clan']} | {r['step_current_clan']} |")
    lines += ['', '| Clan ID | Clan | Slot index | Protection | Kind | Base | Current clan at rank 0 | At growth cap | Raw growth per step |',
              '|---:|---|---:|---|---|---|---|---|---:|']
    for c in clans:
        for s in c['slots']:
            fields = [str(c['clan_id']), c['name_zh'], str(s['slot_index']), s['label_zh'], s['value_kind'],
                      s['base_display_value'], s['display_values_by_rank_index']['current_clan'][0],
                      s['display_values_by_rank_index']['current_clan'][9], str(s['growth_float32'])]
            lines.append('| ' + ' | '.join(f.replace('|', '\\|').replace('\n', '<br>') for f in fields) + ' |')
    lines += ['', 'The live player snapshot identified ' + current_clan['name_zh'] + ', rank ' + ranks[current_rank]['name_zh'] +
              '; computed protection values: ' + ' / '.join(live_control['computed_display_values']) +
              '. This is native snapshot/control-flow validation, not screenshot acceptance.', '',
              'Rebuild with the project Python runner and native-extraction/build_native_catalog.py. The JSON source manifest hashes every retained accepted source. validate_native_catalog.py verifies code byte/disassembly parity, key joins, rank boundaries and all exported values.']
    (OUT / 'clan_protections_native.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'coverage': result['coverage'],
                      'value_kinds': {kind: sum(s['value_kind'] == kind for c in clans for s in c['slots']) for kind in ('numeric','grade','hidden')},
                      'live_control': live_control}, ensure_ascii=True))


if __name__ == '__main__':
    main()
