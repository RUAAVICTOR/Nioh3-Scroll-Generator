"""Read the native current clan and contribution rows with no game calls/writes."""
import hashlib,json,struct,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[2]
sys.path[:0]=[str(ROOT),str(ROOT/'deliverables/load-capacity-research/scripts')]
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from capture_player import _process_executable,_sha256,_file_version

identity=json.loads((HERE/'native-tables-01/capture.json').read_text())
output=HERE/'current-clan-01.json';assert not output.exists()
started=time.monotonic();total=0
report={'status':'partial','read_only':True,'game_writes':0,'native_function_calls':0,'limits':{'read_bytes':16384,'seconds':20}}
try:
    with ProcessReader() as reader:
        assert reader.pid==identity['pid'] and reader.creation_time()==identity['process_birth_filetime']
        exe=_process_executable(reader);assert list(_file_version(exe))==[2,0,2,0] and _sha256(exe)==identity['executable_sha256']
        def read(address,size):
            global total
            total+=size;assert total<=16384 and time.monotonic()-started<20
            return reader.read(address,size)
        for directory,name,rva in [('clan-value-functions-02','10C8F38.bin',0x10C8F38),('clan-current-functions-04','2935ED4.bin',0x2935ED4)]:
            expected=(HERE/directory/name).read_bytes()[:16]
            assert read(reader.module_base+rva,16)==expected
        root=struct.unpack('<Q',read(reader.module_base+0x45B9E70,8))[0];assert root
        clan=read(root+0x21220,4);joined=read(root+0x21280,8);rows=read(root+0x21380,60*32)
        assert read(root+0x21220,4)==clan and read(root+0x21280,8)==joined and read(root+0x21380,len(rows))==rows
        cid=struct.unpack('<I',clan)[0]
        contributions=[{'id':struct.unpack_from('<I',rows,at)[0],'stored_contribution':struct.unpack_from('<Q',rows,at+16)[0],
                        'raw_hex':rows[at:at+32].hex()} for at in range(0,len(rows),32) if struct.unpack_from('<I',rows,at)[0]]
        report.update(pid=reader.pid,process_birth_filetime=reader.creation_time(),executable_sha256=identity['executable_sha256'],
                      root=hex(root),current_clan_id=cid,joined_clock_raw_hex=joined.hex(),contributions=contributions,
                      rows_sha256=hashlib.sha256(rows).hexdigest(),rows_raw_hex=rows.hex(),
                      scope='Stored contributions only; native current-clan elapsed-time contribution is not evaluated.')
        assert reader.creation_time()==identity['process_birth_filetime'];report['status']='complete_current_clan_capture'
finally:
    report.update(read_bytes=total,elapsed_seconds=time.monotonic()-started,process_handle_closed=True)
    output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report.get(k) for k in ('status','current_clan_id','contributions','read_bytes')}))
