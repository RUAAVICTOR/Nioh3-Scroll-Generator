"""Match native clan-label anchors to bounded native prefixes; infer keyed layouts."""
import hashlib
import json
import struct
from pathlib import Path
HERE = Path(__file__).resolve().parent
directory = HERE / 'discovery-03'
capture = json.loads((directory / 'capture.json').read_text())
texts = json.loads((HERE / 'native-text-01.json').read_text(encoding='utf-8'))['entries']
labels = {int(k): v['text'] for k, v in texts.items() if v['text'] in ('本多', '丰臣', '德川', '织田')}
print('LABELS', json.dumps({hex(k): v for k, v in labels.items()}, ensure_ascii=True))
def raw(name):
    blob = next(b for b in capture['blobs'] if b['path'] == name)
    data = (directory / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == blob['sha256']
    return data
found = []
for candidate in capture['table_candidates']:
    if not candidate.get('store_prefix_stable') or not candidate.get('context_and_header_stable'):
        continue
    context = f"{int(candidate['manager_offset'], 0):03x}"
    store = raw(f'candidates/{context}-store-prefix.bin')
    hits = [(at, labels[value]) for at in range(8, len(store)-3, 4) if (value := struct.unpack_from('<I', store, at)[0]) in labels]
    if not hits:
        continue
    count = candidate['row_count_candidate']
    header = raw(f'candidates/{context}-hash-header.bin')
    entries = raw(f'candidates/{context}-hash-entries.bin')
    sentinel = struct.unpack_from('<I', header, 4)[0]
    keys = {i: k for k, i in struct.iter_unpack('<II', entries) if k != sentinel and i < count}
    if len(keys) != count:
        continue
    layouts = []
    for stride in range(4, 1025, 4):
        if 8 + count * stride > len(store):
            break
        for offset in range(0, stride-1, 2):
            if all(struct.unpack_from('<H', store, 8+i*stride+offset)[0] == k for i, k in keys.items()):
                layouts.append({'stride': stride, 'key_offset': offset})
    result = {'manager_offset': candidate['manager_offset'], 'count': count, 'layouts': layouts, 'prefix_hits': hits}
    if len(layouts) == 1:
        stride = layouts[0]['stride']
        result['row_hits'] = [(at, label) for at, label in hits if at < 8 + count*stride]
        result['rows'] = [{'index': i, 'id': k, 'raw_hex': store[8+i*stride:8+(i+1)*stride].hex()}
                          for i, k in sorted(keys.items())]
    found.append(result)
(HERE / 'clan-table-candidates.json').write_text(json.dumps(found, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps([{k: v for k, v in r.items() if k not in ('rows', 'prefix_hits')} for r in found], ensure_ascii=True))
short = {hex(int(k)): v['text'] for k, v in texts.items() if len(v['text']) <= 100 and any(s in v['text'] for s in ('武家', '官职', '庇佑'))}
print('UI_TEXT', json.dumps(short, ensure_ascii=True))
