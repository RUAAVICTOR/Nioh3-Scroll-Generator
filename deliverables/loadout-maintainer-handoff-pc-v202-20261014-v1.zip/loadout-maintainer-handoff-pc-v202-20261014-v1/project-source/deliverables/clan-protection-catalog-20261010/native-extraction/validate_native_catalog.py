"""Offline native byte/control-flow, catalog and bounded text-tree validation."""
import importlib.util
import json
import math
import struct
import sys
from pathlib import Path

from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE = Path(__file__).resolve().parent
OUT = HERE.parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
from research.native_text_tree import NativeTextTree, TextTreeLayout
import build_native_catalog as builder

LAYOUT = TextTreeLayout(48, 0, 8, 16, 25, 32, 40, 8, 0, 4)


def expect_failure(fn, message):
    try:
        fn()
    except (RuntimeError, UnicodeDecodeError) as error:
        assert message in str(error), (message, error)
    else:
        raise AssertionError('Invalid native input was accepted: ' + message)


def fixture(*, key=10, payload='native', header_key=10, terminator=True,
            left=100, right=100, second_key=5, add_second=False):
    head, root, child, text = 100, 200, 300, 1000
    def node(l, p, r, k, sentinel=0, ptr=0):
        raw = bytearray(48)
        struct.pack_into('<QQQ', raw, 0, l, p, r)
        raw[25] = sentinel
        struct.pack_into('<I', raw, 32, k)
        struct.pack_into('<Q', raw, 40, ptr)
        return bytes(raw)
    nodes = {head: node(head, root, head, 0, 1), root: node(left, head, right, key, ptr=text)}
    if add_second:
        nodes[child] = node(head, root, head, second_key, ptr=text)
    body = payload.encode('utf-16le') + (b'\0\0' if terminator else b'xx')
    memory = {**nodes, text-8: struct.pack('<II', header_key, len(body)//2), text: body}
    calls = []
    def read(at, size):
        calls.append((at, size))
        return memory[at][:size]
    return memory, calls, NativeTextTree(read, head, LAYOUT, max_nodes=10, max_depth=8, max_text_units=32)


def validate_tree_failures():
    checks = 0
    _, calls, tree = fixture(payload='原生测试')
    assert tree.lookup(10) == 200 and tree.lookup(9) is None
    assert list(tree.iter_nodes()) == [(10, 200)]
    assert tree.text(10, 200)['text'] == '原生测试'
    assert sum(at == 200 for at, _ in calls) == 1  # Node cache must bound repeats.
    checks += 4
    _, _, tree = fixture(left=200)
    expect_failure(lambda: tree.lookup(9), 'cycle')
    checks += 1
    _, _, tree = fixture(left=300, add_second=True, second_key=10)
    expect_failure(lambda: list(tree.iter_nodes()), 'Duplicate')
    checks += 1
    _, _, tree = fixture(left=300, add_second=True)
    tree.max_depth = 1
    expect_failure(lambda: tree.lookup(5), 'depth')
    checks += 1
    _, _, tree = fixture()
    tree.max_nodes = 1
    expect_failure(lambda: tree.lookup(10), 'node bound')
    checks += 1
    memory, _, tree = fixture()
    memory[200] = b'x'
    expect_failure(lambda: tree.lookup(10), 'Short')
    checks += 1
    _, _, tree = fixture(header_key=11)
    expect_failure(lambda: tree.text(10, 200), 'key/length')
    checks += 1
    _, _, tree = fixture(payload='a'*40)
    expect_failure(lambda: tree.text(10, 200), 'key/length')
    checks += 1
    _, _, tree = fixture(terminator=False)
    expect_failure(lambda: tree.text(10, 200), 'terminator')
    checks += 1
    memory, _, tree = fixture()
    memory[1000] = b'a'
    expect_failure(lambda: tree.text(10, 200), 'length/terminator')
    return checks + 1


def main():
    catalog = builder.load(OUT / 'clan_protections_native.json')
    for source in catalog['sources']:
        raw = (OUT / source['path']).read_bytes()
        assert len(raw) == source['size'] and builder.digest(raw) == source['sha256']
    assert catalog['coverage']['named_clans'] == 50 and catalog['coverage']['protection_slots'] == 100
    assert catalog['source_policy']['native_only'] and not catalog['source_policy']['game_writes']
    assert len(catalog['excluded_native_records']) == 1 and catalog['excluded_native_records'][0]['clan_id'] == 0

    # Re-disassemble every retained exact function/window and compare every byte.
    dis = Cs(CS_ARCH_X86, CS_MODE_64)
    instructions, function_count = {}, 0
    for folder in ('clan-consumers-01', 'clan-value-functions-02', 'clan-rank-functions-03',
                   'clan-current-functions-04', 'clan-value-callers-05', 'clan-format-functions-06'):
        report = builder.load(HERE / folder / 'capture.json')
        assert report['executable_sha256'] == catalog['game_identity']['executable_sha256']
        assert report['pid'] == catalog['game_identity']['pid']
        assert report['process_birth_filetime'] == catalog['game_identity']['process_birth_filetime']
        assert report['game_writes'] == 0 and report['process_handle_closed']
        for blob in report.get('blobs', []):
            raw = (HERE/folder/blob['path']).read_bytes()
            assert len(raw) == blob['size'] and builder.digest(raw) == blob['sha256']
        for f in report.get('functions', report.get('code_consumers', [])):
            begin, end = int(f['begin'], 0), int(f['end'], 0)
            path = f.get('path', f'{begin:X}.bin')
            raw = (HERE/folder/path).read_bytes()
            assert len(raw) == end-begin and raw.hex().startswith(f['signature'])
            if 'sha256' in f:
                assert builder.digest(raw) == f['sha256']
            decoded = list(dis.disasm(raw, begin))
            actual = [{'rva': hex(i.address), 'bytes': i.bytes.hex(),
                       'instruction': i.mnemonic + ' ' + i.op_str} for i in decoded]
            assert actual == f['instructions'], (folder, f['begin'])
            for i in actual:
                if i['rva'] in instructions:
                    assert i == instructions[i['rva']]
                instructions[i['rva']] = i
            function_count += 1
    expected = {
        '0x220da35': 'call 0x220da9c', '0x220da3e': 'call 0x220d234',
        '0x220da45': 'call 0x10c8f38', '0x220da4a': 'cmp ebp, eax',
        '0x220da4c': 'jne 0x220da50', '0x220da4e': 'inc ecx',
        '0x220da50': 'mov eax, 7', '0x220da58': 'cmp ecx, eax',
        '0x220da5a': 'cmovg ecx, eax', '0x220da66': 'movss xmm1, dword ptr [rbx + 0x44]',
        '0x220da6d': 'movss xmm1, dword ptr [rbx + 0x38]',
        '0x220da76': 'cvtdq2ps xmm0, xmm0', '0x220da79': 'mulss xmm0, xmm1',
        '0x220da7d': 'cvttss2si rax, xmm0', '0x220da82': 'add esi, eax',
        '0x220daf1': 'mov edi, dword ptr [rbx + 0x40]',
        '0x220daf6': 'mov edi, dword ptr [rbx + 0x34]',
        '0x2180c91': 'mov r11d, dword ptr [rbp + 0x3c]',
        '0x2180c97': 'mov r11d, dword ptr [rbp + 0x30]',
        '0x2180cc0': 'call 0x220d9ec',
        '0x1bc1c7b': 'mov edx, dword ptr [rcx + 0x34]',
        '0x1bc1c7e': 'call 0x1bc1a08', '0x1bc1a34': 'test byte ptr [rcx + 0x50], 4',
        '0x1bc1a6d': 'call 0x22ce144', '0x1bc1b8d': 'mov al, byte ptr [rcx + 0x6c]',
        '0x1bc1b90': 'cmp al, 2', '0x1bc1ba4': 'imul eax, edx, 0x64',
        '0x1bc1bc5': 'cmp al, 1', '0x1bc1bcf': 'mov eax, 0xcccccccd',
        '0x1bc1c12': 'mov dword ptr [rsp + 0x40], ebx',
        '0x1bc1c23': 'mov qword ptr [rsp + 0x20], rcx',
        '0x220d643': 'cmp r8, qword ptr [rcx]', '0x220d646': 'jbe 0x220d66d',
        '0x220d654': 'cmp r8, qword ptr [rcx + 8]', '0x220d658': 'jb 0x220d66d',
        '0x22ce1dc': 'cmp edx, dword ptr [rbp + rcx*4 - 0x60]',
        '0x22ce1e0': 'jae 0x22ce1f0'}
    for rva, instruction in expected.items():
        assert instructions[rva]['instruction'] == instruction, rva
    for rank in catalog['ranks']:
        rva = 0x220D683 if rank['rank_index'] == 0 else 0x220D68A + (rank['rank_index']-1)*8
        assert hex(rank['name_text_id']) in instructions[hex(rva)]['instruction']

    # Traverse the captured tree independently using the reusable decoder.
    texts = builder.load(HERE / 'native-text-01.json')
    node_raw = (HERE / texts['nodes_blob']['filename']).read_bytes()
    assert len(node_raw) % 56 == 0
    memory = {struct.unpack_from('<Q', node_raw, i)[0]: node_raw[i+8:i+56]
              for i in range(0, len(node_raw), 56)}
    assert len(memory) == len(node_raw)//56
    for item in texts['entries'].values():
        raw, pointer = bytes.fromhex(item['raw_hex']), int(item['pointer'], 0)
        memory[pointer-8], memory[pointer] = raw[:8], raw[8:]
    def read(at, size):
        result = memory[at]
        assert len(result) == size
        return result
    head = struct.unpack_from('<Q', bytes.fromhex(texts['context_hex']))[0]
    tree = NativeTextTree(read, head, LAYOUT, max_nodes=65536, max_depth=64, max_text_units=4096)
    traversed = list(tree.iter_nodes())
    assert len(traversed) == texts['native_node_count'] == 30506
    assert {key for key, _ in traversed} == {int(k) for k in texts['entries']}
    for key, address in traversed:
        assert tree.text(key, address) == texts['entries'][str(key)]
    keys = {c['name_text_id'] for c in catalog['clans']} | {r['name_text_id'] for r in catalog['ranks']}
    keys |= {v for g in catalog['effect_groups'] for v in g['text_ids'].values() if v}
    for key in keys:
        assert hex(tree.lookup(key)) == texts['entries'][str(key)]['node']

    thresholds = [r['minimum_contribution'] for r in catalog['ranks']]
    boundary_checks = 0
    for i, threshold in enumerate(thresholds):
        assert builder.rank_index(threshold, thresholds) == i
        boundary_checks += 1
        if i:
            assert builder.rank_index(threshold-1, thresholds) == i-1
            boundary_checks += 1
    assert builder.rank_index(0xFFFFFFFFFFFFFFFF, thresholds) == 9
    assert builder.raw_value(20, 1.5, 7, False) == 30
    assert builder.raw_value(20, 1.5, 1, False) == 21
    assert builder.raw_value(0, builder.formatter.f32(0.99999999), 1, False) == 1
    groups = {g['id']: g for g in catalog['effect_groups']}
    value_checks = 0
    for c in catalog['clans']:
        row = bytes.fromhex(c['raw_hex'])
        assert builder.digest(row) == c['raw_sha256'] and builder.u32(row, 4) == c['clan_id']
        for s in c['slots']:
            group, base, growth = struct.unpack_from('<Iif', row, int(s['native_slot_offset'], 0))
            assert (group, base, growth) == (s['effect_group_id'], s['base_raw_value'], s['growth_float32'])
            g = groups[group]
            group_raw = bytes.fromhex(g['raw_hex'])
            assert builder.digest(group_raw) == g['raw_sha256']
            assert g['unit_template'] == (texts['entries'][str(g['text_ids']['unit_template'])]['text'] if g['text_ids']['unit_template'] else None)
            for kind, joined in (('current_clan', True), ('other_clan', False)):
                values = s['raw_values_by_rank_index'][kind]
                assert len(values) == 10
                for rank, value in enumerate(values):
                    assert value == builder.raw_value(base, growth, rank, joined)
                    assert s['display_values_by_rank_index'][kind][rank] == builder.formatter.display_value(value, g, catalog['grade_labels_by_index'])
                    value_checks += 1
                assert values[7] == values[8] == values[9]
                if joined:
                    assert values[6] == values[7]
    # Regression: the integer-mode zero argument was unused by the prior
    # guardian catalog. Recheck every retained display without rewriting it.
    guardian = builder.load(ROOT / 'deliverables/guardian-spirit-catalog-20261008/guardian_spirits_native.json')
    guardian_groups = {g['id']: g for g in guardian['effect_groups']}
    regression_values = 0
    for c in guardian['guardians']:
        for s in c['slots']:
            for raw, display in zip(s['raw_values_by_level_index'], s['display_values_by_level_index']):
                assert builder.formatter.display_value(raw, guardian_groups[s['effect_group_id']], guardian['grade_labels_by_index']) == display
                regression_values += 1
    assert catalog['live_control']['computed_display_values'] == ['-15.5%', '-16.5%']
    summary = {'status': 'passed', 'source_files_verified': len(catalog['sources']),
               'native_function_windows_redecoded': function_count,
               'native_control_flow_instruction_checks': len(expected) + 10,
               'captured_tree_nodes_and_texts_redecoded': len(traversed),
               'catalog_native_text_lookups_verified': len(keys),
               'rank_boundary_checks': boundary_checks + 1,
               'exported_rank_values_verified': value_checks,
               'prior_guardian_display_regression_values': regression_values,
               'mocked_tree_validation_checks': validate_tree_failures(),
               'scope': 'Offline native byte/control-flow/catalog verification; no live native function execution or UI observation.'}
    (OUT / 'validation.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
