"""Capture the verified native locale tree for clan label discovery, without calls."""
import argparse
import hashlib
import json
import struct
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / 'deliverables/load-capacity-research/scripts')]
from capture_player import _process_executable, _sha256, _file_version
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from research.native_text_tree import NativeTextTree, TextTreeLayout

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--identity', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--id-file', type=Path)
    args = parser.parse_args()
    assert not args.output.exists()
    identity = json.loads(args.identity.read_text())
    layout = TextTreeLayout(48, 0, 8, 16, 25, 32, 40, 8, 0, 4)
    report = {'status': 'partial', 'read_only': True, 'game_writes': 0,
              'native_function_calls': 0, 'debugger': False,
              'limits': {'read_bytes': 33554432, 'seconds': 20,
                         'nodes': 65536, 'depth': 64, 'text_units': 4096}, 'entries': {}}
    started, total = time.monotonic(), 0
    try:
        with ProcessReader() as reader:
            assert reader.pid == identity['pid'] and reader.creation_time() == identity['process_birth_filetime']
            exe = _process_executable(reader)
            assert list(_file_version(exe)) == [2, 0, 2, 0] and _sha256(exe) == identity['executable_sha256']
            report.update(pid=reader.pid, process_birth_filetime=reader.creation_time(),
                          module_base=hex(reader.module_base), executable_sha256=identity['executable_sha256'])
            def read(address, size):
                nonlocal total
                total += size
                assert total <= 33554432 and time.monotonic() - started < 20
                return reader.read(address, size)
            signatures = {}
            tree_code = (ROOT / 'deliverables/skill-catalog-20261009/native-extraction/skill-text-tree-06/63DDA0.bin').read_bytes()[:16]
            for rva, expected in [(0x5A4B04, bytes.fromhex('448bc1488b0d423902048b91e41c0000')), (0x63DDA0, tree_code)]:
                actual = read(reader.module_base + rva, len(expected))
                signatures[hex(rva)] = {'expected': expected.hex(), 'actual': actual.hex()}
                assert actual == expected
            report['signatures'] = signatures
            root = struct.unpack('<Q', read(reader.module_base + 0x45C8450, 8))[0]
            context = read(root + 0x1CD0, 32)
            head, count = struct.unpack_from('<QQ', context)
            assert 0 < count < 65536
            report.update(locale_root=hex(root), context_hex=context.hex(), native_node_count=count)
            tree = NativeTextTree(read, head, layout, max_nodes=65536, max_depth=64, max_text_units=4096)
            if args.id_file:
                ids = json.loads(args.id_file.read_text())
                assert len(ids) <= 2000 and all(isinstance(k, int) and 0 < k <= 0xFFFFFFFF for k in ids)
                targets = [(key, tree.lookup(key)) for key in sorted(set(ids))]
            else:
                targets = list(tree.iter_nodes())
                assert len(targets) == count
            for key, at in targets:
                report['entries'][str(key)] = tree.text(key, at) if at is not None else {'found': False}
            node_data = b''.join(struct.pack('<Q', at) + raw for at, raw in sorted(tree.nodes.items()))
            node_path = args.output.with_suffix('.nodes.bin')
            node_path.write_bytes(node_data)
            report['nodes_blob'] = {'filename': node_path.name, 'size': len(node_data), 'sha256': hashlib.sha256(node_data).hexdigest()}
            assert read(root + 0x1CD0, 32) == context
            assert reader.creation_time() == identity['process_birth_filetime']
            report['status'] = 'complete_native_text_tree_capture'
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        report.update(read_bytes=total, elapsed_seconds=time.monotonic() - started, process_handle_closed=True)
        args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    selected = {hex(int(k)): v['text'] for k, v in report['entries'].items()
                if len(v.get('text', '')) <= 32 and any(word in v.get('text', '') for word in ('武家', '官职', '本多', '丰臣', '德川', '织田'))}
    print(json.dumps({'status': report['status'], 'texts': len(report['entries']), 'read_bytes': total,
                      'matching_labels': selected}, ensure_ascii=True))

if __name__ == '__main__':
    main()
