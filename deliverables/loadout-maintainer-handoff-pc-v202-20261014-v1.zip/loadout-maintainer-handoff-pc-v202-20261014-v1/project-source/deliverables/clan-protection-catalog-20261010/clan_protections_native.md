# Native clan protections — PC v2.02

All 50 named native clans and 100 protection slots, extracted from game memory. The unnamed ID 0 record is preserved separately in JSON. Native text, tables and machine code are the only inputs; no Wiki, community or screenshot transcription was used.

Each effect retains its native group ID, raw base, float32 growth, full description and values at all ten rank indices. Numeric values below are native calculations, not separately observed UI values. An empty display means the native formatter shows no number; it is not a zero-percent claim.

Formula: base + trunc(float32(min(rank + current-clan bonus, 7) * growth)). The current joined clan receives one extra step before the cap. Rank 7..9 share the same final growth step; the current clan reaches it at rank 6. The two effect definitions do not establish legal selection or simultaneous activation.

| Rank index | Native rank name | Minimum contribution | Other clan step | Current clan step |
|---:|---|---:|---:|---:|
| 0 | 足轻 | 0 | 0 | 1 |
| 1 | 小头 | 1000 | 1 | 2 |
| 2 | 组头 | 3000 | 2 | 3 |
| 3 | 物头 | 6000 | 3 | 4 |
| 4 | 足轻大将 | 10000 | 4 | 5 |
| 5 | 侍大将 | 15000 | 5 | 6 |
| 6 | 武者大将 | 21000 | 6 | 7 |
| 7 | 中老 | 30000 | 7 | 7 |
| 8 | 家老 | 42500 | 7 | 7 |
| 9 | 宿老 | 60000 | 7 | 7 |

| Clan ID | Clan | Slot index | Protection | Kind | Base | Current clan at rank 0 | At growth cap | Raw growth per step |
|---:|---|---:|---|---|---|---|---|---:|
| 1 | 织田 | 0 | 守护灵技的伤害 | numeric | +10.0% | +10.6% | +14.2% | 6.0 |
| 1 | 织田 | 1 | 敌人异常状态持续（混沌） | numeric | +10.0% | +11.0% | +17.0% | 10.0 |
| 2 | 德川 | 0 | 非绝境状态下防止死亡 | numeric | 15.0% | 15.9% | 21.3% | 9.0 |
| 2 | 德川 | 1 | 药品的体力恢复效果（绝境） | numeric | +30.0% | +34.0% | +58.0% | 40.0 |
| 3 | 丰臣 | 0 | 获得精华 | numeric | +5.0% | +5.3% | +7.1% | 3.0 |
| 3 | 丰臣 | 1 | 吸收精华可恢复体力 | numeric | 6 | 7 | 13 | 1.0 |
| 4 | 真田 | 0 | 琢技造成的伤害增加倍率 | numeric | +8.0% | +8.4% | +10.8% | 4.0 |
| 4 | 真田 | 1 | 跳跃的精力 | numeric | -12.0% | -13.0% | -19.0% | 10.0 |
| 5 | 石田 | 0 | 守护灵技的精力伤害 | numeric | +12.0% | +12.7% | +16.9% | 7.0 |
| 5 | 石田 | 1 | 获得金钱 | numeric | +5.0% | +5.5% | +8.5% | 5.0 |
| 6 | 大谷 | 0 | 打倒敌人时赋予昂灵 | hidden |  |  |  | 6.0 |
| 6 | 大谷 | 1 | 属性攻击伤害降低 | numeric | +20 | +23 | +41 | 3.0 |
| 7 | 加藤 | 0 | 承受的伤害降低（攻击动作期间） | numeric | -12.0% | -12.5% | -15.5% | 5.0 |
| 7 | 加藤 | 1 | 被攻击时承受的伤害降低（绝境） | numeric | -13.0% | -13.5% | -16.5% | 5.0 |
| 8 | 浅井 | 0 | 药品恢复扩散 | numeric | +20.0% | +21.1% | +27.7% | 11.0 |
| 8 | 浅井 | 1 | 精力恢复反映（精华槽） | grade | C- | C | A | 1.0 |
| 9 | 今川 | 0 | 对极近距离敌人的弓箭伤害 | numeric | +30.0% | +31.7% | +41.9% | 17.0 |
| 9 | 今川 | 1 | 造成雷属性伤害时吸取体力 | grade | C- | C | A | 1.0 |
| 10 | 前田 | 0 | 刺击伤害 | numeric | +12.0% | +12.7% | +16.9% | 7.0 |
| 10 | 前田 | 1 | 追击和近身刺击施加防御力降低 | hidden |  |  |  | 0.0 |
| 11 | 岛津 | 0 | 近距离攻击伤害（绝境） | numeric | +7.5% | +7.9% | +10.3% | 4.0 |
| 11 | 岛津 | 1 | 精力恢复速度（绝境） | numeric | +7.5% | +8.3% | +13.1% | 8.0 |
| 12 | 毛利 | 0 | 箭矢持有数量上限 | numeric | +3 | +4 | +10 | 1.0 |
| 12 | 毛利 | 1 | 弓伤害 | numeric | +20.0% | +21.0% | +27.0% | 10.0 |
| 13 | 黑田 | 0 | 伤害反映（正面效果数） | grade | C | C+ | A+ | 1.0 |
| 13 | 黑田 | 1 | 大炮伤害 | numeric | +20.0% | +21.0% | +27.0% | 10.0 |
| 14 | 立花 | 0 | 雷属性伤害 | numeric | +8.5% | +9.0% | +12.0% | 5.0 |
| 14 | 立花 | 1 | 行动精力消耗（负面效果时） | numeric | -10.0% | -11.0% | -17.0% | 10.0 |
| 15 | 井伊 | 0 | 如火赤备 | numeric | +2.0% | +2.1% | +3.0% | 1.5 |
| 15 | 井伊 | 1 | 如风赤备 | hidden |  |  |  | 0.0 |
| 16 | 本多 | 0 | 承受的伤害减半（无伤状态） | numeric | 30.0% | 31.7% | 41.9% | 17.0 |
| 16 | 本多 | 1 | 武技伤害 | numeric | +6.0% | +6.5% | +9.5% | 5.0 |
| 17 | 松永 | 0 | 敌人的麻痹状态累积 | numeric | +7.5% | +7.9% | +10.3% | 4.0 |
| 17 | 松永 | 1 | 追击和近身刺击可恢复体力 | numeric | 130 | 145 | 235 | 15.0 |
| 18 | 杂贺 | 0 | 枪弹持有数量上限 | numeric | +2 | +3 | +9 | 1.0 |
| 18 | 杂贺 | 1 | 火枪伤害 | numeric | +20.0% | +21.0% | +27.0% | 10.0 |
| 19 | 伊达 | 0 | 以守护灵技打倒敌人可回收灵力 | numeric | +35.0% | +36.9% | +48.3% | 19.0 |
| 19 | 伊达 | 1 | 近距离攻击的灵力增加量 | numeric | +7.0% | +7.8% | +12.6% | 8.0 |
| 20 | 上杉 | 0 | 坚忍度 | numeric | +5 | +6 | +12 | 1.0 |
| 20 | 上杉 | 1 | 近距离攻击打倒敌人时恢复体力 | numeric | 300 | 315 | 405 | 15.0 |
| 21 | 柴田 | 0 | 精力归零时降低承受的伤害 | numeric | -20.0% | -21.2% | -28.4% | 12.0 |
| 21 | 柴田 | 1 | 近距离攻击伤害 | numeric | +5.0% | +5.5% | +8.5% | 5.0 |
| 22 | 九鬼 | 0 | 对处于水状态敌人的守护灵技伤害 | numeric | +18.0% | +19.0% | +25.0% | 10.0 |
| 22 | 九鬼 | 1 | 水属性伤害 | numeric | +8.0% | +9.0% | +15.0% | 10.0 |
| 23 | 三好 | 0 | 精力恢复速度 | numeric | +7.0% | +7.4% | +9.8% | 4.0 |
| 23 | 三好 | 1 | 依打倒敌人的数量降低承受的伤害 | grade | C | C+ | A+ | 1.0 |
| 24 | 武田 | 0 | 对无伤敌人造成的近距离伤害 | numeric | +12.0% | +12.7% | +16.9% | 7.0 |
| 24 | 武田 | 1 | 火属性伤害 | numeric | +8.0% | +9.0% | +15.0% | 10.0 |
| 25 | 福岛 | 0 | 强攻击伤害 | numeric | +6.0% | +6.3% | +8.1% | 3.0 |
| 25 | 福岛 | 1 | 空手攻击伤害 | numeric | +11.0% | +12.0% | +18.0% | 10.0 |
| 26 | 藤堂 | 0 | 对体力的反映（刚） | grade | D | D+ | B+ | 1.0 |
| 26 | 藤堂 | 1 | 忍术槽增加量 | numeric | +10.0% | +11.0% | +17.0% | 10.0 |
| 27 | 明智 | 0 | 阴阳术　术力 | numeric | +25 | +26 | +32 | 1.0 |
| 27 | 明智 | 1 | 箭弹命中弱点时伤害 | numeric | +13.0% | +14.0% | +20.0% | 10.0 |
| 28 | 足利 | 0 | 格挡成功时赋予造成伤害增加 | hidden |  |  |  | 0.0 |
| 28 | 足利 | 1 | 防御精力消耗降低 | numeric | -9.0% | -9.4% | -11.8% | 4.0 |
| 29 | 佐竹 | 0 | 上段武技伤害 | numeric | +9.0% | +9.5% | +12.5% | 5.0 |
| 29 | 佐竹 | 1 | 以近距离攻击打倒敌人时恢复自己和我方体力 | numeric | 280 | 295 | 385 | 15.0 |
| 30 | 朝仓 | 0 | 装备品掉落率 | numeric | +8.5% | +9.0% | +12.0% | 5.0 |
| 30 | 朝仓 | 1 | 获得金钱 | numeric | +5.0% | +5.5% | +8.5% | 5.0 |
| 31 | 蒲生 | 0 | 幸运 | numeric | +25 | +26 | +32 | 1.0 |
| 31 | 蒲生 | 1 | 连续攻击伤害增加 | grade | D+ | C- | A- | 1.0 |
| 32 | 尚 | 0 | 成功识破时造成伤害增加 | hidden |  |  |  | 0.0 |
| 32 | 尚 | 1 | 闪避动作精力消耗降低 | numeric | -10.0% | -10.9% | -16.3% | 9.0 |
| 33 | 斋藤 | 0 | 敌人的毒状态累积 | numeric | +8.5% | +9.0% | +12.0% | 5.0 |
| 33 | 斋藤 | 1 | 敌人的持续伤害 | numeric | +14.0% | +15.0% | +21.0% | 10.0 |
| 34 | 南部 | 0 | 近距离攻击伤害（无伤） | numeric | +5.5% | +5.8% | +7.6% | 3.0 |
| 34 | 南部 | 1 | 箭弹命中弱点可恢复体力 | numeric | 105 | 109 | 133 | 4.0 |
| 35 | 细川 | 0 | 精力受到攻击降至50%以下时赋予造成伤害增加 | hidden |  |  |  | 0.0 |
| 35 | 细川 | 1 | 打倒敌人时赋予幸运增加 | hidden |  |  |  | 10.0 |
| 36 | 长宗我部 | 0 | 连续攻击精力伤害增加 | grade | C- | C | A | 1.0 |
| 36 | 长宗我部 | 1 | 成功识破时精力恢复速度增加 | hidden |  |  |  | 0.0 |
| 37 | 尼子 | 0 | 近距离攻击的精力消耗降低 | numeric | -8.0% | -8.4% | -10.8% | 4.0 |
| 37 | 尼子 | 1 | 空中承受的伤害 | numeric | -10.5% | -11.0% | -14.0% | 5.0 |
| 38 | 蛎崎 | 0 | 近距离攻击精力伤害 | numeric | +9.5% | +10.0% | +13.0% | 5.0 |
| 38 | 蛎崎 | 1 | 对精力耗尽敌人的近距离伤害 | numeric | +15.0% | +15.5% | +18.5% | 5.0 |
| 39 | 源 | 0 | 守护灵技灵力消耗减少 | numeric | -7.5% | -7.9% | -10.3% | 4.0 |
| 39 | 源 | 1 | 武技灵力增加量 | numeric | +10.0% | +11.0% | +17.0% | 10.0 |
| 40 | 平 | 0 | 防御反映（精华槽） | grade | D+ | C- | A- | 1.0 |
| 40 | 平 | 1 | 死亡时自动回收一部分精华 | numeric | +45.0% | +47.0% | +59.0% | 20.0 |
| 41 | 北条 | 0 | 灵力增加量反映（精华槽） | grade | C- | C | A | 1.0 |
| 41 | 北条 | 1 | 风属性伤害 | numeric | +8.0% | +9.0% | +15.0% | 10.0 |
| 42 | 梶原 | 0 | 不消耗使役符 | numeric | +12.0% | +12.6% | +16.2% | 6.0 |
| 42 | 梶原 | 1 | 阴阳术命中时施加移动速度降低 | hidden |  |  |  | 0.0 |
| 43 | 渡边 | 0 | 对攻击中敌人的近距离伤害 | numeric | +13.0% | +13.7% | +17.9% | 7.0 |
| 43 | 渡边 | 1 | 武技吸取体力 | numeric | +3.0% | +3.0% | +3.0% | 0.0 |
| 44 | 松平 | 0 | 获得武功 | numeric | +10.0% | +10.5% | +13.5% | 5.0 |
| 44 | 松平 | 1 | 上段架式攻击伤害 | numeric | +8.0% | +8.5% | +11.5% | 5.0 |
| 45 | 山内 | 0 | 伤害反映（爱用度） | grade | D+ | C- | A- | 1.0 |
| 45 | 山内 | 1 | 格挡成功时赋予自动恢复体力 | hidden |  |  |  | 0.0 |
| 46 | 锅岛 | 0 | 箭弹的精力伤害 | numeric | +15.5% | +16.4% | +21.8% | 9.0 |
| 46 | 锅岛 | 1 | 炮弹持有数量上限 | numeric | +1 | +2 | +8 | 1.0 |
| 47 | 服部 | 0 | 背后攻击伤害 | numeric | +7.0% | +7.4% | +9.8% | 4.0 |
| 47 | 服部 | 1 | 忍术伤害 | numeric | +7.5% | +8.1% | +11.7% | 6.0 |
| 48 | 柳生 | 0 | 精力耗尽的恢复时间缩短 | hidden |  |  |  | 6.0 |
| 48 | 柳生 | 1 | 收刀状态下施展的武技伤害 | numeric | +9.5% | +10.0% | +13.0% | 5.0 |
| 49 | 高杉 | 0 | 对攻击力的反映（火枪伤害） | grade | D+ | C- | A- | 1.0 |
| 49 | 高杉 | 1 | 对极近距离敌人的火枪伤害 | numeric | +30.0% | +31.7% | +41.9% | 17.0 |
| 50 | 新选组 | 0 | 不可违背武士道 | grade | D | D+ | B+ | 1.0 |
| 50 | 新选组 | 1 | 精华槽增加量 | numeric | +7.5% | +8.0% | +11.0% | 5.0 |

The live player snapshot identified 加藤, rank 宿老; computed protection values: -15.5% / -16.5%. This is native snapshot/control-flow validation, not screenshot acceptance.

Rebuild with the project Python runner and native-extraction/build_native_catalog.py. The JSON source manifest hashes every retained accepted source. validate_native_catalog.py verifies code byte/disassembly parity, key joins, rank boundaries and all exported values.
