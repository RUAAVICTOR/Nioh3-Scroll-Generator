"""Interpret hash-verified captures with the reusable native bonus-curve model."""
import argparse
import hashlib
import importlib.util
import json
import math
import struct
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from research.native_bonus_curve import NativeBonusCurve
from nioh3_scroll_editor.r4_finalizer_reference import f32,f32_mul
from nioh3_scroll_editor.r4_finalizer_resource import load_r4_finalizer_resource_for_version

spec=importlib.util.spec_from_file_location('player_resource_reference',ROOT/'deliverables/player-hp-ki-research-20261014/reference.py')
player_reference=importlib.util.module_from_spec(spec);spec.loader.exec_module(player_reference)
CLANS=ROOT/'apps/workshop/loadout-clans.json'


def analyze(capture_path):
    capture=json.loads((capture_path/'capture.json').read_text())
    if capture['status']!='complete_passive_tables':raise ValueError('Unqualified capture')
    blobs={blob['filename']:blob for blob in capture['blobs']}
    def verified(name):
        data=(capture_path/name).read_bytes();meta=blobs[name]
        if len(data)!=meta['size'] or hashlib.sha256(data).hexdigest()!=meta['sha256'].lower():raise ValueError('Blob mismatch')
        return data
    raw_rows=[]
    for row in capture['bonus_curve']['rows']:
        if not row['valid'] or 'duplicate_of' in row:raise ValueError('Ambiguous bonus vector entry')
        raw_rows.append(verified(row['blob']['filename']))
    curve=NativeBonusCurve(raw_rows)
    resource=load_r4_finalizer_resource_for_version((2,0,2,0))
    if len(raw_rows)!=resource.manifest['bonus_curve']['entry_count']:raise ValueError('Retained curve count mismatch')
    parity=all(raw==resource.bonus_curve_entry(i).row for i,raw in enumerate(raw_rows))
    if not parity:raise ValueError('Current native curves differ from retained version resource')
    chosen=[dict(index=i,raw_hex=raw.hex(),sha256=hashlib.sha256(raw).hexdigest(),point=row.point,
                 sample_count=row.sample_count,samples=row.samples)
            for i,(raw,row) in enumerate(zip(raw_rows,curve.rows)) if row.key==0xFA3E]
    if not chosen:raise ValueError('Missing requested curve')
    groups=next(t for t in capture['tables'] if t['name']=='effect_group')
    group_index=groups['native_keys']['0x5d3a']
    group_raw=verified('tables/effect_group/rows.bin')[8+group_index*0x70:8+(group_index+1)*0x70]
    clans_table=next(t for t in capture['tables'] if t['name']=='clan')
    clan_raw=verified('tables/clan/rows.bin')
    native_clans=[]
    for clan_id,index in clans_table['native_keys'].items():
        raw=clan_raw[8+index*0x98:8+(index+1)*0x98]
        for offset in (0x30,0x3C):
            group,base,growth=struct.unpack_from('<Iif',raw,offset)
            if group==0x5D3A:native_clans.append(dict(clan_id=int(clan_id,16),row_index=index,slot_offset=hex(offset),base=base,growth=growth,raw_hex=raw.hex()))
    catalog=json.loads(CLANS.read_text(encoding='utf-8'))
    named=next(g for g in catalog['effect_groups'] if g['id']==0x5D3A)
    if bytes.fromhex(named['raw_hex'])!=group_raw:raise ValueError('Group/name catalog row mismatch')
    for clan in native_clans:
        named_clan=next(c for c in catalog['clans'] if c['clan_id']==clan['clan_id'])
        if bytes.fromhex(named_clan['raw_hex'])!=bytes.fromhex(clan['raw_hex']):raise ValueError('Clan catalog/native row mismatch')
        clan['name_zh']=named_clan['name_zh']
    attributes,attribute_metadata=player_reference.load_table()
    labels=list(reversed(catalog['grade_labels_by_index']))
    grades=[]
    for selector,label in enumerate(labels):
        percent=curve.evaluate(0xFA3E,1,selector)
        factor=f32_mul(percent,f32(0.01))
        predictions=[]
        for stamina in (5,10,20,40,80,99,150,200):
            term=attributes[stamina][6]
            bonus=math.trunc(f32_mul(factor,term))
            predictions.append(dict(stamina=stamina,stamina_hp_term=term,extra_hp=bonus))
        grades.append(dict(selector=selector,label=label,native_curve_percent=percent,factor=factor,predictions=predictions))
    return dict(schema='nioh3-life-reflection-stamina-analysis/v1',identity=capture['identity'],
        effect_group=dict(id='0x5d3a',row_index=group_index,label_zh=named['label_zh'],flags50=group_raw[0x50],raw_hex=group_raw.hex()),
        native_curve=dict(key='0xfa3e',fixed_point_argument=1,rows=chosen),clans=native_clans,grades=grades,
        attribute_table_sha256=attribute_metadata['table_sha256'],
        checks=dict(current_bonus_vector_matches_shipped_resource=parity,group_name_row_matches=True,clan_name_rows_match=True),
        formula='extra_HP = trunc(f32(f32(curve(FA3E, point=1, grade_selector) * f32(0.01)) * T[clamp(effective_stamina)].u16(+0x0C)))',
        limitations=['Predictions use supplied effective Stamina and grade, not every active equipment/clan configuration.',
                     'This table analysis alone does not identify the current player grade or parenthetical UI value.',
                     'Clan names are joined to the earlier native localization export through exact row-byte parity.'])


def replay_live(analysis,directory):
    capture=json.loads((directory/'capture.json').read_text(encoding='utf-8'))
    if capture['status']!='complete_passive_snapshot' or capture['identity']!=analysis['identity']:
        raise ValueError('Live vector/table process identity mismatch')
    for blob in capture['blobs']:
        raw=(directory/blob['file']).read_bytes()
        if len(raw)!=blob['size'] or hashlib.sha256(raw).hexdigest()!=blob['sha256']:
            raise ValueError('Live blob digest mismatch')
    backing=(directory/'stat-backing.bin').read_bytes()
    style=capture['joined']['owner_style']
    list_offset=0x4728 if style==1 else 0x35D0
    count=struct.unpack_from('<I',backing,list_offset+0xC00)[0]
    if count>256:raise ValueError('Effect count outside native list capacity')
    entries=[]
    for i in range(count):
        offset=list_offset+i*12
        key=struct.unpack_from('<H',backing,offset)[0]
        value=struct.unpack_from('<i',backing,offset+4)[0]
        auxiliary=struct.unpack_from('<H',backing,offset+8)[0]
        entries.append(dict(key=key,value=value,auxiliary=auxiliary,offset=hex(offset)))
    matching=[entry for entry in entries if entry['key']==0x5D3A]
    if len(matching)!=1:raise ValueError('Active target effect is missing or ambiguous')
    entry=matching[0];selector=entry['value']+entry['auxiliary']
    grade=analysis['grades'][min(selector,17)]
    attrs=capture['joined']['effective_attributes'];stamina=attrs[2]
    table,_=player_reference.load_table()
    term=table[player_reference.lookup_index(stamina)][6]
    extra=math.trunc(f32_mul(grade['factor'],term))
    base=capture['base_replay']['base_hp']
    maximum=capture['candidate_outputs']['maximum_hp']
    if base+extra!=capture['joined']['selected_hp'] or maximum!=base+extra:
        raise ValueError('Native/owner HP does not match the effect replay')
    clan=analysis['clans'][0]
    bonus_selector=selector-clan['base']
    if not 0<=bonus_selector<len(analysis['grades']):raise ValueError('Unknown clan display bonus')
    return dict(source=str(directory),identity=capture['identity'],active_effect=entry,
        effective_grade_selector=selector,effective_grade_label=grade['label'],
        native_curve_percent=grade['native_curve_percent'],factor=grade['factor'],
        stamina=stamina,stamina_hp_term=term,base_hp=base,extra_hp=extra,
        selected_hp=capture['joined']['selected_hp'],maximum_hp=maximum,
        ui_decomposition=dict(base_selector=clan['base'],bonus_selector=bonus_selector,
            bonus_label=analysis['grades'][bonus_selector]['label'],total_label=grade['label']),
        evidence_grade='native-table plus active-effect and output snapshot parity; UI display formula recovered statically',
        limitations=['No breakpoint traced this individual application; the retained active list and final outputs are snapshots.',
                     'Parenthetical decomposition uses the native clan row and UI formatter; it is not a second HP factor.'])


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--capture',type=Path,default=HERE/'native-tables-01')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--live',type=Path)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    report=analyze(args.capture)
    if args.live:report['live_replay']=replay_live(report,args.live)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(curve=report['native_curve'],clans=[{k:c[k] for k in ('clan_id','name_zh','base','growth')} for c in report['clans']],
                         grades=[{k:g[k] for k in ('selector','label','native_curve_percent','factor')} for g in report['grades']]),ensure_ascii=False))


if __name__=='__main__':main()
