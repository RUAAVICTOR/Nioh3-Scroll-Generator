"""Native-table, live-snapshot and formatter anchors for the recovered effect."""
import hashlib
import importlib.util
import json
import struct
from pathlib import Path

from nioh3_scroll_editor.r4_finalizer_reference import f32_mul

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
spec=importlib.util.spec_from_file_location('life_reflection_analysis',HERE/'analyze_effect.py')
analysis=importlib.util.module_from_spec(spec);spec.loader.exec_module(analysis)


def report():
    return json.loads((HERE/'effect-analysis-with-live.json').read_text(encoding='utf-8'))


def test_native_grade_table_anchors_and_version_parity():
    data=report()
    assert data['checks']['current_bonus_vector_matches_shipped_resource'] is True
    assert [(g['selector'],g['label'],g['native_curve_percent']) for g in data['grades'] if g['selector'] in (1,7,8,17)]==[(1,'D',200),(7,'B',430),(8,'B+',450),(17,'AAA+',500)]
    assert [row['point'] for row in data['native_curve']['rows']]==[0,1]
    assert data['native_curve']['rows'][0]['samples']==data['native_curve']['rows'][1]['samples']


def test_positive_live_replay_includes_effect_grade_and_exact_hp():
    data=report()
    live=analysis.replay_live(data,HERE/'live-bplus-01')
    assert live['active_effect']['value']==8
    assert live['active_effect']['auxiliary']==0
    assert live['factor']==4.5
    assert (live['base_hp'],live['extra_hp'],live['maximum_hp'])==(880,135,1015)
    assert live['ui_decomposition']==dict(base_selector=1,bonus_selector=7,bonus_label='B',total_label='B+')


def test_negative_positive_vectors_share_inputs_and_have_no_double_bonus():
    before=ROOT/'deliverables/player-hp-ki-research-20261014/live-player-02'
    after=HERE/'live-bplus-01'
    negative=json.loads((before/'capture.json').read_text())
    positive=json.loads((after/'capture.json').read_text())
    assert negative['identity']==positive['identity']
    for key in ('effective_attributes','effective_level','backing_hp_bonus','hp_factors','ki_factor'):
        assert negative['joined'][key]==positive['joined'][key]
    assert negative['joined']['selected_hp']==880
    assert positive['joined']['selected_hp']==1015
    assert negative['joined']['selected_ki']==positive['joined']['selected_ki']==960
    raw=(before/'stat-backing.bin').read_bytes()
    count=struct.unpack_from('<I',raw,0x35D0+0xC00)[0]
    assert all(struct.unpack_from('<H',raw,0x35D0+i*12)[0]!=0x5D3A for i in range(count))


def test_float32_truncation_is_not_decimal_rounding():
    grades={g['label']:g for g in report()['grades']}
    assert int(f32_mul(grades['B']['factor'],30))==128
    assert int(f32_mul(grades['C+']['factor'],30))==110
    predictions=grades['B+']['predictions']
    assert [(p['stamina'],p['extra_hp']) for p in predictions if p['stamina'] in (5,40,99,200)]==[(5,135),(40,823),(99,1354),(200,2151)]


def test_native_ui_formatter_subtracts_base_from_total():
    evidence=json.loads((HERE/'clan-ui-instructions-01.json').read_text())
    native={int(i['rva'],16):i['bytes_hex'] for f in evidence['functions'] for i in f['instructions']}
    assert native[0x1DF6777]=='44 2B EB'  # bonus = total - base
    assert native[0x1DF677A]=='44 8B C8'  # first formatter gets total
    assert native[0x1DF6792]=='45 8B CD'  # second formatter gets bonus


def test_all_retained_instruction_bytes_match_hashed_decoded_source():
    source=ROOT/'deliverables/load-capacity-research/disassembly/live-sections/Nioh3_v2.0.2.0.text.bin'
    raw=source.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='4cec8fb6ad867417a76df8201c1d4f54172443884910463c1953acad91ae6c29'
    for name in ('native-instructions-01.json','effect-list-clan-instructions.json','clan-ui-instructions-01.json','clan-value-instructions.json'):
        evidence=json.loads((HERE/name).read_text())
        for function in evidence['functions']:
            for instruction in function['instructions']:
                expected=bytes.fromhex(instruction['bytes_hex']);offset=int(instruction['rva'],16)-0x1000
                assert raw[offset:offset+len(expected)]==expected


def test_rea_closed_and_analysis_source_immutable():
    for phase in (1,2):
        directory=HERE/f'rea-{phase:02d}'
        completion=json.loads((directory/'completion.json').read_text())
        assert completion['status']=='complete'
        assert completion['source_sha256_unchanged'] is True
        assert completion['cleanup_error'] is None
        events=json.loads((directory/'events.json').read_text())
        last=json.loads((directory/events[-1]['file']).read_text())
        assert last['structuredContent']['result']['open'] is False


def test_native_clan_row_proves_base_and_growth():
    clan=report()['clans'][0]
    assert (clan['clan_id'],clan['name_zh'],clan['base'],clan['growth'])==(26,'藤堂',1,1)
    raw=bytes.fromhex(clan['raw_hex'])
    assert struct.unpack_from('<Iif',raw,0x30)==(0x5D3A,1,1)
