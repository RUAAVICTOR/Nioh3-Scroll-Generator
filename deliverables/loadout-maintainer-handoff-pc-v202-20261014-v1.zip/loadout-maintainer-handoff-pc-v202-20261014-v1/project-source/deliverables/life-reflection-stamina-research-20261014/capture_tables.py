"""Read-only, bounded capture of the existing bonus-curve/group/clan table layouts.

Question: resolve effect 5D3A -> curve FA3E, its grade coefficients and clan row.
No debugger, game call, mutation, equipment injection or save access.
"""
import argparse
import hashlib
import json
import struct
import sys
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'deliverables/load-capacity-research/scripts')]
from scan_capacity import _identity
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from research.enemy_states_v201.capture_tables import BudgetReader, indexed_table
from research.dump_r4_finalizer_tables import CaptureWriter, capture_bonus_curve_table

EXPECTED_SHA='e22c4a635e4ec1e27a177b76e27d7f6a637f426c0ed3928b60f5693bc52ae130'


class Reader(BudgetReader):
    def u64(self,address):return self.qword(address)
    def u32(self,address):return struct.unpack('<I',self.read(address,4))[0]
    def u16(self,address):return struct.unpack('<H',self.read(address,2))[0]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    writer=CaptureWriter(args.output)
    report=dict(schema='nioh3-life-reflection-stamina-table-capture/v1',status='partial',
        at_utc=datetime.now(timezone.utc).isoformat(),
        question='Recover coefficient samples for native effect 5D3A / curve FA3E and its native clan association',
        bounds=dict(max_requested_bytes=8*1024*1024,max_seconds=20),
        game_writes=0,game_function_calls=0,save_access=False,debugger_used=False,tables=[])
    try:
        with ProcessReader() as process:
            identity=_identity(process);report['identity']=identity
            if identity['executable_sha256']!=EXPECTED_SHA:raise ValueError('Unsupported executable')
            reader=Reader(process,max_bytes=8*1024*1024,max_seconds=20)
            text=(ROOT/'deliverables/load-capacity-research/disassembly/live-sections/Nioh3_v2.0.2.0.text.bin').read_bytes()
            if hashlib.sha256(text).hexdigest()!='4cec8fb6ad867417a76df8201c1d4f54172443884910463c1953acad91ae6c29':
                raise ValueError('Retained code mismatch')
            report['signatures']=[]
            for rva in (0x81C77C,0x81C7A6,0x2FA678,0x2FA7E0,0x558C50):
                expected=text[rva-0x1000:rva-0x1000+16]
                actual=reader.read(process.module_base+rva,16)
                report['signatures'].append(dict(rva=hex(rva),expected=expected.hex(),actual=actual.hex()))
                if expected!=actual:raise ValueError('Native signature mismatch')
            manager=reader.u64(process.module_base+0x45B9E30)
            report['manager']=hex(manager)
            bonus_context=reader.u64(manager+0x718)
            report['bonus_curve']=capture_bonus_curve_table(reader,writer,manager)
            contexts={}
            for name,offset,stride,width,cap in (('effect_group',0xA8,0x70,2,8192),('clan',0x758,0x98,4,256)):
                context=reader.u64(manager+offset);contexts[offset]=context
                table=indexed_table(reader,context,stride,width,cap=cap)
                addresses=dict(rows=struct.unpack_from('<Q',table['context'])[0],context=context,
                    hash_context=struct.unpack_from('<Q',table['context'],0x20)[0],
                    hash_entries=struct.unpack_from('<Q',table['hash_context'],8)[0])
                for label,address in addresses.items():
                    writer.blob(f'tables/{name}/{label}.bin',address,table[label])
                report['tables'].append(dict(name=name,manager_offset=hex(offset),row_count=table['count'],
                    row_stride=stride,native_keys={hex(key):index for key,index in table['mapping'].items()}))
            for blob in writer.blobs:
                if reader.read(int(blob.address,16),blob.size)!=(args.output/blob.filename).read_bytes():
                    raise ValueError('Captured table bytes changed')
            if process.creation_time()!=identity['process_birth_filetime'] or reader.u64(process.module_base+0x45B9E30)!=manager:
                raise ValueError('Process or manager changed')
            if reader.u64(manager+0x718)!=bonus_context or any(reader.u64(manager+offset)!=context for offset,context in contexts.items()):
                raise ValueError('Table ownership changed')
            report['status']='complete_passive_tables';report['remaining_bytes']=reader.remaining
    except Exception as error:
        report['status']='failed_closed';report['error']=dict(type=type(error).__name__,message=str(error))
    finally:
        report['blobs']=[asdict(blob) for blob in writer.blobs]
        report['cleanup']='Read-only process handle closed; no debugger, timers, breakpoints or writes created'
        (args.output/'capture.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],identity=report.get('identity'),error=report.get('error'),
                         bonus_rows=report.get('bonus_curve',{}).get('pointer_count'),tables=report['tables'] if report['status']!='complete_passive_tables' else [{k:t[k] for k in ('name','row_count')} for t in report['tables']])))
    if report['status']!='complete_passive_tables':raise SystemExit(1)


if __name__=='__main__':main()
