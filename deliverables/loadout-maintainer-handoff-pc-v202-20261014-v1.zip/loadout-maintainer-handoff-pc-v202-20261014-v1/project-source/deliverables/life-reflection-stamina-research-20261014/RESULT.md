# Life Reflection (Stamina): PC v2.02, 2026-10-14

Native effect group `0x5D3A` (对体力的反映（刚）) adds HP from the **effective
Stamina contribution column**, scaled by the effect's effective letter grade.
For the owner's B+ control, the coefficient is exactly 450% and the Stamina-5
contribution is 30: extra HP is 135, reproducing `880 + 135 = 1015`.

The screenshot's **B+(B)** means **effective total grade (rank-growth bonus
grade)**. The native clan row has base selector 1, the growth bonus is selector
7, and the total is selector 8. Those format as D, B, and B+, respectively.
Only selector 8 is sent to the HP calculation. The parenthetical B is not a
second multiplier.

The native table and owner's screenshot both identify the clan as **Todo
(藤堂), clan ID 26**, rather than the earlier owner-reported Kato name. Exact
native row-byte joins establish the association; no community guide was used.

## Scope and evidence

Executable `2.0.2.0`, SHA-256
`e22c4a635e4ec1e27a177b76e27d7f6a637f426c0ed3928b60f5693bc52ae130`.
Fresh table and positive snapshots were captured in PID 588752, process-birth
FILETIME `134364438863095000`, module base `7FF630AA0000`. The prior negative
snapshot is from the same process. All reads used query/read process rights;
there were no debugger breakpoints, hooks, game calls, memory writes or save
access by the agent. The owner changed the clan/effect through the game UI.

Evidence grades: `native-control-flow` for the recovered consumers and UI
formatter, `native-table` for coefficients and clan records, and `observed`
for the active effect/output snapshots and owner UI. The positive calculation
matches the captured selected stat and final maximum; no breakpoint traced
this particular rebuild invocation.

## Calculation and ordering

The dispatcher `819400` reads effective Stamina at backing-object `+34+8`,
interprets it as signed i32 and clamps it to `1..999`. It looks up the same
attribute-table `u16(+0C)` column used by ordinary player base HP. The formula
at `81C78F..81C7C3` is:

```text
term = attribute_table[clamp(effective_Stamina, 1, 999)].u16(+0x0C)
percent = bonus_curve(key=0xFA3E, point=1, selector=effective_effect_grade)
extra_HP = trunc(f32(f32(percent * f32(0.01)) * f32(term)))
derived_HP += extra_HP
```

The curve point argument is the constant **1**, not player level or Stamina.
Stamina affects `term`, while the grade selects the curve sample. The two
FA3E rows at points 0 and 1 have identical 18 samples, so they introduce no
level-dependent scaling on this path.

This adds to derived HP after the ordinary base/context stage. It does not
multiply total base HP, and it does not directly change Ki. The later fixed
backing-object HP bonus and shared final actor HP stage still exist; scenario
modifiers must be qualified separately when predicting another configuration.

The captured Stamina-contribution column is a stepped table. It reaches 478 at
row 200 and is unchanged through row 999. That is a native-table plateau; no
out-of-playable-range character is asserted. Effective Stamina may differ from
allocated menu Stamina under a level-adjustment branch.

## Grade coefficients

The exact FA3E samples are recovered, with the grade labels joined to the
earlier native display catalog and confirmed for the owner's B+ snapshot.
The full 18-grade table is in `effect-analysis-with-live.json`.

| Grade | Raw selector | Curve value / nominal coefficient |
| --- | ---: | ---: |
| D- | 0 | 150% |
| D | 1 | 200% |
| D+ | 2 | 250% |
| C- | 3 | 290% |
| C | 4 | 330% |
| C+ | 5 | 370% |
| B- | 6 | 400% |
| B | 7 | 430% |
| B+ | 8 | 450% |
| A- | 9 | 460% |
| A | 10 | 465% |
| A+ | 11 | 470% |
| AA- | 12 | 475% |
| AA | 13 | 480% |
| AA+ | 14 | 485% |
| AAA- | 15 | 490% |
| AAA | 16 | 495% |
| AAA+ | 17 | 500% |

These are native sample slots, not proof that every slot is obtainable from
this clan. The clan's recovered base/growth formula caps its growth step at 7,
giving selector 8 / B+ for this slot at the cap.

Each multiply uses float32 and the final conversion truncates. Nominal decimal
arithmetic can differ by one HP: at Stamina 5, B's native sequence produces
128 rather than the decimal `30 * 4.3 = 129`; C+ produces 110 rather than 111.
B+'s coefficient 4.5 is exactly representable and does not have that ambiguity.

| Effective Stamina | Table contribution | Extra HP at B+ |
| ---: | ---: | ---: |
| 5 | 30 | 135 — live/UI control |
| 10 | 90 | 405 — table prediction |
| 20 | 130 | 585 — table prediction |
| 40 | 183 | 823 — table prediction |
| 80 | 263 | 1183 — table prediction |
| 99 | 301 | 1354 — table prediction |
| 150 | 403 | 1813 — table prediction |
| 200 | 478 | 2151 — table prediction |

These cells are the effect's extra HP only. Changing a character's Stamina
normally also changes ordinary base HP and character level; those changes are
not included in the effect-only column.

## Why B+(B) appears

Fresh native clan row 26, slot `+30`, gives effect ID `5D3A`, base raw value 1
and growth float32 1. `220DA9C` returns the base. `220D9EC` obtains the clan's
rank index, adds one when the clan is joined, caps that step at 7, multiplies
the slot's growth value, truncates, then adds the base:

```text
total = base + trunc(f32(min(clan_rank_index + is_joined, 7) * growth))
```

The UI at `1DF675D..1DF67BD` calls the base and total getters, subtracts base
from total at `1DF6777`, formats **total** first, and formats **total - base**
as the parenthetical contribution. The generic letter formatter selects its
grade branch when effect-group flags `+50` include bit 4; this effect's flags
are 7. The owner's screenshot shows Todo, rank 宿老, and B+(B), matching the
native decomposition `1 + 7 = 8`.

This is a display decomposition of raw grade indices. Letter grades are not
percentages to add or multiply, and the parenthetical B does not mean using
the B coefficient 430% alongside B+'s 450%.

## Positive/negative reconstruction

The prior `player-hp-ki-research-20261014/live-player-02` negative snapshot
contains no `5D3A` in the active style's effect list; selected and maximum HP
are 880, and Ki is 960.

After the owner restored the effect, `live-bplus-01` has the same allocated
and effective attributes `[5,5,5,6,5,5,5]`, effective level 1, zero backing HP
bonus, unit captured final HP factors and the same selected external stat.
The active effect entry at backing `+3618` contains ID `5D3A`, base value 8 and
auxiliary value 0. The native rebuild passes the entry's base plus auxiliary
value to the dispatcher, therefore the effective selector is 8.

```text
base_HP = 780(level 1) + 70(Constitution 5) + 30(Stamina 5) = 880
effect_HP = trunc(450% * 30) = 135
selected_HP = maximum_HP = 1015
maximum_Ki = 960, unchanged
```

The actor/status backlink, player vector, selected-object pointer and native
table hash passed revalidation. The two states are owner-operated clan changes,
not a script-controlled single-effect injection. Other active-effect changes
from switching clans are not claimed absent, but the selected HP difference
and the target effect's native calculation agree exactly in these snapshots.

Duplicate-source aggregation has a separate native path: effect-group bit 4
causes `557BA0` to keep the larger base parameter and increment an auxiliary
counter for an existing effect. Rebuild applies base plus auxiliary. The
observed entry's auxiliary counter is zero; no multiple-source live control or
universal stacking rule is claimed here.

## Files, reuse, checks and limits

- `native-tables-01/`: fresh full 662-entry bonus vector, 1152 effect-group rows
  and 51 clan rows, raw blobs, hashes, code signatures and cleanup metadata.
  All bonus-vector rows match the shipped version resource byte-for-byte.
- `live-bplus-01/`: positive player/selected-stat/backing/output/table snapshot.
  `effect-analysis-with-live.json` checks raw hashes and reconstructs the effect.
- `owner-bplus-parenthetical-b.png`: unchanged owner screenshot; SHA-256
  `ef8947fa5107a503dd048f0caa09cc2077abdb8f0d035229c84b34a1d64214b7`.
- `rea-01/` and `rea-02/`: actual REA 6.4.0 / Ghidra 12.1.4 evidence, plans,
  seeds and closure proofs. Both sessions closed, source carrier hashes remained
  unchanged, and no target game was executed by REA.
- Four native instruction inventories are independently byte-checked against
  the hash-verified decoded `.text`. Decompiler return types for the XMM0 curve
  helper were inaccurate; the recovered float-return semantics use the native
  `movss xmm0` and consumer instructions.
- `research/native_bonus_curve.py`: reusable file-backed 0x58-byte bonus-row
  selection, signed-point lower-bound interpolation, sample saturation and
  exact float32 operations. It contains no effect IDs, manager addresses,
  process access or product changes. Validated scope is this PC v2.02 layout;
  callers must verify table/executable provenance. Example:
  `NativeBonusCurve(raw_rows).evaluate(key, signed_point, selector)`.
- Existing capture writer, bonus-table collector, indexed table reader,
  bounded reader, player capture, REA launcher/carrier builder and shared
  float32 operations were reused. No duplicate debugger framework was added.
- Fourteen focused reference/evidence tests passed. They cover native anchors,
  two-state output parity, float32 truncation, UI total-minus-base formatting,
  reusable interpolation/duplicates/saturation and both REA closures.

Initial offline analysis refused the native vector because it contains one
duplicate key/point for unrelated key `4525`. Inspection of native `D248F0`
proved lower-bound ordering defines duplicate selection; the reusable helper
now preserves that ordering, with a focused test. The diagnostic is retained
in `curve-vector-order-diagnostic.json`. A subsequent Windows default-encoding
failure was repaired with explicit UTF-8 reads; `effect-analysis-02.log`
retains its raw traceback. Neither failure involved a game mutation.

Completion is the B+ live reconstruction, the recovered full coefficient table,
the native UI explanation and reusable offline evaluator. Other Stamina/grade
cells remain conditional table predictions; active level adjustment, other
scenario corrections and multiple-source stacking are not new live acceptance.
No product behavior, release setting, save, formal knowledge record or Git
commit was changed by this research.

Run Python through `tools/run_python_tests.ps1`, using the prepared
`D:/Nioh3_v080_deliverables/ce-research-env/Scripts/python.exe`. For example:

```powershell
& tools/run_python_tests.ps1 -Python D:/Nioh3_v080_deliverables/ce-research-env/Scripts/python.exe -TestPath @('tests/test_native_bonus_curve.py','deliverables/life-reflection-stamina-research-20261014/test_effect.py') -PytestArgument @('-q')
& tools/run_python_tests.ps1 -Python D:/Nioh3_v080_deliverables/ce-research-env/Scripts/python.exe -ScriptPath deliverables/life-reflection-stamina-research-20261014/analyze_effect.py -ScriptArgument @('--live','deliverables/life-reflection-stamina-research-20261014/live-bplus-01','--output','D:/Nioh3_v080_deliverables/deliverables/life-reflection-replay.json')
```

Output paths must be fresh. Captures and decoded code remain local.
