0x3FA060 40 53 push rbx
0x3FA062 48 83 EC 20 sub rsp, 0x20
0x3FA066 0F B7 D9 movzx ebx, cx
0x3FA069 0F B7 D1 movzx edx, cx
0x3FA06C 48 8B 0D BD FD 1B 04 mov rcx, qword ptr [rip + 0x41bfdbd]
0x3FA073 48 8B 89 A8 00 00 00 mov rcx, qword ptr [rcx + 0xa8]
0x3FA07A E8 D1 EB 15 00 call 0x558c50
0x3FA07F 45 33 C0 xor r8d, r8d
0x3FA082 48 85 C0 test rax, rax
0x3FA085 74 23 je 0x3fa0aa
0x3FA087 48 8B 05 D2 77 35 04 mov rax, qword ptr [rip + 0x43577d2]
0x3FA08E 48 8B 10 mov rdx, qword ptr [rax]
0x3FA091 48 81 C2 40 63 00 00 add rdx, 0x6340
0x3FA098 66 39 1A cmp word ptr [rdx], bx
0x3FA09B 74 15 je 0x3fa0b2
0x3FA09D 41 FF C0 inc r8d
0x3FA0A0 48 83 C2 10 add rdx, 0x10
0x3FA0A4 41 83 F8 04 cmp r8d, 4
0x3FA0A8 72 EE jb 0x3fa098
0x3FA0AA 33 C0 xor eax, eax
0x3FA0AC 48 83 C4 20 add rsp, 0x20
0x3FA0B0 5B pop rbx
0x3FA0B1 C3 ret 
0x3FA0B2 8B 42 04 mov eax, dword ptr [rdx + 4]
0x3FA0B5 EB F5 jmp 0x3fa0ac
