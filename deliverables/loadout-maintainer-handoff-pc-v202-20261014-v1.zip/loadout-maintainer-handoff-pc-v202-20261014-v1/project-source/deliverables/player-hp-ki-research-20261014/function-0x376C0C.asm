0x376C0C 83 E9 02 sub ecx, 2
0x376C0F 74 32 je 0x376c43
0x376C11 83 E9 01 sub ecx, 1
0x376C14 74 1D je 0x376c33
0x376C16 83 F9 01 cmp ecx, 1
0x376C19 75 1F jne 0x376c3a
0x376C1B BA 97 D3 00 00 mov edx, 0xd397
0x376C20 48 8B 0D 09 32 24 04 mov rcx, qword ptr [rip + 0x4243209]
0x376C27 48 8B 89 30 02 00 00 mov rcx, qword ptr [rcx + 0x230]
0x376C2E E9 D5 18 29 00 jmp 0x608508
0x376C33 BA 67 7C 00 00 mov edx, 0x7c67
0x376C38 EB E6 jmp 0x376c20
0x376C3A F3 0F 10 05 9E D5 85 03 movss xmm0, dword ptr [rip + 0x385d59e]
0x376C42 C3 ret 
