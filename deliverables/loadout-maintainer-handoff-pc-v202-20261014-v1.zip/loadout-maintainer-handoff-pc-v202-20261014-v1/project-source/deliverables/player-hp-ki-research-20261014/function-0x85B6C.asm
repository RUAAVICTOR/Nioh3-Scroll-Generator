0x85B6C 48 8B 81 90 2D 00 00 mov rax, qword ptr [rcx + 0x2d90]
0x85B73 48 85 C0 test rax, rax
0x85B76 75 07 jne 0x85b7f
0x85B78 48 8D 81 A8 25 00 00 lea rax, [rcx + 0x25a8]
0x85B7F C3 ret 
