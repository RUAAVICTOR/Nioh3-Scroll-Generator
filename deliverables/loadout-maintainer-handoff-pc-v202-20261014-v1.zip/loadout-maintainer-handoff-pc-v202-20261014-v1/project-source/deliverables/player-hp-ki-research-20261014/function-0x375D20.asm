0x375D20 48 89 4C 24 08 mov qword ptr [rsp + 8], rcx
0x375D25 55 push rbp
0x375D26 53 push rbx
0x375D27 56 push rsi
0x375D28 57 push rdi
0x375D29 41 54 push r12
0x375D2B 41 55 push r13
0x375D2D 41 56 push r14
0x375D2F 41 57 push r15
0x375D31 48 8B EC mov rbp, rsp
0x375D34 48 83 EC 68 sub rsp, 0x68
0x375D38 48 8B 05 F1 40 24 04 mov rax, qword ptr [rip + 0x42440f1]
0x375D3F 48 8B FA mov rdi, rdx
0x375D42 8B 92 E4 00 00 00 mov edx, dword ptr [rdx + 0xe4]
0x375D48 48 8B F1 mov rsi, rcx
0x375D4B 48 8B 98 00 02 00 00 mov rbx, qword ptr [rax + 0x200]
0x375D52 48 8B CB mov rcx, rbx
0x375D55 E8 26 04 00 00 call 0x376180
0x375D5A 8B 97 E8 00 00 00 mov edx, dword ptr [rdi + 0xe8]
0x375D60 48 8B CB mov rcx, rbx
0x375D63 48 89 45 50 mov qword ptr [rbp + 0x50], rax
0x375D67 E8 14 04 00 00 call 0x376180
0x375D6C 8B 97 EC 00 00 00 mov edx, dword ptr [rdi + 0xec]
0x375D72 48 8B CB mov rcx, rbx
0x375D75 4C 8B F0 mov r14, rax
0x375D78 E8 03 04 00 00 call 0x376180
0x375D7D 8B 97 F0 00 00 00 mov edx, dword ptr [rdi + 0xf0]
0x375D83 48 8B CB mov rcx, rbx
0x375D86 4C 8B F8 mov r15, rax
0x375D89 E8 F2 03 00 00 call 0x376180
0x375D8E 8B 97 F4 00 00 00 mov edx, dword ptr [rdi + 0xf4]
0x375D94 48 8B CB mov rcx, rbx
0x375D97 4C 8B E0 mov r12, rax
0x375D9A E8 E1 03 00 00 call 0x376180
0x375D9F 8B 97 F8 00 00 00 mov edx, dword ptr [rdi + 0xf8]
0x375DA5 48 8B CB mov rcx, rbx
0x375DA8 4C 8B E8 mov r13, rax
0x375DAB E8 D0 03 00 00 call 0x376180
0x375DB0 8B 97 FC 00 00 00 mov edx, dword ptr [rdi + 0xfc]
0x375DB6 48 8B CB mov rcx, rbx
0x375DB9 48 89 45 C8 mov qword ptr [rbp - 0x38], rax
0x375DBD E8 BE 03 00 00 call 0x376180
0x375DC2 8B 97 00 01 00 00 mov edx, dword ptr [rdi + 0x100]
0x375DC8 48 8B CB mov rcx, rbx
0x375DCB 48 89 45 D0 mov qword ptr [rbp - 0x30], rax
0x375DCF E8 AC 03 00 00 call 0x376180
0x375DD4 8B 97 04 01 00 00 mov edx, dword ptr [rdi + 0x104]
0x375DDA 48 8B CB mov rcx, rbx
0x375DDD 48 89 45 58 mov qword ptr [rbp + 0x58], rax
0x375DE1 E8 9A 03 00 00 call 0x376180
0x375DE6 8B 97 08 01 00 00 mov edx, dword ptr [rdi + 0x108]
0x375DEC 48 8B CB mov rcx, rbx
0x375DEF 48 89 45 60 mov qword ptr [rbp + 0x60], rax
0x375DF3 E8 88 03 00 00 call 0x376180
0x375DF8 8B 97 0C 01 00 00 mov edx, dword ptr [rdi + 0x10c]
0x375DFE 48 8B CB mov rcx, rbx
0x375E01 48 89 45 B8 mov qword ptr [rbp - 0x48], rax
0x375E05 E8 76 03 00 00 call 0x376180
0x375E0A 8B 97 E0 00 00 00 mov edx, dword ptr [rdi + 0xe0]
0x375E10 48 8B CB mov rcx, rbx
0x375E13 48 89 45 C0 mov qword ptr [rbp - 0x40], rax
0x375E17 E8 64 03 00 00 call 0x376180
0x375E1C 45 33 D2 xor r10d, r10d
0x375E1F 4C 8B C0 mov r8, rax
0x375E22 4C 39 55 50 cmp qword ptr [rbp + 0x50], r10
0x375E26 0F 84 04 03 00 00 je 0x376130
0x375E2C 4D 85 F6 test r14, r14
0x375E2F 0F 84 FB 02 00 00 je 0x376130
0x375E35 4D 85 FF test r15, r15
0x375E38 0F 84 F2 02 00 00 je 0x376130
0x375E3E 4D 85 E4 test r12, r12
0x375E41 0F 84 E9 02 00 00 je 0x376130
0x375E47 4D 85 ED test r13, r13
0x375E4A 0F 84 E0 02 00 00 je 0x376130
0x375E50 48 8B 5D C8 mov rbx, qword ptr [rbp - 0x38]
0x375E54 48 85 DB test rbx, rbx
0x375E57 0F 84 D3 02 00 00 je 0x376130
0x375E5D 48 8B 7D D0 mov rdi, qword ptr [rbp - 0x30]
0x375E61 48 85 FF test rdi, rdi
0x375E64 0F 84 C6 02 00 00 je 0x376130
0x375E6A 4C 39 55 58 cmp qword ptr [rbp + 0x58], r10
0x375E6E 0F 84 BC 02 00 00 je 0x376130
0x375E74 4C 39 55 60 cmp qword ptr [rbp + 0x60], r10
0x375E78 0F 84 B2 02 00 00 je 0x376130
0x375E7E 4C 39 55 B8 cmp qword ptr [rbp - 0x48], r10
0x375E82 0F 84 A8 02 00 00 je 0x376130
0x375E88 4C 39 55 C0 cmp qword ptr [rbp - 0x40], r10
0x375E8C 0F 84 9E 02 00 00 je 0x376130
0x375E92 48 8B 05 37 B6 3D 04 mov rax, qword ptr [rip + 0x43db637]
0x375E99 45 8B CA mov r9d, r10d
0x375E9C 48 8B 48 08 mov rcx, qword ptr [rax + 8]
0x375EA0 0F B6 51 10 movzx edx, byte ptr [rcx + 0x10]
0x375EA4 83 EA 01 sub edx, 1
0x375EA7 74 24 je 0x375ecd
0x375EA9 83 EA 01 sub edx, 1
0x375EAC 74 11 je 0x375ebf
0x375EAE 83 FA 01 cmp edx, 1
0x375EB1 75 1A jne 0x375ecd
0x375EB3 F3 41 0F 10 40 64 movss xmm0, dword ptr [r8 + 0x64]
0x375EB9 45 8D 4A 02 lea r9d, [r10 + 2]
0x375EBD EB 14 jmp 0x375ed3
0x375EBF F3 41 0F 10 40 60 movss xmm0, dword ptr [r8 + 0x60]
0x375EC5 41 B9 01 00 00 00 mov r9d, 1
0x375ECB EB 06 jmp 0x375ed3
0x375ECD F3 41 0F 10 40 5C movss xmm0, dword ptr [r8 + 0x5c]
0x375ED3 F3 0F 2C C0 cvttss2si eax, xmm0
0x375ED7 45 8B DA mov r11d, r10d
0x375EDA 4C 8D 96 24 02 00 00 lea r10, [rsi + 0x224]
0x375EE1 66 01 86 1C 02 00 00 add word ptr [rsi + 0x21c], ax
0x375EE8 48 8B 75 58 mov rsi, qword ptr [rbp + 0x58]
0x375EEC 41 83 FB 09 cmp r11d, 9
0x375EF0 77 5C ja 0x375f4e
0x375EF2 74 54 je 0x375f48
0x375EF4 41 8B CB mov ecx, r11d
0x375EF7 45 85 DB test r11d, r11d
0x375EFA 74 46 je 0x375f42
0x375EFC 83 E9 01 sub ecx, 1
0x375EFF 74 3C je 0x375f3d
0x375F01 83 E9 01 sub ecx, 1
0x375F04 74 32 je 0x375f38
0x375F06 83 E9 01 sub ecx, 1
0x375F09 74 28 je 0x375f33
0x375F0B 83 E9 01 sub ecx, 1
0x375F0E 74 1E je 0x375f2e
0x375F10 83 E9 01 sub ecx, 1
0x375F13 74 14 je 0x375f29
0x375F15 83 E9 01 sub ecx, 1
0x375F18 74 0A je 0x375f24
0x375F1A 83 F9 01 cmp ecx, 1
0x375F1D 75 59 jne 0x375f78
0x375F1F 48 8B CE mov rcx, rsi
0x375F22 EB 58 jmp 0x375f7c
0x375F24 48 8B CF mov rcx, rdi
0x375F27 EB 53 jmp 0x375f7c
0x375F29 48 8B CB mov rcx, rbx
0x375F2C EB 4E jmp 0x375f7c
0x375F2E 49 8B CD mov rcx, r13
0x375F31 EB 49 jmp 0x375f7c
0x375F33 49 8B CC mov rcx, r12
0x375F36 EB 44 jmp 0x375f7c
0x375F38 49 8B CF mov rcx, r15
0x375F3B EB 3F jmp 0x375f7c
0x375F3D 49 8B CE mov rcx, r14
0x375F40 EB 3A jmp 0x375f7c
0x375F42 48 8B 4D 50 mov rcx, qword ptr [rbp + 0x50]
0x375F46 EB 34 jmp 0x375f7c
0x375F48 48 8B 4D 60 mov rcx, qword ptr [rbp + 0x60]
0x375F4C EB 2E jmp 0x375f7c
0x375F4E 41 8B CB mov ecx, r11d
0x375F51 83 E9 0A sub ecx, 0xa
0x375F54 74 22 je 0x375f78
0x375F56 83 E9 01 sub ecx, 1
0x375F59 74 1D je 0x375f78
0x375F5B 83 E9 01 sub ecx, 1
0x375F5E 74 18 je 0x375f78
0x375F60 83 E9 01 sub ecx, 1
0x375F63 74 13 je 0x375f78
0x375F65 83 E9 01 sub ecx, 1
0x375F68 74 0E je 0x375f78
0x375F6A 83 E9 01 sub ecx, 1
0x375F6D 74 09 je 0x375f78
0x375F6F 83 F9 02 cmp ecx, 2
0x375F72 48 8B 4D B8 mov rcx, qword ptr [rbp - 0x48]
0x375F76 74 04 je 0x375f7c
0x375F78 48 8B 4D C0 mov rcx, qword ptr [rbp - 0x40]
0x375F7C 45 8B C1 mov r8d, r9d
0x375F7F 48 8D 55 D8 lea rdx, [rbp - 0x28]
0x375F83 E8 BC 01 00 00 call 0x376144
0x375F88 41 FF C3 inc r11d
0x375F8B 0F 10 00 movups xmm0, xmmword ptr [rax]
0x375F8E 41 0F 11 02 movups xmmword ptr [r10], xmm0
0x375F92 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x375F96 41 0F 11 4A 10 movups xmmword ptr [r10 + 0x10], xmm1
0x375F9B 49 83 C2 20 add r10, 0x20
0x375F9F 41 83 FB 15 cmp r11d, 0x15
0x375FA3 0F 8C 43 FF FF FF jl 0x375eec
0x375FA9 48 8B 4D 48 mov rcx, qword ptr [rbp + 0x48]
0x375FAD 45 33 C0 xor r8d, r8d
0x375FB0 48 81 C1 C4 04 00 00 add rcx, 0x4c4
0x375FB7 41 8B D0 mov edx, r8d
0x375FBA 45 85 C0 test r8d, r8d
0x375FBD 0F 84 1E 01 00 00 je 0x3760e1
0x375FC3 83 EA 01 sub edx, 1
0x375FC6 0F 84 EB 00 00 00 je 0x3760b7
0x375FCC 83 EA 01 sub edx, 1
0x375FCF 0F 84 B8 00 00 00 je 0x37608d
0x375FD5 83 EA 01 sub edx, 1
0x375FD8 74 79 je 0x376053
0x375FDA 83 EA 01 sub edx, 1
0x375FDD 74 3D je 0x37601c
0x375FDF 83 FA 01 cmp edx, 1
0x375FE2 0F 85 37 01 00 00 jne 0x37611f
0x375FE8 41 8B D1 mov edx, r9d
0x375FEB 45 85 C9 test r9d, r9d
0x375FEE 74 22 je 0x376012
0x375FF0 83 EA 01 sub edx, 1
0x375FF3 74 13 je 0x376008
0x375FF5 83 FA 01 cmp edx, 1
0x375FF8 0F 85 F5 00 00 00 jne 0x3760f3
0x375FFE F3 0F 10 43 64 movss xmm0, dword ptr [rbx + 0x64]
0x376003 E9 0F 01 00 00 jmp 0x376117
0x376008 F3 0F 10 43 60 movss xmm0, dword ptr [rbx + 0x60]
0x37600D E9 05 01 00 00 jmp 0x376117
0x376012 F3 0F 10 43 5C movss xmm0, dword ptr [rbx + 0x5c]
0x376017 E9 FB 00 00 00 jmp 0x376117
0x37601C 41 8B D1 mov edx, r9d
0x37601F 45 85 C9 test r9d, r9d
0x376022 74 24 je 0x376048
0x376024 83 EA 01 sub edx, 1
0x376027 74 14 je 0x37603d
0x376029 83 FA 01 cmp edx, 1
0x37602C 0F 85 C1 00 00 00 jne 0x3760f3
0x376032 F3 41 0F 10 45 64 movss xmm0, dword ptr [r13 + 0x64]
0x376038 E9 DA 00 00 00 jmp 0x376117
0x37603D F3 41 0F 10 45 60 movss xmm0, dword ptr [r13 + 0x60]
0x376043 E9 CF 00 00 00 jmp 0x376117
0x376048 F3 41 0F 10 45 5C movss xmm0, dword ptr [r13 + 0x5c]
0x37604E E9 C4 00 00 00 jmp 0x376117
0x376053 41 8B D1 mov edx, r9d
0x376056 45 85 C9 test r9d, r9d
0x376059 74 26 je 0x376081
0x37605B 83 EA 01 sub edx, 1
0x37605E 74 15 je 0x376075
0x376060 83 FA 01 cmp edx, 1
0x376063 0F 85 8A 00 00 00 jne 0x3760f3
0x376069 F3 41 0F 10 44 24 64 movss xmm0, dword ptr [r12 + 0x64]
0x376070 E9 A2 00 00 00 jmp 0x376117
0x376075 F3 41 0F 10 44 24 60 movss xmm0, dword ptr [r12 + 0x60]
0x37607C E9 96 00 00 00 jmp 0x376117
0x376081 F3 41 0F 10 44 24 5C movss xmm0, dword ptr [r12 + 0x5c]
0x376088 E9 8A 00 00 00 jmp 0x376117
0x37608D 41 8B D1 mov edx, r9d
0x376090 45 85 C9 test r9d, r9d
0x376093 74 1A je 0x3760af
0x376095 83 EA 01 sub edx, 1
0x376098 74 0D je 0x3760a7
0x37609A 83 FA 01 cmp edx, 1
0x37609D 75 54 jne 0x3760f3
0x37609F F3 41 0F 10 47 64 movss xmm0, dword ptr [r15 + 0x64]
0x3760A5 EB 70 jmp 0x376117
0x3760A7 F3 41 0F 10 47 60 movss xmm0, dword ptr [r15 + 0x60]
0x3760AD EB 68 jmp 0x376117
0x3760AF F3 41 0F 10 47 5C movss xmm0, dword ptr [r15 + 0x5c]
0x3760B5 EB 60 jmp 0x376117
0x3760B7 41 8B D1 mov edx, r9d
0x3760BA 45 85 C9 test r9d, r9d
0x3760BD 74 1A je 0x3760d9
0x3760BF 83 EA 01 sub edx, 1
0x3760C2 74 0D je 0x3760d1
0x3760C4 83 FA 01 cmp edx, 1
0x3760C7 75 2A jne 0x3760f3
0x3760C9 F3 41 0F 10 46 64 movss xmm0, dword ptr [r14 + 0x64]
0x3760CF EB 46 jmp 0x376117
0x3760D1 F3 41 0F 10 46 60 movss xmm0, dword ptr [r14 + 0x60]
0x3760D7 EB 3E jmp 0x376117
0x3760D9 F3 41 0F 10 46 5C movss xmm0, dword ptr [r14 + 0x5c]
0x3760DF EB 36 jmp 0x376117
0x3760E1 41 8B D1 mov edx, r9d
0x3760E4 45 85 C9 test r9d, r9d
0x3760E7 74 25 je 0x37610e
0x3760E9 83 EA 01 sub edx, 1
0x3760EC 74 15 je 0x376103
0x3760EE 83 FA 01 cmp edx, 1
0x3760F1 74 05 je 0x3760f8
0x3760F3 0F 57 C0 xorps xmm0, xmm0
0x3760F6 EB 1F jmp 0x376117
0x3760F8 48 8B 45 50 mov rax, qword ptr [rbp + 0x50]
0x3760FC F3 0F 10 40 64 movss xmm0, dword ptr [rax + 0x64]
0x376101 EB 14 jmp 0x376117
0x376103 48 8B 45 50 mov rax, qword ptr [rbp + 0x50]
0x376107 F3 0F 10 40 60 movss xmm0, dword ptr [rax + 0x60]
0x37610C EB 09 jmp 0x376117
0x37610E 48 8B 45 50 mov rax, qword ptr [rbp + 0x50]
0x376112 F3 0F 10 40 5C movss xmm0, dword ptr [rax + 0x5c]
0x376117 F3 0F 58 01 addss xmm0, dword ptr [rcx]
0x37611B F3 0F 11 01 movss dword ptr [rcx], xmm0
0x37611F 41 FF C0 inc r8d
0x376122 48 83 C1 04 add rcx, 4
0x376126 41 83 F8 06 cmp r8d, 6
0x37612A 0F 8C 87 FE FF FF jl 0x375fb7
0x376130 48 83 C4 68 add rsp, 0x68
0x376134 41 5F pop r15
0x376136 41 5E pop r14
0x376138 41 5D pop r13
0x37613A 41 5C pop r12
0x37613C 5F pop rdi
0x37613D 5E pop rsi
0x37613E 5B pop rbx
0x37613F 5D pop rbp
0x376140 C3 ret 
