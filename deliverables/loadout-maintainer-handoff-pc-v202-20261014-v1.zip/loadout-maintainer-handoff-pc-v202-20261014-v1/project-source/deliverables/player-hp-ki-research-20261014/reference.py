"""File-backed PC v2.02 player HP/Ki base calculation, without game access.

Only the attribute-table and context-correction stages are modeled. Equipment
effects, backing-field bonuses, actor multipliers and final Ki additions are
separate inputs/stages and are not silently assumed to have been recovered.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from nioh3_scroll_editor.r4_finalizer_reference import f32, f32_mul

EXE_SHA256 = "e22c4a635e4ec1e27a177b76e27d7f6a637f426c0ed3928b60f5693bc52ae130"
TABLE = ROOT / "deliverables/load-capacity-research/captures/20261008-5-samurai-attribute-table.json"


def load_table(path: Path = TABLE) -> tuple[list[tuple[int, ...]], dict]:
    metadata = json.loads(path.read_text(encoding="utf-8"))
    raw = path.with_suffix(".bin").read_bytes()
    if metadata["exe_sha256"] != EXE_SHA256:
        raise ValueError("Unsupported executable identity")
    if hashlib.sha256(raw).hexdigest() != metadata["table_sha256"]:
        raise ValueError("Retained attribute-table hash mismatch")
    count = struct.unpack_from("<I", raw, 4)[0]
    if count != metadata["table_count"] or count < 1000 or len(raw) != 8 + count * 32:
        raise ValueError("Incomplete attribute table")
    rows = [struct.unpack_from("<16H", raw, 8 + i * 32) for i in range(count)]
    if len(metadata["rows"]) != count:
        raise ValueError("Missing decoded rows")
    for i, row in enumerate(rows):
        decoded = metadata["rows"][i]
        if decoded["index"] != i or tuple(decoded["u16"]) != row:
            raise ValueError("Decoded/raw row disagreement")
        if bytes.fromhex(decoded["hex"]) != raw[8+i*32:8+(i+1)*32]:
            raise ValueError("Retained row bytes disagree")
    return rows, metadata


def lookup_index(value: int) -> int:
    """818AEC interprets its 32-bit index as signed before clamping."""
    if not -(1 << 31) <= value <= 0xFFFFFFFF:
        raise ValueError("Input is outside a native 32-bit field")
    signed = value if value < (1 << 31) else value - (1 << 32)
    return min(999, max(1, signed))


def corrected(value: int, factor: float) -> int:
    if not math.isfinite(factor) or factor < 0:
        raise ValueError("Unsupported context factor")
    product = f32_mul(f32(value), f32(factor))
    if not math.isfinite(product) or not 0 <= product < (1 << 32):
        raise ValueError("Result outside the bounded native conversion model")
    return math.trunc(product)


def calculate(rows, *, level: int, constitution: int, heart: int, stamina: int,
              hp_correction: float = 1.0, ki_correction: float = 1.0) -> dict:
    indices = {name: lookup_index(value) for name, value in
               dict(level=level, constitution=constitution, heart=heart, stamina=stamina).items()}
    terms = {"level_hp": rows[indices["level"]][0],
             "constitution_hp": rows[indices["constitution"]][1],
             "stamina_hp": rows[indices["stamina"]][6],
             "heart_ki": rows[indices["heart"]][2]}
    hp = terms["level_hp"] + terms["constitution_hp"] + terms["stamina_hp"]
    ki = terms["heart_ki"]
    return dict(indices=indices, terms=terms, base_hp=hp, base_ki=ki,
                context_corrected_hp=corrected(hp, hp_correction),
                context_corrected_ki=corrected(ki, ki_correction),
                context_factors=dict(hp=hp_correction, ki=ki_correction),
                evidence_grade="native-control-flow plus retained native-table; consult separate captures for live controls",
                scope="Base and context stage only; not final equipped/combat maxima")


def delta_runs(rows, column):
    runs = []
    for i in range(2, 1000):
        delta = rows[i][column] - rows[i-1][column]
        if runs and runs[-1]["delta"] == delta:
            runs[-1]["to_index"] = i
        else:
            runs.append(dict(from_index=i, to_index=i, delta=delta))
    return runs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--table", type=Path, default=TABLE)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    rows, metadata = load_table(args.table)
    _, second = load_table(args.table.with_name("20261008-5-ninja-attribute-table.json"))
    if second["table_sha256"] != metadata["table_sha256"]:
        raise ValueError("Historical style captures contain different table bytes")
    phases = []
    for i in (1, 2, 3, 4):
        directory = Path(__file__).parent / f"rea-{i:02d}"
        completion = json.loads((directory / "completion.json").read_text())
        if completion["status"] != "complete" or not completion["source_sha256_unchanged"] or completion["cleanup_error"]:
            raise ValueError("Incomplete REA cleanup")
        events = json.loads((directory / "events.json").read_text())
        if events[-1]["name"] != "binary_session":
            raise ValueError("Missing REA session closure")
        session = json.loads((directory / events[-1]["file"]).read_text())["structuredContent"]["result"]
        if session["open"] is not False:
            raise ValueError("REA target remains open")
        phases.append(dict(path=str(directory), completion=completion, final_session_open=False))
    report = dict(
        schema="nioh3-player-hp-ki-base-research/v1", executable_sha256=EXE_SHA256,
        source_table=str(args.table), source_table_sha256=metadata["table_sha256"],
        source_process=dict(pid=metadata["pid"], birth_filetime=metadata["birth_filetime"]),
        bounds=dict(row_count=len(rows), index_clamp=[1, 999], row_stride=32, header_bytes=8),
        columns=dict(level_hp="+0x00", constitution_hp="+0x02", heart_ki="+0x04", stamina_hp="+0x0C"),
        formulas=dict(base_hp="T[clamp(effective_level)].u16(+0) + T[clamp(effective_constitution)].u16(+2) + T[clamp(effective_stamina)].u16(+12)",
                      base_ki="T[clamp(effective_heart)].u16(+4)",
                      context_stage="u32(trunc(f32(f32(base) * correction))); correction supplied separately"),
        samples=[calculate(rows, level=1, constitution=5, heart=5, stamina=5),
                 calculate(rows, level=364, constitution=22, heart=150, stamina=9)],
        curves=[dict(index=i, level_hp=row[0], constitution_hp=row[1], heart_ki=row[2], stamina_hp=row[6])
                for i, row in enumerate(rows) if 1 <= i <= 999],
        delta_runs={name: delta_runs(rows, col) for name, col in
                    dict(level_hp=0, constitution_hp=1, heart_ki=2, stamina_hp=6).items()},
        checks=dict(style_table_byte_identity=True, raw_decoded_parity=True, rea_phases=phases),
        limitations=["Historic level-364 Ki 1370 is an unconfirmed memory observation, not a new positive control.",
                     "Table and decoded-code captures have different historical process births.",
                     "Rows above playable attribute caps are native data, not proof of gameplay reachability.",
                     "Context helpers and downstream effect/mode factors must be supplied/qualified separately.",
                     "This reference export performs no live process access, debugger, game calls, game writes or save access."])
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(dict(rows=len(report["curves"]), samples=report["samples"])))


if __name__ == "__main__":
    main()
