"""Bounded offline checks against retained native table/instruction anchors."""
import importlib.util
import json
import hashlib
import struct
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("player_hp_ki_reference", HERE / "reference.py")
ref = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ref)


@pytest.fixture(scope="module")
def rows():
    return ref.load_table()[0]


def test_raw_table_anchors(rows):
    assert rows[5][:3] == (820, 70, 960)
    assert rows[22][1] == 340
    assert rows[108][6] == 319
    assert rows[364][0] == 2524
    assert rows[150][2] == 1370


def test_historical_character_base_is_not_final_hp(rows):
    result = ref.calculate(rows, level=364, constitution=22, heart=150, stamina=9)
    assert result["base_hp"] == 2944
    assert result["base_ki"] == 1370
    # Earlier memory HP 3706 was marked unconfirmed. Do not invent a modifier
    # that makes an unequipped base calculation match that different stage.
    assert result["base_hp"] != 3706


def test_signed_lookup_boundaries():
    assert [ref.lookup_index(v) for v in (-1, 0, 1, 999, 1000, 0x7FFFFFFF,
                                         0x80000000, 0xFFFFFFFF)] == [1, 1, 1, 999, 999, 999, 1, 1]


def test_retained_upper_rows_are_data_not_playable_cap(rows):
    assert rows[200][1:3] == (1352, 1390)
    assert rows[200][6] == 478
    assert rows[999][0] == 3294
    assert rows[999][1:3] == (1352, 1390)


def test_context_stage_zero_has_no_enemy_minimum_one(rows):
    result = ref.calculate(rows, level=1, constitution=5, heart=5, stamina=5,
                           hp_correction=0, ki_correction=0)
    assert result["base_hp"] == 880
    assert result["context_corrected_hp"] == result["context_corrected_ki"] == 0


def test_context_rejects_unmodeled_conversion():
    for factor in (float("nan"), -1, float("inf"), 1e30):
        with pytest.raises(ValueError):
            ref.corrected(3183, factor)


def test_native_register_and_column_anchors():
    evidence = json.loads((HERE / "instructions-01.json").read_text())
    native = {int(i["rva"], 16): i["bytes_hex"] for f in evidence["functions"]
              for i in f["instructions"]}
    assert native[0x818E43] == "44 8B 48 08"  # R9D = third attribute, effective stamina
    assert native[0x818E4C] == "44 8B 00"     # R8D = effective constitution
    assert native[0x8181DD] == "44 0F B7 48 02"
    assert native[0x8181EF] == "0F B7 40 0C"
    assert native[0x818EA5] == "0F B7 40 04"  # heart Ki column


def test_rea_sessions_closed_without_source_changes():
    for phase in range(1, 5):
        directory = HERE / f"rea-{phase:02d}"
        completion = json.loads((directory / "completion.json").read_text())
        assert completion["status"] == "complete"
        assert completion["source_sha256_unchanged"] is True
        assert completion["cleanup_error"] is None
        events = json.loads((directory / "events.json").read_text())
        session = json.loads((directory / events[-1]["file"]).read_text())
        assert session["structuredContent"]["result"]["open"] is False


def test_owner_level_one_control_and_kato_difference(rows):
    result = ref.calculate(rows,level=1,constitution=5,heart=5,stamina=5)
    assert result["terms"] == dict(level_hp=780,constitution_hp=70,stamina_hp=30,heart_ki=960)
    assert result["base_hp"] == 880
    assert result["base_ki"] == 960
    assert 1015-result["base_hp"] == 135


def test_post_change_native_snapshot_raw_parity(rows):
    directory=HERE/"live-player-02"
    capture=json.loads((directory/"capture.json").read_text())
    assert capture["status"]=="complete_passive_snapshot"
    assert capture["identity"]["executable_sha256"]==ref.EXE_SHA256
    for blob in capture["blobs"]:
        raw=(directory/blob["file"]).read_bytes()
        assert len(raw)==blob["size"]
        assert hashlib.sha256(raw).hexdigest()==blob["sha256"]
    status=(directory/"status.bin").read_bytes()
    stat=(directory/"selected-stat.bin").read_bytes()
    backing=(directory/"stat-backing.bin").read_bytes()
    assert struct.unpack_from("<Q",status,0x2D90)[0]==int(capture["joined"]["stat"],16)
    assert struct.unpack_from("<7I",backing,0x34)==(5,5,5,6,5,5,5)
    replay=ref.calculate(rows,level=struct.unpack_from("<I",backing,0x30)[0],
                         constitution=5,heart=5,stamina=5)
    assert struct.unpack_from("<II",stat,0x18)==(replay["base_hp"],replay["base_ki"])
    assert struct.unpack_from("<Q",status,0x50)[0]==replay["base_hp"]==880
    assert struct.unpack_from("<f",status,0xB0)[0]==replay["base_ki"]==960
    assert struct.unpack_from("<I",backing,0x5880)[0]==0
