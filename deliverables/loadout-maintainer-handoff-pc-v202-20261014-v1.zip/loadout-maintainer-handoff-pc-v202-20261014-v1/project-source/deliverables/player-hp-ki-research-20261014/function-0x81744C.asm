0x81744C 48 89 5C 24 18 mov qword ptr [rsp + 0x18], rbx
0x817451 55 push rbp
0x817452 56 push rsi
0x817453 57 push rdi
0x817454 41 54 push r12
0x817456 41 55 push r13
0x817458 41 56 push r14
0x81745A 41 57 push r15
0x81745C 48 8D 6C 24 E0 lea rbp, [rsp - 0x20]
0x817461 48 81 EC 20 01 00 00 sub rsp, 0x120
0x817468 48 8B 05 C1 0A CA 03 mov rax, qword ptr [rip + 0x3ca0ac1]
0x81746F 48 33 C4 xor rax, rsp
0x817472 48 89 45 10 mov qword ptr [rbp + 0x10], rax
0x817476 4C 8B EA mov r13, rdx
0x817479 48 8B D9 mov rbx, rcx
0x81747C 49 8B CD mov rcx, r13
0x81747F BA 0F 00 00 00 mov edx, 0xf
0x817484 E8 4F F1 8D FF call 0xf65d8
0x817489 48 8D 54 24 20 lea rdx, [rsp + 0x20]
0x81748E B9 80 00 00 00 mov ecx, 0x80
0x817493 45 33 FF xor r15d, r15d
0x817496 0F 10 00 movups xmm0, xmmword ptr [rax]
0x817499 0F 11 02 movups xmmword ptr [rdx], xmm0
0x81749C 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x8174A0 0F 11 4A 10 movups xmmword ptr [rdx + 0x10], xmm1
0x8174A4 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x8174A8 0F 11 42 20 movups xmmword ptr [rdx + 0x20], xmm0
0x8174AC 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x8174B0 0F 11 4A 30 movups xmmword ptr [rdx + 0x30], xmm1
0x8174B4 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x8174B8 0F 11 42 40 movups xmmword ptr [rdx + 0x40], xmm0
0x8174BC 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x8174C0 0F 11 4A 50 movups xmmword ptr [rdx + 0x50], xmm1
0x8174C4 0F 10 40 60 movups xmm0, xmmword ptr [rax + 0x60]
0x8174C8 0F 11 42 60 movups xmmword ptr [rdx + 0x60], xmm0
0x8174CC 48 03 D1 add rdx, rcx
0x8174CF 0F 10 40 70 movups xmm0, xmmword ptr [rax + 0x70]
0x8174D3 48 03 C1 add rax, rcx
0x8174D6 0F 11 42 F0 movups xmmword ptr [rdx - 0x10], xmm0
0x8174DA 0F 10 08 movups xmm1, xmmword ptr [rax]
0x8174DD 0F 11 0A movups xmmword ptr [rdx], xmm1
0x8174E0 0F 10 40 10 movups xmm0, xmmword ptr [rax + 0x10]
0x8174E4 0F 11 42 10 movups xmmword ptr [rdx + 0x10], xmm0
0x8174E8 0F 10 48 20 movups xmm1, xmmword ptr [rax + 0x20]
0x8174EC 0F 11 4A 20 movups xmmword ptr [rdx + 0x20], xmm1
0x8174F0 0F 10 40 30 movups xmm0, xmmword ptr [rax + 0x30]
0x8174F4 0F 11 42 30 movups xmmword ptr [rdx + 0x30], xmm0
0x8174F8 0F 10 48 40 movups xmm1, xmmword ptr [rax + 0x40]
0x8174FC 0F 11 4A 40 movups xmmword ptr [rdx + 0x40], xmm1
0x817500 0F 10 40 50 movups xmm0, xmmword ptr [rax + 0x50]
0x817504 0F 11 42 50 movups xmmword ptr [rdx + 0x50], xmm0
0x817508 48 8B 40 60 mov rax, qword ptr [rax + 0x60]
0x81750C 48 89 42 60 mov qword ptr [rdx + 0x60], rax
0x817510 0F B7 54 24 20 movzx edx, word ptr [rsp + 0x20]
0x817515 66 85 D2 test dx, dx
0x817518 0F 85 7A 76 20 01 jne 0x1a1eb98
0x81751E 48 8B 7B 08 mov rdi, qword ptr [rbx + 8]
0x817522 45 8B C7 mov r8d, r15d
0x817525 BA 0F 00 00 00 mov edx, 0xf
0x81752A 49 8B CD mov rcx, r13
0x81752D 83 7F 2C 01 cmp dword ptr [rdi + 0x2c], 1
0x817531 41 0F 95 C0 setne r8b
0x817535 E8 DA F0 8D FF call 0xf6614
0x81753A 48 8D 4C 24 20 lea rcx, [rsp + 0x20]
0x81753F BA 80 00 00 00 mov edx, 0x80
0x817544 0F 10 00 movups xmm0, xmmword ptr [rax]
0x817547 0F 11 01 movups xmmword ptr [rcx], xmm0
0x81754A 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x81754E 0F 11 49 10 movups xmmword ptr [rcx + 0x10], xmm1
0x817552 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x817556 0F 11 41 20 movups xmmword ptr [rcx + 0x20], xmm0
0x81755A 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x81755E 0F 11 49 30 movups xmmword ptr [rcx + 0x30], xmm1
0x817562 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x817566 0F 11 41 40 movups xmmword ptr [rcx + 0x40], xmm0
0x81756A 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x81756E 0F 11 49 50 movups xmmword ptr [rcx + 0x50], xmm1
0x817572 0F 10 40 60 movups xmm0, xmmword ptr [rax + 0x60]
0x817576 0F 11 41 60 movups xmmword ptr [rcx + 0x60], xmm0
0x81757A 48 03 CA add rcx, rdx
0x81757D 0F 10 48 70 movups xmm1, xmmword ptr [rax + 0x70]
0x817581 48 03 C2 add rax, rdx
0x817584 0F 11 49 F0 movups xmmword ptr [rcx - 0x10], xmm1
0x817588 0F 10 00 movups xmm0, xmmword ptr [rax]
0x81758B 0F 11 01 movups xmmword ptr [rcx], xmm0
0x81758E 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x817592 0F 11 49 10 movups xmmword ptr [rcx + 0x10], xmm1
0x817596 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x81759A 0F 11 41 20 movups xmmword ptr [rcx + 0x20], xmm0
0x81759E 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x8175A2 0F 11 49 30 movups xmmword ptr [rcx + 0x30], xmm1
0x8175A6 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x8175AA 0F 11 41 40 movups xmmword ptr [rcx + 0x40], xmm0
0x8175AE 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x8175B2 0F 11 49 50 movups xmmword ptr [rcx + 0x50], xmm1
0x8175B6 48 8B 40 60 mov rax, qword ptr [rax + 0x60]
0x8175BA 48 89 41 60 mov qword ptr [rcx + 0x60], rax
0x8175BE 0F B7 54 24 20 movzx edx, word ptr [rsp + 0x20]
0x8175C3 66 85 D2 test dx, dx
0x8175C6 0F 85 C5 76 20 01 jne 0x1a1ec91
0x8175CC 48 8B 4D 10 mov rcx, qword ptr [rbp + 0x10]
0x8175D0 48 33 CC xor rcx, rsp
0x8175D3 E8 08 9D 37 00 call 0xb912e0
0x8175D8 48 8B 9C 24 70 01 00 00 mov rbx, qword ptr [rsp + 0x170]
0x8175E0 48 81 C4 20 01 00 00 add rsp, 0x120
0x8175E7 41 5F pop r15
0x8175E9 41 5E pop r14
0x8175EB 41 5D pop r13
0x8175ED 41 5C pop r12
0x8175EF 5F pop rdi
0x8175F0 5E pop rsi
0x8175F1 5D pop rbp
0x8175F2 C3 ret 
