0x2FB2BC 48 89 5C 24 18 mov qword ptr [rsp + 0x18], rbx
0x2FB2C1 55 push rbp
0x2FB2C2 56 push rsi
0x2FB2C3 57 push rdi
0x2FB2C4 41 54 push r12
0x2FB2C6 41 55 push r13
0x2FB2C8 41 56 push r14
0x2FB2CA 41 57 push r15
0x2FB2CC 48 8D 6C 24 A0 lea rbp, [rsp - 0x60]
0x2FB2D1 48 81 EC 60 01 00 00 sub rsp, 0x160
0x2FB2D8 48 8B 05 51 CC 1B 04 mov rax, qword ptr [rip + 0x41bcc51]
0x2FB2DF 48 33 C4 xor rax, rsp
0x2FB2E2 48 89 45 50 mov qword ptr [rbp + 0x50], rax
0x2FB2E6 8B 82 E0 1E 00 00 mov eax, dword ptr [rdx + 0x1ee0]
0x2FB2EC 45 33 D2 xor r10d, r10d
0x2FB2EF 44 8B E8 mov r13d, eax
0x2FB2F2 4C 89 44 24 48 mov qword ptr [rsp + 0x48], r8
0x2FB2F7 41 83 F5 01 xor r13d, 1
0x2FB2FB 89 44 24 38 mov dword ptr [rsp + 0x38], eax
0x2FB2FF 4C 8B F2 mov r14, rdx
0x2FB302 48 8B D9 mov rbx, rcx
0x2FB305 44 89 6C 24 40 mov dword ptr [rsp + 0x40], r13d
0x2FB30A 44 38 51 10 cmp byte ptr [rcx + 0x10], r10b
0x2FB30E 74 14 je 0x2fb324
0x2FB310 48 8B 05 B9 61 45 04 mov rax, qword ptr [rip + 0x44561b9]
0x2FB317 41 B4 01 mov r12b, 1
0x2FB31A 48 8B 48 08 mov rcx, qword ptr [rax + 8]
0x2FB31E 80 79 10 01 cmp byte ptr [rcx + 0x10], 1
0x2FB322 76 03 jbe 0x2fb327
0x2FB324 45 8A E2 mov r12b, r10b
0x2FB327 44 8B 6C 24 38 mov r13d, dword ptr [rsp + 0x38]
0x2FB32C 48 8D 35 CD B3 67 03 lea rsi, [rip + 0x367b3cd]
0x2FB333 49 8B F8 mov rdi, r8
0x2FB336 8B 0E mov ecx, dword ptr [rsi]
0x2FB338 E8 13 06 00 00 call 0x2fb950
0x2FB33D 8B 16 mov edx, dword ptr [rsi]
0x2FB33F 49 8B CE mov rcx, r14
0x2FB342 89 44 24 38 mov dword ptr [rsp + 0x38], eax
0x2FB346 E8 8D B2 DF FF call 0xf65d8
0x2FB34B 48 8D 4C 24 60 lea rcx, [rsp + 0x60]
0x2FB350 0F 10 00 movups xmm0, xmmword ptr [rax]
0x2FB353 0F 11 01 movups xmmword ptr [rcx], xmm0
0x2FB356 48 8D 89 80 00 00 00 lea rcx, [rcx + 0x80]
0x2FB35D 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x2FB361 0F 11 49 90 movups xmmword ptr [rcx - 0x70], xmm1
0x2FB365 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x2FB369 0F 11 41 A0 movups xmmword ptr [rcx - 0x60], xmm0
0x2FB36D 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x2FB371 0F 11 49 B0 movups xmmword ptr [rcx - 0x50], xmm1
0x2FB375 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x2FB379 0F 11 41 C0 movups xmmword ptr [rcx - 0x40], xmm0
0x2FB37D 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x2FB381 0F 11 49 D0 movups xmmword ptr [rcx - 0x30], xmm1
0x2FB385 0F 10 40 60 movups xmm0, xmmword ptr [rax + 0x60]
0x2FB389 0F 11 41 E0 movups xmmword ptr [rcx - 0x20], xmm0
0x2FB38D 0F 10 48 70 movups xmm1, xmmword ptr [rax + 0x70]
0x2FB391 48 83 E8 80 sub rax, -0x80
0x2FB395 0F 11 49 F0 movups xmmword ptr [rcx - 0x10], xmm1
0x2FB399 0F 10 00 movups xmm0, xmmword ptr [rax]
0x2FB39C 0F 11 01 movups xmmword ptr [rcx], xmm0
0x2FB39F 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x2FB3A3 0F 11 49 10 movups xmmword ptr [rcx + 0x10], xmm1
0x2FB3A7 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x2FB3AB 0F 11 41 20 movups xmmword ptr [rcx + 0x20], xmm0
0x2FB3AF 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x2FB3B3 0F 11 49 30 movups xmmword ptr [rcx + 0x30], xmm1
0x2FB3B7 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x2FB3BB 0F 11 41 40 movups xmmword ptr [rcx + 0x40], xmm0
0x2FB3BF 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x2FB3C3 0F 11 49 50 movups xmmword ptr [rcx + 0x50], xmm1
0x2FB3C7 48 8B 40 60 mov rax, qword ptr [rax + 0x60]
0x2FB3CB 48 89 41 60 mov qword ptr [rcx + 0x60], rax
0x2FB3CF 0F B7 54 24 60 movzx edx, word ptr [rsp + 0x60]
0x2FB3D4 66 85 D2 test dx, dx
0x2FB3D7 0F 84 7B 03 00 00 je 0x2fb758
0x2FB3DD 48 8B 0D 4C EA 2B 04 mov rcx, qword ptr [rip + 0x42bea4c]
0x2FB3E4 48 8B 49 68 mov rcx, qword ptr [rcx + 0x68]
0x2FB3E8 E8 CF 99 DF FF call 0xf4dbc
0x2FB3ED 45 33 D2 xor r10d, r10d
0x2FB3F0 4C 8B F8 mov r15, rax
0x2FB3F3 48 85 C0 test rax, rax
0x2FB3F6 0F 84 5C 03 00 00 je 0x2fb758
0x2FB3FC 48 8D 8B F4 01 00 00 lea rcx, [rbx + 0x1f4]
0x2FB403 48 8D 54 24 38 lea rdx, [rsp + 0x38]
0x2FB408 E8 03 A5 07 00 call 0x375910
0x2FB40D 33 D2 xor edx, edx
0x2FB40F 48 89 44 24 38 mov qword ptr [rsp + 0x38], rax
0x2FB414 38 53 10 cmp byte ptr [rbx + 0x10], dl
0x2FB417 74 66 je 0x2fb47f
0x2FB419 48 8B 4B 08 mov rcx, qword ptr [rbx + 8]
0x2FB41D 48 85 C9 test rcx, rcx
0x2FB420 74 5D je 0x2fb47f
0x2FB422 E8 65 76 25 00 call 0x552a8c
0x2FB427 8B C8 mov ecx, eax
0x2FB429 E8 76 76 25 00 call 0x552aa4
0x2FB42E 33 D2 xor edx, edx
0x2FB430 84 C0 test al, al
0x2FB432 74 4B je 0x2fb47f
0x2FB434 41 8A D4 mov dl, r12b
0x2FB437 48 8D 4C 24 60 lea rcx, [rsp + 0x60]
0x2FB43C E8 5B 10 7C 01 call 0x1abc49c
0x2FB441 48 8B 83 D8 07 00 00 mov rax, qword ptr [rbx + 0x7d8]
0x2FB448 33 C9 xor ecx, ecx
0x2FB44A 48 85 C0 test rax, rax
0x2FB44D 74 06 je 0x2fb455
0x2FB44F 0F B7 50 52 movzx edx, word ptr [rax + 0x52]
0x2FB453 EB 02 jmp 0x2fb457
0x2FB455 8B D1 mov edx, ecx
0x2FB457 48 8B CB mov rcx, rbx
0x2FB45A E8 F5 C8 7B 01 call 0x1ab7d54
0x2FB45F 44 0F B7 C2 movzx r8d, dx
0x2FB463 48 8D 4C 24 60 lea rcx, [rsp + 0x60]
0x2FB468 0F B7 D0 movzx edx, ax
0x2FB46B E8 48 86 7B 01 call 0x1ab3ab8
0x2FB470 48 8B D0 mov rdx, rax
0x2FB473 48 8D 4C 24 60 lea rcx, [rsp + 0x60]
0x2FB478 E8 53 79 25 00 call 0x552dd0
0x2FB47D 33 D2 xor edx, edx
0x2FB47F 48 63 06 movsxd rax, dword ptr [rsi]
0x2FB482 F3 0F 10 04 87 movss xmm0, dword ptr [rdi + rax*4]
0x2FB487 0F 2F 05 52 8D 8D 03 comiss xmm0, dword ptr [rip + 0x38d8d52]
0x2FB48E 72 20 jb 0x2fb4b0
0x2FB490 48 8B CB mov rcx, rbx
0x2FB493 E8 1C 05 00 00 call 0x2fb9b4
0x2FB498 4C 8B C0 mov r8, rax
0x2FB49B 48 8D 54 24 60 lea rdx, [rsp + 0x60]
0x2FB4A0 49 8B CF mov rcx, r15
0x2FB4A3 E8 D0 E8 FF FF call 0x2f9d78
0x2FB4A8 33 D2 xor edx, edx
0x2FB4AA B1 01 mov cl, 1
0x2FB4AC 84 C0 test al, al
0x2FB4AE 75 02 jne 0x2fb4b2
0x2FB4B0 8A CA mov cl, dl
0x2FB4B2 88 54 24 54 mov byte ptr [rsp + 0x54], dl
0x2FB4B6 44 8A C1 mov r8b, cl
0x2FB4B9 48 8B 44 24 50 mov rax, qword ptr [rsp + 0x50]
0x2FB4BE 48 8D 54 24 60 lea rdx, [rsp + 0x60]
0x2FB4C3 88 4C 24 30 mov byte ptr [rsp + 0x30], cl
0x2FB4C7 49 8B CF mov rcx, r15
0x2FB4CA 48 89 44 24 20 mov qword ptr [rsp + 0x20], rax
0x2FB4CF E8 CC CA 51 00 call 0x817fa0
0x2FB4D4 48 8B 4C 24 38 mov rcx, qword ptr [rsp + 0x38]
0x2FB4D9 48 8D 54 24 60 lea rdx, [rsp + 0x60]
0x2FB4DE 89 01 mov dword ptr [rcx], eax
0x2FB4E0 49 8B CF mov rcx, r15
0x2FB4E3 01 83 C8 01 00 00 add dword ptr [rbx + 0x1c8], eax
0x2FB4E9 E8 E6 CA 51 00 call 0x817fd4
0x2FB4EE 01 83 18 02 00 00 add dword ptr [rbx + 0x218], eax
0x2FB4F4 48 8D 54 24 60 lea rdx, [rsp + 0x60]
0x2FB4F9 49 8B CF mov rcx, r15
0x2FB4FC E8 17 CB 51 00 call 0x818018
0x2FB501 01 83 B8 07 00 00 add dword ptr [rbx + 0x7b8], eax
0x2FB507 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB50C 41 0F B7 87 38 01 00 00 movzx eax, word ptr [r15 + 0x138]
0x2FB514 66 01 83 1C 02 00 00 add word ptr [rbx + 0x21c], ax
0x2FB51B 41 0F B7 97 3A 01 00 00 movzx edx, word ptr [r15 + 0x13a]
0x2FB523 E8 2C EA FF FF call 0x2f9f54
0x2FB528 0F BF C8 movsx ecx, ax
0x2FB52B 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB530 66 0F 6E C1 movd xmm0, ecx
0x2FB534 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB537 F3 0F 58 83 7C 07 00 00 addss xmm0, dword ptr [rbx + 0x77c]
0x2FB53F F3 0F 11 83 7C 07 00 00 movss dword ptr [rbx + 0x77c], xmm0
0x2FB547 41 0F B7 97 3C 01 00 00 movzx edx, word ptr [r15 + 0x13c]
0x2FB54F E8 00 EA FF FF call 0x2f9f54
0x2FB554 0F BF C8 movsx ecx, ax
0x2FB557 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB55C 66 0F 6E C1 movd xmm0, ecx
0x2FB560 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB563 F3 0F 58 83 80 07 00 00 addss xmm0, dword ptr [rbx + 0x780]
0x2FB56B F3 0F 11 83 80 07 00 00 movss dword ptr [rbx + 0x780], xmm0
0x2FB573 41 0F B7 97 40 01 00 00 movzx edx, word ptr [r15 + 0x140]
0x2FB57B E8 D4 E9 FF FF call 0x2f9f54
0x2FB580 0F BF C8 movsx ecx, ax
0x2FB583 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB588 66 0F 6E C1 movd xmm0, ecx
0x2FB58C 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB58F F3 0F 58 83 84 07 00 00 addss xmm0, dword ptr [rbx + 0x784]
0x2FB597 F3 0F 11 83 84 07 00 00 movss dword ptr [rbx + 0x784], xmm0
0x2FB59F 41 0F B7 97 3E 01 00 00 movzx edx, word ptr [r15 + 0x13e]
0x2FB5A7 E8 A8 E9 FF FF call 0x2f9f54
0x2FB5AC 0F BF C8 movsx ecx, ax
0x2FB5AF 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB5B4 66 0F 6E C1 movd xmm0, ecx
0x2FB5B8 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB5BB F3 0F 58 83 88 07 00 00 addss xmm0, dword ptr [rbx + 0x788]
0x2FB5C3 F3 0F 11 83 88 07 00 00 movss dword ptr [rbx + 0x788], xmm0
0x2FB5CB 41 0F B7 97 42 01 00 00 movzx edx, word ptr [r15 + 0x142]
0x2FB5D3 E8 7C E9 FF FF call 0x2f9f54
0x2FB5D8 0F BF C8 movsx ecx, ax
0x2FB5DB 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB5E0 66 0F 6E C1 movd xmm0, ecx
0x2FB5E4 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB5E7 F3 0F 58 83 8C 07 00 00 addss xmm0, dword ptr [rbx + 0x78c]
0x2FB5EF F3 0F 11 83 8C 07 00 00 movss dword ptr [rbx + 0x78c], xmm0
0x2FB5F7 41 0F B7 97 44 01 00 00 movzx edx, word ptr [r15 + 0x144]
0x2FB5FF E8 50 E9 FF FF call 0x2f9f54
0x2FB604 0F BF C8 movsx ecx, ax
0x2FB607 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB60C 66 0F 6E C1 movd xmm0, ecx
0x2FB610 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB613 F3 0F 58 83 90 07 00 00 addss xmm0, dword ptr [rbx + 0x790]
0x2FB61B F3 0F 11 83 90 07 00 00 movss dword ptr [rbx + 0x790], xmm0
0x2FB623 41 0F B7 97 46 01 00 00 movzx edx, word ptr [r15 + 0x146]
0x2FB62B E8 B4 E9 FF FF call 0x2f9fe4
0x2FB630 0F BF C8 movsx ecx, ax
0x2FB633 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB638 66 0F 6E C1 movd xmm0, ecx
0x2FB63C 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB63F F3 0F 58 83 DC 04 00 00 addss xmm0, dword ptr [rbx + 0x4dc]
0x2FB647 F3 0F 11 83 DC 04 00 00 movss dword ptr [rbx + 0x4dc], xmm0
0x2FB64F 41 0F B7 97 48 01 00 00 movzx edx, word ptr [r15 + 0x148]
0x2FB657 E8 88 E9 FF FF call 0x2f9fe4
0x2FB65C 0F BF C8 movsx ecx, ax
0x2FB65F 66 0F 6E C1 movd xmm0, ecx
0x2FB663 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB668 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB66B F3 0F 58 83 FC 04 00 00 addss xmm0, dword ptr [rbx + 0x4fc]
0x2FB673 F3 0F 11 83 FC 04 00 00 movss dword ptr [rbx + 0x4fc], xmm0
0x2FB67B 41 0F B7 97 4C 01 00 00 movzx edx, word ptr [r15 + 0x14c]
0x2FB683 E8 5C E9 FF FF call 0x2f9fe4
0x2FB688 0F BF C8 movsx ecx, ax
0x2FB68B 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB690 66 0F 6E C1 movd xmm0, ecx
0x2FB694 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB697 F3 0F 58 83 1C 05 00 00 addss xmm0, dword ptr [rbx + 0x51c]
0x2FB69F F3 0F 11 83 1C 05 00 00 movss dword ptr [rbx + 0x51c], xmm0
0x2FB6A7 41 0F B7 97 4A 01 00 00 movzx edx, word ptr [r15 + 0x14a]
0x2FB6AF E8 30 E9 FF FF call 0x2f9fe4
0x2FB6B4 0F BF C8 movsx ecx, ax
0x2FB6B7 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB6BC 66 0F 6E C1 movd xmm0, ecx
0x2FB6C0 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB6C3 F3 0F 58 83 3C 05 00 00 addss xmm0, dword ptr [rbx + 0x53c]
0x2FB6CB F3 0F 11 83 3C 05 00 00 movss dword ptr [rbx + 0x53c], xmm0
0x2FB6D3 41 0F B7 97 4E 01 00 00 movzx edx, word ptr [r15 + 0x14e]
0x2FB6DB E8 04 E9 FF FF call 0x2f9fe4
0x2FB6E0 0F BF C8 movsx ecx, ax
0x2FB6E3 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x2FB6E8 66 0F 6E C1 movd xmm0, ecx
0x2FB6EC 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB6EF F3 0F 58 83 5C 05 00 00 addss xmm0, dword ptr [rbx + 0x55c]
0x2FB6F7 F3 0F 11 83 5C 05 00 00 movss dword ptr [rbx + 0x55c], xmm0
0x2FB6FF 41 0F B7 97 50 01 00 00 movzx edx, word ptr [r15 + 0x150]
0x2FB707 E8 D8 E8 FF FF call 0x2f9fe4
0x2FB70C 0F BF C8 movsx ecx, ax
0x2FB70F 45 33 D2 xor r10d, r10d
0x2FB712 66 0F 6E C1 movd xmm0, ecx
0x2FB716 0F 5B C0 cvtdq2ps xmm0, xmm0
0x2FB719 F3 0F 58 83 7C 05 00 00 addss xmm0, dword ptr [rbx + 0x57c]
0x2FB721 F3 0F 11 83 7C 05 00 00 movss dword ptr [rbx + 0x57c], xmm0
0x2FB729 44 38 93 D0 07 00 00 cmp byte ptr [rbx + 0x7d0], r10b
0x2FB730 75 26 jne 0x2fb758
0x2FB732 4C 39 93 D8 07 00 00 cmp qword ptr [rbx + 0x7d8], r10
0x2FB739 74 1D je 0x2fb758
0x2FB73B 44 38 54 24 30 cmp byte ptr [rsp + 0x30], r10b
0x2FB740 74 16 je 0x2fb758
0x2FB742 41 B1 FF mov r9b, 0xff
0x2FB745 48 8D 54 24 60 lea rdx, [rsp + 0x60]
0x2FB74A 45 8B C5 mov r8d, r13d
0x2FB74D 48 8B CB mov rcx, rbx
0x2FB750 E8 F7 BE 25 00 call 0x55764c
0x2FB755 45 33 D2 xor r10d, r10d
0x2FB758 48 83 C6 04 add rsi, 4
0x2FB75C 48 8D 05 C1 AF 67 03 lea rax, [rip + 0x367afc1]
0x2FB763 48 3B F0 cmp rsi, rax
0x2FB766 0F 85 CA FB FF FF jne 0x2fb336
0x2FB76C 48 8D 3D 8D AF 67 03 lea rdi, [rip + 0x367af8d]
0x2FB773 44 8B 6C 24 40 mov r13d, dword ptr [rsp + 0x40]
0x2FB778 4C 39 93 D8 07 00 00 cmp qword ptr [rbx + 0x7d8], r10
0x2FB77F 0F 84 A3 01 00 00 je 0x2fb928
0x2FB785 4C 8B 7C 24 48 mov r15, qword ptr [rsp + 0x48]
0x2FB78A 45 8B 86 E0 1E 00 00 mov r8d, dword ptr [r14 + 0x1ee0]
0x2FB791 49 8B CE mov rcx, r14
0x2FB794 8B 17 mov edx, dword ptr [rdi]
0x2FB796 41 83 F0 01 xor r8d, 1
0x2FB79A E8 75 AE DF FF call 0xf6614
0x2FB79F 48 8D 4C 24 60 lea rcx, [rsp + 0x60]
0x2FB7A4 0F 10 00 movups xmm0, xmmword ptr [rax]
0x2FB7A7 0F 11 01 movups xmmword ptr [rcx], xmm0
0x2FB7AA 48 8D 89 80 00 00 00 lea rcx, [rcx + 0x80]
0x2FB7B1 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x2FB7B5 0F 11 49 90 movups xmmword ptr [rcx - 0x70], xmm1
0x2FB7B9 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x2FB7BD 0F 11 41 A0 movups xmmword ptr [rcx - 0x60], xmm0
0x2FB7C1 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x2FB7C5 0F 11 49 B0 movups xmmword ptr [rcx - 0x50], xmm1
0x2FB7C9 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x2FB7CD 0F 11 41 C0 movups xmmword ptr [rcx - 0x40], xmm0
0x2FB7D1 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x2FB7D5 0F 11 49 D0 movups xmmword ptr [rcx - 0x30], xmm1
0x2FB7D9 0F 10 40 60 movups xmm0, xmmword ptr [rax + 0x60]
0x2FB7DD 0F 11 41 E0 movups xmmword ptr [rcx - 0x20], xmm0
0x2FB7E1 0F 10 48 70 movups xmm1, xmmword ptr [rax + 0x70]
0x2FB7E5 48 83 E8 80 sub rax, -0x80
0x2FB7E9 0F 11 49 F0 movups xmmword ptr [rcx - 0x10], xmm1
0x2FB7ED 0F 10 00 movups xmm0, xmmword ptr [rax]
0x2FB7F0 0F 11 01 movups xmmword ptr [rcx], xmm0
0x2FB7F3 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x2FB7F7 0F 11 49 10 movups xmmword ptr [rcx + 0x10], xmm1
0x2FB7FB 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x2FB7FF 0F 11 41 20 movups xmmword ptr [rcx + 0x20], xmm0
0x2FB803 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x2FB807 0F 11 49 30 movups xmmword ptr [rcx + 0x30], xmm1
0x2FB80B 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x2FB80F 0F 11 41 40 movups xmmword ptr [rcx + 0x40], xmm0
0x2FB813 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x2FB817 0F 11 49 50 movups xmmword ptr [rcx + 0x50], xmm1
0x2FB81B 48 8B 40 60 mov rax, qword ptr [rax + 0x60]
0x2FB81F 48 89 41 60 mov qword ptr [rcx + 0x60], rax
0x2FB823 0F B7 54 24 60 movzx edx, word ptr [rsp + 0x60]
0x2FB828 66 85 D2 test dx, dx
0x2FB82B 0F 84 E3 00 00 00 je 0x2fb914
0x2FB831 48 8B 0D F8 E5 2B 04 mov rcx, qword ptr [rip + 0x42be5f8]
0x2FB838 48 8B 49 68 mov rcx, qword ptr [rcx + 0x68]
0x2FB83C E8 7B 95 DF FF call 0xf4dbc
0x2FB841 45 33 D2 xor r10d, r10d
0x2FB844 48 8B F0 mov rsi, rax
0x2FB847 48 85 C0 test rax, rax
0x2FB84A 0F 84 C4 00 00 00 je 0x2fb914
0x2FB850 44 38 53 10 cmp byte ptr [rbx + 0x10], r10b
0x2FB854 74 68 je 0x2fb8be
0x2FB856 48 8B 4B 08 mov rcx, qword ptr [rbx + 8]
0x2FB85A 48 85 C9 test rcx, rcx
0x2FB85D 74 5F je 0x2fb8be
0x2FB85F E8 28 72 25 00 call 0x552a8c
0x2FB864 8B C8 mov ecx, eax
0x2FB866 E8 39 72 25 00 call 0x552aa4
0x2FB86B 45 33 D2 xor r10d, r10d
0x2FB86E 84 C0 test al, al
0x2FB870 74 4C je 0x2fb8be
0x2FB872 41 8A D4 mov dl, r12b
0x2FB875 48 8D 4C 24 60 lea rcx, [rsp + 0x60]
0x2FB87A E8 1D 0C 7C 01 call 0x1abc49c
0x2FB87F 48 8B 83 D8 07 00 00 mov rax, qword ptr [rbx + 0x7d8]
0x2FB886 33 C9 xor ecx, ecx
0x2FB888 48 85 C0 test rax, rax
0x2FB88B 74 06 je 0x2fb893
0x2FB88D 0F B7 50 52 movzx edx, word ptr [rax + 0x52]
0x2FB891 EB 02 jmp 0x2fb895
0x2FB893 8B D1 mov edx, ecx
0x2FB895 48 8B CB mov rcx, rbx
0x2FB898 E8 B7 C4 7B 01 call 0x1ab7d54
0x2FB89D 44 0F B7 C2 movzx r8d, dx
0x2FB8A1 48 8D 4C 24 60 lea rcx, [rsp + 0x60]
0x2FB8A6 0F B7 D0 movzx edx, ax
0x2FB8A9 E8 0A 82 7B 01 call 0x1ab3ab8
0x2FB8AE 48 8B D0 mov rdx, rax
0x2FB8B1 48 8D 4C 24 60 lea rcx, [rsp + 0x60]
0x2FB8B6 E8 15 75 25 00 call 0x552dd0
0x2FB8BB 45 33 D2 xor r10d, r10d
0x2FB8BE 48 63 07 movsxd rax, dword ptr [rdi]
0x2FB8C1 F3 41 0F 10 04 87 movss xmm0, dword ptr [r15 + rax*4]
0x2FB8C7 0F 2F 05 12 89 8D 03 comiss xmm0, dword ptr [rip + 0x38d8912]
0x2FB8CE 72 21 jb 0x2fb8f1
0x2FB8D0 48 8B CB mov rcx, rbx
0x2FB8D3 E8 DC 00 00 00 call 0x2fb9b4
0x2FB8D8 4C 8B C0 mov r8, rax
0x2FB8DB 48 8D 54 24 60 lea rdx, [rsp + 0x60]
0x2FB8E0 48 8B CE mov rcx, rsi
0x2FB8E3 E8 90 E4 FF FF call 0x2f9d78
0x2FB8E8 45 33 D2 xor r10d, r10d
0x2FB8EB 84 C0 test al, al
0x2FB8ED B0 01 mov al, 1
0x2FB8EF 75 03 jne 0x2fb8f4
0x2FB8F1 41 8A C2 mov al, r10b
0x2FB8F4 44 38 93 D0 07 00 00 cmp byte ptr [rbx + 0x7d0], r10b
0x2FB8FB 75 17 jne 0x2fb914
0x2FB8FD 84 C0 test al, al
0x2FB8FF 74 13 je 0x2fb914
0x2FB901 45 8B C5 mov r8d, r13d
0x2FB904 48 8D 54 24 60 lea rdx, [rsp + 0x60]
0x2FB909 48 8B CB mov rcx, rbx
0x2FB90C E8 CB 9E 25 00 call 0x5557dc
0x2FB911 45 33 D2 xor r10d, r10d
0x2FB914 48 83 C7 04 add rdi, 4
0x2FB918 48 8D 05 05 AE 67 03 lea rax, [rip + 0x367ae05]
0x2FB91F 48 3B F8 cmp rdi, rax
0x2FB922 0F 85 62 FE FF FF jne 0x2fb78a
0x2FB928 48 8B 4D 50 mov rcx, qword ptr [rbp + 0x50]
0x2FB92C 48 33 CC xor rcx, rsp
0x2FB92F E8 AC 59 89 00 call 0xb912e0
0x2FB934 48 8B 9C 24 B0 01 00 00 mov rbx, qword ptr [rsp + 0x1b0]
0x2FB93C 48 81 C4 60 01 00 00 add rsp, 0x160
0x2FB943 41 5F pop r15
0x2FB945 41 5E pop r14
0x2FB947 41 5D pop r13
0x2FB949 41 5C pop r12
0x2FB94B 5F pop rdi
0x2FB94C 5E pop rsi
0x2FB94D 5D pop rbp
0x2FB94E C3 ret 
