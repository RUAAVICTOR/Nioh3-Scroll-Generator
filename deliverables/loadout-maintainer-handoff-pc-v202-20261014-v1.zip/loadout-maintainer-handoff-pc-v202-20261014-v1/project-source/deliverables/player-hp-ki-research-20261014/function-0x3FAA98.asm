0x3FAA98 48 89 5C 24 20 mov qword ptr [rsp + 0x20], rbx
0x3FAA9D 55 push rbp
0x3FAA9E 56 push rsi
0x3FAA9F 57 push rdi
0x3FAAA0 41 54 push r12
0x3FAAA2 41 55 push r13
0x3FAAA4 41 56 push r14
0x3FAAA6 41 57 push r15
0x3FAAA8 48 83 EC 20 sub rsp, 0x20
0x3FAAAC 48 8B 41 08 mov rax, qword ptr [rcx + 8]
0x3FAAB0 33 DB xor ebx, ebx
0x3FAAB2 48 8B F1 mov rsi, rcx
0x3FAAB5 48 85 C0 test rax, rax
0x3FAAB8 0F 84 29 02 00 00 je 0x3face7
0x3FAABE 38 99 D0 07 00 00 cmp byte ptr [rcx + 0x7d0], bl
0x3FAAC4 0F 85 1D 02 00 00 jne 0x3face7
0x3FAACA 48 8B A9 D8 07 00 00 mov rbp, qword ptr [rcx + 0x7d8]
0x3FAAD1 48 85 ED test rbp, rbp
0x3FAAD4 0F 84 0D 02 00 00 je 0x3face7
0x3FAADA 44 8B 60 2C mov r12d, dword ptr [rax + 0x2c]
0x3FAADE 4C 8D 35 63 BC 57 03 lea r14, [rip + 0x357bc63]
0x3FAAE5 41 8B 3E mov edi, dword ptr [r14]
0x3FAAE8 48 8B CE mov rcx, rsi
0x3FAAEB 8B D7 mov edx, edi
0x3FAAED 89 5C 24 60 mov dword ptr [rsp + 0x60], ebx
0x3FAAF1 44 8B DB mov r11d, ebx
0x3FAAF4 44 8B D3 mov r10d, ebx
0x3FAAF7 E8 54 CF 15 00 call 0x557a50
0x3FAAFC 85 C0 test eax, eax
0x3FAAFE 7E 37 jle 0x3fab37
0x3FAB00 44 8B C7 mov r8d, edi
0x3FAB03 41 8B D2 mov edx, r10d
0x3FAB06 48 8B CE mov rcx, rsi
0x3FAB09 E8 8A CF 15 00 call 0x557a98
0x3FAB0E B9 BA 38 00 00 mov ecx, 0x38ba
0x3FAB13 66 39 08 cmp word ptr [rax], cx
0x3FAB16 74 14 je 0x3fab2c
0x3FAB18 8B D7 mov edx, edi
0x3FAB1A 48 8B CE mov rcx, rsi
0x3FAB1D 41 FF C2 inc r10d
0x3FAB20 E8 2B CF 15 00 call 0x557a50
0x3FAB25 44 3B D0 cmp r10d, eax
0x3FAB28 7C D6 jl 0x3fab00
0x3FAB2A EB 0B jmp 0x3fab37
0x3FAB2C 41 BB 01 00 00 00 mov r11d, 1
0x3FAB32 44 89 5C 24 60 mov dword ptr [rsp + 0x60], r11d
0x3FAB37 8B D7 mov edx, edi
0x3FAB39 48 8B CD mov rcx, rbp
0x3FAB3C 44 8B EB mov r13d, ebx
0x3FAB3F E8 20 12 00 00 call 0x3fbd64
0x3FAB44 39 98 54 11 00 00 cmp dword ptr [rax + 0x1154], ebx
0x3FAB4A 0F 8E 83 01 00 00 jle 0x3facd3
0x3FAB50 4C 8B CD mov r9, rbp
0x3FAB53 48 89 5C 24 70 mov qword ptr [rsp + 0x70], rbx
0x3FAB58 4C 8B D3 mov r10, rbx
0x3FAB5B 8B D7 mov edx, edi
0x3FAB5D 49 8B C9 mov rcx, r9
0x3FAB60 E8 F7 CF 15 00 call 0x557b5c
0x3FAB65 41 8B D5 mov edx, r13d
0x3FAB68 46 89 9C 10 0C 0C 00 00 mov dword ptr [rax + r10 + 0xc0c], r11d
0x3FAB70 48 8B AE D8 07 00 00 mov rbp, qword ptr [rsi + 0x7d8]
0x3FAB77 41 8B 3E mov edi, dword ptr [r14]
0x3FAB7A 48 8B CD mov rcx, rbp
0x3FAB7D 44 8B C7 mov r8d, edi
0x3FAB80 E8 4B 10 00 00 call 0x3fbbd0
0x3FAB85 4C 8B F8 mov r15, rax
0x3FAB88 4C 8B CD mov r9, rbp
0x3FAB8B 0F B7 48 04 movzx ecx, word ptr [rax + 4]
0x3FAB8F 03 48 08 add ecx, dword ptr [rax + 8]
0x3FAB92 83 F9 01 cmp ecx, 1
0x3FAB95 0F 86 10 01 00 00 jbe 0x3facab
0x3FAB9B 48 8B 05 8E F2 1B 04 mov rax, qword ptr [rip + 0x41bf28e]
0x3FABA2 41 8B 17 mov edx, dword ptr [r15]
0x3FABA5 48 8B 98 38 01 00 00 mov rbx, qword ptr [rax + 0x138]
0x3FABAC 48 8B 4B 20 mov rcx, qword ptr [rbx + 0x20]
0x3FABB0 E8 DB FB FF FF call 0x3fa790
0x3FABB5 8B D0 mov edx, eax
0x3FABB7 48 8B CB mov rcx, rbx
0x3FABBA E8 B1 FB FF FF call 0x3fa770
0x3FABBF 33 DB xor ebx, ebx
0x3FABC1 48 89 44 24 68 mov qword ptr [rsp + 0x68], rax
0x3FABC6 48 8B D0 mov rdx, rax
0x3FABC9 4C 8B CD mov r9, rbp
0x3FABCC 48 85 C0 test rax, rax
0x3FABCF 0F 84 D1 00 00 00 je 0x3faca6
0x3FABD5 33 ED xor ebp, ebp
0x3FABD7 48 63 CB movsxd rcx, ebx
0x3FABDA 48 83 F9 07 cmp rcx, 7
0x3FABDE 73 0E jae 0x3fabee
0x3FABE0 48 8D 41 02 lea rax, [rcx + 2]
0x3FABE4 48 8D 04 40 lea rax, [rax + rax*2]
0x3FABE8 48 C1 E0 03 shl rax, 3
0x3FABEC EB 05 jmp 0x3fabf3
0x3FABEE B8 30 00 00 00 mov eax, 0x30
0x3FABF3 4C 8D 04 10 lea r8, [rax + rdx]
0x3FABF7 41 0F B7 78 08 movzx edi, word ptr [r8 + 8]
0x3FABFC 66 85 FF test di, di
0x3FABFF 0F 84 87 00 00 00 je 0x3fac8c
0x3FAC05 45 39 67 0C cmp dword ptr [r15 + 0xc], r12d
0x3FAC09 74 07 je 0x3fac12
0x3FAC0B 41 F6 40 04 02 test byte ptr [r8 + 4], 2
0x3FAC10 74 7A je 0x3fac8c
0x3FAC12 41 F6 40 04 01 test byte ptr [r8 + 4], 1
0x3FAC17 41 8B 4F 08 mov ecx, dword ptr [r15 + 8]
0x3FAC1B 41 8B 10 mov edx, dword ptr [r8]
0x3FAC1E 74 07 je 0x3fac27
0x3FAC20 41 0F B7 47 06 movzx eax, word ptr [r15 + 6]
0x3FAC25 EB 05 jmp 0x3fac2c
0x3FAC27 41 0F B7 47 04 movzx eax, word ptr [r15 + 4]
0x3FAC2C 03 C1 add eax, ecx
0x3FAC2E 3B C2 cmp eax, edx
0x3FAC30 72 55 jb 0x3fac87
0x3FAC32 2B D1 sub edx, ecx
0x3FAC34 49 8B CF mov rcx, r15
0x3FAC37 E8 00 F5 FF FF call 0x3fa13c
0x3FAC3C 8B D0 mov edx, eax
0x3FAC3E 49 8B C8 mov rcx, r8
0x3FAC41 E8 0A F5 FF FF call 0x3fa150
0x3FAC46 48 8B 8E D8 07 00 00 mov rcx, qword ptr [rsi + 0x7d8]
0x3FAC4D 44 8B C8 mov r9d, eax
0x3FAC50 44 0F B7 C7 movzx r8d, di
0x3FAC54 41 8B D4 mov edx, r12d
0x3FAC57 E8 44 CF 15 00 call 0x557ba0
0x3FAC5C 45 39 26 cmp dword ptr [r14], r12d
0x3FAC5F 74 26 je 0x3fac87
0x3FAC61 B8 BF D7 00 00 mov eax, 0xd7bf
0x3FAC66 66 3B F8 cmp di, ax
0x3FAC69 75 05 jne 0x3fac70
0x3FAC6B 45 85 E4 test r12d, r12d
0x3FAC6E 74 10 je 0x3fac80
0x3FAC70 B8 4B CB 00 00 mov eax, 0xcb4b
0x3FAC75 66 3B F8 cmp di, ax
0x3FAC78 75 0D jne 0x3fac87
0x3FAC7A 41 83 FC 01 cmp r12d, 1
0x3FAC7E 75 07 jne 0x3fac87
0x3FAC80 C6 86 D1 07 00 00 01 mov byte ptr [rsi + 0x7d1], 1
0x3FAC87 48 8B 54 24 68 mov rdx, qword ptr [rsp + 0x68]
0x3FAC8C FF C3 inc ebx
0x3FAC8E 83 FB 07 cmp ebx, 7
0x3FAC91 0F 82 40 FF FF FF jb 0x3fabd7
0x3FAC97 48 8B AE D8 07 00 00 mov rbp, qword ptr [rsi + 0x7d8]
0x3FAC9E 33 DB xor ebx, ebx
0x3FACA0 41 8B 3E mov edi, dword ptr [r14]
0x3FACA3 4C 8B CD mov r9, rbp
0x3FACA6 44 8B 5C 24 60 mov r11d, dword ptr [rsp + 0x60]
0x3FACAB 4C 8B 54 24 70 mov r10, qword ptr [rsp + 0x70]
0x3FACB0 8B D7 mov edx, edi
0x3FACB2 49 83 C2 44 add r10, 0x44
0x3FACB6 49 8B C9 mov rcx, r9
0x3FACB9 4C 89 54 24 70 mov qword ptr [rsp + 0x70], r10
0x3FACBE 41 FF C5 inc r13d
0x3FACC1 E8 9E 10 00 00 call 0x3fbd64
0x3FACC6 44 3B A8 54 11 00 00 cmp r13d, dword ptr [rax + 0x1154]
0x3FACCD 0F 8C 88 FE FF FF jl 0x3fab5b
0x3FACD3 49 83 C6 04 add r14, 4
0x3FACD7 48 8D 05 72 BA 57 03 lea rax, [rip + 0x357ba72]
0x3FACDE 4C 3B F0 cmp r14, rax
0x3FACE1 0F 85 FE FD FF FF jne 0x3faae5
0x3FACE7 48 8B 5C 24 78 mov rbx, qword ptr [rsp + 0x78]
0x3FACEC 48 83 C4 20 add rsp, 0x20
0x3FACF0 41 5F pop r15
0x3FACF2 41 5E pop r14
0x3FACF4 41 5D pop r13
0x3FACF6 41 5C pop r12
0x3FACF8 5F pop rdi
0x3FACF9 5E pop rsi
0x3FACFA 5D pop rbp
0x3FACFB C3 ret 
