0x376944 48 8B 81 D8 07 00 00 mov rax, qword ptr [rcx + 0x7d8]
0x37694B 48 85 C0 test rax, rax
0x37694E 75 08 jne 0x376958
0x376950 48 8B 41 08 mov rax, qword ptr [rcx + 8]
0x376954 8B 40 34 mov eax, dword ptr [rax + 0x34]
0x376957 C3 ret 
