0x5FE3CC 48 8B 89 D8 07 00 00 mov rcx, qword ptr [rcx + 0x7d8]
0x5FE3D3 48 85 C9 test rcx, rcx
0x5FE3D6 75 01 jne 0x5fe3d9
0x5FE3D8 C3 ret 
