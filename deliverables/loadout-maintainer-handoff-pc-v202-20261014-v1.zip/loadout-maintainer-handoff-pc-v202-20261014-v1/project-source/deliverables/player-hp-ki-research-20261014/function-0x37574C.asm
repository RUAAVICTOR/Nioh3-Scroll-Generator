0x37574C 48 83 EC 28 sub rsp, 0x28
0x375750 45 33 C9 xor r9d, r9d
0x375753 48 8D 41 2C lea rax, [rcx + 0x2c]
0x375757 41 BA 64 00 00 00 mov r10d, 0x64
0x37575D 41 8B D1 mov edx, r9d
0x375760 48 83 FA 06 cmp rdx, 6
0x375764 44 89 51 18 mov dword ptr [rcx + 0x18], r10d
0x375768 44 89 51 1C mov dword ptr [rcx + 0x1c], r10d
0x37576C 0F 83 95 01 00 00 jae 0x375907
0x375772 83 48 10 FF or dword ptr [rax + 0x10], 0xffffffff
0x375776 48 FF C2 inc rdx
0x375779 4C 89 48 F8 mov qword ptr [rax - 8], r9
0x37577D 4C 89 08 mov qword ptr [rax], r9
0x375780 4C 89 48 08 mov qword ptr [rax + 8], r9
0x375784 44 89 48 14 mov dword ptr [rax + 0x14], r9d
0x375788 44 89 48 30 mov dword ptr [rax + 0x30], r9d
0x37578C 66 44 89 48 34 mov word ptr [rax + 0x34], r9w
0x375791 48 83 C0 40 add rax, 0x40
0x375795 48 83 FA 06 cmp rdx, 6
0x375799 7C D1 jl 0x37576c
0x37579B 41 8B D1 mov edx, r9d
0x37579E 4C 8D 81 F4 01 00 00 lea r8, [rcx + 0x1f4]
0x3757A5 49 8B C1 mov rax, r9
0x3757A8 48 83 F8 09 cmp rax, 9
0x3757AC 0F 83 4F 01 00 00 jae 0x375901
0x3757B2 45 89 08 mov dword ptr [r8], r9d
0x3757B5 FF C2 inc edx
0x3757B7 49 83 C0 04 add r8, 4
0x3757BB 48 FF C0 inc rax
0x3757BE 83 FA 09 cmp edx, 9
0x3757C1 72 E5 jb 0x3757a8
0x3757C3 41 BB 00 00 80 3F mov r11d, 0x3f800000
0x3757C9 44 89 89 A4 01 00 00 mov dword ptr [rcx + 0x1a4], r9d
0x3757D0 BA 15 00 00 00 mov edx, 0x15
0x3757D5 44 89 99 A8 01 00 00 mov dword ptr [rcx + 0x1a8], r11d
0x3757DC 44 89 99 AC 01 00 00 mov dword ptr [rcx + 0x1ac], r11d
0x3757E3 48 8D 81 2C 02 00 00 lea rax, [rcx + 0x22c]
0x3757EA 44 8B C2 mov r8d, edx
0x3757ED 4C 89 89 B4 01 00 00 mov qword ptr [rcx + 0x1b4], r9
0x3757F4 4C 89 89 BC 01 00 00 mov qword ptr [rcx + 0x1bc], r9
0x3757FB 4C 89 89 C4 01 00 00 mov qword ptr [rcx + 0x1c4], r9
0x375802 44 89 91 CC 01 00 00 mov dword ptr [rcx + 0x1cc], r10d
0x375809 44 89 91 D0 01 00 00 mov dword ptr [rcx + 0x1d0], r10d
0x375810 44 89 91 D4 01 00 00 mov dword ptr [rcx + 0x1d4], r10d
0x375817 44 89 91 D8 01 00 00 mov dword ptr [rcx + 0x1d8], r10d
0x37581E 44 89 91 DC 01 00 00 mov dword ptr [rcx + 0x1dc], r10d
0x375825 44 89 91 E0 01 00 00 mov dword ptr [rcx + 0x1e0], r10d
0x37582C 44 89 91 E4 01 00 00 mov dword ptr [rcx + 0x1e4], r10d
0x375833 44 89 91 E8 01 00 00 mov dword ptr [rcx + 0x1e8], r10d
0x37583A 44 89 91 EC 01 00 00 mov dword ptr [rcx + 0x1ec], r10d
0x375841 44 89 91 F0 01 00 00 mov dword ptr [rcx + 0x1f0], r10d
0x375848 4C 89 89 18 02 00 00 mov qword ptr [rcx + 0x218], r9
0x37584F 66 44 89 89 20 02 00 00 mov word ptr [rcx + 0x220], r9w
0x375857 4C 89 48 F8 mov qword ptr [rax - 8], r9
0x37585B 4C 89 08 mov qword ptr [rax], r9
0x37585E 4C 89 48 08 mov qword ptr [rax + 8], r9
0x375862 4C 89 48 10 mov qword ptr [rax + 0x10], r9
0x375866 48 8D 40 20 lea rax, [rax + 0x20]
0x37586A 49 83 E8 01 sub r8, 1
0x37586E 75 E7 jne 0x375857
0x375870 33 C0 xor eax, eax
0x375872 0F 57 C0 xorps xmm0, xmm0
0x375875 0F 11 81 C4 04 00 00 movups xmmword ptr [rcx + 0x4c4], xmm0
0x37587C 48 89 81 D4 04 00 00 mov qword ptr [rcx + 0x4d4], rax
0x375883 48 8D 81 E4 04 00 00 lea rax, [rcx + 0x4e4]
0x37588A 4C 89 48 F8 mov qword ptr [rax - 8], r9
0x37588E 4C 89 08 mov qword ptr [rax], r9
0x375891 4C 89 48 08 mov qword ptr [rax + 8], r9
0x375895 4C 89 48 10 mov qword ptr [rax + 0x10], r9
0x375899 48 8D 40 20 lea rax, [rax + 0x20]
0x37589D 48 83 EA 01 sub rdx, 1
0x3758A1 75 E7 jne 0x37588a
0x3758A3 33 C0 xor eax, eax
0x3758A5 0F 57 C0 xorps xmm0, xmm0
0x3758A8 0F 11 81 7C 07 00 00 movups xmmword ptr [rcx + 0x77c], xmm0
0x3758AF 48 89 81 8C 07 00 00 mov qword ptr [rcx + 0x78c], rax
0x3758B6 44 89 89 94 07 00 00 mov dword ptr [rcx + 0x794], r9d
0x3758BD 44 89 91 98 07 00 00 mov dword ptr [rcx + 0x798], r10d
0x3758C4 44 89 91 9C 07 00 00 mov dword ptr [rcx + 0x79c], r10d
0x3758CB 44 89 99 A0 07 00 00 mov dword ptr [rcx + 0x7a0], r11d
0x3758D2 44 89 99 A4 07 00 00 mov dword ptr [rcx + 0x7a4], r11d
0x3758D9 4C 89 89 AC 07 00 00 mov qword ptr [rcx + 0x7ac], r9
0x3758E0 4C 89 89 B4 07 00 00 mov qword ptr [rcx + 0x7b4], r9
0x3758E7 48 8B 89 C0 07 00 00 mov rcx, qword ptr [rcx + 0x7c0]
0x3758EE 48 85 C9 test rcx, rcx
0x3758F1 75 05 jne 0x3758f8
0x3758F3 48 83 C4 28 add rsp, 0x28
0x3758F7 C3 ret 
0x3758F8 48 83 C4 28 add rsp, 0x28
0x3758FC E9 E3 D8 4F 00 jmp 0x8731e4
0x375901 E8 FA FF 8E 00 call 0xc65900
0x375906 CC int3 
0x375907 E8 08 00 8F 00 call 0xc65914
0x37590C CC int3 
