0x817364 48 8B 81 D8 07 00 00 mov rax, qword ptr [rcx + 0x7d8]
0x81736B 48 85 C0 test rax, rax
0x81736E 74 04 je 0x817374
0x817370 8B 40 10 mov eax, dword ptr [rax + 0x10]
0x817373 C3 ret 
