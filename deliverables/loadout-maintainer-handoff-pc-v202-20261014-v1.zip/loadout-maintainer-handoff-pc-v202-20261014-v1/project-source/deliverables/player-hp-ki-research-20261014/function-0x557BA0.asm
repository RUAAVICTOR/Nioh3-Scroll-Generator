0x557BA0 66 45 85 C0 test r8w, r8w
0x557BA4 0F 84 64 01 00 00 je 0x557d0e
0x557BAA 48 8B C4 mov rax, rsp
0x557BAD 48 89 58 08 mov qword ptr [rax + 8], rbx
0x557BB1 48 89 68 10 mov qword ptr [rax + 0x10], rbp
0x557BB5 48 89 70 18 mov qword ptr [rax + 0x18], rsi
0x557BB9 48 89 78 20 mov qword ptr [rax + 0x20], rdi
0x557BBD 41 54 push r12
0x557BBF 41 55 push r13
0x557BC1 41 56 push r14
0x557BC3 48 83 EC 30 sub rsp, 0x30
0x557BC7 48 8B 05 62 22 06 04 mov rax, qword ptr [rip + 0x4062262]
0x557BCE 8B F2 mov esi, edx
0x557BD0 48 8B D9 mov rbx, rcx
0x557BD3 41 0F B7 D0 movzx edx, r8w
0x557BD7 41 8B F9 mov edi, r9d
0x557BDA 41 0F B7 E8 movzx ebp, r8w
0x557BDE 45 33 F6 xor r14d, r14d
0x557BE1 4C 8B A8 A8 00 00 00 mov r13, qword ptr [rax + 0xa8]
0x557BE8 49 8B CD mov rcx, r13
0x557BEB E8 60 10 00 00 call 0x558c50
0x557BF0 4C 8B C8 mov r9, rax
0x557BF3 48 85 C0 test rax, rax
0x557BF6 0F 84 F4 00 00 00 je 0x557cf0
0x557BFC 48 8B C8 mov rcx, rax
0x557BFF E8 E4 FE FF FF call 0x557ae8
0x557C04 83 F8 07 cmp eax, 7
0x557C07 74 55 je 0x557c5e
0x557C09 49 8B C9 mov rcx, r9
0x557C0C E8 D7 FE FF FF call 0x557ae8
0x557C11 85 C0 test eax, eax
0x557C13 74 40 je 0x557c55
0x557C15 83 E8 01 sub eax, 1
0x557C18 74 36 je 0x557c50
0x557C1A 83 E8 01 sub eax, 1
0x557C1D 74 2C je 0x557c4b
0x557C1F 83 E8 01 sub eax, 1
0x557C22 74 22 je 0x557c46
0x557C24 83 E8 01 sub eax, 1
0x557C27 74 18 je 0x557c41
0x557C29 83 E8 01 sub eax, 1
0x557C2C 74 0E je 0x557c3c
0x557C2E 83 F8 01 cmp eax, 1
0x557C31 0F 85 B9 00 00 00 jne 0x557cf0
0x557C37 3B 7B 2C cmp edi, dword ptr [rbx + 0x2c]
0x557C3A EB 1C jmp 0x557c58
0x557C3C 3B 7B 28 cmp edi, dword ptr [rbx + 0x28]
0x557C3F EB 17 jmp 0x557c58
0x557C41 3B 7B 24 cmp edi, dword ptr [rbx + 0x24]
0x557C44 EB 12 jmp 0x557c58
0x557C46 3B 7B 20 cmp edi, dword ptr [rbx + 0x20]
0x557C49 EB 0D jmp 0x557c58
0x557C4B 3B 7B 1C cmp edi, dword ptr [rbx + 0x1c]
0x557C4E EB 08 jmp 0x557c58
0x557C50 3B 7B 18 cmp edi, dword ptr [rbx + 0x18]
0x557C53 EB 03 jmp 0x557c58
0x557C55 3B 7B 14 cmp edi, dword ptr [rbx + 0x14]
0x557C58 0F 8F 92 00 00 00 jg 0x557cf0
0x557C5E 8B D6 mov edx, esi
0x557C60 48 8B CB mov rcx, rbx
0x557C63 E8 F4 FE FF FF call 0x557b5c
0x557C68 48 8B D8 mov rbx, rax
0x557C6B 41 8B F6 mov esi, r14d
0x557C6E BA 01 00 00 00 mov edx, 1
0x557C73 44 39 B0 00 0C 00 00 cmp dword ptr [rax + 0xc00], r14d
0x557C7A 7E 34 jle 0x557cb0
0x557C7C 4C 8B F0 mov r14, rax
0x557C7F 45 0F B7 26 movzx r12d, word ptr [r14]
0x557C83 66 44 3B E5 cmp r12w, bp
0x557C87 75 16 jne 0x557c9f
0x557C89 0F B7 D5 movzx edx, bp
0x557C8C 49 8B CD mov rcx, r13
0x557C8F E8 BC 0F 00 00 call 0x558c50
0x557C94 48 8B C8 mov rcx, rax
0x557C97 48 85 C0 test rax, rax
0x557C9A 75 73 jne 0x557d0f
0x557C9C 8D 50 01 lea edx, [rax + 1]
0x557C9F 03 F2 add esi, edx
0x557CA1 49 83 C6 0C add r14, 0xc
0x557CA5 3B B3 00 0C 00 00 cmp esi, dword ptr [rbx + 0xc00]
0x557CAB 7C D2 jl 0x557c7f
0x557CAD 45 33 F6 xor r14d, r14d
0x557CB0 48 63 83 00 0C 00 00 movsxd rax, dword ptr [rbx + 0xc00]
0x557CB7 48 3D 00 01 00 00 cmp rax, 0x100
0x557CBD 73 31 jae 0x557cf0
0x557CBF 48 8D 0C 40 lea rcx, [rax + rax*2]
0x557CC3 66 89 6C 24 20 mov word ptr [rsp + 0x20], bp
0x557CC8 89 7C 24 24 mov dword ptr [rsp + 0x24], edi
0x557CCC F2 0F 10 44 24 20 movsd xmm0, qword ptr [rsp + 0x20]
0x557CD2 F2 0F 11 04 8B movsd qword ptr [rbx + rcx*4], xmm0
0x557CD7 66 44 89 74 24 28 mov word ptr [rsp + 0x28], r14w
0x557CDD 44 88 74 24 2A mov byte ptr [rsp + 0x2a], r14b
0x557CE2 8B 44 24 28 mov eax, dword ptr [rsp + 0x28]
0x557CE6 89 44 8B 08 mov dword ptr [rbx + rcx*4 + 8], eax
0x557CEA 01 93 00 0C 00 00 add dword ptr [rbx + 0xc00], edx
0x557CF0 48 8B 5C 24 50 mov rbx, qword ptr [rsp + 0x50]
0x557CF5 48 8B 6C 24 58 mov rbp, qword ptr [rsp + 0x58]
0x557CFA 48 8B 74 24 60 mov rsi, qword ptr [rsp + 0x60]
0x557CFF 48 8B 7C 24 68 mov rdi, qword ptr [rsp + 0x68]
0x557D04 48 83 C4 30 add rsp, 0x30
0x557D08 41 5E pop r14
0x557D0A 41 5D pop r13
0x557D0C 41 5C pop r12
0x557D0E C3 ret 
0x557D0F 48 63 C6 movsxd rax, esi
0x557D12 4C 8D 04 40 lea r8, [rax + rax*2]
0x557D16 B8 BA 38 00 00 mov eax, 0x38ba
0x557D1B 66 44 3B E0 cmp r12w, ax
0x557D1F 75 17 jne 0x557d38
0x557D21 42 0F B7 54 83 08 movzx edx, word ptr [rbx + r8*4 + 8]
0x557D27 42 03 54 83 04 add edx, dword ptr [rbx + r8*4 + 4]
0x557D2C 3B D7 cmp edx, edi
0x557D2E 0F 42 D7 cmovb edx, edi
0x557D31 42 89 54 83 04 mov dword ptr [rbx + r8*4 + 4], edx
0x557D36 EB B8 jmp 0x557cf0
0x557D38 F6 41 50 04 test byte ptr [rcx + 0x50], 4
0x557D3C 74 1C je 0x557d5a
0x557D3E 42 8B 44 83 04 mov eax, dword ptr [rbx + r8*4 + 4]
0x557D43 3B C7 cmp eax, edi
0x557D45 0F 42 C7 cmovb eax, edi
0x557D48 42 89 44 83 04 mov dword ptr [rbx + r8*4 + 4], eax
0x557D4D B8 01 00 00 00 mov eax, 1
0x557D52 66 42 01 44 83 08 add word ptr [rbx + r8*4 + 8], ax
0x557D58 EB 96 jmp 0x557cf0
0x557D5A 42 0F B7 54 83 08 movzx edx, word ptr [rbx + r8*4 + 8]
0x557D60 46 8B 4C 83 04 mov r9d, dword ptr [rbx + r8*4 + 4]
0x557D65 44 03 CA add r9d, edx
0x557D68 44 03 CF add r9d, edi
0x557D6B 46 89 4C 83 04 mov dword ptr [rbx + r8*4 + 4], r9d
0x557D70 8B 49 04 mov ecx, dword ptr [rcx + 4]
0x557D73 66 0F 6E C1 movd xmm0, ecx
0x557D77 0F 5B C0 cvtdq2ps xmm0, xmm0
0x557D7A 0F 2F 05 53 C4 67 03 comiss xmm0, dword ptr [rip + 0x367c453]
0x557D81 0F 82 69 FF FF FF jb 0x557cf0
0x557D87 42 8D 04 0A lea eax, [rdx + r9]
0x557D8B 3B C1 cmp eax, ecx
0x557D8D 0F 86 5D FF FF FF jbe 0x557cf0
0x557D93 42 89 4C 83 04 mov dword ptr [rbx + r8*4 + 4], ecx
0x557D98 E9 53 FF FF FF jmp 0x557cf0
