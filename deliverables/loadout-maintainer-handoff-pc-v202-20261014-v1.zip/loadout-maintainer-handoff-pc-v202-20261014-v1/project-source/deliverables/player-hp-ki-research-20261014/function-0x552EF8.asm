0x552EF8 4C 8B DC mov r11, rsp
0x552EFB 49 89 5B 18 mov qword ptr [r11 + 0x18], rbx
0x552EFF 49 89 73 20 mov qword ptr [r11 + 0x20], rsi
0x552F03 66 89 54 24 10 mov word ptr [rsp + 0x10], dx
0x552F08 49 89 4B 08 mov qword ptr [r11 + 8], rcx
0x552F0C 57 push rdi
0x552F0D 48 83 EC 30 sub rsp, 0x30
0x552F11 49 8D 43 10 lea rax, [r11 + 0x10]
0x552F15 33 DB xor ebx, ebx
0x552F17 49 89 43 E8 mov qword ptr [r11 - 0x18], rax
0x552F1B 48 8D 3D E6 5F 42 03 lea rdi, [rip + 0x3425fe6]
0x552F22 49 8D 43 08 lea rax, [r11 + 8]
0x552F26 49 89 43 F0 mov qword ptr [r11 - 0x10], rax
0x552F2A 83 64 24 40 00 and dword ptr [rsp + 0x40], 0
0x552F2F 48 8D 35 C2 5F 42 03 lea rsi, [rip + 0x3425fc2]
0x552F36 44 8B 07 mov r8d, dword ptr [rdi]
0x552F39 8B 16 mov edx, dword ptr [rsi]
0x552F3B 48 8B 0D EE E5 1F 04 mov rcx, qword ptr [rip + 0x41fe5ee]
0x552F42 E8 51 00 00 00 call 0x552f98
0x552F47 48 8B D0 mov rdx, rax
0x552F4A 48 8D 4C 24 20 lea rcx, [rsp + 0x20]
0x552F4F E8 7C 2F B2 00 call 0x1075ed0
0x552F54 48 8D 05 AD 5F 42 03 lea rax, [rip + 0x3425fad]
0x552F5B 48 83 C6 04 add rsi, 4
0x552F5F 48 3B F0 cmp rsi, rax
0x552F62 75 D2 jne 0x552f36
0x552F64 3B 5C 24 40 cmp ebx, dword ptr [rsp + 0x40]
0x552F68 48 8D 05 A1 5F 42 03 lea rax, [rip + 0x3425fa1]
0x552F6F 0F 4C 5C 24 40 cmovl ebx, dword ptr [rsp + 0x40]
0x552F74 48 83 C7 04 add rdi, 4
0x552F78 48 3B F8 cmp rdi, rax
0x552F7B 75 AD jne 0x552f2a
0x552F7D 48 8B 74 24 58 mov rsi, qword ptr [rsp + 0x58]
0x552F82 8B C3 mov eax, ebx
0x552F84 48 8B 5C 24 50 mov rbx, qword ptr [rsp + 0x50]
0x552F89 48 83 C4 30 add rsp, 0x30
0x552F8D 5F pop rdi
0x552F8E C3 ret 
