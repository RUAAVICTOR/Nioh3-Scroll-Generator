0x3771EC 48 8B C4 mov rax, rsp
0x3771EF 53 push rbx
0x3771F0 48 81 EC 80 00 00 00 sub rsp, 0x80
0x3771F7 0F 29 70 E8 movaps xmmword ptr [rax - 0x18], xmm6
0x3771FB 48 8B D9 mov rbx, rcx
0x3771FE 0F 29 78 D8 movaps xmmword ptr [rax - 0x28], xmm7
0x377202 44 0F 29 40 C8 movaps xmmword ptr [rax - 0x38], xmm8
0x377207 44 0F 29 48 B8 movaps xmmword ptr [rax - 0x48], xmm9
0x37720C 44 0F 29 50 A8 movaps xmmword ptr [rax - 0x58], xmm10
0x377211 44 0F 29 58 98 movaps xmmword ptr [rax - 0x68], xmm11
0x377216 E8 51 E9 D0 FF call 0x85b6c
0x37721B F3 0F 10 B1 50 36 00 00 movss xmm6, dword ptr [rcx + 0x3650]
0x377223 45 0F 57 D2 xorps xmm10, xmm10
0x377227 8B 49 20 mov ecx, dword ptr [rcx + 0x20]
0x37722A 8B 50 1C mov edx, dword ptr [rax + 0x1c]
0x37722D F3 4C 0F 2A D2 cvtsi2ss xmm10, rdx
0x377232 E8 D5 F9 FF FF call 0x376c0c
0x377237 48 8B 05 02 2C 24 04 mov rax, qword ptr [rip + 0x4242c02]
0x37723E F3 44 0F 10 05 99 CF 85 03 movss xmm8, dword ptr [rip + 0x385cf99]
0x377247 44 0F 28 D8 movaps xmm11, xmm0
0x37724B 48 8B 08 mov rcx, qword ptr [rax]
0x37724E 41 0F 28 F8 movaps xmm7, xmm8
0x377252 45 0F 57 C9 xorps xmm9, xmm9
0x377256 48 8B 81 98 16 00 00 mov rax, qword ptr [rcx + 0x1698]
0x37725D 48 2B 81 90 16 00 00 sub rax, qword ptr [rcx + 0x1690]
0x377264 48 C1 F8 02 sar rax, 2
0x377268 48 83 F8 02 cmp rax, 2
0x37726C 72 31 jb 0x37729f
0x37726E 48 8B 03 mov rax, qword ptr [rbx]
0x377271 48 85 C0 test rax, rax
0x377274 74 29 je 0x37729f
0x377276 F6 00 0F test byte ptr [rax], 0xf
0x377279 75 24 jne 0x37729f
0x37727B 80 B8 93 08 00 00 00 cmp byte ptr [rax + 0x893], 0
0x377282 74 1B je 0x37729f
0x377284 48 8B 0D A5 2B 24 04 mov rcx, qword ptr [rip + 0x4242ba5]
0x37728B BA 7B 97 00 00 mov edx, 0x977b
0x377290 48 8B 89 30 02 00 00 mov rcx, qword ptr [rcx + 0x230]
0x377297 E8 6C 12 29 00 call 0x608508
0x37729C 0F 28 F8 movaps xmm7, xmm0
0x37729F 48 8B CB mov rcx, rbx
0x3772A2 E8 CD E2 D0 FF call 0x85574
0x3772A7 48 8B C8 mov rcx, rax
0x3772AA E8 69 D2 2A 00 call 0x624518
0x3772AF 83 B8 00 06 00 00 00 cmp dword ptr [rax + 0x600], 0
0x3772B6 7C 60 jl 0x377318
0x3772B8 48 8B CB mov rcx, rbx
0x3772BB E8 B4 E2 D0 FF call 0x85574
0x3772C0 48 8B C8 mov rcx, rax
0x3772C3 E8 50 D2 2A 00 call 0x624518
0x3772C8 48 8D 8B 48 01 00 00 lea rcx, [rbx + 0x148]
0x3772CF E8 28 79 F8 FF call 0x2febfc
0x3772D4 F3 0F 59 05 34 D5 85 03 mulss xmm0, dword ptr [rip + 0x385d534]
0x3772DC BA E1 CB 00 00 mov edx, 0xcbe1
0x3772E1 48 8B 0D 48 2B 24 04 mov rcx, qword ptr [rip + 0x4242b48]
0x3772E8 44 8B 88 00 06 00 00 mov r9d, dword ptr [rax + 0x600]
0x3772EF F3 4C 0F 2C C0 cvttss2si r8, xmm0
0x3772F4 48 8B 89 18 07 00 00 mov rcx, qword ptr [rcx + 0x718]
0x3772FB E8 78 33 F8 FF call 0x2fa678
0x377300 0F 57 C9 xorps xmm1, xmm1
0x377303 F3 48 0F 2C C8 cvttss2si rcx, xmm0
0x377308 8B C9 mov ecx, ecx
0x37730A F3 48 0F 2A C9 cvtsi2ss xmm1, rcx
0x37730F F3 41 0F 58 C9 addss xmm1, xmm9
0x377314 44 0F 28 C9 movaps xmm9, xmm1
0x377318 F3 0F 10 83 B0 00 00 00 movss xmm0, dword ptr [rbx + 0xb0]
0x377320 F3 41 0F 59 F2 mulss xmm6, xmm10
0x377325 F3 41 0F 59 F3 mulss xmm6, xmm11
0x37732A F3 0F 59 F7 mulss xmm6, xmm7
0x37732E F3 41 0F 58 F1 addss xmm6, xmm9
0x377333 0F 2E C6 ucomiss xmm0, xmm6
0x377336 7A 02 jp 0x37733a
0x377338 74 2D je 0x377367
0x37733A 48 8B CB mov rcx, rbx
0x37733D F3 0F 11 B3 B0 00 00 00 movss dword ptr [rbx + 0xb0], xmm6
0x377345 E8 22 E8 D0 FF call 0x85b6c
0x37734A 44 0F 2F C7 comiss xmm8, xmm7
0x37734E 8B 48 20 mov ecx, dword ptr [rax + 0x20]
0x377351 0F 57 C0 xorps xmm0, xmm0
0x377354 F3 48 0F 2A C1 cvtsi2ss xmm0, rcx
0x377359 76 04 jbe 0x37735f
0x37735B F3 0F 59 C7 mulss xmm0, xmm7
0x37735F F3 0F 11 83 B4 00 00 00 movss dword ptr [rbx + 0xb4], xmm0
0x377367 0F 28 74 24 70 movaps xmm6, xmmword ptr [rsp + 0x70]
0x37736C 0F 28 7C 24 60 movaps xmm7, xmmword ptr [rsp + 0x60]
0x377371 44 0F 28 44 24 50 movaps xmm8, xmmword ptr [rsp + 0x50]
0x377377 44 0F 28 4C 24 40 movaps xmm9, xmmword ptr [rsp + 0x40]
0x37737D 44 0F 28 54 24 30 movaps xmm10, xmmword ptr [rsp + 0x30]
0x377383 44 0F 28 5C 24 20 movaps xmm11, xmmword ptr [rsp + 0x20]
0x377389 48 81 C4 80 00 00 00 add rsp, 0x80
0x377390 5B pop rbx
0x377391 C3 ret 
