"""Bounded passive player resource snapshot; no debugger, writes or save access."""
import argparse
import hashlib
import json
import struct
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "deliverables/load-capacity-research/scripts")]
from scan_capacity import _identity
from capture_player import PLAYER_POINTER_RVA, PLAYER_VTABLE_RVA
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from research.enemy_states_v201.capture_tables import BudgetReader
from reference import EXE_SHA256, calculate, load_table


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--locator",type=Path)
    parser.add_argument("--expected-hp",type=int,default=880)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    report = dict(schema="nioh3-player-resource-passive-capture/v1",
                  captured_at_utc=datetime.now(timezone.utc).isoformat(),
                  question="Reconstruct level-1 player HP/Ki after removing Kato's Life Reflection (Stamina)",
                  owner_observation=dict(level=1, attributes=[5,5,5,6,5,5,5],
                                         maximum_hp=args.expected_hp, maximum_ki=960,
                                         modifier_presence="unknown"),
                  bounds=dict(max_bytes=262144, max_seconds=15),
                  status="exploratory", blobs=[], game_writes=0, debugger_used=False,
                  game_function_calls=0, save_access=False)
    stable = []
    def retain(reader, name, address, size):
        raw = reader.read(address, size)
        (args.output / name).write_bytes(raw)
        report["blobs"].append(dict(file=name, address=hex(address), size=size,
                                     sha256=hashlib.sha256(raw).hexdigest()))
        return raw
    def watch(reader, address, size):
        raw = reader.read(address, size)
        stable.append((address, raw))
        return raw
    def pointer(reader, address):
        return int.from_bytes(watch(reader, address, 8), "little")
    try:
        with ProcessReader() as process:
            identity = _identity(process)
            report["identity"] = identity
            if identity["executable_sha256"] != EXE_SHA256:
                raise ValueError("Unsupported executable hash")
            reader = BudgetReader(process, max_bytes=262144, max_seconds=15)
            base = process.module_base
            native = ROOT / "deliverables/load-capacity-research/disassembly/live-sections/Nioh3_v2.0.2.0.text.bin"
            text = native.read_bytes()
            if hashlib.sha256(text).hexdigest() != "4cec8fb6ad867417a76df8201c1d4f54172443884910463c1953acad91ae6c29":
                raise ValueError("Retained code hash mismatch")
            report["signatures"] = []
            for rva in (0x818B68,0x8181A4,0x818AEC,0x85B6C,0xBE108,0x3771EC):
                expected = text[rva-0x1000:rva-0x1000+16]
                actual = reader.read(base+rva, 16)
                report["signatures"].append(dict(rva=hex(rva), expected=expected.hex(), actual=actual.hex()))
                if expected != actual:
                    raise ValueError("Native signature mismatch")
            player = pointer(reader, base+PLAYER_POINTER_RVA)
            if pointer(reader, player) != base+PLAYER_VTABLE_RVA:
                raise ValueError("Player vtable mismatch")
            attrs = struct.unpack("<7I", watch(reader, player+0x94, 28))
            level = int.from_bytes(watch(reader, player+0x69DC, 4), "little")
            report["player"] = dict(address=hex(player), level=level, allocated_attributes=attrs)
            retain(reader,"allocated-attributes.bin",player+0x94,28)
            if level != 1 or attrs != (5,5,5,6,5,5,5):
                raise ValueError("Owner control vector differs from live player")
            # Historical BSAddress chain is an exploratory locator, not an
            # identity proof. Validate resource values and the actor backlink.
            if args.locator:
                locator=json.loads(args.locator.read_text())
                if locator["identity"]!=identity:raise ValueError("Locator process identity changed")
                owners={int(c["owner"],16) for c in locator["candidates"] if c.get("matches_control")}
                if len(owners)!=1:raise ValueError("Ambiguous control-vector status owner")
                hp_interface=owners.pop()+0x38
                report["resource_locator"]=dict(source=str(args.locator),hp_interface=hex(hp_interface),
                    qualification="unique matching owner in bounded vtable scan; backlink/output checks required")
            else:
                root = pointer(reader, base+0x45D6C18)
                middle = pointer(reader, root+0x50)
                hp_interface = pointer(reader, middle+0x198)
                report["resource_locator"] = dict(global_rva="0x45d6c18", root=hex(root),
                    middle=hex(middle), hp_interface=hex(hp_interface), qualification="candidate")
            interface = retain(reader,"resource-interface.bin",hp_interface,0x100)
            maximum_hp = struct.unpack_from("<Q",interface,0x18)[0]
            maximum_ki = struct.unpack_from("<f",interface,0x78)[0]
            report["candidate_outputs"] = dict(maximum_hp=maximum_hp, maximum_ki=maximum_ki)
            if maximum_hp != args.expected_hp or maximum_ki != 960:
                raise ValueError("Historical resource locator does not match owner UI vector")
            status = hp_interface-0x38
            actor = pointer(reader,status)
            if pointer(reader,actor+0x3A0) != status:
                raise ValueError("Resource status/actor backlink mismatch")
            status_raw = retain(reader,"status.bin",status,0x3800)
            external = pointer(reader,status+0x2D90)
            stat = external or status+0x25A8
            stat_raw = retain(reader,"selected-stat.bin",stat,0x7E0)
            owner = pointer(reader,stat+8)
            backing = pointer(reader,stat+0x7D8)
            backing_raw = retain(reader,"stat-backing.bin",backing,0x58B0)
            effective = struct.unpack_from("<7I",backing_raw,0x34)
            effective_level = struct.unpack_from("<I",backing_raw,0x30)[0]
            selected_hp,selected_ki = struct.unpack_from("<II",stat_raw,0x18)
            report["joined"] = dict(actor=hex(actor),status=hex(status),stat=hex(stat),
                external_stat=bool(external),owner=hex(owner),backing=hex(backing),
                effective_attributes=effective,effective_level=effective_level,
                selected_hp=selected_hp,selected_ki=selected_ki,
                backing_hp_bonus=struct.unpack_from("<I",backing_raw,0x5880)[0],
                hp_factors={hex(o):struct.unpack_from("<f",status_raw,o)[0] for o in (0x3648,0x364C,0x30BC)},
                ki_factor=struct.unpack_from("<f",status_raw,0x3650)[0],
                native_type=struct.unpack_from("<I",status_raw,0x20)[0],
                owner_style=struct.unpack("<I",watch(reader,owner+0x2C,4))[0])
            modifier = pointer(reader,stat+0x7C0)
            if modifier:
                modifier_raw = retain(reader,"modifier.bin",modifier,0x620)
                report["joined"]["ki_additive_gate"] = struct.unpack_from("<i",modifier_raw,0x600)[0]
            manager = pointer(reader,base+0x45B9E30)
            wrapper = pointer(reader,manager+0x90)
            table = pointer(reader,wrapper)
            count = struct.unpack("<I",watch(reader,table+4,4))[0]
            if not 1000 <= count <= 1001:
                raise ValueError("Attribute-table count outside bound")
            raw_table = retain(reader,"attribute-table.bin",table,8+32*count)
            historic_rows,historic_metadata = load_table()
            if hashlib.sha256(raw_table).hexdigest() != historic_metadata["table_sha256"]:
                raise ValueError("Current attribute table differs from retained table")
            report["base_replay"] = calculate(historic_rows,level=effective_level,
                constitution=effective[0],heart=effective[1],stamina=effective[2])
            # Retain exact repeated values for the measured output/inputs.
            for address,size in ((status+0x50,8),(status+0xB0,4),(stat+0x18,8),
                                 (backing+0x30,32),(backing+0x5880,4)):
                watch(reader,address,size)
            if process.creation_time() != identity["process_birth_filetime"]:
                raise ValueError("Process birth changed")
            for address,raw in stable:
                if reader.read(address,len(raw)) != raw:
                    raise ValueError("Selected pointer/input/output changed during capture")
            report["remaining_read_budget"] = reader.remaining
            report["status"] = "complete_passive_snapshot"
            report["qualification"] = "Current player allocated vector, candidate resource outputs, actor/status backlink and selected effective attributes; no traced writer or independent actor-role identity"
    except Exception as error:
        report["status"] = "failed_closed"
        report["failure"] = dict(type=type(error).__name__,message=str(error))
        raise
    finally:
        report["cleanup"] = "Read-only process handle closed; no debugger, breakpoints, timers or game writes created"
        (args.output/"capture.json").write_text(json.dumps(report,indent=2)+"\n")
        print(json.dumps({key:report[key] for key in ("status","player","candidate_outputs","joined","base_replay","failure") if key in report}))


if __name__ == "__main__":
    main()
