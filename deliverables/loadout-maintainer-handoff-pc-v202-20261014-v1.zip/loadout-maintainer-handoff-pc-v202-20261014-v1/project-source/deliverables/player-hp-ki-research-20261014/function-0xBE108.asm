0xBE108 48 89 5C 24 08 mov qword ptr [rsp + 8], rbx
0xBE10D 48 89 74 24 10 mov qword ptr [rsp + 0x10], rsi
0xBE112 57 push rdi
0xBE113 48 83 EC 20 sub rsp, 0x20
0xBE117 48 8B F9 mov rdi, rcx
0xBE11A E8 4D 7A FC FF call 0x85b6c
0xBE11F 48 8B 31 mov rsi, qword ptr [rcx]
0xBE122 8B 58 18 mov ebx, dword ptr [rax + 0x18]
0xBE125 48 85 F6 test rsi, rsi
0xBE128 0F 84 C2 00 00 00 je 0xbe1f0
0xBE12E F6 06 0F test byte ptr [rsi], 0xf
0xBE131 0F 85 B9 00 00 00 jne 0xbe1f0
0xBE137 48 8B CE mov rcx, rsi
0xBE13A E8 85 5E 03 00 call 0xf3fc4
0xBE13F 48 85 C0 test rax, rax
0xBE142 0F 85 A8 00 00 00 jne 0xbe1f0
0xBE148 8B 4F 20 mov ecx, dword ptr [rdi + 0x20]
0xBE14B E8 6C 5A 86 00 call 0x923bbc
0xBE150 8B 57 20 mov edx, dword ptr [rdi + 0x20]
0xBE153 0F 28 D0 movaps xmm2, xmm0
0xBE156 8A 8E 95 08 00 00 mov cl, byte ptr [rsi + 0x895]
0xBE15C E8 27 BA 86 00 call 0x929b88
0xBE161 48 8B 05 D8 BC 4F 04 mov rax, qword ptr [rip + 0x44fbcd8]
0xBE168 0F 28 D8 movaps xmm3, xmm0
0xBE16B F3 0F 10 05 6D 60 B1 03 movss xmm0, dword ptr [rip + 0x3b1606d]
0xBE173 48 8B 08 mov rcx, qword ptr [rax]
0xBE176 48 8B 81 98 16 00 00 mov rax, qword ptr [rcx + 0x1698]
0xBE17D 48 2B 81 90 16 00 00 sub rax, qword ptr [rcx + 0x1690]
0xBE184 48 C1 F8 02 sar rax, 2
0xBE188 48 83 F8 02 cmp rax, 2
0xBE18C 0F 83 62 3B 87 01 jae 0x1931cf4
0xBE192 0F 57 C9 xorps xmm1, xmm1
0xBE195 48 85 DB test rbx, rbx
0xBE198 78 7A js 0xbe214
0xBE19A F3 48 0F 2A CB cvtsi2ss xmm1, rbx
0xBE19F F3 0F 59 8F 48 36 00 00 mulss xmm1, dword ptr [rdi + 0x3648]
0xBE1A7 33 C0 xor eax, eax
0xBE1A9 F3 0F 59 8F 4C 36 00 00 mulss xmm1, dword ptr [rdi + 0x364c]
0xBE1B1 F3 0F 59 8F BC 30 00 00 mulss xmm1, dword ptr [rdi + 0x30bc]
0xBE1B9 F3 0F 59 CA mulss xmm1, xmm2
0xBE1BD F3 0F 59 CB mulss xmm1, xmm3
0xBE1C1 F3 0F 59 C8 mulss xmm1, xmm0
0xBE1C5 F3 0F 10 05 4F 61 B1 03 movss xmm0, dword ptr [rip + 0x3b1614f]
0xBE1CD 0F 2F C8 comiss xmm1, xmm0
0xBE1D0 72 16 jb 0xbe1e8
0xBE1D2 F3 0F 5C C8 subss xmm1, xmm0
0xBE1D6 0F 2F C8 comiss xmm1, xmm0
0xBE1D9 73 0D jae 0xbe1e8
0xBE1DB 48 B9 00 00 00 00 00 00 00 80 movabs rcx, 0x8000000000000000
0xBE1E5 48 8B C1 mov rax, rcx
0xBE1E8 F3 48 0F 2C D9 cvttss2si rbx, xmm1
0xBE1ED 48 03 D8 add rbx, rax
0xBE1F0 48 39 5F 50 cmp qword ptr [rdi + 0x50], rbx
0xBE1F4 75 10 jne 0xbe206
0xBE1F6 48 8B 5C 24 30 mov rbx, qword ptr [rsp + 0x30]
0xBE1FB 48 8B 74 24 38 mov rsi, qword ptr [rsp + 0x38]
0xBE200 48 83 C4 20 add rsp, 0x20
0xBE204 5F pop rdi
0xBE205 C3 ret 
0xBE206 48 8D 4F 38 lea rcx, [rdi + 0x38]
0xBE20A 48 8B D3 mov rdx, rbx
0xBE20D E8 EA 29 8C 00 call 0x980bfc
0xBE212 EB E2 jmp 0xbe1f6
0xBE214 48 8B C3 mov rax, rbx
0xBE217 83 E3 01 and ebx, 1
0xBE21A 48 D1 E8 shr rax, 1
0xBE21D 48 0B C3 or rax, rbx
0xBE220 F3 48 0F 2A C8 cvtsi2ss xmm1, rax
0xBE225 F3 0F 58 C9 addss xmm1, xmm1
0xBE229 E9 71 FF FF FF jmp 0xbe19f
