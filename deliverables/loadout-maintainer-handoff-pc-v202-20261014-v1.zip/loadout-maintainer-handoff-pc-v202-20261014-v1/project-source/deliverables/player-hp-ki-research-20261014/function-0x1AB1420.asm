0x1AB1420 48 89 5C 24 08 mov qword ptr [rsp + 8], rbx
0x1AB1425 57 push rdi
0x1AB1426 48 83 EC 20 sub rsp, 0x20
0x1AB142A 8B DA mov ebx, edx
0x1AB142C 48 8B F9 mov rdi, rcx
0x1AB142F E8 24 F5 FF FF call 0x1ab0958
0x1AB1434 F6 C3 01 test bl, 1
0x1AB1437 74 0D je 0x1ab1446
0x1AB1439 BA C0 00 00 00 mov edx, 0xc0
0x1AB143E 48 8B CF mov rcx, rdi
0x1AB1441 E8 B2 06 0E FF call 0xb91af8
0x1AB1446 48 8B 5C 24 30 mov rbx, qword ptr [rsp + 0x30]
0x1AB144B 48 8B C7 mov rax, rdi
0x1AB144E 48 83 C4 20 add rsp, 0x20
0x1AB1452 5F pop rdi
0x1AB1453 C3 ret 
