0x818B68 48 89 5C 24 18 mov qword ptr [rsp + 0x18], rbx
0x818B6D 48 89 74 24 20 mov qword ptr [rsp + 0x20], rsi
0x818B72 55 push rbp
0x818B73 57 push rdi
0x818B74 41 55 push r13
0x818B76 41 56 push r14
0x818B78 41 57 push r15
0x818B7A 48 8D AC 24 20 E0 FF FF lea rbp, [rsp - 0x1fe0]
0x818B82 B8 E0 20 00 00 mov eax, 0x20e0
0x818B87 E8 84 97 37 00 call 0xb92310
0x818B8C 48 2B E0 sub rsp, rax
0x818B8F 48 8B 05 9A F3 C9 03 mov rax, qword ptr [rip + 0x3c9f39a]
0x818B96 48 33 C4 xor rax, rsp
0x818B99 48 89 85 D0 1F 00 00 mov qword ptr [rbp + 0x1fd0], rax
0x818BA0 4C 8B 71 08 mov r14, qword ptr [rcx + 8]
0x818BA4 48 8B DA mov rbx, rdx
0x818BA7 48 8B F9 mov rdi, rcx
0x818BAA 4D 85 F6 test r14, r14
0x818BAD 0F 84 22 08 00 00 je 0x8193d5
0x818BB3 4D 8B 7E 18 mov r15, qword ptr [r14 + 0x18]
0x818BB7 4D 85 FF test r15, r15
0x818BBA 0F 84 15 08 00 00 je 0x8193d5
0x818BC0 49 8D 96 90 05 00 00 lea rdx, [r14 + 0x590]
0x818BC7 41 B8 18 20 00 00 mov r8d, 0x2018
0x818BCD 48 8D 4D B0 lea rcx, [rbp - 0x50]
0x818BD1 E8 7A B6 37 00 call 0xb94250
0x818BD6 48 8B 53 08 mov rdx, qword ptr [rbx + 8]
0x818BDA 48 85 D2 test rdx, rdx
0x818BDD 74 09 je 0x818be8
0x818BDF 48 8D 4D B0 lea rcx, [rbp - 0x50]
0x818BE3 E8 64 7E 29 01 call 0x1ab0a4c
0x818BE8 48 8D 4C 24 60 lea rcx, [rsp + 0x60]
0x818BED E8 16 E7 FF FF call 0x817308
0x818BF2 48 8B 43 18 mov rax, qword ptr [rbx + 0x18]
0x818BF6 48 85 C0 test rax, rax
0x818BF9 74 27 je 0x818c22
0x818BFB 0F 10 00 movups xmm0, xmmword ptr [rax]
0x818BFE 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x818C02 0F 29 44 24 60 movaps xmmword ptr [rsp + 0x60], xmm0
0x818C07 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x818C0B 0F 29 4C 24 70 movaps xmmword ptr [rsp + 0x70], xmm1
0x818C10 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x818C14 8B 40 40 mov eax, dword ptr [rax + 0x40]
0x818C17 0F 29 45 80 movaps xmmword ptr [rbp - 0x80], xmm0
0x818C1B 0F 29 4D 90 movaps xmmword ptr [rbp - 0x70], xmm1
0x818C1F 89 45 A0 mov dword ptr [rbp - 0x60], eax
0x818C22 48 8B CF mov rcx, rdi
0x818C25 E8 22 CB B5 FF call 0x37574c
0x818C2A 48 8B CF mov rcx, rdi
0x818C2D E8 32 E7 FF FF call 0x817364
0x818C32 48 8B 8F D8 07 00 00 mov rcx, qword ptr [rdi + 0x7d8]
0x818C39 48 85 C9 test rcx, rcx
0x818C3C 74 03 je 0x818c41
0x818C3E 89 41 30 mov dword ptr [rcx + 0x30], eax
0x818C41 48 8B CF mov rcx, rdi
0x818C44 E8 6B 2D AE FF call 0x2fb9b4
0x818C49 48 8B D0 mov rdx, rax
0x818C4C E8 3B E7 FF FF call 0x81738c
0x818C51 48 8B 8F D8 07 00 00 mov rcx, qword ptr [rdi + 0x7d8]
0x818C58 41 83 CD FF or r13d, 0xffffffff
0x818C5C 48 85 C9 test rcx, rcx
0x818C5F 74 27 je 0x818c88
0x818C61 66 44 89 69 50 mov word ptr [rcx + 0x50], r13w
0x818C66 48 8B 87 D8 07 00 00 mov rax, qword ptr [rdi + 0x7d8]
0x818C6D 48 85 C0 test rax, rax
0x818C70 74 16 je 0x818c88
0x818C72 66 44 89 68 52 mov word ptr [rax + 0x52], r13w
0x818C77 48 8B 87 D8 07 00 00 mov rax, qword ptr [rdi + 0x7d8]
0x818C7E 48 85 C0 test rax, rax
0x818C81 74 05 je 0x818c88
0x818C83 66 44 89 68 54 mov word ptr [rax + 0x54], r13w
0x818C88 80 7F 10 00 cmp byte ptr [rdi + 0x10], 0
0x818C8C 0F 84 9C 01 00 00 je 0x818e2e
0x818C92 49 8B CE mov rcx, r14
0x818C95 E8 F2 9D D3 FF call 0x552a8c
0x818C9A 8B C8 mov ecx, eax
0x818C9C E8 03 9E D3 FF call 0x552aa4
0x818CA1 84 C0 test al, al
0x818CA3 0F 84 85 01 00 00 je 0x818e2e
0x818CA9 48 8B CF mov rcx, rdi
0x818CAC E8 B3 E6 FF FF call 0x817364
0x818CB1 8B D8 mov ebx, eax
0x818CB3 E8 2C 7B D3 FF call 0x5507e4
0x818CB8 0F B7 C8 movzx ecx, ax
0x818CBB 3B D9 cmp ebx, ecx
0x818CBD 0F 86 5C 01 00 00 jbe 0x818e1f
0x818CC3 E8 1C 7B D3 FF call 0x5507e4
0x818CC8 0F B7 C8 movzx ecx, ax
0x818CCB 48 8B 87 D8 07 00 00 mov rax, qword ptr [rdi + 0x7d8]
0x818CD2 48 85 C0 test rax, rax
0x818CD5 74 03 je 0x818cda
0x818CD7 89 48 30 mov dword ptr [rax + 0x30], ecx
0x818CDA E8 49 7B D3 FF call 0x550828
0x818CDF 48 8B 8F D8 07 00 00 mov rcx, qword ptr [rdi + 0x7d8]
0x818CE6 48 85 C9 test rcx, rcx
0x818CE9 74 04 je 0x818cef
0x818CEB 66 89 41 50 mov word ptr [rcx + 0x50], ax
0x818CEF E8 E8 7B D3 FF call 0x5508dc
0x818CF4 84 C0 test al, al
0x818CF6 74 07 je 0x818cff
0x818CF8 E8 7B CC 3F 01 call 0x1c15978
0x818CFD EB 05 jmp 0x818d04
0x818CFF E8 68 7B D3 FF call 0x55086c
0x818D04 0F B7 C8 movzx ecx, ax
0x818D07 48 8B 87 D8 07 00 00 mov rax, qword ptr [rdi + 0x7d8]
0x818D0E 48 85 C0 test rax, rax
0x818D11 74 04 je 0x818d17
0x818D13 66 89 48 52 mov word ptr [rax + 0x52], cx
0x818D17 E8 18 CC 3F 01 call 0x1c15934
0x818D1C 48 8B 8F D8 07 00 00 mov rcx, qword ptr [rdi + 0x7d8]
0x818D23 44 0F B7 C8 movzx r9d, ax
0x818D27 48 85 C9 test rcx, rcx
0x818D2A 74 04 je 0x818d30
0x818D2C 66 89 41 54 mov word ptr [rcx + 0x54], ax
0x818D30 48 8B CF mov rcx, rdi
0x818D33 E8 0C DC B5 FF call 0x376944
0x818D38 8B C8 mov ecx, eax
0x818D3A 0F 57 D2 xorps xmm2, xmm2
0x818D3D F3 48 0F 2A D1 cvtsi2ss xmm2, rcx
0x818D42 48 8B CF mov rcx, rdi
0x818D45 E8 1A E6 FF FF call 0x817364
0x818D4A 8B C8 mov ecx, eax
0x818D4C 33 C0 xor eax, eax
0x818D4E 48 89 44 24 48 mov qword ptr [rsp + 0x48], rax
0x818D53 33 D2 xor edx, edx
0x818D55 0F 57 C0 xorps xmm0, xmm0
0x818D58 89 44 24 50 mov dword ptr [rsp + 0x50], eax
0x818D5C 0F 57 C9 xorps xmm1, xmm1
0x818D5F F3 48 0F 2A C1 cvtsi2ss xmm0, rcx
0x818D64 0F 11 4C 24 38 movups xmmword ptr [rsp + 0x38], xmm1
0x818D69 F3 0F 5E D0 divss xmm2, xmm0
0x818D6D 48 8B CF mov rcx, rdi
0x818D70 E8 3F 2C AE FF call 0x2fb9b4
0x818D75 8B 0C 90 mov ecx, dword ptr [rax + rdx*4]
0x818D78 83 E9 05 sub ecx, 5
0x818D7B 66 0F 6E C1 movd xmm0, ecx
0x818D7F 0F 5B C0 cvtdq2ps xmm0, xmm0
0x818D82 F3 0F 59 C2 mulss xmm0, xmm2
0x818D86 F3 0F 2C C0 cvttss2si eax, xmm0
0x818D8A 89 44 94 38 mov dword ptr [rsp + rdx*4 + 0x38], eax
0x818D8E 48 FF C2 inc rdx
0x818D91 48 83 FA 07 cmp rdx, 7
0x818D95 7C D6 jl 0x818d6d
0x818D97 33 D2 xor edx, edx
0x818D99 33 C0 xor eax, eax
0x818D9B 03 54 84 38 add edx, dword ptr [rsp + rax*4 + 0x38]
0x818D9F 48 FF C0 inc rax
0x818DA2 48 83 F8 07 cmp rax, 7
0x818DA6 7C F3 jl 0x818d9b
0x818DA8 48 8B CF mov rcx, rdi
0x818DAB E8 94 DB B5 FF call 0x376944
0x818DB0 44 8B C0 mov r8d, eax
0x818DB3 33 C9 xor ecx, ecx
0x818DB5 44 2B C2 sub r8d, edx
0x818DB8 45 85 C0 test r8d, r8d
0x818DBB 7E 15 jle 0x818dd2
0x818DBD 8B D1 mov edx, ecx
0x818DBF 83 E2 07 and edx, 7
0x818DC2 83 FA 07 cmp edx, 7
0x818DC5 73 04 jae 0x818dcb
0x818DC7 FF 44 94 38 inc dword ptr [rsp + rdx*4 + 0x38]
0x818DCB FF C1 inc ecx
0x818DCD 41 3B C8 cmp ecx, r8d
0x818DD0 7C EB jl 0x818dbd
0x818DD2 33 C0 xor eax, eax
0x818DD4 83 44 84 38 05 add dword ptr [rsp + rax*4 + 0x38], 5
0x818DD9 48 FF C0 inc rax
0x818DDC 48 83 F8 07 cmp rax, 7
0x818DE0 7C F2 jl 0x818dd4
0x818DE2 48 8D 54 24 38 lea rdx, [rsp + 0x38]
0x818DE7 48 8B CF mov rcx, rdi
0x818DEA E8 9D E5 FF FF call 0x81738c
0x818DEF 48 8B 8F D8 07 00 00 mov rcx, qword ptr [rdi + 0x7d8]
0x818DF6 48 85 C9 test rcx, rcx
0x818DF9 74 24 je 0x818e1f
0x818DFB 48 83 C1 58 add rcx, 0x58
0x818DFF 45 33 C0 xor r8d, r8d
0x818E02 41 8A D0 mov dl, r8b
0x818E05 E8 8A D8 0F 00 call 0x916694
0x818E0A 66 44 3B 48 04 cmp r9w, word ptr [rax + 4]
0x818E0F 73 05 jae 0x818e16
0x818E11 66 44 89 48 04 mov word ptr [rax + 4], r9w
0x818E16 41 FF C0 inc r8d
0x818E19 41 83 F8 02 cmp r8d, 2
0x818E1D 7C E3 jl 0x818e02
0x818E1F 48 8B CF mov rcx, rdi
0x818E22 E8 1D DB B5 FF call 0x376944
0x818E27 8B D0 mov edx, eax
0x818E29 E8 C2 39 2A 01 call 0x1abc7f0
0x818E2E 49 8B D6 mov rdx, r14
0x818E31 48 8D 4C 24 30 lea rcx, [rsp + 0x30]
0x818E36 E8 61 DA B5 FF call 0x37689c
0x818E3B 48 8B CF mov rcx, rdi
0x818E3E E8 09 FD FF FF call 0x818b4c
0x818E43 44 8B 48 08 mov r9d, dword ptr [rax + 8]
0x818E47 E8 00 FD FF FF call 0x818b4c
0x818E4C 44 8B 00 mov r8d, dword ptr [rax]
0x818E4F E8 F0 DA B5 FF call 0x376944
0x818E54 8B D0 mov edx, eax
0x818E56 E8 49 F3 FF FF call 0x8181a4
0x818E5B 48 8D 54 24 30 lea rdx, [rsp + 0x30]
0x818E60 89 47 18 mov dword ptr [rdi + 0x18], eax
0x818E63 49 8B CF mov rcx, r15
0x818E66 E8 C5 D6 B5 FF call 0x376530
0x818E6B 8B 47 18 mov eax, dword ptr [rdi + 0x18]
0x818E6E 0F 57 C9 xorps xmm1, xmm1
0x818E71 48 8B CF mov rcx, rdi
0x818E74 F3 48 0F 2A C8 cvtsi2ss xmm1, rax
0x818E79 F3 0F 59 C1 mulss xmm0, xmm1
0x818E7D F3 48 0F 2C C0 cvttss2si rax, xmm0
0x818E82 89 47 18 mov dword ptr [rdi + 0x18], eax
0x818E85 E8 C2 FC FF FF call 0x818b4c
0x818E8A 48 8B 35 9F 0F DA 03 mov rsi, qword ptr [rip + 0x3da0f9f]
0x818E91 8B 50 04 mov edx, dword ptr [rax + 4]
0x818E94 48 8B 8E 90 00 00 00 mov rcx, qword ptr [rsi + 0x90]
0x818E9B E8 4C FC FF FF call 0x818aec
0x818EA0 48 85 C0 test rax, rax
0x818EA3 74 32 je 0x818ed7
0x818EA5 0F B7 40 04 movzx eax, word ptr [rax + 4]
0x818EA9 48 8D 54 24 30 lea rdx, [rsp + 0x30]
0x818EAE 49 8B CF mov rcx, r15
0x818EB1 89 47 1C mov dword ptr [rdi + 0x1c], eax
0x818EB4 E8 DF D7 B5 FF call 0x376698
0x818EB9 8B 47 1C mov eax, dword ptr [rdi + 0x1c]
0x818EBC 0F 57 C9 xorps xmm1, xmm1
0x818EBF 48 8B 35 6A 0F DA 03 mov rsi, qword ptr [rip + 0x3da0f6a]
0x818EC6 F3 48 0F 2A C8 cvtsi2ss xmm1, rax
0x818ECB F3 0F 59 C1 mulss xmm0, xmm1
0x818ECF F3 48 0F 2C C0 cvttss2si rax, xmm0
0x818ED4 89 47 1C mov dword ptr [rdi + 0x1c], eax
0x818ED7 B8 00 00 80 3F mov eax, 0x3f800000
0x818EDC 48 8B CF mov rcx, rdi
0x818EDF 89 87 A8 01 00 00 mov dword ptr [rdi + 0x1a8], eax
0x818EE5 89 87 AC 01 00 00 mov dword ptr [rdi + 0x1ac], eax
0x818EEB E8 C4 2A AE FF call 0x2fb9b4
0x818EF0 4C 8B 8E 90 00 00 00 mov r9, qword ptr [rsi + 0x90]
0x818EF7 49 8B C9 mov rcx, r9
0x818EFA 8B 50 08 mov edx, dword ptr [rax + 8]
0x818EFD E8 EA FB FF FF call 0x818aec
0x818F02 48 85 C0 test rax, rax
0x818F05 74 21 je 0x818f28
0x818F07 41 83 7E 2C 00 cmp dword ptr [r14 + 0x2c], 0
0x818F0C 75 06 jne 0x818f14
0x818F0E 0F B7 48 08 movzx ecx, word ptr [rax + 8]
0x818F12 EB 04 jmp 0x818f18
0x818F14 0F B7 48 0A movzx ecx, word ptr [rax + 0xa]
0x818F18 0F B7 C1 movzx eax, cx
0x818F1B 89 87 B4 07 00 00 mov dword ptr [rdi + 0x7b4], eax
0x818F21 4C 8B 8E 90 00 00 00 mov r9, qword ptr [rsi + 0x90]
0x818F28 48 8B CF mov rcx, rdi
0x818F2B E8 1C FC FF FF call 0x818b4c
0x818F30 49 8B C9 mov rcx, r9
0x818F33 8B 50 14 mov edx, dword ptr [rax + 0x14]
0x818F36 E8 B1 FB FF FF call 0x818aec
0x818F3B F3 0F 10 1D 51 B9 3B 03 movss xmm3, dword ptr [rip + 0x33bb951]
0x818F43 48 85 C0 test rax, rax
0x818F46 74 20 je 0x818f68
0x818F48 0F B7 40 16 movzx eax, word ptr [rax + 0x16]
0x818F4C 66 0F 6E D0 movd xmm2, eax
0x818F50 0F 5B D2 cvtdq2ps xmm2, xmm2
0x818F53 F3 0F 59 D3 mulss xmm2, xmm3
0x818F57 F3 0F 11 97 A4 07 00 00 movss dword ptr [rdi + 0x7a4], xmm2
0x818F5F 4C 8B 8E 90 00 00 00 mov r9, qword ptr [rsi + 0x90]
0x818F66 EB 08 jmp 0x818f70
0x818F68 F3 0F 10 97 A4 07 00 00 movss xmm2, dword ptr [rdi + 0x7a4]
0x818F70 48 8B CF mov rcx, rdi
0x818F73 E8 D4 FB FF FF call 0x818b4c
0x818F78 49 8B C9 mov rcx, r9
0x818F7B 8B 50 04 mov edx, dword ptr [rax + 4]
0x818F7E E8 69 FB FF FF call 0x818aec
0x818F83 48 85 C0 test rax, rax
0x818F86 74 1E je 0x818fa6
0x818F88 0F B7 40 06 movzx eax, word ptr [rax + 6]
0x818F8C 66 0F 6E C0 movd xmm0, eax
0x818F90 0F 5B C0 cvtdq2ps xmm0, xmm0
0x818F93 F3 0F 59 C3 mulss xmm0, xmm3
0x818F97 F3 0F 58 C2 addss xmm0, xmm2
0x818F9B F3 0F 11 87 A4 07 00 00 movss dword ptr [rdi + 0x7a4], xmm0
0x818FA3 0F 28 D0 movaps xmm2, xmm0
0x818FA6 48 8B 9E 30 02 00 00 mov rbx, qword ptr [rsi + 0x230]
0x818FAD BA 32 1F 00 00 mov edx, 0x1f32
0x818FB2 48 8B CB mov rcx, rbx
0x818FB5 E8 4E F5 DE FF call 0x608508
0x818FBA BA AF 22 00 00 mov edx, 0x22af
0x818FBF 48 8B CB mov rcx, rbx
0x818FC2 0F 28 C8 movaps xmm1, xmm0
0x818FC5 E8 3E F5 DE FF call 0x608508
0x818FCA F3 0F 59 C1 mulss xmm0, xmm1
0x818FCE 48 8B CF mov rcx, rdi
0x818FD1 F3 0F 59 C2 mulss xmm0, xmm2
0x818FD5 F3 0F 11 87 A8 07 00 00 movss dword ptr [rdi + 0x7a8], xmm0
0x818FDD E8 6A FB FF FF call 0x818b4c
0x818FE2 4C 8B 8E 90 00 00 00 mov r9, qword ptr [rsi + 0x90]
0x818FE9 49 8B C9 mov rcx, r9
0x818FEC 8B 50 0C mov edx, dword ptr [rax + 0xc]
0x818FEF E8 F8 FA FF FF call 0x818aec
0x818FF4 F3 0F 10 0D E4 B1 3B 03 movss xmm1, dword ptr [rip + 0x33bb1e4]
0x818FFC 48 85 C0 test rax, rax
0x818FFF 74 22 je 0x819023
0x819001 0F B7 40 0E movzx eax, word ptr [rax + 0xe]
0x819005 66 0F 6E C0 movd xmm0, eax
0x819009 0F 5B C0 cvtdq2ps xmm0, xmm0
0x81900C F3 0F 59 C3 mulss xmm0, xmm3
0x819010 F3 0F 58 C1 addss xmm0, xmm1
0x819014 F3 0F 11 87 A8 01 00 00 movss dword ptr [rdi + 0x1a8], xmm0
0x81901C 4C 8B 8E 90 00 00 00 mov r9, qword ptr [rsi + 0x90]
0x819023 48 8B CF mov rcx, rdi
0x819026 E8 21 FB FF FF call 0x818b4c
0x81902B 49 8B C9 mov rcx, r9
0x81902E 8B 50 14 mov edx, dword ptr [rax + 0x14]
0x819031 E8 B6 FA FF FF call 0x818aec
0x819036 48 85 C0 test rax, rax
0x819039 74 22 je 0x81905d
0x81903B 0F B7 40 14 movzx eax, word ptr [rax + 0x14]
0x81903F 66 0F 6E C0 movd xmm0, eax
0x819043 0F 5B C0 cvtdq2ps xmm0, xmm0
0x819046 F3 0F 59 C3 mulss xmm0, xmm3
0x81904A F3 0F 58 C1 addss xmm0, xmm1
0x81904E F3 0F 11 87 AC 01 00 00 movss dword ptr [rdi + 0x1ac], xmm0
0x819056 4C 8B 8E 90 00 00 00 mov r9, qword ptr [rsi + 0x90]
0x81905D 48 8B CF mov rcx, rdi
0x819060 E8 E7 FA FF FF call 0x818b4c
0x819065 49 8B C9 mov rcx, r9
0x819068 8B 50 10 mov edx, dword ptr [rax + 0x10]
0x81906B E8 7C FA FF FF call 0x818aec
0x819070 48 85 C0 test rax, rax
0x819073 74 11 je 0x819086
0x819075 0F B7 40 10 movzx eax, word ptr [rax + 0x10]
0x819079 89 87 BC 01 00 00 mov dword ptr [rdi + 0x1bc], eax
0x81907F 4C 8B 8E 90 00 00 00 mov r9, qword ptr [rsi + 0x90]
0x819086 48 8B CF mov rcx, rdi
0x819089 E8 BE FA FF FF call 0x818b4c
0x81908E 49 8B C9 mov rcx, r9
0x819091 8B 50 10 mov edx, dword ptr [rax + 0x10]
0x819094 E8 53 FA FF FF call 0x818aec
0x819099 48 85 C0 test rax, rax
0x81909C 74 11 je 0x8190af
0x81909E 0F B7 40 12 movzx eax, word ptr [rax + 0x12]
0x8190A2 89 87 C0 01 00 00 mov dword ptr [rdi + 0x1c0], eax
0x8190A8 4C 8B 8E 90 00 00 00 mov r9, qword ptr [rsi + 0x90]
0x8190AF 48 8B CF mov rcx, rdi
0x8190B2 E8 95 FA FF FF call 0x818b4c
0x8190B7 49 8B C9 mov rcx, r9
0x8190BA 8B 50 18 mov edx, dword ptr [rax + 0x18]
0x8190BD E8 2A FA FF FF call 0x818aec
0x8190C2 48 85 C0 test rax, rax
0x8190C5 74 0A je 0x8190d1
0x8190C7 0F B7 40 18 movzx eax, word ptr [rax + 0x18]
0x8190CB 89 87 C4 01 00 00 mov dword ptr [rdi + 0x1c4], eax
0x8190D1 48 8B 8E 30 02 00 00 mov rcx, qword ptr [rsi + 0x230]
0x8190D8 BA 0F E4 00 00 mov edx, 0xe40f
0x8190DD E8 26 F4 DE FF call 0x608508
0x8190E2 49 8B D7 mov rdx, r15
0x8190E5 F3 0F 11 87 B0 07 00 00 movss dword ptr [rdi + 0x7b0], xmm0
0x8190ED 48 8B CF mov rcx, rdi
0x8190F0 E8 2B CC B5 FF call 0x375d20
0x8190F5 49 8B CE mov rcx, r14
0x8190F8 41 8B DD mov ebx, r13d
0x8190FB E8 34 E3 FF FF call 0x817434
0x819100 48 85 C0 test rax, rax
0x819103 74 0A je 0x81910f
0x819105 48 8B 40 08 mov rax, qword ptr [rax + 8]
0x819109 8B 98 5C 08 00 00 mov ebx, dword ptr [rax + 0x85c]
0x81910F 48 8B CF mov rcx, rdi
0x819112 E8 35 FA FF FF call 0x818b4c
0x819117 C6 44 24 28 00 mov byte ptr [rsp + 0x28], 0
0x81911C 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x819121 44 8B CB mov r9d, ebx
0x819124 48 89 44 24 20 mov qword ptr [rsp + 0x20], rax
0x819129 48 8D 55 B0 lea rdx, [rbp - 0x50]
0x81912D E8 16 F1 FF FF call 0x818248
0x819132 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x819137 48 8B CF mov rcx, rdi
0x81913A 48 8D 55 B0 lea rdx, [rbp - 0x50]
0x81913E E8 79 21 AE FF call 0x2fb2bc
0x819143 48 8D 55 B0 lea rdx, [rbp - 0x50]
0x819147 48 8B CF mov rcx, rdi
0x81914A E8 FD E2 FF FF call 0x81744c
0x81914F 48 8B CF mov rcx, rdi
0x819152 E8 41 19 BE FF call 0x3faa98
0x819157 80 BF D1 07 00 00 00 cmp byte ptr [rdi + 0x7d1], 0
0x81915E 74 2A je 0x81918a
0x819160 48 8B CF mov rcx, rdi
0x819163 C6 87 D1 07 00 00 00 mov byte ptr [rdi + 0x7d1], 0
0x81916A E8 DD F9 FF FF call 0x818b4c
0x81916F C6 44 24 28 01 mov byte ptr [rsp + 0x28], 1
0x819174 4C 8D 44 24 60 lea r8, [rsp + 0x60]
0x819179 44 8B CB mov r9d, ebx
0x81917C 48 89 44 24 20 mov qword ptr [rsp + 0x20], rax
0x819181 48 8D 55 B0 lea rdx, [rbp - 0x50]
0x819185 E8 BE F0 FF FF call 0x818248
0x81918A 48 8B CF mov rcx, rdi
0x81918D E8 62 E4 FF FF call 0x8175f4
0x819192 48 8B CF mov rcx, rdi
0x819195 E8 BE BD B5 FF call 0x374f58
0x81919A 48 8B CF mov rcx, rdi
0x81919D E8 C6 B0 D3 FF call 0x554268
0x8191A2 48 8B 05 87 0C DA 03 mov rax, qword ptr [rip + 0x3da0c87]
0x8191A9 BA 22 DC 00 00 mov edx, 0xdc22
0x8191AE C6 87 D0 07 00 00 01 mov byte ptr [rdi + 0x7d0], 1
0x8191B5 48 8B 98 30 02 00 00 mov rbx, qword ptr [rax + 0x230]
0x8191BC 48 8B CB mov rcx, rbx
0x8191BF E8 44 F3 DE FF call 0x608508
0x8191C4 BA 4F D8 00 00 mov edx, 0xd84f
0x8191C9 48 8B CB mov rcx, rbx
0x8191CC 0F 28 D8 movaps xmm3, xmm0
0x8191CF E8 34 F3 DE FF call 0x608508
0x8191D4 48 83 BF C0 07 00 00 00 cmp qword ptr [rdi + 0x7c0], 0
0x8191DC 0F 57 D2 xorps xmm2, xmm2
0x8191DF 8B 87 B8 07 00 00 mov eax, dword ptr [rdi + 0x7b8]
0x8191E5 0F 57 C9 xorps xmm1, xmm1
0x8191E8 F3 48 0F 2A D0 cvtsi2ss xmm2, rax
0x8191ED 8B 87 B4 07 00 00 mov eax, dword ptr [rdi + 0x7b4]
0x8191F3 F3 48 0F 2A C8 cvtsi2ss xmm1, rax
0x8191F8 F3 0F 5E D1 divss xmm2, xmm1
0x8191FC F3 0F 59 D3 mulss xmm2, xmm3
0x819200 F3 0F 58 C2 addss xmm0, xmm2
0x819204 F3 0F 11 87 A0 07 00 00 movss dword ptr [rdi + 0x7a0], xmm0
0x81920C 74 43 je 0x819251
0x81920E 41 8B D5 mov edx, r13d
0x819211 48 8B CF mov rcx, rdi
0x819214 33 DB xor ebx, ebx
0x819216 E8 35 E8 D3 FF call 0x557a50
0x81921B 85 C0 test eax, eax
0x81921D 7E 32 jle 0x819251
0x81921F 45 8B C5 mov r8d, r13d
0x819222 8B D3 mov edx, ebx
0x819224 48 8B CF mov rcx, rdi
0x819227 E8 6C E8 D3 FF call 0x557a98
0x81922C 48 8B CF mov rcx, rdi
0x81922F 44 0F B7 40 08 movzx r8d, word ptr [rax + 8]
0x819234 44 03 40 04 add r8d, dword ptr [rax + 4]
0x819238 0F B7 10 movzx edx, word ptr [rax]
0x81923B E8 C0 01 00 00 call 0x819400
0x819240 41 8B D5 mov edx, r13d
0x819243 48 8B CF mov rcx, rdi
0x819246 FF C3 inc ebx
0x819248 E8 03 E8 D3 FF call 0x557a50
0x81924D 3B D8 cmp ebx, eax
0x81924F 7C CE jl 0x81921f
0x819251 48 8B CF mov rcx, rdi
0x819254 E8 BF B2 E0 FF call 0x624518
0x819259 44 8B 87 B4 07 00 00 mov r8d, dword ptr [rdi + 0x7b4]
0x819260 8B 97 B8 07 00 00 mov edx, dword ptr [rdi + 0x7b8]
0x819266 41 8B 4E 2C mov ecx, dword ptr [r14 + 0x2c]
0x81926A 8B 98 1C 06 00 00 mov ebx, dword ptr [rax + 0x61c]
0x819270 44 8B CB mov r9d, ebx
0x819273 C6 44 24 20 00 mov byte ptr [rsp + 0x20], 0
0x819278 E8 1F E6 FF FF call 0x81789c
0x81927D 48 8B CF mov rcx, rdi
0x819280 89 87 98 07 00 00 mov dword ptr [rdi + 0x798], eax
0x819286 E8 8D B2 E0 FF call 0x624518
0x81928B 44 8B 87 B4 07 00 00 mov r8d, dword ptr [rdi + 0x7b4]
0x819292 44 8B CB mov r9d, ebx
0x819295 8B 97 B8 07 00 00 mov edx, dword ptr [rdi + 0x7b8]
0x81929B 8A 88 D1 06 00 00 mov cl, byte ptr [rax + 0x6d1]
0x8192A1 88 4C 24 20 mov byte ptr [rsp + 0x20], cl
0x8192A5 41 8B 4E 2C mov ecx, dword ptr [r14 + 0x2c]
0x8192A9 E8 EE E5 FF FF call 0x81789c
0x8192AE 8B C8 mov ecx, eax
0x8192B0 89 87 9C 07 00 00 mov dword ptr [rdi + 0x79c], eax
0x8192B6 49 8B 06 mov rax, qword ptr [r14]
0x8192B9 48 85 C0 test rax, rax
0x8192BC 74 38 je 0x8192f6
0x8192BE F6 00 0F test byte ptr [rax], 0xf
0x8192C1 75 33 jne 0x8192f6
0x8192C3 80 B8 86 08 00 00 00 cmp byte ptr [rax + 0x886], 0
0x8192CA 74 2A je 0x8192f6
0x8192CC 80 B8 8A 08 00 00 00 cmp byte ptr [rax + 0x88a], 0
0x8192D3 75 21 jne 0x8192f6
0x8192D5 8B 87 98 07 00 00 mov eax, dword ptr [rdi + 0x798]
0x8192DB BA 14 00 00 00 mov edx, 0x14
0x8192E0 3B C2 cmp eax, edx
0x8192E2 0F 42 C2 cmovb eax, edx
0x8192E5 3B CA cmp ecx, edx
0x8192E7 89 87 98 07 00 00 mov dword ptr [rdi + 0x798], eax
0x8192ED 0F 42 CA cmovb ecx, edx
0x8192F0 89 8F 9C 07 00 00 mov dword ptr [rdi + 0x79c], ecx
0x8192F6 48 8B CF mov rcx, rdi
0x8192F9 E8 1A B2 E0 FF call 0x624518
0x8192FE F3 0F 10 80 A8 00 00 00 movss xmm0, dword ptr [rax + 0xa8]
0x819306 0F 2F 05 C7 AE 3B 03 comiss xmm0, dword ptr [rip + 0x33baec7]
0x81930D 76 20 jbe 0x81932f
0x81930F 48 8B CF mov rcx, rdi
0x819312 E8 01 B2 E0 FF call 0x624518
0x819317 F3 0F 10 80 A8 00 00 00 movss xmm0, dword ptr [rax + 0xa8]
0x81931F F3 0F 58 87 AC 01 00 00 addss xmm0, dword ptr [rdi + 0x1ac]
0x819327 F3 0F 11 87 AC 01 00 00 movss dword ptr [rdi + 0x1ac], xmm0
0x81932F 48 8B CF mov rcx, rdi
0x819332 E8 E1 B1 E0 FF call 0x624518
0x819337 F3 0F 10 40 64 movss xmm0, dword ptr [rax + 0x64]
0x81933C 0F 2F 05 91 AE 3B 03 comiss xmm0, dword ptr [rip + 0x33bae91]
0x819343 72 28 jb 0x81936d
0x819345 48 8B CF mov rcx, rdi
0x819348 E8 CB B1 E0 FF call 0x624518
0x81934D 8B 8F C4 01 00 00 mov ecx, dword ptr [rdi + 0x1c4]
0x819353 0F 57 C0 xorps xmm0, xmm0
0x819356 F3 48 0F 2A C1 cvtsi2ss xmm0, rcx
0x81935B F3 0F 59 40 64 mulss xmm0, dword ptr [rax + 0x64]
0x819360 F3 48 0F 2C C0 cvttss2si rax, xmm0
0x819365 03 C1 add eax, ecx
0x819367 89 87 C4 01 00 00 mov dword ptr [rdi + 0x1c4], eax
0x81936D 48 8B CF mov rcx, rdi
0x819370 E8 A3 B1 E0 FF call 0x624518
0x819375 83 B8 08 06 00 00 00 cmp dword ptr [rax + 0x608], 0
0x81937C 7C 4B jl 0x8193c9
0x81937E 48 8B CF mov rcx, rdi
0x819381 E8 92 B1 E0 FF call 0x624518
0x819386 49 8D 8E 48 01 00 00 lea rcx, [r14 + 0x148]
0x81938D E8 6A 58 AE FF call 0x2febfc
0x819392 F3 0F 59 05 76 B4 3B 03 mulss xmm0, dword ptr [rip + 0x33bb476]
0x81939A BA 62 7A 00 00 mov edx, 0x7a62
0x81939F 48 8B 0D 8A 0A DA 03 mov rcx, qword ptr [rip + 0x3da0a8a]
0x8193A6 44 8B 88 08 06 00 00 mov r9d, dword ptr [rax + 0x608]
0x8193AD F3 4C 0F 2C C0 cvttss2si r8, xmm0
0x8193B2 48 8B 89 18 07 00 00 mov rcx, qword ptr [rcx + 0x718]
0x8193B9 E8 BA 12 AE FF call 0x2fa678
0x8193BE F3 48 0F 2C C0 cvttss2si rax, xmm0
0x8193C3 01 87 C4 01 00 00 add dword ptr [rdi + 0x1c4], eax
0x8193C9 48 8D 55 B0 lea rdx, [rbp - 0x50]
0x8193CD 48 8B CF mov rcx, rdi
0x8193D0 E8 EB 0B BE FF call 0x3f9fc0
0x8193D5 48 8B 8D D0 1F 00 00 mov rcx, qword ptr [rbp + 0x1fd0]
0x8193DC 48 33 CC xor rcx, rsp
0x8193DF E8 FC 7E 37 00 call 0xb912e0
0x8193E4 4C 8D 9C 24 E0 20 00 00 lea r11, [rsp + 0x20e0]
0x8193EC 49 8B 5B 40 mov rbx, qword ptr [r11 + 0x40]
0x8193F0 49 8B 73 48 mov rsi, qword ptr [r11 + 0x48]
0x8193F4 49 8B E3 mov rsp, r11
0x8193F7 41 5F pop r15
0x8193F9 41 5E pop r14
0x8193FB 41 5D pop r13
0x8193FD 5F pop rdi
0x8193FE 5D pop rbp
0x8193FF C3 ret 
