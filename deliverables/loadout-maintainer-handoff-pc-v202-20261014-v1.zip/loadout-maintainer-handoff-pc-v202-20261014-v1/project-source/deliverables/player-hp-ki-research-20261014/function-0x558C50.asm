0x558C50 48 89 5C 24 08 mov qword ptr [rsp + 8], rbx
0x558C55 48 89 6C 24 10 mov qword ptr [rsp + 0x10], rbp
0x558C5A 48 89 74 24 18 mov qword ptr [rsp + 0x18], rsi
0x558C5F 57 push rdi
0x558C60 48 83 EC 20 sub rsp, 0x20
0x558C64 48 8B 59 20 mov rbx, qword ptr [rcx + 0x20]
0x558C68 48 8B F9 mov rdi, rcx
0x558C6B 0F B7 F2 movzx esi, dx
0x558C6E 8B D6 mov edx, esi
0x558C70 4C 8B 5B 08 mov r11, qword ptr [rbx + 8]
0x558C74 4C 8B 53 10 mov r10, qword ptr [rbx + 0x10]
0x558C78 4D 2B D3 sub r10, r11
0x558C7B 49 C1 FA 03 sar r10, 3
0x558C7F E8 E4 D5 70 00 call 0xc66268
0x558C84 33 D2 xor edx, edx
0x558C86 8B C0 mov eax, eax
0x558C88 49 F7 F2 div r10
0x558C8B 45 33 C0 xor r8d, r8d
0x558C8E 48 8B CA mov rcx, rdx
0x558C91 41 8B E8 mov ebp, r8d
0x558C94 4D 85 D2 test r10, r10
0x558C97 74 69 je 0x558d02
0x558C99 4C 63 CA movsxd r9, edx
0x558C9C 43 0F B7 04 CB movzx eax, word ptr [r11 + r9*8]
0x558CA1 66 3B C6 cmp ax, si
0x558CA4 75 33 jne 0x558cd9
0x558CA6 48 63 C1 movsxd rax, ecx
0x558CA9 41 8B 44 C3 04 mov eax, dword ptr [r11 + rax*8 + 4]
0x558CAE 48 8B 17 mov rdx, qword ptr [rdi]
0x558CB1 3B 42 04 cmp eax, dword ptr [rdx + 4]
0x558CB4 73 0B jae 0x558cc1
0x558CB6 48 6B C8 70 imul rcx, rax, 0x70
0x558CBA 4C 8D 42 08 lea r8, [rdx + 8]
0x558CBE 4C 03 C1 add r8, rcx
0x558CC1 48 8B 5C 24 30 mov rbx, qword ptr [rsp + 0x30]
0x558CC6 49 8B C0 mov rax, r8
0x558CC9 48 8B 6C 24 38 mov rbp, qword ptr [rsp + 0x38]
0x558CCE 48 8B 74 24 40 mov rsi, qword ptr [rsp + 0x40]
0x558CD3 48 83 C4 20 add rsp, 0x20
0x558CD7 5F pop rdi
0x558CD8 C3 ret 
0x558CD9 66 3B 43 04 cmp ax, word ptr [rbx + 4]
0x558CDD 74 23 je 0x558d02
0x558CDF FF C1 inc ecx
0x558CE1 FF C5 inc ebp
0x558CE3 48 63 D1 movsxd rdx, ecx
0x558CE6 49 3B D2 cmp rdx, r10
0x558CE9 1B C0 sbb eax, eax
0x558CEB 23 C8 and ecx, eax
0x558CED 49 8D 41 01 lea rax, [r9 + 1]
0x558CF1 49 3B D2 cmp rdx, r10
0x558CF4 4D 1B C9 sbb r9, r9
0x558CF7 4C 23 C8 and r9, rax
0x558CFA 48 63 C5 movsxd rax, ebp
0x558CFD 49 3B C2 cmp rax, r10
0x558D00 72 9A jb 0x558c9c
0x558D02 B8 FF FF FF FF mov eax, 0xffffffff
0x558D07 EB A5 jmp 0x558cae
