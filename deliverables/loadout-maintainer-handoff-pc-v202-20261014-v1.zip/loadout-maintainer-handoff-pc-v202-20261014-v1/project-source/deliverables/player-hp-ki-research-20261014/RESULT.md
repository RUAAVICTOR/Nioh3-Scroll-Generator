# Player HP/Ki calculation: PC v2.02, 2026-10-14

Follow-up: the [Life Reflection (Stamina) result](../life-reflection-stamina-research-20261014/RESULT.md)
now closes the B+ coefficient at 450%, the 135-HP positive replay and the
B+(B) UI decomposition. Fresh native rows and the owner's screenshot identify
the clan as Todo (藤堂); the Kato references below preserve the earlier owner
description and should not be used as the final clan association.

The player base-stat calculation is recovered from actual Reverse Engineer
Anything 6.4.0 / Ghidra 12.1.4 output and independently retained native
instructions. HP is a sum of level, Constitution (体), and Stamina (刚) table
contributions. Ki is a Heart (心) table lookup. Context correction, equipment
effects, backing-object bonuses and final actor conversion are separate stages.
The corrected base formula matches the owner's level-1 UI values and a fresh
same-process selected-stat snapshot after removing the Kato clan effect.
It is not a complete prediction of every equipped combat maximum.

Correction: the initial report mislabeled the third attribute as Strength (武).
`818E43` loads `R9D` from attribute offset `+8`, which is Stamina (刚).
The fourth attribute Strength (武) is at `+C` and is not that input. The raw
native instructions are unchanged; the semantic label and offline reference
have been corrected. Earlier generated curves are retained under `superseded/`
for audit and must not be used as the current semantic reference.

Scope: executable `2.0.2.0`, SHA-256
`e22c4a635e4ec1e27a177b76e27d7f6a637f426c0ed3928b60f5693bc52ae130`.
Initial static analysis used historical decoded sections and captured tables
with the game closed. The subsequent owner-assisted follow-up used bounded
query/read-only process access. No debugger, game-function execution,
memory write or save access was used by the agent. No product change,
commit, release, formal knowledge record or Pro handoff was made.

## Functions and native evidence

Addresses below are RVAs, independent of the current module base.

| RVA | Role | Evidence |
| --- | --- | --- |
| `818B68..819400` | Player derived-stat rebuild | `rea-01/002-procedure_pseudo_code.cpp`, `instructions-01.json` |
| `8181A4..8181FE` | Sum the three base-HP terms | `rea-01/003-procedure_pseudo_code.cpp`, `function-0x8181A4.asm` |
| `818AEC` | Signed-index clamp and 32-byte attribute-row lookup | `rea-01/006-procedure_pseudo_code.cpp`; historical same-executable live signatures |
| `818B4C` | Effective attributes at `stat.backing + 34` | `rea-01/007-procedure_pseudo_code.cpp` |
| `2FB9B4` | Original attributes at `stat.backing + 14` | `rea-01/008-procedure_pseudo_code.cpp` |
| `376944` | Effective level at `stat.backing + 30`, otherwise `owner + 34` | `rea-02/007-procedure_pseudo_code.cpp` |
| `817364` | Original level at `stat.backing + 10`, otherwise `owner + 34` | `rea-02/006-procedure_pseudo_code.cpp` |
| `376530` / `376698` | HP / Ki context-correction accumulators | `rea-01/004` / `005-procedure_pseudo_code.cpp` |
| `819400..82266C` | Apply individual effect IDs and values | `rea-04/002-procedure_pseudo_code.cpp`, `instructions-05.json` |
| `8175F4` | Add backing-object bonuses, including HP at `+5880` | `rea-02/003-procedure_pseudo_code.cpp`, `function-0x8175F4.asm` |
| `BE108..BE22E` | Shared final HP update, with conditional actor scaling | `rea-03/008-procedure_pseudo_code.cpp`, `function-0xBE108.asm` |
| `3771EC..377392` | Shared final Ki maximum and separate cap update | `rea-03/014-procedure_pseudo_code.cpp`, `function-0x3771EC.asm` |

The original retained code image base was inferred as `7FF64E550000` from six
independent vtable/function joins in the earlier enemy research. It is not a
current live-process base. `carrier-01.json` through `carrier-04.json` retain
exact selected ranges and limitations. Focused PE files are analysis carriers
with a synthetic entry and filtered exception index; never execute them as games.

## Exact base formula

The attribute table is reached through module global `45B9E30`, manager `+90`,
then the wrapper's first pointer. It has an eight-byte header and 32-byte rows.
`818AEC` interprets the low 32-bit index as signed, clamps it to `1..999`,
checks the row count, and returns `table + 8 + index * 32`. There is no
interpolation at this consumer.

Let `T[x].u16(offset)` denote a little-endian table field after that clamp.

```text
HP_base = T[effective_level].u16(0x00)
        + T[effective_Constitution].u16(0x02)
        + T[effective_Stamina].u16(0x0C)

Ki_base = T[effective_Heart].u16(0x04)

stat.u32(+18) = u32(trunc(f32(f32(HP_base) * HP_context_correction)))
stat.u32(+1C) = u32(trunc(f32(f32(Ki_base) * Ki_context_correction)))
```

The HP call sequence at `818E43..818E56` loads Stamina into `R9D`, Constitution
into `R8D`, and effective level into `EDX`. `8181A4` reads row offsets `0`,
`2`, `C` in that order. The decompiler omitted some register arguments; the
formula above uses the independently decoded instructions. `818E91` loads
effective Heart, `818EA5` reads row `+4`, and `818ED4` stores corrected Ki.
The player context stage has no enemy-producer minimum-one clamp.

The attribute names/order are supported by the earlier UI-backed player
research in the v0.8.8 worktree's
`docs/knowledge/V082_LIVE_CHARACTER_EQUIPMENT_RESEARCH_20260926.md`:
体、心、刚、武、技、智、咒. Their player-object allocated fields begin at `+94`.
The new formula consumes the effective backing-object copy, which may differ
from that allocated block.

The conditional branch at `818C88..818E2E` can rescale the seven attributes
around the baseline value 5 when effective level is limited. It truncates the
scaled terms, distributes a remainder using the native loop, restores the
baseline, and writes an effective attribute copy. Consequently, using the
allocated menu values blindly in a level-adjusted scenario is unsafe. This
offline reference accepts already-effective inputs and does not emulate that
unqualified scenario gate.

## Retained curves and examples

The corrected `base-curves.json` contains every row `1..999`, exact contributions, delta runs,
source hashes, sample terms and REA closure proofs. The samurai and ninja
historical captures have byte-identical attribute tables. This shows these base
columns share one table; it does not prove all style-dependent final bonuses equal.

| Heart | Base Ki |
| ---: | ---: |
| 5 | 960 |
| 40 | 1205 |
| 80 | 1306 |
| 99 | 1350 |
| 150 | 1370 |
| 200 | 1390 |

At level 364, Constitution 22, Heart 150, Stamina 9:
`HP_base = 2524 + 340 + 80 = 2944`, `Ki_base = 1370`.
The historical character report listed memory HP 3706 / Ki 1370 as unconfirmed.
The Ki agreement is a consistency check only; the HP difference is not a measured
bonus decomposition or evidence of a new live reconstruction.

The retained level contribution starts at 780 for level 1; per-level increments
are 10 through 80, 9 through 99, 5 through 150, 4 through 200, 2 through 499,
then 1 through 999. Constitution/Stamina/Ki curves have their own step patterns.
Constitution, Stamina and Heart contributions plateau after row 200 in this
table. Out-of-playable-range rows are data, not proof of gameplay reachability.

## Downstream additions and final consumers

The effect dispatcher receives `(stat, effect_id, value)` and independently
shows these arithmetic paths. Numeric IDs remain authoritative; their localized
names were not recovered from the limited scroll-name catalog.

| Effect ID | Native operation |
| --- | --- |
| `0860`, `B1B6` | Add `value` to `stat.u32(+18)`; common store at `81F563` |
| `7F69` | Add `value` to `stat.u32(+1C)` at `81DA6B` |
| `5D3A` | Read effective Stamina (刚), select table row `+0C`, and add `trunc(f32(f32(curve(FA3E, 1, value) * 0.01) * row_value))` to HP at `81C7C3` |
| `B95E` | Keep the larger integer parameter at modifier-object `+600`; the final Ki consumer uses that field to activate the `CBE1` additive curve |

The `5D3A` conversion adds a further contribution from the same Stamina column.
Ordinary base HP already includes that Stamina contribution once.
The native curve helper `2FA678` output has unresolved decompiler parameter
types, so this conversion is retained as a symbolic native curve call rather
than an invented percentage rule. Its table and legal effect-value domain still
need separate qualification.

`8175F4` adds `backing.u32(+5880)` to HP after the earlier effect-processing
calls. It does not directly add Ki at `+1C`. The producer/meaning of `+5880`
is unverified. Further effects are processed after this stage through the
additional native routines; do not assume the listed additions are exhaustive.

The shared final-HP updater reads the selected stat object through `85B6C`:
`status.+2D90` when present, otherwise `status +25A8`. Thus the embedded fallback
HP/Ki offsets are `status +25C0/+25C4`, but a player with an external stat object
must use that object. `BE108` stores a 64-bit final HP maximum at `status +50`.
On its qualified scaling branch it multiplies derived HP, `status +3648`,
`+364C`, `+30BC`, native type and actor factors, and an optional group factor,
in float32 order before integer conversion. Its actor guard and bypass remain
branch conditions; this task does not assume every live player takes that branch.

The shared final-Ki updater `3771EC` stores a float maximum at `status +B0`:

```text
maximum_Ki = f32_add(
    f32_mul(f32_mul(f32_mul(status.f32(+3650), f32(Ki_derived)),
                    native_type_Ki_factor), qualified_group_factor),
    qualified_CBE1_addition)
```

Each operation above rounds to float32 in the native instruction order. The additive
term is evaluated only when modifier `+600 >= 0`, with lookup index derived
from native `2FEBFC` output times 1000; it is truncated and normalized to a
32-bit unsigned value before float addition. Type factors come from `376C0C`,
and the conditional group factor uses scalar key `977B`. The separate `+B4`
cap is updated from `selected_stat +20`, with its own attenuation rule. Neither
current Ki nor that separate cap should be substituted for the `+B0` maximum.

## Fresh level-1 control and clan-effect difference

The owner reported level 1, allocated attributes `[5,5,5,6,5,5,5]`, maximum HP
1015, and maximum Ki 960. They identified Kato clan's Life Reflection (Stamina)
as a contributing effect, then changed it and reported HP 880.

After the change, `live-player-02/capture.json` retained a passive snapshot in
PID 588752, creation FILETIME `134364438863095000`, with the exact PC v2.02
executable hash and six live native-code signature checks. The player's known
global/vtable, allocated vector and level matched. A bounded vtable search found
one matching status owner, with an embedded and an external stat candidate. The
native `status +2D90` selector chose the external stat object; the actor/status
backlink and repeated selected inputs/outputs passed stability checks.

| Quantity | Captured result |
| --- | --- |
| Effective level | 1 |
| Effective attributes | `5,5,5,6,5,5,5` |
| Base HP terms | `780 + 70 + 30 = 880` |
| Selected-stat HP / Ki | `880 / 960` |
| Final HP maximum / Ki maximum | `880 / 960.0` |
| Backing-object HP bonus `+5880` | 0 |
| Retained final HP factors `+3648/+364C/+30BC` | `1 / 1 / 1` |
| Retained final Ki factor `+3650` | 1 |
| Ki additive gate `+600` | -1, inactive |
| Native type selector | 1 |

The live attribute table matched the retained table hash byte-for-byte. This is
an observed snapshot and owner UI agreement, not a traced rebuild invocation.
The actor's player-role identity was not independently proved beyond the unique
matching control, pointer joins and outputs. Context correction factors were not
independently decomposed; equality of the selected output to the base does not
establish every intermediate factor individually.

The owner-reported before/after difference is `1015 - 880 = 135`. Native effect
`5D3A` adds a further contribution from the Stamina table's `+0C` column, which
is 30 at Stamina 5. An effective 4.5 multiplier would give 135. That multiplier
is **inferred**, not a captured `FA3E` curve result. No pre-change selected-stat
snapshot, Kato effect-value/rank readback, or complete other-effect control was
captured. The clan/effect attribution comes from the owner, while the native
numeric effect's arithmetic comes from retained code. No new localized-ID join
or general clan-rank formula is claimed.

The initial resource locator failed closed because the old, previously
unconfirmed `45D6C18 -> +50 -> +198` chain produced an unreadable intermediate
address. `live-player-01/capture.json` retains the failure and matched allocated
vector. A separate attempt to find `818B68` directly in a vtable found none:
`player-rebuild-callers.json` confirms it is directly called by `377394`. The
repair reused the proven base-stat vtable from constructor `5FDB1C` and the
existing bounded scanner. The 256 MiB bounded scan returned 32 candidates; it
does not claim a complete process inventory. No debugger or target write was
used in the failed or repaired attempts.

## Verification and remaining scope

- Four real REA sessions completed and closed with `binary_session.open=false`;
  every selected input-carrier hash remained unchanged.
- Byte verification passed for 10,538 instruction records / 50,010 bytes, all
  selected carrier code pages, full retained `.rdata`, and original entries in
  the intentionally filtered `.pdata`. See `byte-parity-verification.json`.
- Ten corrected reference/evidence tests passed: retained table anchors, historical
  sample decomposition, signed clamp boundaries, upper table rows, zero
  correction behavior, invalid conversion rejection, instruction/register
  anchors, REA cleanup, the owner's level-1 control and the retained live snapshot's
  raw hashes/selected-object/HP/Ki parity. The original eight tests
  did not catch the third/fourth attribute naming error; the new control does.
  These checks are distinct from the retained live snapshot.
- Early focused output omitted cold chunks in the final HP and effect paths.
  Phase 3 explicitly mapped the relevant cold ranges. Remaining bad-instruction
  warnings in other helpers are visible in retained output; their omitted
  branches and whole-program caller inventories remain incomplete.
- One post-change player-vector/output snapshot was collected. No controlled
  stat increment, traced clan-effect application, new style-change control,
  active multiplayer correction or UI formatter trace was collected. Exact
  equipped maxima outside this control remain conditional on those inputs.

Reuse: the existing enemy REA launcher, focused-carrier builder,
`research/build_pe_analysis_image.py`, `research/native_xrefs.py`,
`research/disassemble_native_functions.py`, existing load-capacity attribute
captures, and shared float32 operations were reused. No duplicate debugger or
binary-analysis framework was introduced.

Task-local reproducible commands (run from the repository with PowerShell 7):

```powershell
& tools/run_python_tests.ps1 -Python D:/Nioh3_v080_deliverables/ce-research-env/Scripts/python.exe -TestPath @('deliverables/player-hp-ki-research-20261014/test_reference.py') -PytestArgument @('-q')
& tools/run_python_tests.ps1 -Python D:/Nioh3_v080_deliverables/ce-research-env/Scripts/python.exe -ScriptPath deliverables/player-hp-ki-research-20261014/reference.py -ScriptArgument @('--output','D:/Nioh3_v080_deliverables/deliverables/player-hp-ki-replay.json')
```

Output paths must be fresh. `reference.calculate()` accepts effective level,
Constitution, Heart, Stamina and explicitly supplied context factors. It
models only the base/context stages and performs no game access.
`capture_player_resources.py --locator <retained locator> --expected-hp <owner value> --output <fresh directory>`
checks current process identity, native signatures, player vector, pointer joins,
table hash and stable selected outputs; it uses read-only process rights with a
256 KiB / 15-second read budget. The locator's candidate inventory is exploratory
until those checks pass. REA plans,
seeds and raw MCP evidence are retained in this directory. The carriers and
full decoded source sections stay local and are not suitable for public sharing.

