0x818248 48 8B C4 mov rax, rsp
0x81824B 48 89 58 18 mov qword ptr [rax + 0x18], rbx
0x81824F 55 push rbp
0x818250 56 push rsi
0x818251 57 push rdi
0x818252 41 54 push r12
0x818254 41 55 push r13
0x818256 41 56 push r14
0x818258 41 57 push r15
0x81825A 48 8D A8 18 FF FF FF lea rbp, [rax - 0xe8]
0x818261 48 81 EC B0 01 00 00 sub rsp, 0x1b0
0x818268 0F 29 70 B8 movaps xmmword ptr [rax - 0x48], xmm6
0x81826C 0F 29 78 A8 movaps xmmword ptr [rax - 0x58], xmm7
0x818270 48 8B 05 B9 FC C9 03 mov rax, qword ptr [rip + 0x3c9fcb9]
0x818277 48 33 C4 xor rax, rsp
0x81827A 48 89 85 80 00 00 00 mov qword ptr [rbp + 0x80], rax
0x818281 8B 82 E0 1E 00 00 mov eax, dword ptr [rdx + 0x1ee0]
0x818287 4D 8B E0 mov r12, r8
0x81828A 4C 8B 9D 10 01 00 00 mov r11, qword ptr [rbp + 0x110]
0x818291 4C 8B EA mov r13, rdx
0x818294 89 44 24 48 mov dword ptr [rsp + 0x48], eax
0x818298 48 8B F1 mov rsi, rcx
0x81829B 83 F0 01 xor eax, 1
0x81829E 44 89 4C 24 38 mov dword ptr [rsp + 0x38], r9d
0x8182A3 45 33 F6 xor r14d, r14d
0x8182A6 89 44 24 4C mov dword ptr [rsp + 0x4c], eax
0x8182AA 48 8B 05 7F 1B DA 03 mov rax, qword ptr [rip + 0x3da1b7f]
0x8182B1 45 8B CE mov r9d, r14d
0x8182B4 4C 89 44 24 50 mov qword ptr [rsp + 0x50], r8
0x8182B9 48 89 54 24 58 mov qword ptr [rsp + 0x58], rdx
0x8182BE 45 8D 56 07 lea r10d, [r14 + 7]
0x8182C2 48 8B 98 90 00 00 00 mov rbx, qword ptr [rax + 0x90]
0x8182C9 49 83 F9 07 cmp r9, 7
0x8182CD 7D 06 jge 0x8182d5
0x8182CF 43 8B 14 8B mov edx, dword ptr [r11 + r9*4]
0x8182D3 EB 05 jmp 0x8182da
0x8182D5 BA 01 00 00 00 mov edx, 1
0x8182DA 48 8B CB mov rcx, rbx
0x8182DD E8 0A 08 00 00 call 0x818aec
0x8182E2 0F B7 48 1A movzx ecx, word ptr [rax + 0x1a]
0x8182E6 42 89 4C 8D 60 mov dword ptr [rbp + r9*4 + 0x60], ecx
0x8182EB 49 FF C1 inc r9
0x8182EE 49 83 EA 01 sub r10, 1
0x8182F2 75 D5 jne 0x8182c9
0x8182F4 44 38 76 10 cmp byte ptr [rsi + 0x10], r14b
0x8182F8 74 14 je 0x81830e
0x8182FA 48 8B 05 CF 91 F3 03 mov rax, qword ptr [rip + 0x3f391cf]
0x818301 40 B7 01 mov dil, 1
0x818304 48 8B 48 08 mov rcx, qword ptr [rax + 8]
0x818308 80 79 10 01 cmp byte ptr [rcx + 0x10], 1
0x81830C 76 03 jbe 0x818311
0x81830E 41 8A FE mov dil, r14b
0x818311 F3 0F 10 3D C7 BE 3B 03 movss xmm7, dword ptr [rip + 0x33bbec7]
0x818319 48 8D 1D A8 05 3C 03 lea rbx, [rip + 0x33c05a8]
0x818320 48 89 5C 24 40 mov qword ptr [rsp + 0x40], rbx
0x818325 48 8D 46 24 lea rax, [rsi + 0x24]
0x818329 40 88 7C 24 30 mov byte ptr [rsp + 0x30], dil
0x81832E 45 8B FE mov r15d, r14d
0x818331 48 8D 54 24 34 lea rdx, [rsp + 0x34]
0x818336 44 89 7C 24 34 mov dword ptr [rsp + 0x34], r15d
0x81833B 48 8B C8 mov rcx, rax
0x81833E E8 9D D9 B5 FF call 0x375ce0
0x818343 4C 8B F0 mov r14, rax
0x818346 41 83 FF 05 cmp r15d, 5
0x81834A 0F 83 CB 04 00 00 jae 0x81881b
0x818350 48 63 1B movsxd rbx, dword ptr [rbx]
0x818353 49 8B CD mov rcx, r13
0x818356 8B D3 mov edx, ebx
0x818358 89 5C 24 34 mov dword ptr [rsp + 0x34], ebx
0x81835C E8 77 E2 8D FF call 0xf65d8
0x818361 48 8D 4C 24 70 lea rcx, [rsp + 0x70]
0x818366 BA 80 00 00 00 mov edx, 0x80
0x81836B 0F 10 00 movups xmm0, xmmword ptr [rax]
0x81836E 0F 11 01 movups xmmword ptr [rcx], xmm0
0x818371 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x818375 0F 11 49 10 movups xmmword ptr [rcx + 0x10], xmm1
0x818379 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x81837D 0F 11 41 20 movups xmmword ptr [rcx + 0x20], xmm0
0x818381 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x818385 0F 11 49 30 movups xmmword ptr [rcx + 0x30], xmm1
0x818389 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x81838D 0F 11 41 40 movups xmmword ptr [rcx + 0x40], xmm0
0x818391 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x818395 0F 11 49 50 movups xmmword ptr [rcx + 0x50], xmm1
0x818399 0F 10 40 60 movups xmm0, xmmword ptr [rax + 0x60]
0x81839D 0F 11 41 60 movups xmmword ptr [rcx + 0x60], xmm0
0x8183A1 48 03 CA add rcx, rdx
0x8183A4 0F 10 48 70 movups xmm1, xmmword ptr [rax + 0x70]
0x8183A8 48 03 C2 add rax, rdx
0x8183AB 0F 11 49 F0 movups xmmword ptr [rcx - 0x10], xmm1
0x8183AF 0F 10 00 movups xmm0, xmmword ptr [rax]
0x8183B2 0F 11 01 movups xmmword ptr [rcx], xmm0
0x8183B5 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x8183B9 0F 11 49 10 movups xmmword ptr [rcx + 0x10], xmm1
0x8183BD 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x8183C1 0F 11 41 20 movups xmmword ptr [rcx + 0x20], xmm0
0x8183C5 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x8183C9 0F 11 49 30 movups xmmword ptr [rcx + 0x30], xmm1
0x8183CD 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x8183D1 0F 11 41 40 movups xmmword ptr [rcx + 0x40], xmm0
0x8183D5 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x8183D9 0F 11 49 50 movups xmmword ptr [rcx + 0x50], xmm1
0x8183DD 48 8B 40 60 mov rax, qword ptr [rax + 0x60]
0x8183E1 48 89 41 60 mov qword ptr [rcx + 0x60], rax
0x8183E5 0F B7 54 24 70 movzx edx, word ptr [rsp + 0x70]
0x8183EA 66 85 D2 test dx, dx
0x8183ED 0F 84 23 04 00 00 je 0x818816
0x8183F3 48 8B 0D 36 1A DA 03 mov rcx, qword ptr [rip + 0x3da1a36]
0x8183FA 48 8B 49 68 mov rcx, qword ptr [rcx + 0x68]
0x8183FE E8 B9 C9 8D FF call 0xf4dbc
0x818403 33 D2 xor edx, edx
0x818405 4C 8B E8 mov r13, rax
0x818408 48 85 C0 test rax, rax
0x81840B 0F 84 7A 04 00 00 je 0x81888b
0x818411 38 56 10 cmp byte ptr [rsi + 0x10], dl
0x818414 74 66 je 0x81847c
0x818416 48 8B 4E 08 mov rcx, qword ptr [rsi + 8]
0x81841A 48 85 C9 test rcx, rcx
0x81841D 74 5D je 0x81847c
0x81841F E8 68 A6 D3 FF call 0x552a8c
0x818424 8B C8 mov ecx, eax
0x818426 E8 79 A6 D3 FF call 0x552aa4
0x81842B 33 D2 xor edx, edx
0x81842D 84 C0 test al, al
0x81842F 74 4B je 0x81847c
0x818431 40 8A D7 mov dl, dil
0x818434 48 8D 4C 24 70 lea rcx, [rsp + 0x70]
0x818439 E8 5E 40 2A 01 call 0x1abc49c
0x81843E 48 8B 86 D8 07 00 00 mov rax, qword ptr [rsi + 0x7d8]
0x818445 33 C9 xor ecx, ecx
0x818447 48 85 C0 test rax, rax
0x81844A 74 06 je 0x818452
0x81844C 0F B7 50 52 movzx edx, word ptr [rax + 0x52]
0x818450 EB 02 jmp 0x818454
0x818452 8B D1 mov edx, ecx
0x818454 48 8B CE mov rcx, rsi
0x818457 E8 F8 F8 29 01 call 0x1ab7d54
0x81845C 44 0F B7 C2 movzx r8d, dx
0x818460 48 8D 4C 24 70 lea rcx, [rsp + 0x70]
0x818465 0F B7 D0 movzx edx, ax
0x818468 E8 4B B6 29 01 call 0x1ab3ab8
0x81846D 48 8B D0 mov rdx, rax
0x818470 48 8D 4C 24 70 lea rcx, [rsp + 0x70]
0x818475 E8 56 A9 D3 FF call 0x552dd0
0x81847A 33 D2 xor edx, edx
0x81847C F3 41 0F 10 34 9C movss xmm6, dword ptr [r12 + rbx*4]
0x818482 0F 2F F7 comiss xmm6, xmm7
0x818485 72 21 jb 0x8184a8
0x818487 48 8B CE mov rcx, rsi
0x81848A E8 25 35 AE FF call 0x2fb9b4
0x81848F 4C 8B C0 mov r8, rax
0x818492 48 8D 54 24 70 lea rdx, [rsp + 0x70]
0x818497 49 8B CD mov rcx, r13
0x81849A E8 D9 18 AE FF call 0x2f9d78
0x81849F 33 D2 xor edx, edx
0x8184A1 41 B4 01 mov r12b, 1
0x8184A4 84 C0 test al, al
0x8184A6 75 03 jne 0x8184ab
0x8184A8 44 8A E2 mov r12b, dl
0x8184AB 44 8B 4C 24 38 mov r9d, dword ptr [rsp + 0x38]
0x8184B0 45 8A C4 mov r8b, r12b
0x8184B3 88 54 24 64 mov byte ptr [rsp + 0x64], dl
0x8184B7 49 8B CD mov rcx, r13
0x8184BA 48 8B 44 24 60 mov rax, qword ptr [rsp + 0x60]
0x8184BF 48 8D 54 24 70 lea rdx, [rsp + 0x70]
0x8184C4 48 89 44 24 20 mov qword ptr [rsp + 0x20], rax
0x8184C9 E8 26 F6 FF FF call 0x817af4
0x8184CE 44 8B 4C 24 38 mov r9d, dword ptr [rsp + 0x38]
0x8184D3 48 8D 54 24 70 lea rdx, [rsp + 0x70]
0x8184D8 45 33 D2 xor r10d, r10d
0x8184DB 45 8A C4 mov r8b, r12b
0x8184DE 44 88 54 24 6C mov byte ptr [rsp + 0x6c], r10b
0x8184E3 8B D8 mov ebx, eax
0x8184E5 48 8B 4C 24 68 mov rcx, qword ptr [rsp + 0x68]
0x8184EA 48 89 4C 24 20 mov qword ptr [rsp + 0x20], rcx
0x8184EF 49 8B CD mov rcx, r13
0x8184F2 E8 45 F6 FF FF call 0x817b3c
0x8184F7 48 8B 4E 08 mov rcx, qword ptr [rsi + 8]
0x8184FB 4C 8D 4D 60 lea r9, [rbp + 0x60]
0x8184FF 8B F8 mov edi, eax
0x818501 4C 8D 44 24 70 lea r8, [rsp + 0x70]
0x818506 8B 44 24 34 mov eax, dword ptr [rsp + 0x34]
0x81850A 89 44 24 28 mov dword ptr [rsp + 0x28], eax
0x81850E 48 89 4C 24 20 mov qword ptr [rsp + 0x20], rcx
0x818513 49 8B CD mov rcx, r13
0x818516 E8 49 35 BE FF call 0x3fba64
0x81851B 8B D0 mov edx, eax
0x81851D 8B CB mov ecx, ebx
0x81851F E8 DC FC FF FF call 0x818200
0x818524 0F 57 C0 xorps xmm0, xmm0
0x818527 8D 0C 03 lea ecx, [rbx + rax]
0x81852A F3 48 0F 2A C1 cvtsi2ss xmm0, rcx
0x81852F F3 0F 59 C6 mulss xmm0, xmm6
0x818533 F3 48 0F 2C C8 cvttss2si rcx, xmm0
0x818538 41 89 0E mov dword ptr [r14], ecx
0x81853B 8B CF mov ecx, edi
0x81853D E8 BE FC FF FF call 0x818200
0x818542 44 8B 4C 24 38 mov r9d, dword ptr [rsp + 0x38]
0x818547 48 8D 54 24 70 lea rdx, [rsp + 0x70]
0x81854C 03 C7 add eax, edi
0x81854E 0F 57 C0 xorps xmm0, xmm0
0x818551 33 FF xor edi, edi
0x818553 49 8B CD mov rcx, r13
0x818556 41 89 7E 08 mov dword ptr [r14 + 8], edi
0x81855A F3 48 0F 2A C0 cvtsi2ss xmm0, rax
0x81855F F3 0F 59 C6 mulss xmm0, xmm6
0x818563 F3 48 0F 2C C0 cvttss2si rax, xmm0
0x818568 41 89 46 04 mov dword ptr [r14 + 4], eax
0x81856C 41 0F B6 85 9B 01 00 00 movzx eax, byte ptr [r13 + 0x19b]
0x818574 41 89 46 0C mov dword ptr [r14 + 0xc], eax
0x818578 E8 2B F8 FF FF call 0x817da8
0x81857D 44 8B 4C 24 38 mov r9d, dword ptr [rsp + 0x38]
0x818582 48 8D 54 24 70 lea rdx, [rsp + 0x70]
0x818587 49 8B CD mov rcx, r13
0x81858A 41 89 46 10 mov dword ptr [r14 + 0x10], eax
0x81858E E8 11 F9 FF FF call 0x817ea4
0x818593 41 83 4E 18 FF or dword ptr [r14 + 0x18], 0xffffffff
0x818598 49 8B CD mov rcx, r13
0x81859B 41 89 46 14 mov dword ptr [r14 + 0x14], eax
0x81859F 41 89 7E 1C mov dword ptr [r14 + 0x1c], edi
0x8185A3 E8 2C FB FF FF call 0x8180d4
0x8185A8 F3 41 0F 11 46 20 movss dword ptr [r14 + 0x20], xmm0
0x8185AE 0F 57 C0 xorps xmm0, xmm0
0x8185B1 41 8B 85 E8 00 00 00 mov eax, dword ptr [r13 + 0xe8]
0x8185B8 41 89 46 24 mov dword ptr [r14 + 0x24], eax
0x8185BC 41 8B 85 EC 00 00 00 mov eax, dword ptr [r13 + 0xec]
0x8185C3 41 89 46 28 mov dword ptr [r14 + 0x28], eax
0x8185C7 41 8B 85 F0 00 00 00 mov eax, dword ptr [r13 + 0xf0]
0x8185CE F3 48 0F 2A C0 cvtsi2ss xmm0, rax
0x8185D3 F3 0F 59 05 B5 C2 3B 03 mulss xmm0, dword ptr [rip + 0x33bc2b5]
0x8185DB F3 41 0F 11 46 2C movss dword ptr [r14 + 0x2c], xmm0
0x8185E1 E8 06 FB FF FF call 0x8180ec
0x8185E6 F3 41 0F 11 46 30 movss dword ptr [r14 + 0x30], xmm0
0x8185EC 41 8B 45 48 mov eax, dword ptr [r13 + 0x48]
0x8185F0 41 89 46 34 mov dword ptr [r14 + 0x34], eax
0x8185F4 41 0F B6 85 9A 01 00 00 movzx eax, byte ptr [r13 + 0x19a]
0x8185FC 41 89 46 38 mov dword ptr [r14 + 0x38], eax
0x818600 41 8B 85 B0 00 00 00 mov eax, dword ptr [r13 + 0xb0]
0x818607 C1 E8 03 shr eax, 3
0x81860A 24 01 and al, 1
0x81860C 4C 8B 6C 24 58 mov r13, qword ptr [rsp + 0x58]
0x818611 41 88 46 3C mov byte ptr [r14 + 0x3c], al
0x818615 41 88 7E 3D mov byte ptr [r14 + 0x3d], dil
0x818619 49 63 85 E0 1E 00 00 movsxd rax, dword ptr [r13 + 0x1ee0]
0x818620 48 69 C8 70 0F 00 00 imul rcx, rax, 0xf70
0x818627 8B C7 mov eax, edi
0x818629 42 38 BC 29 68 0F 00 00 cmp byte ptr [rcx + r13 + 0xf68], dil
0x818631 8B 4C 24 34 mov ecx, dword ptr [rsp + 0x34]
0x818635 0F 94 C0 sete al
0x818638 3B C1 cmp eax, ecx
0x81863A 74 0B je 0x818647
0x81863C 83 F9 0D cmp ecx, 0xd
0x81863F 74 06 je 0x818647
0x818641 33 C9 xor ecx, ecx
0x818643 8A C1 mov al, cl
0x818645 EB 04 jmp 0x81864b
0x818647 B0 01 mov al, 1
0x818649 33 C9 xor ecx, ecx
0x81864B 38 8E D0 07 00 00 cmp byte ptr [rsi + 0x7d0], cl
0x818651 0F 85 B0 01 00 00 jne 0x818807
0x818657 48 39 8E D8 07 00 00 cmp qword ptr [rsi + 0x7d8], rcx
0x81865E 0F 84 A3 01 00 00 je 0x818807
0x818664 45 84 E4 test r12b, r12b
0x818667 0F 84 9A 01 00 00 je 0x818807
0x81866D 38 8D 18 01 00 00 cmp byte ptr [rbp + 0x118], cl
0x818673 0F 85 8E 01 00 00 jne 0x818807
0x818679 44 8B 44 24 48 mov r8d, dword ptr [rsp + 0x48]
0x81867E 48 8D 54 24 70 lea rdx, [rsp + 0x70]
0x818683 F6 D8 neg al
0x818685 48 8B CE mov rcx, rsi
0x818688 45 1A C9 sbb r9b, r9b
0x81868B E8 BC EF D3 FF call 0x55764c
0x818690 48 8B 5C 24 40 mov rbx, qword ptr [rsp + 0x40]
0x818695 4C 8B 64 24 50 mov r12, qword ptr [rsp + 0x50]
0x81869A 33 C9 xor ecx, ecx
0x81869C 40 8A 7C 24 30 mov dil, byte ptr [rsp + 0x30]
0x8186A1 48 8D 46 24 lea rax, [rsi + 0x24]
0x8186A5 48 83 C3 04 add rbx, 4
0x8186A9 41 FF C7 inc r15d
0x8186AC 48 89 5C 24 40 mov qword ptr [rsp + 0x40], rbx
0x8186B1 41 83 FF 06 cmp r15d, 6
0x8186B5 0F 8C 76 FC FF FF jl 0x818331
0x8186BB 48 39 8E D8 07 00 00 cmp qword ptr [rsi + 0x7d8], rcx
0x8186C2 0F 84 5D 02 00 00 je 0x818925
0x8186C8 38 8D 18 01 00 00 cmp byte ptr [rbp + 0x118], cl
0x8186CE 0F 85 51 02 00 00 jne 0x818925
0x8186D4 8B D9 mov ebx, ecx
0x8186D6 4C 8D 35 EB 01 3C 03 lea r14, [rip + 0x33c01eb]
0x8186DD 44 8A E7 mov r12b, dil
0x8186E0 45 33 D2 xor r10d, r10d
0x8186E3 83 FB 05 cmp ebx, 5
0x8186E6 0F 83 2A 02 00 00 jae 0x818916
0x8186EC 4D 63 3E movsxd r15, dword ptr [r14]
0x8186EF 49 8B CD mov rcx, r13
0x8186F2 45 8B 85 E0 1E 00 00 mov r8d, dword ptr [r13 + 0x1ee0]
0x8186F9 41 8B D7 mov edx, r15d
0x8186FC 41 83 F0 01 xor r8d, 1
0x818700 E8 0F DF 8D FF call 0xf6614
0x818705 48 8D 4C 24 70 lea rcx, [rsp + 0x70]
0x81870A BA 80 00 00 00 mov edx, 0x80
0x81870F 0F 10 00 movups xmm0, xmmword ptr [rax]
0x818712 0F 11 01 movups xmmword ptr [rcx], xmm0
0x818715 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x818719 0F 11 49 10 movups xmmword ptr [rcx + 0x10], xmm1
0x81871D 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x818721 0F 11 41 20 movups xmmword ptr [rcx + 0x20], xmm0
0x818725 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x818729 0F 11 49 30 movups xmmword ptr [rcx + 0x30], xmm1
0x81872D 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x818731 0F 11 41 40 movups xmmword ptr [rcx + 0x40], xmm0
0x818735 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x818739 0F 11 49 50 movups xmmword ptr [rcx + 0x50], xmm1
0x81873D 0F 10 40 60 movups xmm0, xmmword ptr [rax + 0x60]
0x818741 0F 11 41 60 movups xmmword ptr [rcx + 0x60], xmm0
0x818745 48 03 CA add rcx, rdx
0x818748 0F 10 48 70 movups xmm1, xmmword ptr [rax + 0x70]
0x81874C 48 03 C2 add rax, rdx
0x81874F 0F 11 49 F0 movups xmmword ptr [rcx - 0x10], xmm1
0x818753 0F 10 00 movups xmm0, xmmword ptr [rax]
0x818756 0F 11 01 movups xmmword ptr [rcx], xmm0
0x818759 0F 10 48 10 movups xmm1, xmmword ptr [rax + 0x10]
0x81875D 0F 11 49 10 movups xmmword ptr [rcx + 0x10], xmm1
0x818761 0F 10 40 20 movups xmm0, xmmword ptr [rax + 0x20]
0x818765 0F 11 41 20 movups xmmword ptr [rcx + 0x20], xmm0
0x818769 0F 10 48 30 movups xmm1, xmmword ptr [rax + 0x30]
0x81876D 0F 11 49 30 movups xmmword ptr [rcx + 0x30], xmm1
0x818771 0F 10 40 40 movups xmm0, xmmword ptr [rax + 0x40]
0x818775 0F 11 41 40 movups xmmword ptr [rcx + 0x40], xmm0
0x818779 0F 10 48 50 movups xmm1, xmmword ptr [rax + 0x50]
0x81877D 0F 11 49 50 movups xmmword ptr [rcx + 0x50], xmm1
0x818781 48 8B 40 60 mov rax, qword ptr [rax + 0x60]
0x818785 48 89 41 60 mov qword ptr [rcx + 0x60], rax
0x818789 0F B7 54 24 70 movzx edx, word ptr [rsp + 0x70]
0x81878E 66 85 D2 test dx, dx
0x818791 0F 84 7F 01 00 00 je 0x818916
0x818797 48 8B 0D 92 16 DA 03 mov rcx, qword ptr [rip + 0x3da1692]
0x81879E 48 8B 49 68 mov rcx, qword ptr [rcx + 0x68]
0x8187A2 E8 15 C6 8D FF call 0xf4dbc
0x8187A7 33 C9 xor ecx, ecx
0x8187A9 48 8B F8 mov rdi, rax
0x8187AC 48 85 C0 test rax, rax
0x8187AF 0F 84 5E 01 00 00 je 0x818913
0x8187B5 38 4E 10 cmp byte ptr [rsi + 0x10], cl
0x8187B8 0F 84 01 01 00 00 je 0x8188bf
0x8187BE 48 8B 4E 08 mov rcx, qword ptr [rsi + 8]
0x8187C2 48 85 C9 test rcx, rcx
0x8187C5 0F 84 F4 00 00 00 je 0x8188bf
0x8187CB E8 BC A2 D3 FF call 0x552a8c
0x8187D0 8B C8 mov ecx, eax
0x8187D2 E8 CD A2 D3 FF call 0x552aa4
0x8187D7 84 C0 test al, al
0x8187D9 0F 84 E0 00 00 00 je 0x8188bf
0x8187DF 41 8A D4 mov dl, r12b
0x8187E2 48 8D 4C 24 70 lea rcx, [rsp + 0x70]
0x8187E7 E8 B0 3C 2A 01 call 0x1abc49c
0x8187EC 48 8B 86 D8 07 00 00 mov rax, qword ptr [rsi + 0x7d8]
0x8187F3 33 C9 xor ecx, ecx
0x8187F5 48 85 C0 test rax, rax
0x8187F8 0F 84 99 00 00 00 je 0x818897
0x8187FE 0F B7 50 52 movzx edx, word ptr [rax + 0x52]
0x818802 E9 92 00 00 00 jmp 0x818899
0x818807 48 8B 5C 24 40 mov rbx, qword ptr [rsp + 0x40]
0x81880C 4C 8B 64 24 50 mov r12, qword ptr [rsp + 0x50]
0x818811 E9 86 FE FF FF jmp 0x81869c
0x818816 48 8B 5C 24 40 mov rbx, qword ptr [rsp + 0x40]
0x81881B 33 D2 xor edx, edx
0x81881D 41 83 FF 04 cmp r15d, 4
0x818821 0F 84 73 FE FF FF je 0x81869a
0x818827 48 8B 46 08 mov rax, qword ptr [rsi + 8]
0x81882B B9 19 00 00 00 mov ecx, 0x19
0x818830 39 50 24 cmp dword ptr [rax + 0x24], edx
0x818833 75 08 jne 0x81883d
0x818835 E8 CA F8 FF FF call 0x818104
0x81883A 0F B7 C8 movzx ecx, ax
0x81883D 41 89 0E mov dword ptr [r14], ecx
0x818840 41 89 4E 04 mov dword ptr [r14 + 4], ecx
0x818844 33 C9 xor ecx, ecx
0x818846 41 83 4E 18 FF or dword ptr [r14 + 0x18], 0xffffffff
0x81884B 41 89 4E 08 mov dword ptr [r14 + 8], ecx
0x81884F 49 89 4E 1C mov qword ptr [r14 + 0x1c], rcx
0x818853 49 89 4E 24 mov qword ptr [r14 + 0x24], rcx
0x818857 49 89 4E 2C mov qword ptr [r14 + 0x2c], rcx
0x81885B 41 89 4E 34 mov dword ptr [r14 + 0x34], ecx
0x81885F 41 C7 46 0C 02 00 00 00 mov dword ptr [r14 + 0xc], 2
0x818867 41 C7 46 10 14 00 00 00 mov dword ptr [r14 + 0x10], 0x14
0x81886F 41 C7 46 14 0A 00 00 00 mov dword ptr [r14 + 0x14], 0xa
0x818877 41 C7 46 38 0D 00 00 00 mov dword ptr [r14 + 0x38], 0xd
0x81887F 66 41 C7 46 3C 00 01 mov word ptr [r14 + 0x3c], 0x100
0x818886 E9 11 FE FF FF jmp 0x81869c
0x81888B 48 8B 5C 24 40 mov rbx, qword ptr [rsp + 0x40]
0x818890 4C 8B 6C 24 58 mov r13, qword ptr [rsp + 0x58]
0x818895 EB 86 jmp 0x81881d
0x818897 8B D1 mov edx, ecx
0x818899 48 8B CE mov rcx, rsi
0x81889C E8 B3 F4 29 01 call 0x1ab7d54
0x8188A1 44 0F B7 C2 movzx r8d, dx
0x8188A5 48 8D 4C 24 70 lea rcx, [rsp + 0x70]
0x8188AA 0F B7 D0 movzx edx, ax
0x8188AD E8 06 B2 29 01 call 0x1ab3ab8
0x8188B2 48 8B D0 mov rdx, rax
0x8188B5 48 8D 4C 24 70 lea rcx, [rsp + 0x70]
0x8188BA E8 11 A5 D3 FF call 0x552dd0
0x8188BF 48 8B 4C 24 50 mov rcx, qword ptr [rsp + 0x50]
0x8188C4 F3 42 0F 10 04 B9 movss xmm0, dword ptr [rcx + r15*4]
0x8188CA 0F 2F C7 comiss xmm0, xmm7
0x8188CD 72 22 jb 0x8188f1
0x8188CF 48 8B CE mov rcx, rsi
0x8188D2 E8 DD 30 AE FF call 0x2fb9b4
0x8188D7 4C 8B C0 mov r8, rax
0x8188DA 48 8D 54 24 70 lea rdx, [rsp + 0x70]
0x8188DF 48 8B CF mov rcx, rdi
0x8188E2 E8 91 14 AE FF call 0x2f9d78
0x8188E7 33 C9 xor ecx, ecx
0x8188E9 84 C0 test al, al
0x8188EB 74 06 je 0x8188f3
0x8188ED B0 01 mov al, 1
0x8188EF EB 04 jmp 0x8188f5
0x8188F1 33 C9 xor ecx, ecx
0x8188F3 8A C1 mov al, cl
0x8188F5 38 8E D0 07 00 00 cmp byte ptr [rsi + 0x7d0], cl
0x8188FB 75 16 jne 0x818913
0x8188FD 84 C0 test al, al
0x8188FF 74 12 je 0x818913
0x818901 44 8B 44 24 4C mov r8d, dword ptr [rsp + 0x4c]
0x818906 48 8D 54 24 70 lea rdx, [rsp + 0x70]
0x81890B 48 8B CE mov rcx, rsi
0x81890E E8 C9 CE D3 FF call 0x5557dc
0x818913 45 33 D2 xor r10d, r10d
0x818916 FF C3 inc ebx
0x818918 49 83 C6 04 add r14, 4
0x81891C 83 FB 06 cmp ebx, 6
0x81891F 0F 8C BE FD FF FF jl 0x8186e3
0x818925 48 8B 8D 80 00 00 00 mov rcx, qword ptr [rbp + 0x80]
0x81892C 48 33 CC xor rcx, rsp
0x81892F E8 AC 89 37 00 call 0xb912e0
0x818934 4C 8D 9C 24 B0 01 00 00 lea r11, [rsp + 0x1b0]
0x81893C 49 8B 5B 50 mov rbx, qword ptr [r11 + 0x50]
0x818940 41 0F 28 73 F0 movaps xmm6, xmmword ptr [r11 - 0x10]
0x818945 41 0F 28 7B E0 movaps xmm7, xmmword ptr [r11 - 0x20]
0x81894A 49 8B E3 mov rsp, r11
0x81894D 41 5F pop r15
0x81894F 41 5E pop r14
0x818951 41 5D pop r13
0x818953 41 5C pop r12
0x818955 5F pop rdi
0x818956 5E pop rsi
0x818957 5D pop rbp
0x818958 C3 ret 
