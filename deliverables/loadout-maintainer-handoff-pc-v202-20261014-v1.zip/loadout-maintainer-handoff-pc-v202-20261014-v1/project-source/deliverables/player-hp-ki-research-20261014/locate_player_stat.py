"""Task-local vtable locator using the existing bounded read-only pattern scanner."""
import argparse
import hashlib
import json
import struct
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'deliverables/load-capacity-research/scripts')]
from scan_capacity import _identity, scan
from nioh3_scroll_editor.process_memory_readonly import ProcessReader
from nioh3_scroll_editor.runtime_catalog_probe import MEM_PRIVATE
from reference import EXE_SHA256


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    report=dict(schema='nioh3-player-stat-vtable-locator/v1',at_utc=datetime.now(timezone.utc).isoformat(),
                classification='read-only exploratory identity candidates',candidates=[],game_writes=0,
                debugger_used=False,limits=dict(max_bytes=268435456,max_hits=128,max_seconds=12))
    sections=ROOT/'deliverables/load-capacity-research/disassembly/live-sections'
    rdata=(sections/'Nioh3_v2.0.2.0.rdata.bin').read_bytes()
    if hashlib.sha256(rdata).hexdigest()!='0e701e3455ec1d605ceaa4f493b0898611e0d2914d57abfb0806c775513db66f':
        raise ValueError('Retained rdata mismatch')
    old_base=0x7FF64E550000
    # 818B68 is a direct callee, not a vtable entry. Its wrapper 377394
    # dispatches the player branch and appears in the stat virtual table.
    needle=struct.pack('<Q',old_base+0x377394)
    cursor=0;vtables={}
    while True:
        cursor=rdata.find(needle,cursor)
        if cursor<0:break
        if cursor%8==0:
            start=cursor
            for _ in range(64):
                previous=struct.unpack_from('<Q',rdata,start-8)[0]-old_base
                if not 0x1000<=previous<0x38E2000:break
                start-=8
            vtables[0x38E2000+start]=dict(rebuild_slot=cursor-start,source_entry_rva=hex(0x38E2000+cursor))
        cursor+=1
    vtables.setdefault(0x3A737E8,dict(source='stat constructor 5FDB1C; fallback candidate'))
    report['native_vtable_candidates']={hex(k):v for k,v in vtables.items()}
    with ProcessReader() as reader:
        identity=_identity(reader)
        report['identity']=identity
        if identity['executable_sha256']!=EXE_SHA256:raise ValueError('Executable mismatch')
        player=reader.u64(reader.module_base+0x4751850)
        if reader.u64(player)!=reader.module_base+0x402DA20:raise ValueError('Player identity mismatch')
        if tuple(struct.unpack('<7I',reader.read(player+0x94,28)))!=(5,5,5,6,5,5,5):raise ValueError('Control changed')
        patterns={hex(rva):struct.pack('<Q',reader.module_base+rva) for rva in vtables}
        if not patterns:raise ValueError('No native vtable')
        start=max(0x10000,player-0x08000000);end=player+0x08000000
        report['scan']=scan(reader,0,268435456,128,[],byte_patterns=patterns,max_seconds=12,
                            start_address=start,end_address=end,memory_types={MEM_PRIVATE})
        for hit in report['scan']['hits']:
            address=int(hit['address'],16)
            try:
                raw=reader.read(address,0x7E0)
                owner=struct.unpack_from('<Q',raw,8)[0]
                backing=struct.unpack_from('<Q',raw,0x7D8)[0]
                selected_hp,selected_ki=struct.unpack_from('<II',raw,0x18)
                effective=struct.unpack('<7I',reader.read(backing+0x34,28)) if backing else None
                effective_level=reader.u32(backing+0x30) if backing else None
                report['candidates'].append(dict(address=hex(address),vtable_rva=hit['type'],owner=hex(owner),
                    backing=hex(backing),selected_hp=selected_hp,selected_ki=selected_ki,
                    effective_attributes=effective,effective_level=effective_level,
                    matches_control=effective==(5,5,5,6,5,5,5) and effective_level==1))
            except Exception as error:
                report['candidates'].append(dict(address=hex(address),error=str(error)))
        if reader.creation_time()!=identity['process_birth_filetime']:raise ValueError('Process changed')
    report['cleanup']='Read-only handle closed; no breakpoints, timers or game writes'
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(vtables=report['native_vtable_candidates'],hits=len(report['scan']['hits']),
                         bytes=report['scan']['scanned_bytes'],candidates=report['candidates'])))


if __name__=='__main__':main()
