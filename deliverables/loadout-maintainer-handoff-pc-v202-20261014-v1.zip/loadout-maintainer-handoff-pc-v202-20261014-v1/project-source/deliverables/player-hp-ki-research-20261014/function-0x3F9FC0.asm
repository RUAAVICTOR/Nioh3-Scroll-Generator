0x3F9FC0 48 89 5C 24 18 mov qword ptr [rsp + 0x18], rbx
0x3F9FC5 48 89 6C 24 20 mov qword ptr [rsp + 0x20], rbp
0x3F9FCA 56 push rsi
0x3F9FCB 57 push rdi
0x3F9FCC 41 56 push r14
0x3F9FCE 48 83 EC 30 sub rsp, 0x30
0x3F9FD2 48 8B 05 57 DF 0B 04 mov rax, qword ptr [rip + 0x40bdf57]
0x3F9FD9 48 33 C4 xor rax, rsp
0x3F9FDC 48 89 44 24 28 mov qword ptr [rsp + 0x28], rax
0x3F9FE1 44 8B B2 E0 1E 00 00 mov r14d, dword ptr [rdx + 0x1ee0]
0x3F9FE8 48 8D 5C 24 20 lea rbx, [rsp + 0x20]
0x3F9FED B8 2B D1 00 00 mov eax, 0xd12b
0x3F9FF2 C7 44 24 20 E2 1E 37 C4 mov dword ptr [rsp + 0x20], 0xc4371ee2
0x3F9FFA 66 89 44 24 24 mov word ptr [rsp + 0x24], ax
0x3F9FFF 48 8B EA mov rbp, rdx
0x3FA002 48 8B F1 mov rsi, rcx
0x3FA005 0F B7 13 movzx edx, word ptr [rbx]
0x3FA008 E8 EB 8E 15 00 call 0x552ef8
0x3FA00D 44 0F B7 03 movzx r8d, word ptr [rbx]
0x3FA011 48 8B D5 mov rdx, rbp
0x3FA014 48 8B CE mov rcx, rsi
0x3FA017 8B F8 mov edi, eax
0x3FA019 E8 EA 0C 00 00 call 0x3fad08
0x3FA01E 0F B7 0B movzx ecx, word ptr [rbx]
0x3FA021 03 F8 add edi, eax
0x3FA023 E8 38 00 00 00 call 0x3fa060
0x3FA028 03 F8 add edi, eax
0x3FA02A 85 FF test edi, edi
0x3FA02C 0F 8F 04 70 5A 01 jg 0x19a1036
0x3FA032 48 83 C3 02 add rbx, 2
0x3FA036 48 8D 44 24 26 lea rax, [rsp + 0x26]
0x3FA03B 48 3B D8 cmp rbx, rax
0x3FA03E 75 C5 jne 0x3fa005
0x3FA040 48 8B 4C 24 28 mov rcx, qword ptr [rsp + 0x28]
0x3FA045 48 33 CC xor rcx, rsp
0x3FA048 E8 93 72 79 00 call 0xb912e0
0x3FA04D 48 8B 5C 24 60 mov rbx, qword ptr [rsp + 0x60]
0x3FA052 48 8B 6C 24 68 mov rbp, qword ptr [rsp + 0x68]
0x3FA057 48 83 C4 30 add rsp, 0x30
0x3FA05B 41 5E pop r14
0x3FA05D 5F pop rdi
0x3FA05E 5E pop rsi
0x3FA05F C3 ret 
