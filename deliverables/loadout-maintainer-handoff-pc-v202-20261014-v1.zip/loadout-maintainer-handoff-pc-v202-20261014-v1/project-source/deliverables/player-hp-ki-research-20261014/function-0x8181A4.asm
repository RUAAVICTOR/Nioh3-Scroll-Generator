0x8181A4 48 89 5C 24 08 mov qword ptr [rsp + 8], rbx
0x8181A9 57 push rdi
0x8181AA 48 83 EC 20 sub rsp, 0x20
0x8181AE 48 8B 05 7B 1C DA 03 mov rax, qword ptr [rip + 0x3da1c7b]
0x8181B5 41 8B F9 mov edi, r9d
0x8181B8 45 8B D0 mov r10d, r8d
0x8181BB 4C 8B 98 90 00 00 00 mov r11, qword ptr [rax + 0x90]
0x8181C2 49 8B CB mov rcx, r11
0x8181C5 E8 22 09 00 00 call 0x818aec
0x8181CA 41 8B D2 mov edx, r10d
0x8181CD 49 8B CB mov rcx, r11
0x8181D0 48 8B D8 mov rbx, rax
0x8181D3 E8 14 09 00 00 call 0x818aec
0x8181D8 8B D7 mov edx, edi
0x8181DA 49 8B CB mov rcx, r11
0x8181DD 44 0F B7 48 02 movzx r9d, word ptr [rax + 2]
0x8181E2 E8 05 09 00 00 call 0x818aec
0x8181E7 0F B7 0B movzx ecx, word ptr [rbx]
0x8181EA 48 8B 5C 24 30 mov rbx, qword ptr [rsp + 0x30]
0x8181EF 0F B7 40 0C movzx eax, word ptr [rax + 0xc]
0x8181F3 41 03 C1 add eax, r9d
0x8181F6 03 C1 add eax, ecx
0x8181F8 48 83 C4 20 add rsp, 0x20
0x8181FC 5F pop rdi
0x8181FD C3 ret 
