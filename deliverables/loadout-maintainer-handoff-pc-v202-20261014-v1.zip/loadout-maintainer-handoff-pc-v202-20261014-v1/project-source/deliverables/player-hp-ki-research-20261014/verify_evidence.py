"""Verify this task's instruction/carrier bytes against retained PC v2.02 sections."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = ROOT / "deliverables/load-capacity-research/disassembly/live-sections"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    output = HERE / "byte-parity-verification.json"
    if output.exists():
        raise FileExistsError(output)
    manifest = json.loads((SOURCE / "manifest.json").read_text())
    sources = {}
    for entry in manifest["sections"]:
        raw = (SOURCE / entry["filename"]).read_bytes()
        assert len(raw) == entry["size"]
        assert digest(raw) == entry["sha256"].lower()
        sources[entry["name"]] = (int(entry["rva"], 16), raw)
    text_rva, text = sources[".text"]
    instructions = 0
    decoded_bytes = 0
    for phase in range(1, 6):
        evidence = json.loads((HERE / f"instructions-{phase:02d}.json").read_text())
        for function in evidence["functions"]:
            for instruction in function["instructions"]:
                raw = bytes.fromhex(instruction["bytes_hex"])
                offset = int(instruction["rva"], 16) - text_rva
                assert text[offset:offset+len(raw)] == raw
                instructions += 1
                decoded_bytes += len(raw)
    carriers = []
    for phase in range(1, 5):
        metadata = json.loads((HERE / f"carrier-{phase:02d}.json").read_text())
        image = Path(metadata["output"]).read_bytes()
        assert digest(image) == metadata["output_sha256"]
        assert metadata["source_game_sha256"] == manifest["executable"]["sha256"].lower()
        pages = 0
        for section in metadata["sections"]:
            raw = image[section["file_offset"]:section["file_offset"]+section["size"]]
            assert digest(raw) == section["sha256"]
            if section["name"].startswith(".c"):
                offset = int(section["rva"], 16) - text_rva
                assert text[offset:offset+len(raw)] == raw
                pages += 1
            elif section["name"] == ".rdata":
                assert raw == sources[".rdata"][1]
            elif section["name"] == ".pdata":
                # The focused index is intentionally filtered, not byte-equal
                # as a whole. Every selected original entry must still exist.
                for offset in range(0, len(raw), 12):
                    assert raw[offset:offset+12] in sources[".pdata"][1]
        assert pages == metadata["code_pages"]
        carriers.append(dict(phase=phase, code_pages=pages, sha256=metadata["output_sha256"],
                             source_sha256_unchanged=True))
    report = dict(schema="nioh3-player-hp-ki-byte-parity/v1", status="passed",
                  instruction_records_checked=instructions, instruction_bytes_checked=decoded_bytes,
                  carriers=carriers, source_section_hashes_verified=True,
                  limitations=["Byte parity proves the analysis input, not game execution or semantic completeness.",
                               "Focused carriers omit unselected callers/code and have a synthetic entry.",
                               "The source dump did not retain the original PID or module base; the analysis base is inferred."])
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
