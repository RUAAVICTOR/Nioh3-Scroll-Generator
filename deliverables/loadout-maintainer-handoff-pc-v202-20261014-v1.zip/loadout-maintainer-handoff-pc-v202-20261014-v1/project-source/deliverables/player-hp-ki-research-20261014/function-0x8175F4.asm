0x8175F4 48 8B D1 mov rdx, rcx
0x8175F7 48 8B 89 D8 07 00 00 mov rcx, qword ptr [rcx + 0x7d8]
0x8175FE 48 85 C9 test rcx, rcx
0x817601 0F 84 BF 00 00 00 je 0x8176c6
0x817607 8B 81 80 58 00 00 mov eax, dword ptr [rcx + 0x5880]
0x81760D 01 42 18 add dword ptr [rdx + 0x18], eax
0x817610 8B 81 88 58 00 00 mov eax, dword ptr [rcx + 0x5888]
0x817616 01 82 C4 01 00 00 add dword ptr [rdx + 0x1c4], eax
0x81761C 48 8B C1 mov rax, rcx
0x81761F 8B 89 8C 58 00 00 mov ecx, dword ptr [rcx + 0x588c]
0x817625 01 8A 94 07 00 00 add dword ptr [rdx + 0x794], ecx
0x81762B 8B 88 9C 58 00 00 mov ecx, dword ptr [rax + 0x589c]
0x817631 01 8A C8 01 00 00 add dword ptr [rdx + 0x1c8], ecx
0x817637 8B 88 90 58 00 00 mov ecx, dword ptr [rax + 0x5890]
0x81763D 01 4A 2C add dword ptr [rdx + 0x2c], ecx
0x817640 8B 88 94 58 00 00 mov ecx, dword ptr [rax + 0x5894]
0x817646 01 8A 2C 01 00 00 add dword ptr [rdx + 0x12c], ecx
0x81764C 66 0F 6E 90 A0 58 00 00 movd xmm2, dword ptr [rax + 0x58a0]
0x817654 0F 5B D2 cvtdq2ps xmm2, xmm2
0x817657 0F 28 C2 movaps xmm0, xmm2
0x81765A 0F 28 CA movaps xmm1, xmm2
0x81765D F3 0F 58 82 24 02 00 00 addss xmm0, dword ptr [rdx + 0x224]
0x817665 F3 0F 58 8A 44 02 00 00 addss xmm1, dword ptr [rdx + 0x244]
0x81766D F3 0F 11 82 24 02 00 00 movss dword ptr [rdx + 0x224], xmm0
0x817675 0F 28 C2 movaps xmm0, xmm2
0x817678 F3 0F 58 82 64 02 00 00 addss xmm0, dword ptr [rdx + 0x264]
0x817680 F3 0F 11 8A 44 02 00 00 movss dword ptr [rdx + 0x244], xmm1
0x817688 0F 28 CA movaps xmm1, xmm2
0x81768B F3 0F 58 8A 84 02 00 00 addss xmm1, dword ptr [rdx + 0x284]
0x817693 F3 0F 11 82 64 02 00 00 movss dword ptr [rdx + 0x264], xmm0
0x81769B 0F 28 C2 movaps xmm0, xmm2
0x81769E F3 0F 58 82 A4 02 00 00 addss xmm0, dword ptr [rdx + 0x2a4]
0x8176A6 F3 0F 58 92 C4 02 00 00 addss xmm2, dword ptr [rdx + 0x2c4]
0x8176AE F3 0F 11 8A 84 02 00 00 movss dword ptr [rdx + 0x284], xmm1
0x8176B6 F3 0F 11 82 A4 02 00 00 movss dword ptr [rdx + 0x2a4], xmm0
0x8176BE F3 0F 11 92 C4 02 00 00 movss dword ptr [rdx + 0x2c4], xmm2
0x8176C6 C3 ret 
