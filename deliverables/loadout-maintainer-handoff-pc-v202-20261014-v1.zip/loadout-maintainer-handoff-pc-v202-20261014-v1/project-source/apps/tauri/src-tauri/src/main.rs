#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
mod broker;
mod game_install;
mod game_version;
mod onefile;
mod package;
mod storage;
#[cfg(test)]
mod tests;
mod update;
mod worker;
use broker::Broker;
use serde_json::{json, Value};
use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};
use tauri::Manager;
use tauri_plugin_clipboard_manager::ClipboardExt;
use tauri_plugin_dialog::DialogExt;
use tauri_plugin_opener::OpenerExt;

const QQ_INVITE_URL: &str = "https://qm.qq.com/cgi-bin/qm/qr?k=0qS7eJtELBBcN8_ne4B7qG-c63Ze6pIo&jump_from=webapi&authKey=OMNXRYe8Ns3exbv9xiDr6HOQca3C/F+f5dVguJS7d2NFCf5URf308buzPfPXaf2G";
const QQ_PROFILE_URL: &str = "tencent://ntqq-open?subCmd=profile&action=openMiniBuddyProfile&actionParams=%7B%22uin%22%3A%221106302479%22%2C%22sourceType%22%3A%22QrCodeShareBuddyLink%22%7D";

fn qq_protocol_from_html(html: &str) -> Option<String> {
    let encoded = html.split_once("var qsig = \"")?.1.split_once("\";")?.0;
    let protocol = encoded.replace("\\/", "/").replace("\\u0026", "&");
    let url = tauri::Url::parse(&protocol).ok()?;
    if url.scheme() != "tencent" || url.host_str() != Some("groupwpa") || url.path() != "/" {
        return None;
    }
    let mut subcommand = false;
    let mut valid_parameter = false;
    for (name, value) in url.query_pairs() {
        match name.as_ref() {
            "subcmd" => subcommand = value == "all",
            "param" => {
                valid_parameter = value.len() >= 32
                    && value.len() <= 4096
                    && value.contains("31313036333032343739")
                    && value.as_bytes().iter().all(u8::is_ascii_hexdigit)
            }
            _ => return None,
        }
    }
    (subcommand && valid_parameter).then(|| format!("{protocol}&jump_from=webapi"))
}

async fn qq_protocol() -> Option<String> {
    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(4))
        .user_agent("Nioh3-Studio")
        .build()
        .ok()?;
    let response = client.get(QQ_INVITE_URL).send().await.ok()?;
    if !response.status().is_success() {
        return None;
    }
    qq_protocol_from_html(&response.text().await.ok()?)
}

struct State {
    broker: Arc<Broker>,
    updater: Arc<update::Updater>,
    packaged: bool,
    update_ready: AtomicBool,
    apply_update: AtomicBool,
    quitting: AtomicBool,
    closing: AtomicBool,
}
fn trusted(url: &tauri::Url) -> bool {
    url.port().is_none()
        && url.username().is_empty()
        && url.password().is_none()
        && ((url.scheme() == "tauri" && url.host_str() == Some("localhost"))
            || (["http", "https"].contains(&url.scheme())
                && url.host_str() == Some("tauri.localhost")))
}

fn test_debug_port() -> Option<u16> {
    std::env::var_os("NIOH3_TAURI_TEST_ROOT")?;
    std::env::var("NIOH3_TAURI_TEST_DEBUG_PORT")
        .ok()?
        .parse::<u16>()
        .ok()
        .filter(|port| *port != 0)
}

/// Log which worker graph each role resolved to, and where.
///
/// This is the host's own resolution, recorded before any worker starts, so a
/// packaged acceptance can prove the argv the host would spawn without inferring
/// it from a separately launched binary. A package that declares a backend it
/// cannot run logs the refusal instead of falling back.
fn log_resolved_workers(root: &std::path::Path, data: &std::path::Path, packaged: bool) {
    for role in ["offline_search", "save", "runtime"] {
        let (executable, arguments) = match worker::resolve_role_launch(root, role, packaged, data)
        {
            Ok(launch) => launch,
            Err(error) => {
                storage::log(
                    data,
                    "worker-backend",
                    &format!("role={role} resolution failed: {error}"),
                );
                continue;
            }
        };
        let digest = std::fs::read(&executable)
            .ok()
            .map(|bytes| {
                use sha2::{Digest, Sha256};
                format!("{:x}", Sha256::digest(&bytes))
            })
            .unwrap_or_else(|| "unavailable".into());
        storage::log(
            data,
            "worker-backend",
            &format!(
                "role={role} executable={} sha256={digest} argv={}",
                executable.display(),
                arguments.join(" ")
            ),
        );
    }
}

#[tauri::command]
async fn desktop_request(
    app: tauri::AppHandle,
    window: tauri::WebviewWindow,
    state: tauri::State<'_, State>,
    channel: String,
    value: Value,
) -> Result<Value, String> {
    if window.label() != "main" {
        return Err("UNTRUSTED_WINDOW".into());
    }
    let url = window.url().map_err(|e| e.to_string())?;
    if !trusted(&url) {
        return Err("UNTRUSTED_ORIGIN".into());
    }
    if state.closing.load(Ordering::SeqCst) {
        return Err("APPLICATION_CLOSING".into());
    }
    let broker = &state.broker;
    match channel.as_str() {
        "support:ready" => {
            if state.packaged && !state.update_ready.load(Ordering::SeqCst) {
                broker.dispatch("core:handshake", Value::Null).await?;
                if let Err(error) = state.updater.cleanup(&broker.root) {
                    storage::log(&broker.data, "update-cleanup-deferred", &error);
                }
                state.update_ready.store(true, Ordering::SeqCst);
            }
            Ok(Value::Null)
        }
        "review:window" => {
            match value.as_str() {
                Some("minimize") => window.minimize(),
                Some("maximize") => {
                    if window.is_maximized().map_err(|e| e.to_string())? {
                        window.unmaximize()
                    } else {
                        window.maximize()
                    }
                }
                Some("drag") => window.start_dragging(),
                Some("close") => window.close(),
                _ => return Err("INVALID_WINDOW_ACTION".into()),
            }
            .map_err(|e| e.to_string())?;
            Ok(Value::Null)
        }
        "review:copy" => {
            let text = value
                .as_str()
                .filter(|s| s.len() <= 200000)
                .ok_or("INVALID_CLIPBOARD_TEXT")?;
            app.clipboard()
                .write_text(text)
                .map_err(|e| e.to_string())?;
            Ok(Value::Null)
        }
        "preferences:locale" => {
            let _guard = broker.storage.lock().await;
            let path = broker.data.join("v2-preferences.json");
            let locale = std::fs::read(path)
                .ok()
                .and_then(|b| serde_json::from_slice::<Value>(&b).ok())
                .and_then(|v| v["locale"].as_str().map(str::to_string))
                .unwrap_or("zh-CN".into());
            Ok(json!(
                if ["zh-CN", "en-US", "ja-JP"].contains(&locale.as_str()) {
                    locale.as_str()
                } else {
                    "zh-CN"
                }
            ))
        }
        "preferences:set-locale" => {
            let locale = value
                .as_str()
                .filter(|s| ["zh-CN", "en-US", "ja-JP"].contains(s))
                .ok_or("INVALID_LOCALE")?;
            let _guard = broker.storage.lock().await;
            storage::write_json(
                &broker.data.join("v2-preferences.json"),
                &json!({"schema":1,"locale":locale}),
            )?;
            Ok(value)
        }
        "operations:select" => {
            match app
                .dialog()
                .file()
                .add_filter("SAVEDATA.BIN", &["BIN"])
                .blocking_pick_file()
            {
                None => Ok(Value::Null),
                Some(path) => {
                    broker
                        .call(
                            "save",
                            "save.register",
                            json!({"path":path.into_path().map_err(|e| e.to_string())?}),
                        )
                        .await
                }
            }
        }
        "operations:resign" => {
            // The source save is chosen in the native picker; the renderer only
            // names the target save and snapshot.
            match app
                .dialog()
                .file()
                .add_filter("SAVEDATA.BIN", &["BIN"])
                .blocking_pick_file()
            {
                None => Ok(Value::Null),
                Some(path) => {
                    broker
                        .call(
                            "save",
                            "save.prepare_resign",
                            json!({"save_id":value["save_id"],"snapshot_id":value["snapshot_id"],"source_path":path.into_path().map_err(|e| e.to_string())?}),
                        )
                        .await
                }
            }
        }
        "review:log" => {
            let text = value
                .as_str()
                .filter(|s| s.len() <= 16384)
                .ok_or("INVALID_LOG_MESSAGE")?;
            storage::log(&broker.data, "client", text);
            Ok(Value::Null)
        }
        "review:link" => {
            let url = match value.as_str() {
                Some("github") => "https://github.com/Master-Bayesian/Nioh3-Scroll-Generator",
                Some("updates") => {
                    "https://github.com/Master-Bayesian/Nioh3-Scroll-Generator/releases/latest"
                }
                Some("qq") => {
                    if let Some(protocol) = qq_protocol().await {
                        if app.opener().open_url(protocol, None::<&str>).is_ok() {
                            return Ok(Value::Null);
                        }
                    }
                    if app.opener().open_url(QQ_PROFILE_URL, None::<&str>).is_ok() {
                        return Ok(Value::Null);
                    }
                    QQ_INVITE_URL
                }
                _ => return Err("INVALID_EXTERNAL_LINK".into()),
            };
            app.opener()
                .open_url(url, None::<&str>)
                .map_err(|e| e.to_string())?;
            Ok(Value::Null)
        }
        "review:backup-folder" | "review:save-folder" => {
            let path = if channel == "review:backup-folder" {
                let result = broker
                    .run("save", "save.backup_location", json!({}))
                    .await?;
                std::path::PathBuf::from(
                    result["backup_directory"]
                        .as_str()
                        .ok_or("INVALID_BACKUP_DIRECTORY")?,
                )
            } else {
                let result = broker.run("save", "save.live_add_source", value).await?;
                std::path::PathBuf::from(result["save_path"].as_str().ok_or("INVALID_SAVE_SOURCE")?)
                    .parent()
                    .ok_or("INVALID_SAVE_SOURCE")?
                    .to_path_buf()
            };
            app.opener()
                .open_path(path.to_string_lossy(), None::<&str>)
                .map_err(|e| e.to_string())?;
            Ok(Value::Null)
        }
        "support:reset" => {
            broker.reset_state().await?;
            Ok(Value::Null)
        }
        "review:data-directory" => {
            let action = value
                .as_str()
                .filter(|s| ["inspect", "set", "reset", "open"].contains(s))
                .ok_or("INVALID_DIRECTORY_ACTION")?;
            let path = if action == "set" {
                match app.dialog().file().blocking_pick_folder() {
                    None => return Ok(Value::Null),
                    Some(path) => Some(path.into_path().map_err(|e| e.to_string())?),
                }
            } else {
                None
            };
            let result = broker
                .run(
                    "save",
                    "save.data_directory",
                    json!({"action":if action == "open" {"inspect"} else {action},"path":path}),
                )
                .await?;
            if action == "open" {
                app.opener()
                    .open_path(
                        result["data_directory"]
                            .as_str()
                            .ok_or("DIRECTORY_EXPECTED")?,
                        None::<&str>,
                    )
                    .map_err(|e| e.to_string())?;
            }
            Ok(result)
        }
        "review:game-installation" => {
            let _guard = broker.storage.lock().await;
            match value.as_str() {
                Some("inspect") => game_install::inspect(&broker.data),
                Some("reset") => game_install::reset(&broker.data),
                Some("select") => match app
                    .dialog()
                    .file()
                    .add_filter("Nioh3.exe", &["exe"])
                    .blocking_pick_file()
                {
                    None => Ok(Value::Null),
                    Some(path) => game_install::choose(
                        &broker.data,
                        &path.into_path().map_err(|e| e.to_string())?,
                    ),
                },
                _ => Err("INVALID_GAME_INSTALL_ACTION".into()),
            }
        }
        "support:diagnostics" | "support:export" | "review:copy-log" | "review:feedback" => {
            let verification = if state.packaged {
                match package::verify(&broker.root) {
                    Ok(m) => {
                        json!({"ok":true,"version":m.version,"fileCount":m.files.len(),"signed":false,
                        "sourceCommit":m.git.as_ref().map(|g|g.commit.as_str()),"sourceDirty":m.git.as_ref().map(|g|g.dirty),
                        "manifestSha256":package::hash_file(&broker.root.join("build-manifest.json")).ok()})
                    }
                    Err(error) => json!({"ok":false,"error":error}),
                }
            } else {
                Value::Null
            };
            let locale = std::fs::read(broker.data.join("v2-preferences.json"))
                .ok()
                .and_then(|b| serde_json::from_slice::<Value>(&b).ok())
                .map(|v| v["locale"].clone())
                .unwrap_or(json!("zh-CN"));
            let log_directory = broker.data.join("logs");
            let report = json!({"schema":"nioh3-v2-diagnostics/v1","version":env!("CARGO_PKG_VERSION"),"packaged":state.packaged,"locale":locale,"platform":std::env::consts::OS,"arch":std::env::consts::ARCH,"dataDirectory":broker.data,"logDirectory":log_directory,"runtimeVersions":{"tauri":"2.11.5"},"packageVerification":verification,"workers":broker.diagnostics().await,"firstSessionFailure":storage::first_failure(&broker.data),"gameInstallation":game_install::inspect(&broker.data).ok(),"executablePath":std::env::current_exe().ok().map(|p|p.to_string_lossy().into_owned()),"outerExecutable":std::env::var("NIOH3_ONEFILE_EXE").ok()});
            if channel == "support:export" {
                if let Some(path) = app
                    .dialog()
                    .file()
                    .set_file_name("nioh3-diagnostics.json")
                    .blocking_save_file()
                {
                    storage::write_json(&path.into_path().map_err(|e| e.to_string())?, &report)?;
                    Ok(json!({"saved":true}))
                } else {
                    Ok(json!({"saved":false}))
                }
            } else if channel == "review:copy-log" {
                let tail = storage::support_log_tail(&broker.data, 128_000);
                let report = serde_json::to_string_pretty(&report).map_err(|e| e.to_string())?;
                app.clipboard()
                    .write_text(format!(
                        "=== Nioh 3 Studio diagnostics ===\n{report}\n\n=== Operation log (latest 128000 bytes, including rotated files) ===\n{tail}"
                    ))
                    .map_err(|e| e.to_string())?;
                Ok(Value::Null)
            } else if channel == "review:feedback" {
                // One file a player can drag into a chat or an issue, shown in
                // Explorer so they never have to find the data directory.
                let tail = storage::support_log_tail(&broker.data, 1_000_000);
                let report = serde_json::to_string_pretty(&report).map_err(|e| e.to_string())?;
                let directory = broker.data.join("feedback");
                std::fs::create_dir_all(&directory).map_err(|e| e.to_string())?;
                let stamp = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .map(|elapsed| elapsed.as_secs())
                    .unwrap_or_default();
                let path = directory.join(format!("nioh3-feedback-{stamp}.txt"));
                let live_add =
                    serde_json::to_string_pretty(&storage::live_add_digest(&broker.data, 8))
                        .map_err(|e| e.to_string())?;
                std::fs::write(
                    &path,
                    format!(
                        "=== Nioh 3 Studio feedback ===\n{report}\n\n=== Latest live additions (expected and built records) ===\n{live_add}\n\n=== Operation log (latest 1000000 bytes, including rotated files) ===\n{tail}"
                    ),
                )
                .map_err(|e| e.to_string())?;
                let _ = app.opener().reveal_item_in_dir(&path);
                Ok(json!({"path": path}))
            } else {
                Ok(report)
            }
        }
        "review:update" => {
            let action = value["action"].as_str().ok_or("INVALID_UPDATE_ACTION")?;
            let channel = value["channel"]
                .as_str()
                .filter(|c| ["stable", "beta"].contains(c))
                .ok_or("INVALID_UPDATE_CHANNEL")?;
            match action {
                "status" => {}
                "check" | "download" => {
                    if !state.update_ready.load(Ordering::SeqCst) {
                        return Err("UPDATE_STARTUP_PENDING".into());
                    }
                    state.updater.action(action, channel).await?;
                }
                "apply" => {
                    if !state.packaged || state.updater.ready.lock().await.is_none() {
                        return Err("UPDATE_NOT_READY".into());
                    }
                    state.apply_update.store(true, Ordering::SeqCst);
                    window.close().map_err(|e| e.to_string())?;
                }
                _ => return Err("INVALID_UPDATE_ACTION".into()),
            }
            Ok(state
                .updater
                .state(state.packaged && state.update_ready.load(Ordering::SeqCst))
                .await)
        }
        _ => broker.dispatch(&channel, value).await,
    }
}

/// How long closing waits for workers to finish what they are doing. Closing
/// is never refused: durable records stay recoverable after a restart, and
/// this only gives an in-flight operation the chance to finish cleanly.
const CLOSE_GRACE: std::time::Duration = std::time::Duration::from_secs(20);

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _args, _cwd| {
            if let Some(window) = app.get_webview_window("main") {
                let _ = window.unminimize();
                let _ = window.show();
                let _ = window.set_focus();
            }
        }))
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_clipboard_manager::init())
        .setup(|app| {
            let packaged = !cfg!(debug_assertions);
            // A packaged acceptance needs to run the real packaged resolution
            // against a staged runtime. The override is test-only: it is compiled
            // out of a release build (`!packaged` is false there, so the branch
            // cannot be taken), and inside a debug build it additionally requires
            // both NIOH3_TAURI_PACKAGE_ROOT and NIOH3_TAURI_TEST_ROOT. A debug
            // binary run directly by a user with both variables set would take it;
            // that is a test-build configuration, not part of the shipped graph.
            let package_override = (!packaged)
                .then(|| std::env::var_os("NIOH3_TAURI_PACKAGE_ROOT").map(std::path::PathBuf::from))
                .flatten()
                .filter(|_| std::env::var_os("NIOH3_TAURI_TEST_ROOT").is_some());
            let packaged = packaged || package_override.is_some();
            let root = match package_override {
                Some(root) => root,
                None if packaged => app.path().resource_dir()?,
                None => std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
                    .join("../../..")
                    .canonicalize()?,
            };
            let arguments: Vec<_> = std::env::args_os().collect();
            let profile = arguments
                .windows(2)
                .find(|p| p[0] == "--user-data-dir")
                .map(|p| std::path::PathBuf::from(&p[1]));
            if profile.as_ref().is_some_and(|p| !p.is_absolute()) {
                return Err("Profile directory must be absolute".into());
            }
            let explicit_profile = profile.is_some();
            let data = if let Some(path) = profile {
                path
            } else if cfg!(debug_assertions) {
                std::env::var_os("NIOH3_TAURI_TEST_ROOT")
                    .map(std::path::PathBuf::from)
                    .unwrap_or(app.path().app_data_dir()?)
            } else {
                app.path().app_data_dir()?
            };
            std::fs::create_dir_all(&data)?;
            // Copy only small broker-owned files, never the Chromium profile.
            if !explicit_profile && std::env::var_os("NIOH3_TAURI_TEST_ROOT").is_none() {
                if let Some(roaming) = std::env::var_os("APPDATA") {
                    let previous = std::path::PathBuf::from(roaming).join("nioh3-scroll-editor-v2");
                    for name in ["favorites.json", "v2-preferences.json"] {
                        let source = previous.join(name);
                        let target = data.join(name);
                        if !target.exists()
                            && std::fs::metadata(&source)
                                .map(|m| m.is_file() && m.len() <= 4_000_000)
                                .unwrap_or(false)
                        {
                            std::fs::copy(source, target)?;
                        }
                    }
                }
            }
            storage::log(&data, "startup", env!("CARGO_PKG_VERSION"));
            worker::initialize_game_install(&data);
            // Record the resolved worker graph at startup. A packaged acceptance
            // can then read the identity of the worker the *host* resolved
            // instead of inferring it from a separately spawned binary.
            log_resolved_workers(&root, &data, packaged);
            if packaged
                && package::verify(&root)
                    .map_err(std::io::Error::other)?
                    .version
                    != env!("CARGO_PKG_VERSION")
            {
                return Err("PACKAGE_VERSION_MISMATCH".into());
            }
            if let Some(executable) = std::env::var_os("NIOH3_ONEFILE_EXE") {
                storage::log(
                    &data,
                    "onefile-runtime",
                    &format!(
                        "executable={} runtime={} launcher_pid={}",
                        std::path::Path::new(&executable).display(),
                        root.display(),
                        std::env::var("NIOH3_ONEFILE_PID").unwrap_or_default()
                    ),
                );
            }
            let updater = update::Updater::new(data.join("updates"));
            let webview_data = data.join("webview");
            app.manage(State {
                broker: Arc::new(Broker::new(root.clone(), data, packaged)),
                updater,
                packaged,
                update_ready: AtomicBool::new(!packaged),
                apply_update: AtomicBool::new(false),
                quitting: AtomicBool::new(false),
                closing: AtomicBool::new(false),
            });
            let mut window =
                tauri::WebviewWindowBuilder::from_config(app, &app.config().app.windows[0])?
                    .data_directory(webview_data)
                    .on_navigation(trusted);
            if let Some(port) = test_debug_port() {
                window = window.additional_browser_args(&format!("--remote-debugging-port={port}"));
            }
            window.build()?;
            Ok(())
        })
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                let state = window.state::<State>();
                if state.quitting.load(Ordering::SeqCst) {
                    return;
                }
                api.prevent_close();
                if state.closing.swap(true, Ordering::SeqCst) {
                    return;
                }
                let app = window.app_handle().clone();
                let window = window.clone();
                tauri::async_runtime::spawn(async move {
                    let state = app.state::<State>();
                    let deadline = std::time::Instant::now() + CLOSE_GRACE;
                    let mut clean = state.broker.shutdown().await;
                    if !clean {
                        // The player asked to close: the window goes away now and
                        // an in-flight operation gets a bounded chance to finish.
                        let _ = window.hide();
                        while !clean && std::time::Instant::now() < deadline {
                            tokio::time::sleep(std::time::Duration::from_millis(500)).await;
                            clean = state.broker.shutdown().await;
                        }
                        if !clean {
                            storage::log(
                                &state.broker.data,
                                "shutdown",
                                "workers still busy after the close grace period; exiting anyway",
                            );
                        }
                    }
                    if clean && state.apply_update.load(Ordering::SeqCst) {
                        let target = std::env::current_exe()
                            .ok()
                            .and_then(|p| p.parent().map(std::path::Path::to_path_buf));
                        let result = match target {
                            Some(target) => state.updater.launch(&target).await,
                            None => Err("UPDATE_TARGET_INVALID".into()),
                        };
                        if let Err(error) = result {
                            state.apply_update.store(false, Ordering::SeqCst);
                            state.closing.store(false, Ordering::SeqCst);
                            let _ = window.show();
                            app.dialog().message(error).blocking_show();
                            return;
                        }
                    }
                    state.quitting.store(true, Ordering::SeqCst);
                    app.exit(0);
                });
            }
        })
        .invoke_handler(tauri::generate_handler![desktop_request])
        .run(tauri::generate_context!())
        .expect("Tauri application startup failed");
}
