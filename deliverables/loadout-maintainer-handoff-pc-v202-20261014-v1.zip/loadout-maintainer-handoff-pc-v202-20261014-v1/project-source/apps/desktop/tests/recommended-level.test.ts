import { test } from 'node:test';
import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { WorkerClient } from '../src/worker-client';

/**
 * The exact game file version a packaged worker must be launched with.
 *
 * Required rather than defaulted: a packaged gate that offers an EXE but no
 * version would otherwise exercise an identity-free launch.
 */
function packagedGameFileVersion(): string {
  const raw = process.env.NIOH3_PARITY_GAME_FILE_VERSION ?? '';
  if (!/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/.test(raw)) {
    throw new Error('Set NIOH3_PARITY_GAME_FILE_VERSION to the packaged worker\'s exact four-part game file version');
  }
  return raw;
}

/** A packaged EXE carries its identity on the argv; a source launch opts in. */
function workerArgv(packaged: boolean): string[] {
  return packaged ? ['--game-file-version', packagedGameFileVersion()] : ['--legacy-test-context'];
}

test('displayed level selector uses the exact worker curve without clamping', { timeout: 30000 }, async () => {
  const executable = process.env.NIOH3_WORKER_EXE;
  // A source launch requires one explicit identity: the standalone gate uses the
  // worker's non-production test opt-in, and a packaged EXE its own version.
  const worker = new WorkerClient(resolve('.'), executable || process.env.NIOH3_PYTHON || 'python', !!executable, undefined,
    workerArgv(!!executable));
  try {
    const catalog = await worker.catalog(4, 'en-US');
    assert.equal(catalog.recommended_level.minimum_displayed_level, 142);
    // The current bound is raw 600 -> displayed 356.
    assert.equal(catalog.recommended_level.maximum_internal_level, 600);
    assert.equal(catalog.recommended_level.maximum_displayed_level, 356);
    const selected = await worker.resolveRecommendedLevel(350);
    assert.equal(selected.status, 'exact');
    assert.deepEqual(selected.canonical_internal_levels, [585, 586]);
    assert.equal(selected.selected_internal_level, 585);
    assert.equal(selected.metadata.evidence, 'captured_native_curve_prediction');
    const top = await worker.resolveRecommendedLevel(356);
    assert.equal(top.status, 'exact');
    assert.deepEqual(top.canonical_internal_levels, [599, 600]);
    assert.equal(top.selected_internal_level, 599);
    for (const requested of [141, 357, 700, 701, 0]) {
      const unavailable = await worker.resolveRecommendedLevel(requested);
      assert.equal(unavailable.status, 'out_of_range');
      assert.deepEqual(unavailable.canonical_internal_levels, []);
      assert.equal(unavailable.selected_internal_level, null);
    }
    for (const requested of [true, '350', 350.5, NaN, Infinity]) {
      await assert.rejects(worker.resolveRecommendedLevel(requested as number), /INVALID_REQUEST/);
    }
  } finally { await worker.close(); }
});
