import assert from 'node:assert/strict';
import {ANY_RULE_VALUE,data,enemyCombinationProblem,initialQuery,matches,queryProblem,ruleFamilyKeys,ruleFamilyValues,toRecordTransferCount} from './model';
const sample=data.samples.find(s=>s.rarity===4&&s.effects.some(e=>e.role==='恩宠'))!;
const grace=sample.effects.find(e=>e.role==='恩宠')!;
const q={...initialQuery(),effects:[],graces:[grace.id,'not-a-grace']};
assert.ok(matches(sample,q));
assert.ok(!matches(sample,{...q,graces:['not-a-grace']}));
const rules=[{id:'present',name:'present',keys:[sample.rules[0].key],variant:'any',mode:1},{id:'absent',name:'absent',keys:[-1],variant:'any',mode:1}];
assert.ok(matches(sample,{...q,rules}));
assert.ok(!matches(sample,{...q,rules:rules.map(r=>({...r,mode:0}))}));
assert.equal(queryProblem({...q,count:25}),'');
assert.ok(queryProblem({...q,count:26}));
assert.deepEqual(ruleFamilyValues('一难横行'),['50%','65%','80%']);
assert.equal(ruleFamilyKeys('一难横行',ANY_RULE_VALUE).length,69);
assert.equal(ruleFamilyKeys('一难横行','80%').length,23);
assert.equal(ruleFamilyKeys('造成的属性伤害增加','30%').length,4);
assert.equal(toRecordTransferCount(-1),0xFFFFFFFF);
const byTier=(tier:string)=>data.enemies.filter(e=>e.tier===tier);
const must=(list:typeof data.enemies)=>list.map(e=>({...e,mode:0,state:'any' as const,availability:'any' as const}));
const [low,middle,high]=[byTier('低手'),byTier('中手'),byTier('高手')];
assert.equal(enemyCombinationProblem({...q,enemies:must([...low.slice(0,3),high[0]])}),'');
assert.equal(enemyCombinationProblem({...q,enemies:must(high.slice(0,3))}),'');
assert.equal(enemyCombinationProblem({...q,enemies:must([...middle.slice(0,2),high[0]])}),'');
assert.ok(enemyCombinationProblem({...q,enemies:must([low[0],middle[0]])}));
assert.ok(enemyCombinationProblem({...q,enemies:must([low[0],...high.slice(0,2)])}));
assert.ok(enemyCombinationProblem({...q,enemies:must(high.slice(0,4))}));
assert.ok(enemyCombinationProblem({...q,enemies:must(middle.slice(0,3))}));
assert.ok(queryProblem({...q,enemies:must(high.slice(0,4))}).includes('不可能同时出现'));
assert.equal(enemyCombinationProblem({...q,enemies:must(high.slice(0,4)).map(e=>({...e,mode:1}))}),'');
console.log('16 query semantic checks passed');
{
  // Templated effects name the buff or ailment the game fills in.
  const named=(id:string)=>data.editorEffects.find(effect=>effect.id===id)!.name;
  assert.equal(named('2143'),'吸收精华后赋予^09~BUFF~{昂灵}^09~~');
  assert.ok(data.editorEffects.filter(effect=>/~(?:DE)?BUFF~\{\}/.test(effect.name)).length===0,'every templated editor effect is resolved');
  assert.equal(named('9135'),'{怪风}计量槽增加量');
  console.log('effect template arguments resolved');
}
