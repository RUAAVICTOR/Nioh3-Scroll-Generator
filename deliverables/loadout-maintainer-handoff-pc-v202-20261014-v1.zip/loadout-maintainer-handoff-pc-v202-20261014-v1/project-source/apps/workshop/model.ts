import catalog from "./catalog.json";
import itemNames from "./item-names.json";
import effectArguments from "./effect-arguments.json";
import { hasTemplateSlot, withTemplateArgument } from "./game-text";
export const data = catalog;

// The editor lists every native effect by its raw native string, and some of
// those are sentence templates ("...赋予^09~BUFF~{}^09~~") whose argument the
// game fills from another row. Where the search catalog carries the curated
// name for the same effect (the reference's player-ready overlay), use it.
{
  const curated = new Map<string, string>();
  for (const context of Object.values(data.contexts))
    for (const effect of [...context.effects, ...context.graces])
      if (!hasTemplateSlot(effect.name)) curated.set(effect.id, effect.name);
  for (const effect of data.editorEffects)
    if (hasTemplateSlot(effect.name) && curated.has(effect.id))
      effect.name = curated.get(effect.id)!;
  // The rest name the buff or ailment the game fills in, resolved from each
  // effect's group row ("吸收精华后赋予{}" -> "吸收精华后赋予{承受伤害减少}").
  const resolved: Record<string, string> = { ...effectArguments.names };
  // A few ninjutsu rows name no subject, and the game shows a bare "{}" for
  // them; the effect ID keeps them apart.
  for (const id of effectArguments.unnamed_in_game.ids)
    resolved[id] ??= `未命名忍术（0x${id.toString(16).toUpperCase().padStart(4, "0")}）`;
  for (const effect of [
    ...data.editorEffects,
    ...Object.values(data.contexts).flatMap((context) => [...context.effects, ...context.graces]),
  ])
    if (resolved[effect.id]) effect.name = withTemplateArgument(effect.name, resolved[effect.id]);
}
// Special rules that name an onmyo item the auxiliary name table lacks carry a
// placeholder ("未识别阴阳术（原生编号 0x3011，可生成）"). The bundled item names
// know those items (0x3011 is 削气符), so show the real name instead.
const onmyoItems = (itemNames as { items: Record<string, string[]> }).items;
export function nameUnknownOnmyo(text: string): string {
  if (!text.includes("未识别阴阳术")) return text;
  return text.replace(
    /未识别阴阳术（原生编号 0x([0-9A-F]+)，可生成）/g,
    (whole, hex: string) => onmyoItems[String(Number.parseInt(hex, 16))]?.[0] || whole,
  );
}
{
  const walk = (value: unknown): unknown => {
    if (typeof value === "string") return nameUnknownOnmyo(value);
    if (Array.isArray(value)) {
      value.forEach((entry, index) => (value[index] = walk(entry)));
      return value;
    }
    if (value && typeof value === "object")
      for (const [key, entry] of Object.entries(value)) (value as Record<string, unknown>)[key] = walk(entry);
    return value;
  };
  walk(data);
}
export function toRecordTransferCount(value: number): number {
  if (!Number.isInteger(value) || value < -1 || value > 0xffffffff)
    throw new RangeError("Invalid transfer count");
  return value === -1 ? 0xffffffff : value;
}
export type Sample = (typeof catalog.samples)[number] & {
  level?: number;
  playthrough?: number;
  backend?: {
    jobId?: string;
    candidateId: string;
    referenceId?: string;
    installable: boolean;
  };
  enemyVariant?: "solo" | "expedition";
  enemyOccurrences?: {
    lookupKey: number;
    name: string;
    waveIndex: number;
    position: number;
    availability: "base" | "expedition_only";
    possessed: "yes" | "no" | "unknown";
    curse: "guaranteed" | "possible" | "never" | "unknown";
  }[];
  possessedComplete?: boolean;
  curseScope?: string;
  saveEntry?: import("../../packages/contracts/protected-responses").SaveInventory["entries"][number];
};
export type SelectedEffect = {
  id: string;
  choiceId?: string;
  name: string;
  mode: number;
  roll: number;
  cross: boolean;
};
export const conditionKey = (item: { id: string; choiceId?: string }) =>
  item.choiceId || item.id;
export function effectRequirements(q: Query) {
  const primary = q.unrestricted ? [] : q.effects.slice(0, q.primaryCount),
    rest = q.unrestricted ? q.effects : q.effects.slice(q.primaryCount);
  const choice = (e: SelectedEffect) => ({
    effect_id: Number(e.id),
    minimum_roll_percent: e.roll,
  });
  const result: {
    scope: "primary" | "secondary" | "any";
    alternatives: ReturnType<typeof choice>[];
  }[] = [];
  if (primary.length)
    result.push({ scope: "primary", alternatives: primary.map(choice) });
  const seen = new Set<number>();
  for (const e of rest) {
    if (e.mode && seen.has(e.mode)) continue;
    if (e.mode) seen.add(e.mode);
    result.push({
      scope: q.unrestricted ? "any" : "secondary",
      alternatives: (e.mode ? rest.filter((v) => v.mode === e.mode) : [e]).map(
        choice,
      ),
    });
  }
  return result;
}
export function matchesEffectOccurrences(sample: Sample, q: Query) {
  const effects = sample.effects.filter(
    (e) => e.role === "主词条" || e.role === "副词条",
  );
  const choices = effectRequirements(q)
    .map((r) =>
      effects.flatMap((e, i) =>
        (r.scope === "primary" && i !== 0) ||
        (r.scope === "secondary" && i === 0)
          ? []
          : r.alternatives.some(
                (c) =>
                  c.effect_id === Number(e.id) &&
                  e.roll >= c.minimum_roll_percent,
              )
            ? [i]
            : [],
      ),
    )
    .sort((a, b) => a.length - b.length);
  const assign = (i: number, used: number): boolean =>
    i === choices.length ||
    choices[i].some(
      (slot) => !(used & (1 << slot)) && assign(i + 1, used | (1 << slot)),
    );
  return assign(0, 0);
}
export type EnemyCondition = {
  id: string;
  name: string;
  keys: number[];
  possessedKeys: number[];
  mode: number;
  state: "any" | "possessed" | "curse";
  availability: "any" | "base" | "expedition_only";
};
export function enemyCanBePossessed(enemy: Pick<EnemyCondition, "id" | "keys">): boolean {
  const catalogEnemy = data.enemies.find(
    (candidate) =>
      candidate.id === enemy.id ||
      candidate.keys.some((key) => enemy.keys.includes(key)),
  );
  return !!catalogEnemy?.possessedKeys.length;
}
export type RuleCondition = {
  id: string;
  name: string;
  keys: number[];
  variant: string;
  mode?: number;
};
export const ANY_RULE_VALUE = "any-rule-value";
export function ruleFamilyValues(category: string): string[] {
  const members = data.rules.filter((rule) => rule.category === category);
  if (!members.length) return [];
  const common = new Set(members[0].variants.map((variant) => variant.label));
  for (const member of members.slice(1)) {
    const labels = new Set(member.variants.map((variant) => variant.label));
    for (const value of common) if (!labels.has(value)) common.delete(value);
  }
  return [...common].sort(
    (left, right) =>
      (Number.parseFloat(left) || 0) - (Number.parseFloat(right) || 0) ||
      left.localeCompare(right),
  );
}
export function ruleFamilyKeys(category: string, value = ANY_RULE_VALUE): number[] {
  const members = data.rules.filter((rule) => rule.category === category);
  return [
    ...new Set(
      members.flatMap((member) =>
        value === ANY_RULE_VALUE
          ? member.keys
          : member.variants
              .filter((variant) => variant.label === value)
              .map((variant) => variant.key),
      ),
    ),
  ];
}
export type Query = {
  effects: SelectedEffect[];
  enemies: EnemyCondition[];
  enemyVariant: "solo" | "expedition";
  rules: RuleCondition[];
  terrains: string[];
  capacities: number[];
  graces: string[];
  unrestricted: boolean;
  primaryCount: number;
  ng: number;
  rarity: number;
  level: number;
  recommended: number;
  transfers: number;
  count: number;
};
export const initialSample = data.samples.find((s) => s.rarity === 4)!;
export function initialQuery(): Query {
  return {
    effects: [],
    enemies: [],
    enemyVariant: "solo",
    rules: [],
    terrains: [],
    capacities: [],
    graces: [],
    unrestricted: false,
    primaryCount: 1,
    ng: 3,
    rarity: 4,
    level: 180,
    recommended: 350,
    transfers: -1,
    count: 25,
  };
}
export function matches(sample: Sample, q: Query): boolean {
  if (
    (sample.playthrough || 3) !== q.ng ||
    (sample.level ?? 180) !== q.level ||
    sample.rarity !== q.rarity
  )
    return false;
  if (!matchesEffectOccurrences(sample, q)) return false;
  const primary = q.unrestricted ? [] : q.effects.slice(0, q.primaryCount);
  const ordinary = sample.effects.filter(
    (e) => e.role === "主词条" || e.role === "副词条",
  );
  const actualPrimary = ordinary[0];
  if (
    primary.length &&
    !primary.some(
      (e) => e.id === actualPrimary?.id && actualPrimary.roll >= e.roll,
    )
  )
    return false;
  if (
    primary.some(
      (e) =>
        e.cross &&
        e.id !== actualPrimary?.id &&
        !ordinary.slice(1).some((v) => v.id === e.id && v.roll >= e.roll),
    )
  )
    return false;
  const secondary = q.unrestricted
    ? q.effects
    : q.effects.slice(q.primaryCount);
  const available = q.unrestricted ? ordinary : ordinary.slice(1);
  if (
    secondary
      .filter((e) => !e.mode)
      .some((e) => !available.some((v) => v.id === e.id && v.roll >= e.roll))
  )
    return false;
  for (const group of new Set(
    secondary.filter((e) => e.mode).map((e) => e.mode),
  ))
    if (
      !secondary
        .filter((e) => e.mode === group)
        .some((e) => available.some((v) => v.id === e.id && v.roll >= e.roll))
    )
      return false;
  if (
    q.graces.length &&
    !sample.effects.some((e) => e.role === "恩宠" && q.graces.includes(e.id))
  )
    return false;
  if (q.capacities.length && !q.capacities.includes(sample.capacity))
    return false;
  if (
    q.terrains.length &&
    !q.terrains.some((id) => {
      const t = data.terrains.find((t) => t.option_id === id)!;
      return t.aggregate
        ? t.effect_keys.every((k) => sample.terrainKeys.includes(k))
        : t.effect_keys.length === sample.terrainKeys.length &&
            t.effect_keys.every((k) => sample.terrainKeys.includes(k));
    })
  )
    return false;
  if (
    q.rules
      .filter((r) => !r.mode)
      .some((r) => !sample.rules.some((v) => r.keys.includes(v.key)))
  )
    return false;
  for (const group of new Set(q.rules.filter((r) => r.mode).map((r) => r.mode)))
    if (
      !q.rules
        .filter((r) => r.mode === group)
        .some((r) => sample.rules.some((v) => r.keys.includes(v.key)))
    )
      return false;
  const enemyMatches = (condition: EnemyCondition) => {
    if (sample.enemyOccurrences) {
      return sample.enemyOccurrences.some(
        (occurrence) =>
          condition.keys.includes(occurrence.lookupKey) &&
          (condition.availability === "any" ||
            occurrence.availability === condition.availability) &&
          (condition.state === "any" ||
            (condition.state === "possessed" && occurrence.possessed === "yes") ||
            (condition.state === "curse" &&
              (occurrence.curse === "guaranteed" || occurrence.curse === "possible"))),
      );
    }
    return (
      condition.state === "any" &&
      condition.availability === "any" &&
      condition.keys.some((key) => sample.enemyKeys.includes(key))
    );
  };
  if (q.enemies.filter((e) => !e.mode).some((e) => !enemyMatches(e)))
    return false;
  for (const group of new Set(
    q.enemies.filter((e) => e.mode).map((e) => e.mode),
  ))
    if (
      !q.enemies
        .filter((e) => e.mode === group)
        .some(enemyMatches)
    )
      return false;
  return true;
}
/**
 * Structural check of the must-have enemies against the game's three enemy
 * layouts (see the enemy-generation research note): middle and high pools
 * only, 2–3 enemies with at least one high; low enemies plus at most one high;
 * or low enemies only. Either-group enemies and co-op additions are not
 * checked, and passing is not a promise that a matching seed exists.
 */
export function enemyCombinationProblem(q: Query): string {
  if (q.enemyVariant !== "solo") return "";
  const tiers = q.enemies
    .filter((enemy) => !enemy.mode)
    .map((enemy) => data.enemies.find((candidate) => candidate.id === enemy.id)?.tier ?? "");
  const low = tiers.filter((tier) => tier === "低手").length;
  const middle = tiers.filter((tier) => tier === "中手").length;
  const high = tiers.filter((tier) => tier === "高手" || tier === "中／高手").length;
  if (low && middle) return "低手和中手不会出现在同一张绘卷里。";
  if (low && high > 1) return "有低手的绘卷最多只有 1 个高手。";
  if (!low && middle + high > 3) return "中手和高手合计最多 3 个。";
  if (!low && middle > 2) return "中手最多 2 个：这类绘卷里至少有 1 个高手。";
  return "";
}
export function queryProblem(q: Query, realBackend = false): string {
  if (!Number.isInteger(q.count) || q.count < 1 || q.count > 25)
    return "候选数量应为 1–25。";
  if (
    !Number.isInteger(q.recommended) ||
    !(String(q.recommended) in data.levels)
  )
    return "推荐等级应为 142–356 内可转换的整数。";
  if (!Number.isInteger(q.level) || q.level < 0 || q.level > 180)
    return "绘卷等级应为 0–180。";
  if (
    !Number.isInteger(q.transfers) ||
    q.transfers < -1 ||
    q.transfers > 4294967295
  )
    return "转手次数应为 −1 或有效的无符号整数。";
  if (q.effects.length > 24)
    return "最多保留 24 个词条选项，任一组按一项逻辑要求计算。";
  if (q.enemies.some((enemy) => enemy.state === "curse"))
    return "一难状态会在每次进入时变化，无法按绘卷 ID 精确筛选。";
  const enemyProblem = enemyCombinationProblem(q);
  if (enemyProblem) return "这组必含敌人不可能同时出现：" + enemyProblem;
  if (
    q.enemies.some(
      (enemy) => enemy.state === "possessed" && !enemyCanBePossessed(enemy),
    )
  )
    return "这个敌人没有地狱附身变体，请关闭开关或选择标有“可附身”的低手敌人。";
  if (
    q.enemyVariant === "solo" &&
    q.enemies.some((enemy) => enemy.availability === "expedition_only")
  )
    return "仅常世同行追加的敌人需要使用常世同行预览。";
  if (
    q.ng !== 3 &&
    (q.enemyVariant === "expedition" ||
      q.enemies.some(
        (enemy) => enemy.state !== "any" || enemy.availability !== "any",
      ))
  )
    return "敌人状态与常世同行预览目前仅支持三周目。";
  if (!realBackend && (q.ng !== 3 || q.level !== 180))
    return "此预览暂仅支持搜索三周目、180 级绘卷。";
  return "";
}
