import { data } from "./model";

const hasCjk =(text: string) => /[㐀-鿿]/.test(text);

/** The message without the `Error:` prefix `String(error)` adds. */
export function stripErrorPrefix(message: string): string {
  return message.replace(/^\s*(?:Uncaught\s+)?Error:\s*/, "");
}

/**
 * Whether a status value reports a failure. Interface texts are authored in
 * Chinese, so a value with no Chinese at all came from a backend failure.
 */
export function isFailureText(message: string): boolean {
  const text = message.trim();
  if (!text) return false;
  const stripped = stripErrorPrefix(text);
  return stripped !== text || !hasCjk(stripped) || publicError(stripped) !== stripped;
}

/** The display name of an effect the worker names as `0xNNNN`. */
function effectName(hex: string): string {
  const id = String(parseInt(hex, 16));
  const found =
    data.editorEffects.find((effect) => effect.id === id) ||
    Object.values(data.contexts)
      .flatMap((context) => [...context.effects, ...context.graces])
      .find((effect) => effect.id === id);
  return found ? `“${found.name}”` : hex;
}

const effectNames = (text: string) =>
  (text.match(/0x[0-9A-F]{4}\b/gi) || []).map(effectName).join("、");

/** Why the search worker refused a condition set, in the player's terms. */
function infeasibleConditions(detail: string): string {
  const category = detail.match(/holds at most (\d+), but (\d+) were selected/);
  if (category) {
    const [capacity, count] = [Number(category[1]), Number(category[2])];
    const names = effectNames(detail.split("share native category")[0]);
    return `${names ? `所选的 ${names} ` : `所选词条中有 ${count} 个词条`}在游戏里属于同一类词条，一张绘卷上这一类最多只有 ${capacity} 个，所以它们不可能同时出现。请去掉其中 ${count - capacity} 个再搜索。`;
  }
  if (/belong to native conflict groups/.test(detail))
    return `${effectNames(detail)} 在游戏里互相冲突，不会出现在同一张绘卷上。请去掉其中一个再搜索。`;
  const slots = detail.match(/ordinary secondary slots but this structure has only (\d+)/);
  if (slots)
    return `选的副词条太多了：这种绘卷最多只有 ${slots[1]} 个普通副词条位置。请减少副词条再搜索。`;
  if (/cannot be generated for this scroll type|weight 0 for this playthrough and rarity|not in the native parameter table/.test(detail))
    return `${effectNames(detail)} 不会出现在当前周目和稀有度的绘卷上。请换一个周目或稀有度，或去掉这个词条。`;
  if (/rarity 5 has a single deep slot/.test(detail))
    return `R5 绘卷只有一个深层词条位置，所以 ${effectNames(detail)} 最多只能同时出现一个。请只保留其中一个再搜索。`;
  return "这个词条组合在游戏里不可能出现，请调整筛选条件后再搜索。";
}

/**
 * A refusal the player resolves by changing their own choices. It is shown
 * as a hint, never as a failure to report.
 */
export function isUserCorrectable(message: string): boolean {
  return /no solution in the native generation structure|原生生成结构中无解|no legal native path|compiled no plan family|has no draw-1 preimage|at most 32 scratch keys|FAVORITES_CAPACITY_REACHED|CART_CAPACITY_REACHED|Possessed is available only|Unequip the item in game before removing it/i.test(
    message,
  );
}

/**
 * The save file changed since this view read it (the game saved, or the save
 * worker restarted). Reading the save again is the whole remedy.
 */
const STALE_SNAPSHOT = /Snapshot expired|Save changed after preview/i;

export function isStaleSnapshotError(message: string): boolean {
  return STALE_SNAPSHOT.test(message);
}

/** A live addition refused because another executor holds its admission lock. */
const LIVE_ADD_LOCK = /Another native executor is admitting an operation/i;

/** Whether the player can clear the refusal with the live-add lock reset. */
export function isLiveAddLockError(message: string): boolean {
  return LIVE_ADD_LOCK.test(message);
}

/** User-facing next steps; the broker keeps full technical errors in rolling logs. */
export function publicError(message: string): string {
  if (hasCjk(message)) message = stripErrorPrefix(message);
  const infeasible = message.match(/no solution in the native generation structure: ([\s\S]*)$/);
  if (infeasible) return infeasibleConditions(infeasible[1]);
  const cases: [RegExp, string][] = [
    [/EQUIPMENT_INVENTORY_FULL/, "背包里的装备已满（2000 件）。请先在游戏里分解、出售或存入仓库，空出位置后再添加。"],
    [/RESET_GAME_RUNNING/, "游戏正在运行。请先关闭游戏，再点“确认重置”。"],
    [/RESET_WORKER_BUSY/, "工具还有操作没有结束。请等它完成，或关闭并重新打开工具后再重置。"],
    [/RESET_ARCHIVE_FAILED/, "有文件正被占用，无法移走。请关闭并重新打开工具后再重置；仍不行时请导出反馈文件发给开发者。"],
    [/Recover the previous equipment addition before preparing another/, "上一件装备的添加结果还没有确认。请在上一条记录里点“恢复核对”；如果一直无法确认，重启游戏并读档后就可以继续添加。"],
    [/EQUIPMENT_BACKUP_SOURCE_REQUIRED/, "发现多个存档。读取添加状态并确认本次未执行后，点击“准备另一件装备”，在“目标存档”里选中当前角色的存档，再生成预览。"],
    [/No save was found under .*expected <account>\/SAVEDATAxx\/SAVEDATA\.BIN/i, "未找到可读的角色存档。请查看技术详情中的搜索目录，在游戏中创建存档或恢复目录访问后重试；也可以在“目标存档”旁点“手动定位”选择存档。"],
    [/Source save (?:changed during backup|changed after equipment preparation)|Source save cannot be read at .*Cancel this equipment plan/i, "源存档已变化或无法读取。请查看技术详情中的源文件路径，等待游戏存档完成并恢复文件访问，再核对或取消旧操作并重新准备。结果不明时先恢复核对，不要重复添加。"],
    [/Verified backup (?:changed after equipment preparation|cannot be read at .*Cancel this equipment plan)|Automatic save backup verification failed/i, "备份副本未通过校验或无法读取。请查看技术详情中的备份路径并恢复访问，再核对或取消旧操作并重新准备，生成新的已验证备份。结果不明时先恢复核对，不要重复添加。"],
    [/Equipment save checkpoint (?:is missing|belongs to another operation|has an invalid source hash|cannot read|must be a separate backup file)|A verified save checkpoint is required before equipment preview/i, "本次装备操作缺少有效的备份记录。请查看技术详情中的具体原因，核对或取消旧操作后，在“目标存档”里选中当前角色的存档并重新准备。结果不明时先恢复核对，不要重复添加。"],
    [/COMPATIBILITY_IDENTITY_CHANGED/,"游戏进程或程序身份已变化。请查看兼容提示，重新连接并准备新计划。结果不明的写入必须先核对恢复凭据，不能直接重试。"],
    // The Rust save and runtime layers report in English; these restore the
    // explanations the Python backend gave players for the same refusals.
    [
      /no legal native path|compiled no plan family/i,
      "所选词条在游戏里无法组成一张合法的绘卷（无论哪个作为主词条，生成到一半都会冲突或无词条可抽）。请调整词条后再搜索。",
    ],
    [
      /has no draw-1 preimage/i,
      "所选恩宠不会出现在这种绘卷上。请换一个恩宠或稀有度后再搜索。",
    ],
    [
      /at most 32 scratch keys/i,
      "选择的特殊规则太多了（最多 32 条）。请减少特殊规则后再搜索。",
    ],
    [
      /SEARCH_BACKEND_UNAVAILABLE|accelerator refused to run|accelerator is (?:unavailable|missing)|CPU fallback is disabled/i,
      "没有可用的显卡搜索加速，已停止搜索。请更新显卡驱动后重试；也可以在“设置”里打开“允许使用 CPU 搜索”（会慢很多）。",
    ],
    [
      /HOOK_MODIFIED|was changed by another program/i,
      "游戏里的同一处代码已被其他程序（例如 Cheat Engine 脚本）修改，本工具不会覆盖它。请先关闭相关脚本或重启游戏再试。",
    ],
    [
      /HOOK_RESTORE_UNVERIFIED|HOOK_NOT_RESTORED|could not be read or restored|temporary override at 0x[0-9a-f]+ was not removed/i,
      "无法确认临时修改已经撤销。为安全起见，请直接退出游戏；重启游戏后临时修改会自然消失。",
    ],
    [/SESSION_NOT_OPEN|override session is not open/i, "临时修改已经停止。"],
    [
      /stop the existing override and wait for pending native calls/i,
      "上一次的临时修改还在生效，或游戏里还有调用没完成。请先点“停止临时修改”，稍等片刻再试。",
    ],
    [/no running process matches Nioh3\.exe/i, "没有检测到正在运行的仁王3。请先启动游戏并读档进入角色。"],
    [/character layout: no character is loaded/i, "游戏里还没有读档进入角色。请读档后再试。"],
    [
      /character layout: (?:the player object's vtable does not match|the equipment container does not sit)/i,
      "当前游戏版本的角色数据位置与本工具不一致，已停止读取，游戏没有被改动。",
    ],
    [
      /the character changed during the read|the game changed a value since it was read|equipment changed in game since it was read/i,
      "游戏里的数值刚好在变化（例如正在拾取物品）。请在游戏里停下来后重新读取，再修改。",
    ],
    [/the game process changed since the character was read/i, "游戏已经重启过。请重新读取角色后再修改。"],
    [/a written value did not read back as written/i, "写入后核对不一致，结果不确定。请重新读取角色核对当前数值。"],
    [/Finish the live scroll addition before editing the character/i, "实时添加绘卷还没结束，请等它完成后再修改角色。"],
    [/Save changed; refresh inventory/i, "游戏刚刚存过档。请点“重新读取”后再核对修改。"],
    [/Save changed (?:since it was read|while reading the character)/i,"存档文件刚刚发生了变化（可能是游戏存了档）。请重新读取后再修改。"],
    [/Only occupied equipment slots may be edited/i, "这个装备格是空的，不能修改。"],
    [/Unequip the item in game before removing it|an equipped item cannot be removed/i, "这件装备正在装备中，请先在游戏里卸下再移除。"],
    [/(?:^|:\s*)Nothing to change$/i, "没有需要修改的内容。"],
    [
      /has not initialized its player identity yet/i,
      "游戏还没有加载好角色。请进入角色存档、能自由行动后再试。",
    ],
    [
      /COUNT_INSTANCE_UNAVAILABLE|is no longer in the current inventory/i,
      "这张绘卷已不在当前背包里（可能已被使用或丢弃）。请重新读取后再试。",
    ],
    [
      /COUNT_SOURCE_CHANGED|COUNT_INSTANCE_CHANGED/,
      "游戏里的绘卷状态已经变化。请重新读取后再试。",
    ],
    [
      /manifest does not declare the v2 schema/i,
      "这是旧版本工具创建的备份，缺少身份清单，不能自动恢复。当前存档没有被修改。",
    ],
    [
      /manifest save-layout profile differs from this build/i,
      "这个备份的存档结构版本与当前程序不一致，不能恢复。当前存档没有被修改。",
    ],
    [
      /restore bundle is missing role|restore bundle must declare exactly three roles|is missing or is not a regular file/i,
      "备份文件不完整（缺少文件），不能恢复。当前存档没有被修改。",
    ],
    [
      /has an invalid SHA-256|manifest operation id is not 32 lowercase|is declared more than once|unknown restore role/i,
      "备份清单格式无效，不能恢复。当前存档没有被修改。",
    ],
    [
      /selected restore bundle changed after preparation/i,
      "所选备份在准备恢复后又发生了变化，已停止恢复。请重新选择备份。",
    ],
    [
      /escapes the managed backups root|is a link to another location|backup path .* is unsafe or aliased/i,
      "拒绝操作不在本工具备份目录里的备份。",
    ],
    [/recycle-bin move was cancelled/i, "已取消删除备份。"],
    [
      /Windows refused the recycle-bin move/i,
      "Windows 拒绝把备份移入回收站，备份没有被删除。",
    ],
    [
      /WORKER_TIMEOUT|WORKER_PIPE_CLOSED|OFFLINE_WORKER_CLOSED|RUST_(?:PROTECTED_)?WORKER_MISSING/,
      "后台组件没有响应或意外退出。如果刚才在写入，请先核对结果再重试；请重启本工具，反复出现请导出反馈文件发给开发者。",
    ],
    [
      /UPDATE_(?:HASH_MISMATCH|SIGNATURE_INVALID|ARCHIVE_INVALID|MANIFEST_INVALID|ASSET_INVALID|ASSET_ORIGIN_INVALID|KEY_INVALID|TOO_LARGE|RESPONSE_TOO_LARGE|TOO_MANY_FILES)/,
      "更新文件没有通过校验，已停止更新，当前版本不受影响。请稍后重试，或到 GitHub 手动下载新版本。",
    ],
    [
      /GAME_EXECUTABLE_NOT_FOUND/,
      "没有找到《仁王3》的游戏程序，无法确认版本。请点“选择游戏程序”，或在设置中手动选择 Nioh3.exe。",
    ],
    [
      /GAME_EXECUTABLE_AMBIGUOUS/,
      "找到了多个《仁王3》游戏程序。请在设置中选择要使用的 Nioh3.exe，重新打开工作室后生效。",
    ],
    [
      /GAME_EXECUTABLE_UNREADABLE|GAME_VERSION_(?:UNREADABLE|MALFORMED)|FILE_VERSION_UNREADABLE/,
      "无法读取《仁王3》游戏程序的版本信息。请在设置中重新选择实际的 Nioh3.exe，并确认文件完整。",
    ],
    [/GAME_EXECUTABLE_SELECTION_INVALID|GAME_INSTALL_CONFIG_INVALID/,"游戏程序路径记录无效，请在设置中重新选择实际的 Nioh3.exe。"],
    [/GAME_VERSION_UNSUPPORTED/,"当前游戏版本尚未支持，请检查更新。"],
    [/COMPATIBILITY_CONFIRMATION_REQUIRED/,"检测到旧版本或不同的游戏程序，请核对兼容提示和存档备份后继续。"],
    [/COMPATIBILITY_PLAN_EXPIRED|COMPATIBILITY_PLAN_MISMATCH/,"兼容计划已失效。请重新准备并验证备份，再核对新计划。"],
    [/COMPATIBILITY_BACKUP_REQUIRED|COMPATIBILITY_BACKUP_UNVERIFIED/,"存档备份尚未通过验证，无法确认兼容计划。请查看兼容提示，解决备份问题后重试。"],
    [/COMPATIBILITY_AUDIT_FAILED/,"兼容确认记录未能安全保存，尚未获得继续权限。请查看兼容提示并重新准备。"],
    [/COMPATIBILITY_RESOURCE_CONTEXT_CHANGED/,"当前游戏版本与工作室已加载的数据不一致。请在下方选择当前运行的 Nioh3.exe，再重新打开工作室并准备计划。游戏无需关闭。"],
    [/COMPATIBILITY_FEATURE_UNSUPPORTED/,"当前版本的兼容计划不支持这项操作。请查看兼容提示中的功能范围，或在设置中选择受支持版本。"],
    [/not the digest this surface pins|EXECUTABLE_DIGEST_MISMATCH/,"这份游戏程序与已验证版本不同。请查看兼容提示，核对存档备份后再继续实时操作。"],
    [
      /no contiguous run of \d+ free scroll slots|All 400 scroll slots/i,
      "存档里没有足够的空绘卷栏位（最多 400 张），本次没有写入。请先在游戏里处理掉一些绘卷再添加。",
    ],
    [
      /slot \d+ is occupied|is not fully zeroed, so it cannot receive/i,
      "目标绘卷栏位已被占用（存档可能刚被游戏修改），已拒绝写入。请点“重新读取”后再试。",
    ],
    [
      /no unused .+ remains in this save/i,
      "这个存档里可分配给新绘卷的编号已经用尽，无法再添加，存档没有被修改。",
    ],
    [
      /changed after the operation was prepared/i,
      "生成计划之后游戏又写入了存档（游戏可能没有停在标题界面），本次没有写入，存档没有改动。请让游戏回到标题界面后点“重新读取”，再重新生成计划。",
    ],
    [
      /no authentic scroll template is available/i,
      "存档里没有可作为模板的同周目绘卷（至少需要一张现有绘卷），本次没有写入。",
    ],
    [
      /has no numeric Steam account directory|is not a SAVEDATA\?\? directory entry|is not a readable save root directory/i,
      "无法从这个路径识别存档。请用“手动定位”选择 Savedata\\<数字账号>\\SAVEDATAxx\\SAVEDATA.BIN。",
    ],
    [
      /not a shipped container size|must (?:start with|decrypt to a buffer starting with) RNNUSR|save is too small for the fixed inventory region/i,
      "这个文件不是《仁王3》的角色存档，或者存档版本不受支持。存档没有被修改。",
    ],
    [
      /backup account \d+ slot \d+|does not match the save path account/i,
      "这个备份属于其他账号或其他存档栏位，不能恢复到当前存档。",
    ],
    [
      /digest mismatch: expected/i,
      "备份文件校验失败（文件可能被改动或损坏），已停止恢复，当前存档没有被修改。",
    ],
    [
      /commit finished in an unprovable state/i,
      "写入结果无法确认。请先核对存档和操作记录，不要重复添加。",
    ],
    [
      /exactly one .+ must be running, but \d+ were found|AMBIGUOUS_PROCESS/,
      "检测到同时运行了多个《仁王3》，请只保留一个再试。",
    ],
    [
      /(?:OpenProcess\(\d+\)|CreateToolhelp32Snapshot\(modules, \d+\)) failed with error 5\b/,
      "系统拒绝访问游戏进程，可能是游戏与工具的权限级别不同。如果游戏以管理员身份运行，请以管理员身份重新启动本工具；也可以关闭游戏的“以管理员身份运行”设置，再重新启动游戏和本工具，然后重试读取。",
    ],
    [
      /module .+ was not found in process/i,
      "游戏还没有完全启动，请进入角色存档后再试。",
    ],
    [
      /GAME_RUNNING|GAME_STATE_UNKNOWN/,
      "请让游戏回到标题界面后重试写入存档。本次没有修改存档。",
    ],
    [/Stop temporary overrides before editing remaining count/, "请先停止临时修改，再核对当前次数。"],
    [/Current scroll state is not supported for count editing/, "这张绘卷的当前状态暂不支持修改次数。"],
    [/FAVORITES_CAPACITY_REACHED/, "收藏夹最多保存 50 张绘卷。"],
    [/CART_CAPACITY_REACHED/, "购物车最多保存 50 张绘卷。"],
    [
      /Possessed is available only for eligible low-pool enemy variants/i,
      "这个敌人没有地狱附身变体，请关闭开关或选择标有“可附身”的低手敌人。",
    ],
    [
      /INVALID_REQUEST:\s*search\.start/i,
      "筛选条件无法提交。请更新应用；若仍出现，请导出反馈文件发给开发者。",
    ],
    [
      /Saved defined record fields differ|Saved inventory serial set differs/i,
      "存档与当前绘卷状态不一致。请先在神社保存，关闭菜单后重新核对添加。",
    ],
    [
      /context has changed|context.*differs|identity does not match|CART_REFERENCE_EXPIRED/i,
      "候选已失效，请按原 ID 重新搜索后添加。",
    ],
    [
      /No.*Nioh3|not.*running|process.*not found/i,
      "请先启动游戏并进入角色存档。",
    ],
    [
      /Pickup queue|not idle|scheduler|menu/i,
      "请关闭游戏菜单，原地等待片刻后重新核对。",
    ],
    [
      /backup.*(missing|changed|invalid|corrupt)|Backup.*(differ|match)/i,
      "自动备份无法通过校验，本次没有继续添加。请重新核对添加。",
    ],
    [
      STALE_SNAPSHOT,
      "存档在游戏里保存后已经变化，请点“重新读取”后再添加。",
    ],
    [
      /Foreign native receipt/,
      "实时添加的状态目录里有不属于本工具操作的回执文件，添加已停止，游戏没有被改动。请导出反馈文件发给开发者。",
    ],
    [
      /No accepted idle dispatch before timeout/,
      "游戏没有及时响应添加请求，这次没有添加任何东西。请确认已经读档进入游戏（不是标题界面或读盘画面），然后重试。",
    ],
    [
      /was rejected after dispatch|Native builder output differs|Native assembly differs/i,
      "游戏生成的绘卷与预期不一致，这次没有添加，背包和存档都没有改动，可以直接重试。若反复出现，请导出反馈文件发给开发者。",
    ],
    [
      /QueryFullProcessImageNameW|PROCESS_INSTANCE_CHANGED|PROCESS_GONE|replaced by a different process instance|is no longer running/i,
      "游戏已退出或重新启动。请进入角色存档后重新核对添加。",
    ],
    [
      LIVE_ADD_LOCK,
      "实时添加被上一次没有正常结束的操作锁住了（例如添加时程序被强制关闭）。请点下面的“重置实时添加状态”，然后重新操作一次。",
    ],
    [
      /uncertain|unresolved|already submitted/i,
      "上次操作尚未确认，请先核对结果，不要重复添加。",
    ],
    [
      /APPEND_ONLY_REPAIR_REQUIRED|duplicate serials/i,
      "这个存档里已有绘卷的序列号重复，为避免改动已有绘卷，“添加到存档”已停止，存档没有被修改。请改用“游戏内实时添加”。",
    ],
    [/BUSY|occupied/i, "另一项操作仍在进行，请等待完成。"],
    [/INVALID_SCROLL_ID/, "这个绘卷 ID 不是游戏能生成的：ID 的低 4 位十六进制不能全为 0，也不能大于 0x0FFFFFFF。"],
    [
      /not a verified supported version|not approved for product use|requires verified|requires accepted|profile changed|UNSUPPORTED_GAME_VERSION|GAME_EXECUTABLE_UNSUPPORTED|PROFILE_NOT_APPROVED|PROFILE_INTEGRITY|PROFILE_UNRESOLVED|SIGNATURE_MISMATCH|unsupported Nioh 3 executable version/i,
      "当前游戏版本尚未支持，请检查更新。",
    ],
    [
      /FAVORITE.*INVALID|Unexpected token.*JSON/,
      "收藏夹文件无法读取，原文件已保留。请导出反馈文件发给开发者。",
    ],
    // Broader groups, after every specific explanation above: refusals the
    // player clears with one step of their own, grouped by that step. Every
    // other backend failure falls through to the generic advice below, so
    // none of them is ever shown as raw English or JSON alone.
    [
      /Save changed after preparation|Save changed while reading inventory|Batch source save changed|Plan expired|Unknown save ID/i,
      "存档刚被游戏改写，或这次的计划已经过期。请点“重新读取”，然后重新核对。",
    ],
    [
      /changed in game since it was read|changed during capture|changed between batch items|index changed during preview|Preview changed inventory|Inventory owner changed|Batch process context changed|Batch disk checkpoint changed|retry at rest/i,
      "游戏里的背包刚好在变化（例如正在拾取、使用或整理物品）。请在游戏里停下来、关闭菜单，然后重新核对。",
    ],
    [
      /Insufficient scroll capacity/i,
      "游戏里的绘卷背包没有足够的空位。请先在游戏里出售或丢弃一些绘卷，再重新核对。",
    ],
    [
      /Inventory data is not loaded|Item manager is not loaded|Unexpected inventory owner/i,
      "游戏还没有加载好角色。请进入角色存档、能自由行动后再试。",
    ],
    [
      /(?:Live addition|Count editing) is not accepted for this game version|Equipment (?:rules|generation) (?:are|is) unavailable for this game version|PC v2\.01 is required|validated only for PC v2\.01|UNSUPPORTED_CONTEXT|RESOURCE_MISMATCH/,
      "当前游戏版本尚未支持，请检查更新。",
    ],
    [
      /This item cannot be generated: it is not equipment/,
      "这件物品不是装备，不能按游戏规则生成。请在列表里换一件武器、防具、饰品或魂核。",
    ],
    [
      /This item cannot be generated at this rarity|The difficulty must be 1 to 5/,
      "稀有度请填 0–5，难度请在下拉框里选择，然后重新查找。",
    ],
    [
      /The save's difficulty and progress could not be read/,
      "没有从存档里读到难度和进度，不能按游戏规则生成。请点“重新读取”后再试；仍然不行的话，可以改用“魔改”添加。",
    ],
    [
      /The character has not played this difficulty/,
      "这个角色还没有玩过所选难度，这个难度的掉落不算自然。请换一个难度后重新查找。",
    ],
    [
      /A hell weapon cannot be generated from a seed/,
      "地狱武器不能按种子生成。请取消“地狱武器”，或改用“魔改”添加。",
    ],
    [
      /This seed gives the item no effects/,
      "这个种子在当前生成路线下未生成有效装备。请重新查找并选择其他结果。",
    ],
    [
      /Ask for at most seven effects/,
      "想要的词条最多 7 个。请去掉一些后重新查找。",
    ],
    [
      /requires an idle runtime host|Resolve existing runtime ownership|CLOSING: protected host|wait for its commit outcome/i,
      "上一项游戏内操作还没有结束。请等它完成后再试；一直这样的话，请完全关闭本程序后重新打开。",
    ],
    [
      /Native candidate expired|regenerate before installation|Materialize and finalize the candidate|CANDIDATE_NOT_INSTALLABLE|Candidate record length is invalid/i,
      "这个候选已经失效。请重新搜索或重新生成后再添加。",
    ],
    [
      /Previous batch item has not been verified/i,
      "上次操作尚未确认，请先核对结果，不要重复添加。",
    ],
    [
      /Backup does not belong to the selected save|Select backups belonging to this save/i,
      "选中的备份不属于当前存档。请先在上面选对存档，再选择它的备份。",
    ],
    [/Select a character SAVEDATA\.BIN/i, "请选择角色存档文件 SAVEDATA.BIN。"],
    [
      /os error 32\b|being used by another process/i,
      "文件正被其他程序占用（例如游戏正在存档，或云同步、杀毒软件正在读取）。请稍等片刻再试。",
    ],
    [
      /os error 5\b|Access is denied/i,
      "没有权限读写这个文件。请检查杀毒软件是否拦截了本程序，或文件夹是否设为只读。",
    ],
    [/os error 112\b|not enough space on the disk/i, "磁盘空间不足。请清理磁盘后再试。"],
    [/os error 2\b|No such file or directory/i, "找不到需要的文件。请点“重新检测”或重新选择存档后再试。"],
    [
      /WORKER_BACKEND_|WORKER_UNAVAILABLE|HANDSHAKE_REQUIRED|CONTRACT_MISMATCH/,
      "程序的后台组件没有正常启动。请完全关闭本程序后重新打开；仍不行请重新下载安装。",
    ],
    [
      /UPDATE_[A-Z_]+/,
      "更新没有完成，当前版本不受影响。请稍后再试，或到 GitHub 下载最新版本。",
    ],
  ];
  for (const [pattern, text] of cases) if (pattern.test(message)) return text;
  if (
    (/^Error(?: invoking remote method|:)/.test(message) ||
      /^[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+(?::|$)/.test(message) ||
      // A structured `{ code, message }` failure serialized for display.
      /^\{\s*"code"\s*:\s*"[A-Z][A-Z0-9_]*"/.test(message)) &&
    !/[\u3400-\u9fff]/.test(message)
  ) {
    const code = message.match(/\b[A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+\b/)?.[0];
    return `操作没有完成。${code ? `错误代码：${code}。` : ""}${FAILURE_ADVICE}`;
  }
  return message;
}

/** The next step every unexplained failure ends with. */
export const FAILURE_ADVICE =
  "涉及写入时，请先核对结果再重试；反复出现请导出反馈文件发给开发者。";

/**
 * A non-empty display text for any rejection value.
 *
 * Tauri commands reject with plain strings and the diagnostic invoker rethrows
 * them unchanged, so `(error as Error).message` is `undefined` for most
 * backend failures and a status line would silently go blank. Structured
 * `{ code, message }` payloads keep their code.
 */
export function errorText(
  error: unknown,
  fallback = "操作没有完成，也没有返回原因；请导出反馈文件发给开发者。",
): string {
  if (error instanceof Error && error.message.trim()) return error.message;
  if (typeof error === "string" && error.trim()) return error;
  if (error !== null && typeof error === "object") {
    const value = error as Record<string, unknown>;
    if (typeof value.message === "string" && value.message.trim())
      return typeof value.code === "string" && value.code.trim()
        ? `${value.code}: ${value.message}`
        : value.message;
    try {
      const text = JSON.stringify(error);
      if (text && text !== "{}") return text;
    } catch {
      // Fall through to the fallback below.
    }
  }
  return fallback;
}
