# Review and integration guide

## Feature slice

The planner offers named persistent local drafts with independent Samurai/Ninja
configurations; saved inventory, favorites and equipment-code selection; read-only
equipment inspection; attributes; guardians; individual clan effect choices; two
soul cores; skills; ordinary/special effect summaries and set/grace tiers.

The domains calculate weight/capacity, agility/toughness, armor requirements and
supported remodel simulation, plus bounded ordinary maximum Life/Ki.
Using one inventory identity in multiple active equipment slots is rejected.
Zero-plus armor cannot select remodel modes. Modifier calculation and display
share reviewed native IDs, units, grade merging and float32/truncation contracts.

Start implementation review at apps/workshop/LoadoutPlanner.tsx. Follow the
loadout-*.ts domains and their apps/desktop/tests/loadout-*.test.ts contracts.
Rust save projection is additive in crates/nioh3-save/src/loadout.rs and the
protected save handler; JSON/TypeScript response schemas preserve this boundary.

## Deliberate product boundaries

- New UI text is maintained in Chinese; English/Japanese fallback is intentional.
- Guardian ownership and skill/clan unlocking are not imposed by this planner.
  Guardian level is limited to 1..50.
- Save import skips guardian selection/ownership and clan-rank cache fields.
- Additional saved records stay internal and do not contribute to active totals.
- Selected skill effects are excluded from ordinary/special totals by owner choice.
- Attack/defense calculation is outside scope.
- Life/Ki estimates exclude unrepresented fixed player rewards, level sync and
  temporary encounter/context multipliers. Unknown relevant inputs remain bounded.
- Native table/formula coverage is not universal gameplay obtainability or
  live-game acceptance. Rarity-5 armor and exceptional toughness branches retain
  their stated evidence limits.

Knowledge contracts: LOADOUT_STATS.md, LOADOUT_ARMOR_REQUIREMENTS.md,
LOADOUT_RESOURCES.md and LOADOUT_PERSISTENCE.md under docs/knowledge/.
The current product decision and later corrected Stamina/clan semantics supersede
historical open-backlog statements or earlier Strength/Kato wording in old reports.

## Research reading map

- Guardian: native catalog, semantics and native_validation.json in the included
  guardian-spirit-catalog directory; original rows, growth and bounded code proofs.
- Clans: clan_protections_native.json, readable table, validation and accepted
  native-extraction sources. Each row chooses one of two clan effects.
- Skills: skills_native.json and validation; category/subtype/hidden-menu filters,
  149 definitions, separate budgets. Definitions do not infer unlock state.
- Sets/effect formatting: product export tools, accepted discovery-02 set/weapon
  payloads, complete native Chinese text and four verified code windows.
- Armor: public armor_remodel_v202 model, coefficients and 1,352 native returns.
- Capacity/ranks/stage: accepted October 8 capacity inputs and bounded evidence
  directories for state getters, rank predicates and the difficulty-stage mapping.
- Life/Ki: corrected base reference, Stamina reflection and modifier analysis,
  shared NativeBonusCurve, native rows and positive/negative controls.

source-map.json gives the exact regeneration paths. tables/ is a readable
projection, never a replacement source for native identities or formulas.

## Upstream work remaining

Integrate against current main in a separate checkout. The recorded upstream
comparison lists ten overlapping paths including main.tsx, locales, protected save
handler, contracts and shared product documentation. These are overlapping edits,
not a claim that ten textual conflicts have already been reproduced.

Port feature wiring deliberately; do not overwrite the new upstream entry point,
contracts, locale catalogs, global handoff or release records with the old copies.
Regenerate merged contracts/locales and rerun relevant source, save-host and UI
gates. Keep the existing save/protected-operation and generation behavior intact.
A full snapshot is supplied so dependencies are available; a PR should contain
only the feature changes, necessary research inputs/tools and concise documentation.

Related existing open research contributions at inspection:
- https://github.com/Master-Bayesian/Nioh3-Scroll-Generator/pull/38
- https://github.com/Master-Bayesian/Nioh3-Scroll-Generator/pull/39
- https://github.com/Master-Bayesian/Nioh3-Scroll-Generator/pull/40

Do not assume those PRs are already merged. Their full commit histories are not
duplicated here; the required armor model/public evidence is included.

## Acceptance records

evidence/isolated-replay/reproduction.json records ten exact data matches,
three original catalog builds, two independent catalog validators, all product
projections, declared Python versions and the strict file-open boundary.
evidence/isolated-source-tests/ records the clean-install typecheck and 125 tests.
Earlier browser evidence is version-scoped and includes the latest 29 card checks.

Current collection performs no new game/save access and no EXE build.
Upstream integration, a new PR and any later native/player acceptance remain
separate work. This package is ready for source/research review, not a release.
